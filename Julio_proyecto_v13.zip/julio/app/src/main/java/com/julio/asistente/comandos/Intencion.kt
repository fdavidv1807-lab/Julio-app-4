package com.julio.asistente.comandos

import com.julio.asistente.horario.Recurrencia
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

/** Lo que el usuario quiere hacer, ya separado del texto, de la pantalla y de la base de datos. */
sealed class Intencion {
    data class AgregarHorario(
        val titulo: String?, val fecha: LocalDate?, val hora: LocalTime?, val recurrencia: Recurrencia,
    ) : Intencion()
    data class ConsultarHorario(val fecha: LocalDate) : Intencion()
    data class AgregarTarea(val titulo: String?) : Intencion()
    object ConsultarTareas : Intencion()
    data class CompletarTarea(val referencia: String) : Intencion()
    data class CrearAlarma(val hora: LocalTime?, val fecha: LocalDate?, val dias: Int, val enMinutos: Long?) : Intencion()
    data class CambiarAlarma(val activar: Boolean, val hora: LocalTime?, val dia: DayOfWeek?) : Intencion()
    object ConsultarAlarmas : Intencion()
    data class IniciarEnfoque(val minutos: Int?) : Intencion()
    data class IniciarDescanso(val minutos: Int?) : Intencion()
    data class ConfigurarDescanso(val minutos: Int) : Intencion()
    object PausarEnfoque : Intencion()
    object ReanudarEnfoque : Intencion()
    object FinalizarEnfoque : Intencion()
    object EstadoEnfoque : Intencion()
    object ConsultarMetas : Intencion()
    data class CrearMeta(val titulo: String?) : Intencion()
    data class ActualizarMeta(val referencia: String?, val porcentaje: Int?) : Intencion()
    /** «Agrega X» sin fecha ni hora: ¿actividad del horario o tarea pendiente? */
    data class Ambigua(val texto: String) : Intencion()
    object Desconocida : Intencion()
}
