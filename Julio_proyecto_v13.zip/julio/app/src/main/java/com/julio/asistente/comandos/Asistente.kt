package com.julio.asistente.comandos

import android.app.Application
import com.julio.asistente.alarmas.AlarmaProgramador
import com.julio.asistente.alarmas.CalculoAlarma
import com.julio.asistente.core.Fechas
import com.julio.asistente.core.Permisos
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.data.local.MetaEntity
import com.julio.asistente.data.local.TareaEntity
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.enfoque.Fase
import com.julio.asistente.horario.Ocurrencias
import com.julio.asistente.horario.Recurrencia
import com.julio.asistente.recordatorios.RecordatorioProgramador
import com.julio.asistente.recordatorios.textoAntelacion
import kotlinx.coroutines.flow.first
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.TextStyle
import java.util.Locale

/**
 * Entiende una frase, la ejecuta contra los datos reales y responde.
 * Regla de oro: solo dice que algo se hizo después de comprobarlo en la base de datos o en el sistema.
 */
class Asistente(private val app: Application) {

    private val db = JulioDatabase.get(app)
    private var esperando: Esperando? = null

    suspend fun procesar(texto: String): String {
        val hoy = LocalDate.now()
        val ahora = LocalTime.now()
        val previo = esperando
        esperando = null

        if (previo != null) {
            val n = Texto.normalizar(texto)
            if (Regex("\\b(cancela|cancelar|olvidalo|olvida|dejalo|nada|no importa|ya no)\\b").containsMatchIn(n)) {
                return "De acuerdo, lo dejé así. No hice ningún cambio."
            }
            return continuar(previo, texto, hoy, ahora)
        }
        return ejecutar(Interprete.interpretar(texto, hoy, ahora))
    }

    // ---------- Respuestas a preguntas de Julio ----------

    private suspend fun continuar(previo: Esperando, texto: String, hoy: LocalDate, ahora: LocalTime): String {
        val n = Texto.numeros(Texto.normalizar(texto))
        return when (previo) {
            is Esperando.TituloTarea -> ejecutar(Intencion.AgregarTarea(tituloLibre(n, texto)))
            is Esperando.TituloMeta -> ejecutar(Intencion.CrearMeta(tituloLibre(n, texto)))
            is Esperando.TipoEntrada -> {
                val nOrig = Texto.numeros(Texto.normalizar(previo.texto))
                val titulo = Interprete.limpiar(
                    nOrig,
                    listOf("\\b(agrega|agregar|anade|anadir|crea|crear|apunta|apuntar|anota|anotar|programa|programar|agenda|agendar|pon|poner|registra|registrar|recuerdame)\\b"),
                )
                val tituloFinal = if (titulo.isBlank()) null else Texto.capitalizar(Texto.restaurar(titulo, previo.texto))
                if (Regex("\\b(tarea|tareas|pendiente|pendientes)\\b").containsMatchIn(n)) {
                    ejecutar(Intencion.AgregarTarea(tituloFinal))
                } else if (Regex("\\b(actividad|horario|agenda|programad|clase|cita|evento)").containsMatchIn(n)) {
                    ejecutar(Intencion.AgregarHorario(tituloFinal, null, null, Recurrencia.NINGUNA))
                } else {
                    esperando = previo
                    "No te entendí. Dime «tarea» si es un pendiente, o «actividad» si va en el horario con fecha y hora."
                }
            }
            is Esperando.DatosActividad -> {
                val h = Texto.extraerHora(n, ahora, false)
                val f = Texto.extraerFecha(h.resto, hoy)
                if (h.hora == null && f.fecha == null && previo.titulo != null) {
                    esperando = previo
                    "No entendí la fecha ni la hora. Dime por ejemplo «mañana a las ocho de la mañana»."
                } else {
                    val titulo = previo.titulo ?: tituloLibre(f.resto, texto)
                    ejecutar(Intencion.AgregarHorario(titulo, f.fecha ?: previo.fecha, h.hora ?: previo.hora, previo.recurrencia))
                }
            }
            is Esperando.DatosAlarma -> {
                val h = Texto.extraerHora(n, ahora, true)
                val f = Texto.extraerFecha(h.resto, hoy)
                if (h.hora == null && f.fecha == null) {
                    esperando = previo
                    "No entendí la hora. Dime por ejemplo «a las seis y media de la mañana»."
                } else {
                    ejecutar(Intencion.CrearAlarma(h.hora ?: previo.hora, f.fecha ?: previo.fecha, previo.dias, h.enMinutos))
                }
            }
            is Esperando.MetaParaProgreso -> {
                val ref = Interprete.limpiar(n, listOf("\\b(la|el|meta|de|mi)\\b"))
                ejecutar(Intencion.ActualizarMeta(ref.ifBlank { null }, previo.porcentaje))
            }
            is Esperando.PorcentajeMeta -> {
                val p = Regex("(\\d{1,3})").find(n)?.groupValues?.get(1)?.toIntOrNull()
                if (p == null || p !in 0..100) {
                    esperando = previo
                    "Dime un porcentaje entre 0 y 100."
                } else {
                    actualizarMetaPorId(previo.metaId, p)
                }
            }
        }
    }

    private fun tituloLibre(n: String, original: String): String? {
        val t = Interprete.limpiar(n, emptyList())
        return if (t.isBlank()) null else Texto.capitalizar(Texto.restaurar(t, original))
    }

    // ---------- Ejecución ----------

    private suspend fun ejecutar(i: Intencion): String = when (i) {
        is Intencion.AgregarHorario -> agregarHorario(i)
        is Intencion.ConsultarHorario -> consultarHorario(i.fecha)
        is Intencion.AgregarTarea -> agregarTarea(i.titulo)
        is Intencion.ConsultarTareas -> consultarTareas()
        is Intencion.CompletarTarea -> completarTarea(i.referencia)
        is Intencion.CrearAlarma -> crearAlarma(i)
        is Intencion.CambiarAlarma -> cambiarAlarma(i)
        is Intencion.ConsultarAlarmas -> consultarAlarmas()
        is Intencion.IniciarEnfoque -> iniciarSesion(Fase.ENFOQUE, i.minutos)
        is Intencion.IniciarDescanso -> iniciarSesion(Fase.DESCANSO, i.minutos)
        is Intencion.ConfigurarDescanso -> configurarDescanso(i.minutos)
        is Intencion.PausarEnfoque -> pausar()
        is Intencion.ReanudarEnfoque -> reanudar()
        is Intencion.FinalizarEnfoque -> finalizar()
        is Intencion.EstadoEnfoque -> estadoEnfoque()
        is Intencion.ConsultarMetas -> consultarMetas()
        is Intencion.CrearMeta -> crearMeta(i.titulo)
        is Intencion.ActualizarMeta -> actualizarMeta(i)
        is Intencion.Ambigua -> {
            esperando = Esperando.TipoEntrada(i.texto)
            "¿Lo agrego como una actividad con fecha y hora en tu Horario, o como una tarea pendiente?"
        }
        is Intencion.Desconocida ->
            "No lo entendí como una orden. Puedo ayudarte con tu horario, tus tareas, alarmas, modo enfoque y metas; " +
                "abajo tienes ejemplos de lo que puedes decirme. Conversar sobre otros temas necesita conectar " +
                "una inteligencia artificial externa, y eso todavía no está activado."
    }

    // ----- Horario -----

    private suspend fun agregarHorario(i: Intencion.AgregarHorario): String {
        val titulo = i.titulo
        if (titulo.isNullOrBlank()) {
            esperando = Esperando.DatosActividad(null, i.fecha, i.hora, i.recurrencia)
            return "¿Cómo se llama la actividad?"
        }
        val hoy = LocalDate.now()
        var fecha = i.fecha
        if (fecha == null && i.recurrencia == Recurrencia.DIARIA) fecha = hoy
        val hora = i.hora
        if (hora == null && fecha == null) {
            esperando = Esperando.DatosActividad(titulo, null, null, i.recurrencia)
            return "¿Para qué fecha y a qué hora programo «$titulo»?"
        }
        if (hora == null) {
            esperando = Esperando.DatosActividad(titulo, fecha, null, i.recurrencia)
            return "¿A qué hora es «$titulo»?"
        }
        if (fecha == null) {
            esperando = Esperando.DatosActividad(titulo, null, hora, i.recurrencia)
            return "¿Para qué día programo «$titulo» a las ${Fechas.textoHora(hora)}?"
        }
        val zona = ZoneId.systemDefault()
        val inicio = LocalDateTime.of(fecha, hora).atZone(zona)
        if (i.recurrencia == Recurrencia.NINGUNA && inicio.isBefore(ZonedDateTime.now())) {
            esperando = Esperando.DatosActividad(titulo, null, hora, i.recurrencia)
            return "Esa fecha y hora ya pasaron. ¿Para qué día programo «$titulo»?"
        }
        val dao = db.actividadDao()
        val id = dao.insertar(
            ActividadEntity(titulo = titulo, inicio = inicio.toInstant().toEpochMilli(), recurrencia = i.recurrencia.name),
        )
        val guardada = dao.porId(id) ?: return "No pude guardar la actividad. No la agregué; inténtalo de nuevo."
        val repite = if (i.recurrencia != Recurrencia.NINGUNA) " (${i.recurrencia.etiqueta.lowercase()})" else ""
        return "Listo. Agregué «${guardada.titulo}» al horario: ${Fechas.textoLargo(fecha)} a las ${Fechas.textoHora(hora)}$repite."
    }

    private suspend fun consultarHorario(fecha: LocalDate): String {
        val actividades = db.actividadDao().observarTodas().first()
        val lista = Ocurrencias.entre(actividades, fecha, fecha)
        val dia = if (fecha == LocalDate.now()) "hoy" else "el ${Fechas.textoLargo(fecha).lowercase()}"
        if (lista.isEmpty()) return "No tienes actividades programadas $dia."
        val texto = lista.take(8).joinToString("; ") {
            val horas = it.horaFin?.let { f -> "${Fechas.textoHora(it.horaInicio)} a ${Fechas.textoHora(f)}" }
                ?: Fechas.textoHora(it.horaInicio)
            "$horas, ${it.actividad.titulo}"
        }
        val extra = if (lista.size > 8) " Y ${lista.size - 8} más en la pantalla Horario." else ""
        return "Para $dia tienes ${lista.size}: $texto.$extra"
    }

    // ----- Tareas -----

    private suspend fun agregarTarea(titulo: String?): String {
        if (titulo.isNullOrBlank()) {
            esperando = Esperando.TituloTarea
            return "¿Qué tarea quieres agregar?"
        }
        val dao = db.tareaDao()
        val id = dao.insertar(TareaEntity(titulo = titulo))
        val guardada = dao.porId(id) ?: return "No pude guardar la tarea. No la agregué; inténtalo de nuevo."
        return "Listo. Agregué «${guardada.titulo}» a tus tareas pendientes."
    }

    private suspend fun consultarTareas(): String {
        val pendientes = db.tareaDao().observarTodas().first().filter { !it.completada }
        if (pendientes.isEmpty()) return "No tienes tareas pendientes."
        val nombres = pendientes.take(8).joinToString(", ") { it.titulo }
        val extra = if (pendientes.size > 8) " Y ${pendientes.size - 8} más en la pantalla Tareas." else ""
        return "Tienes ${pendientes.size} tarea(s) pendiente(s): $nombres.$extra"
    }

    private fun coincide(titulo: String, referencia: String): Boolean {
        val t = Texto.normalizar(titulo)
        val palabras = Texto.normalizar(referencia).split(" ").filter { it.length >= 3 && it != "del" && it != "los" && it != "las" }
        return palabras.isNotEmpty() && palabras.all { t.contains(it) }
    }

    private suspend fun completarTarea(referencia: String): String {
        if (referencia.isBlank()) return "¿Cuál tarea quieres marcar como terminada? Dime su nombre."
        val dao = db.tareaDao()
        val candidatas = dao.observarTodas().first().filter { !it.completada && coincide(it.titulo, referencia) }
        if (candidatas.isEmpty()) return "No encontré una tarea pendiente que coincida con «$referencia»."
        if (candidatas.size > 1) {
            return "Encontré ${candidatas.size} tareas parecidas: ${candidatas.joinToString(", ") { it.titulo }}. " +
                "Repite la orden con el nombre más completo."
        }
        val t = candidatas[0]
        val nueva = t.copy(completada = true)
        dao.actualizar(nueva)
        RecordatorioProgramador.programarTarea(app, nueva)
        val verificada = dao.porId(t.id)
        return if (verificada?.completada == true) "Listo. Marqué «${t.titulo}» como terminada."
        else "No pude comprobar que «${t.titulo}» quedara terminada. Revisa la pantalla Tareas."
    }

    // ----- Alarmas -----

    private fun hora12(t: LocalTime) = Fechas.textoHora(t)

    private fun descAlarma(a: AlarmaEntity): String {
        val hora = hora12(LocalTime.of(a.hora, a.minuto))
        val repite = when {
            a.diasMascara == 0x7F -> "todos los días"
            a.diasMascara != 0 -> DayOfWeek.values()
                .filter { (a.diasMascara and CalculoAlarma.bit(it)) != 0 }
                .joinToString(", ") { it.getDisplayName(TextStyle.SHORT, Locale.getDefault()) }
            a.fechaEpochDay != null -> Fechas.textoLargo(LocalDate.ofEpochDay(a.fechaEpochDay))
            else -> ""
        }
        return if (repite.isBlank()) hora else "$hora ($repite)"
    }

    private suspend fun crearAlarma(i: Intencion.CrearAlarma): String {
        val ahora = ZonedDateTime.now()
        var hora = i.hora
        var fecha = i.fecha
        if (i.enMinutos != null) {
            val t = ahora.plusMinutes(i.enMinutos)
            hora = t.toLocalTime().withSecond(0).withNano(0)
            fecha = t.toLocalDate()
        }
        if (hora == null) {
            esperando = Esperando.DatosAlarma(null, i.fecha, i.dias)
            return "¿A qué hora quieres la alarma?"
        }
        var alarma = AlarmaEntity(
            hora = hora.hour, minuto = hora.minute,
            fechaEpochDay = if (i.dias == 0) fecha?.toEpochDay() else null,
            diasMascara = i.dias, activa = true,
        )
        if (i.dias == 0 && alarma.fechaEpochDay == null) {
            val proxima = CalculoAlarma.proxima(alarma, ahora)
            if (proxima != null) alarma = alarma.copy(fechaEpochDay = proxima.toLocalDate().toEpochDay())
        }
        if (CalculoAlarma.proxima(alarma, ahora) == null) {
            esperando = Esperando.DatosAlarma(hora, null, i.dias)
            return "Esa fecha y hora ya pasaron. ¿Para qué día pongo la alarma de ${hora12(hora)}?"
        }
        val dao = db.alarmaDao()
        val id = dao.insertar(alarma)
        val guardada = alarma.copy(id = id)
        val programada = AlarmaProgramador.programar(app, guardada)
        if (programada == null) {
            dao.actualizar(guardada.copy(activa = false))
            return "No pude programar la alarma en el sistema, así que quedó desactivada. " +
                (AlarmaProgramador.ultimoError ?: "Revisa los permisos en la pantalla Alarmas.")
        }
        val verificada = dao.porId(id)
        if (verificada == null || !verificada.activa) return "No pude comprobar que la alarma quedara guardada. Revisa la pantalla Alarmas."
        val aviso = if (!Permisos.notificaciones(app)) " Ojo: falta el permiso de notificaciones; actívalo en la pantalla Alarmas." else ""
        return "Listo. Alarma programada para el ${Fechas.textoLargo(programada.toLocalDate())} a las ${hora12(programada.toLocalTime())}.$aviso"
    }

    private fun coincideDia(a: AlarmaEntity, dia: DayOfWeek): Boolean =
        (a.diasMascara and CalculoAlarma.bit(dia)) != 0 ||
            a.fechaEpochDay?.let { LocalDate.ofEpochDay(it).dayOfWeek == dia } == true

    private suspend fun cambiarAlarma(i: Intencion.CambiarAlarma): String {
        val dao = db.alarmaDao()
        val hora = i.hora
        val dia = i.dia
        val candidatas = dao.observarTodas().first().filter { a ->
            a.activa != i.activar &&
                (hora == null || (a.hora == hora.hour && a.minuto == hora.minute)) &&
                (dia == null || coincideDia(a, dia))
        }
        val verbo = if (i.activar) "activar" else "desactivar"
        if (candidatas.isEmpty()) return "No encontré una alarma que se pueda $verbo con eso."
        if (candidatas.size > 1) {
            return "Hay ${candidatas.size} alarmas que coinciden: ${candidatas.joinToString("; ") { descAlarma(it) }}. " +
                "Dime la hora de la que quieres $verbo."
        }
        val a = candidatas[0]
        if (!i.activar) {
            dao.actualizar(a.copy(activa = false))
            AlarmaProgramador.cancelar(app, a.id)
            val v = dao.porId(a.id)
            return if (v != null && !v.activa) "Listo. Desactivé la alarma de ${descAlarma(a)}."
            else "No pude comprobar que la alarma quedara desactivada. Revisa la pantalla Alarmas."
        }
        var nueva = a.copy(activa = true)
        val ahora = ZonedDateTime.now()
        if (nueva.diasMascara == 0 && CalculoAlarma.proxima(nueva, ahora) == null) {
            val siguiente = CalculoAlarma.proxima(nueva.copy(fechaEpochDay = null), ahora)
            if (siguiente != null) nueva = nueva.copy(fechaEpochDay = siguiente.toLocalDate().toEpochDay())
        }
        val programada = AlarmaProgramador.programar(app, nueva)
        if (programada == null) {
            return "No pude activar la alarma en el sistema. " + (AlarmaProgramador.ultimoError ?: "Revisa los permisos en la pantalla Alarmas.")
        }
        dao.actualizar(nueva)
        val v = dao.porId(a.id)
        return if (v != null && v.activa) "Listo. Activé la alarma; sonará el ${Fechas.textoLargo(programada.toLocalDate())} a las ${hora12(programada.toLocalTime())}."
        else "No pude comprobar que la alarma quedara activada. Revisa la pantalla Alarmas."
    }

    private suspend fun consultarAlarmas(): String {
        val activas = db.alarmaDao().observarTodas().first().filter { it.activa }
        if (activas.isEmpty()) return "No tienes alarmas activas."
        return "Tienes ${activas.size} alarma(s) activa(s): ${activas.joinToString("; ") { descAlarma(it) }}."
    }

    // ----- Modo enfoque -----

    private fun textoMin(min: Int) = textoAntelacion(min)

    private fun iniciarSesion(fase: Fase, minutos: Int?): String {
        val prefs = EnfoqueControl.preferencias.value
        val min = minutos ?: if (fase == Fase.ENFOQUE) prefs.enfoqueMin else prefs.descansoMin
        val limite = if (fase == Fase.ENFOQUE) 720 else 240
        if (min !in 1..limite) return "La duración debe estar entre 1 minuto y ${limite / 60} horas."
        val estado = EnfoqueControl.sesion.value.estado
        if (estado == EstadoSesion.CORRIENDO || estado == EstadoSesion.PAUSADA) {
            return "Ya hay una sesión en curso. Dime «termina la sesión» si quieres empezar otra."
        }
        EnfoqueControl.guardarPreferencias(
            app,
            if (fase == Fase.ENFOQUE) prefs.copy(enfoqueMin = min) else prefs.copy(descansoMin = min),
        )
        EnfoqueControl.iniciar(app, fase, min * 60_000L)
        return if (EnfoqueControl.sesion.value.estado == EstadoSesion.CORRIENDO) {
            if (fase == Fase.ENFOQUE) "Listo. Sesión de enfoque de ${textoMin(min)} iniciada. Te aviso cuando termine."
            else "Listo. Descanso de ${textoMin(min)} iniciado."
        } else {
            "No pude iniciar la sesión. Inténtalo desde la pantalla Enfoque."
        }
    }

    private fun configurarDescanso(min: Int): String {
        if (min !in 1..240) return "El descanso debe durar entre 1 minuto y 4 horas."
        val prefs = EnfoqueControl.preferencias.value
        EnfoqueControl.guardarPreferencias(app, prefs.copy(descansoMin = min))
        return if (EnfoqueControl.preferencias.value.descansoMin == min) "Listo. Tus descansos serán de ${textoMin(min)}."
        else "No pude guardar esa configuración."
    }

    private fun pausar(): String {
        if (EnfoqueControl.sesion.value.estado != EstadoSesion.CORRIENDO) return "No hay una sesión en marcha para pausar."
        EnfoqueControl.pausar(app)
        return if (EnfoqueControl.sesion.value.estado == EstadoSesion.PAUSADA) "Sesión en pausa." else "No pude pausar la sesión."
    }

    private fun reanudar(): String {
        if (EnfoqueControl.sesion.value.estado != EstadoSesion.PAUSADA) return "No hay una sesión en pausa."
        EnfoqueControl.reanudar(app)
        return if (EnfoqueControl.sesion.value.estado == EstadoSesion.CORRIENDO) "Sesión reanudada." else "No pude reanudar la sesión."
    }

    private fun finalizar(): String {
        val estado = EnfoqueControl.sesion.value.estado
        if (estado == EstadoSesion.INACTIVA) return "No hay ninguna sesión en marcha."
        EnfoqueControl.finalizar(app)
        return if (EnfoqueControl.sesion.value.estado == EstadoSesion.INACTIVA) "Sesión finalizada." else "No pude finalizar la sesión."
    }

    private fun estadoEnfoque(): String {
        val s = EnfoqueControl.sesion.value
        val nombre = if (s.fase == Fase.ENFOQUE) "de enfoque" else "de descanso"
        return when (s.estado) {
            EstadoSesion.INACTIVA -> "No hay ninguna sesión en marcha."
            EstadoSesion.CORRIENDO -> {
                val restante = (s.finMs - System.currentTimeMillis()).coerceAtLeast(0L)
                "Te quedan ${minutosRestantes(restante)} $nombre."
            }
            EstadoSesion.PAUSADA -> "La sesión está en pausa; te quedan ${minutosRestantes(s.restanteMs)} $nombre."
            EstadoSesion.TERMINADA -> "Tu sesión $nombre ya terminó."
        }
    }

    private fun minutosRestantes(ms: Long): String {
        val min = ((ms + 59_999L) / 60_000L).toInt().coerceAtLeast(1)
        return textoMin(min)
    }

    // ----- Metas -----

    private suspend fun consultarMetas(): String {
        val metas = db.metaDao().observarTodas().first()
        if (metas.isEmpty()) return "Aún no tienes metas. Puedes decir «quiero agregar una meta nueva»."
        val texto = metas.take(8).joinToString("; ") { "${it.titulo}, ${if (it.completada) "completada" else "${it.progreso} por ciento"}" }
        return "Tienes ${metas.size} meta(s): $texto."
    }

    private suspend fun crearMeta(titulo: String?): String {
        if (titulo.isNullOrBlank()) {
            esperando = Esperando.TituloMeta
            return "¿Cuál es la meta? Dime su nombre."
        }
        val dao = db.metaDao()
        val id = dao.insertar(MetaEntity(titulo = titulo))
        val guardada = dao.porId(id) ?: return "No pude guardar la meta. No la agregué; inténtalo de nuevo."
        return "Listo. Agregué la meta «${guardada.titulo}» con 0 por ciento de avance."
    }

    private suspend fun actualizarMeta(i: Intencion.ActualizarMeta): String {
        val metas = db.metaDao().observarTodas().first()
        if (metas.isEmpty()) return "No tienes metas todavía."
        val ref = i.referencia
        val candidatas = when {
            ref == null -> if (metas.size == 1) metas else emptyList()
            else -> metas.filter { coincide(it.titulo, ref) }
        }
        if (candidatas.isEmpty()) {
            if (ref == null) {
                esperando = Esperando.MetaParaProgreso(i.porcentaje)
                return "¿Cuál meta quieres actualizar? Tus metas: ${metas.joinToString(", ") { it.titulo }}."
            }
            return "No encontré una meta que coincida con «$ref». Tus metas: ${metas.joinToString(", ") { it.titulo }}."
        }
        if (candidatas.size > 1) {
            esperando = Esperando.MetaParaProgreso(i.porcentaje)
            return "Hay ${candidatas.size} metas parecidas: ${candidatas.joinToString(", ") { it.titulo }}. ¿Cuál?"
        }
        val meta = candidatas[0]
        val pct = i.porcentaje
        if (pct == null) {
            esperando = Esperando.PorcentajeMeta(meta.id)
            return "¿A qué porcentaje está «${meta.titulo}»?"
        }
        return actualizarMetaPorId(meta.id, pct)
    }

    private suspend fun actualizarMetaPorId(id: Long, porcentaje: Int): String {
        val dao = db.metaDao()
        val meta = dao.porId(id) ?: return "No encontré esa meta."
        val p = porcentaje.coerceIn(0, 100)
        dao.actualizar(meta.copy(progreso = p, completada = p == 100))
        val v = dao.porId(id)
        return if (v != null && v.progreso == p) {
            if (p == 100) "Listo. «${meta.titulo}» quedó completada." else "Listo. «${meta.titulo}» va en $p por ciento."
        } else {
            "No pude comprobar que el progreso se guardara. Revisa tus metas."
        }
    }
}
