package com.julio.asistente.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.julio.asistente.R
import com.julio.asistente.voz.EstadoVoz
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private val Azul = Color(0xFF2F6BFF)
private val Cian = Color(0xFF4DD0E1)
private val Fondo = Color(0xFF0A2A7A)

/**
 * Orbe de Julio, sin caja: flota directamente sobre el fondo de la app.
 *  - Reposo: respira muy despacio.
 *  - Escuchando: ondas hacia afuera y barras que reaccionan a tu voz (nivel del micrófono).
 *  - Procesando: los arcos giran rápido.
 *  - Respondiendo: el gorila «habla» (la quijada se abre al ritmo de cada palabra), las barras
 *    y las ondas laten con la voz.
 * El movimiento de la boca sigue el ritmo de las palabras que reporta el motor de voz; no es
 * sincronía exacta de labios.
 */
@Composable
fun Orbe(estado: EstadoVoz, nivel: Float, palabras: Int, modifier: Modifier = Modifier) {
    val gorila: ImageBitmap = ImageBitmap.imageResource(R.drawable.julio_orbe)

    val transicion = rememberInfiniteTransition(label = "orbe")
    val fase by transicion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "fase",
    )

    // Un impulso por cada palabra que el motor de voz empieza a decir.
    val impulso = remember { Animatable(0f) }
    LaunchedEffect(palabras) {
        if (estado == EstadoVoz.RESPONDIENDO && palabras > 0) {
            impulso.snapTo(1f)
            impulso.animateTo(0f, tween(200))
        }
    }

    // Velocidades enteras: el bucle de 6 s se repite sin saltos.
    val velocidad = when (estado) {
        EstadoVoz.REPOSO -> 1
        EstadoVoz.ESCUCHANDO -> 2
        EstadoVoz.RESPONDIENDO -> 3
        EstadoVoz.PROCESANDO -> 6
    }

    Canvas(modifier.aspectRatio(1f)) {
        val c = center
        val lado = size.minDimension
        val f = fase.toDouble()
        val dosPi = 2.0 * PI

        // ¿Cuánto abre la boca? Impulso por palabra + un vaivén de respaldo si el motor no reporta palabras.
        val habla = estado == EstadoVoz.RESPONDIENDO
        val vaiven = if (habla) 0.35f * abs(sin(f * dosPi * 12.0)).toFloat() else 0f
        val apertura = if (habla) max(impulso.value, vaiven) else 0f

        val energia = when (estado) {
            EstadoVoz.REPOSO -> 0.08f
            EstadoVoz.ESCUCHANDO -> 0.2f + 0.8f * nivel
            EstadoVoz.PROCESANDO -> 0.5f
            EstadoVoz.RESPONDIENDO -> 0.25f + 0.75f * apertura
        }
        val respiracion = 1f + 0.015f * sin(f * dosPi).toFloat()
        val intensidad = if (estado == EstadoVoz.REPOSO) 0.55f else 1f

        // Disco de fondo con borde suave (se mezcla con la pantalla; no es una caja)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Fondo.copy(alpha = 0.95f), Fondo.copy(alpha = 0.55f), Color.Transparent),
                center = c, radius = lado * 0.5f,
            ),
            radius = lado * 0.5f, center = c,
        )

        val rGorila = lado * 0.26f * respiracion
        val rAnillo = lado * 0.33f

        // Halo del anillo
        for (k in 3 downTo 1) {
            drawCircle(
                color = Azul.copy(alpha = 0.08f * k * intensidad),
                radius = rAnillo + k * lado * 0.006f, center = c,
                style = Stroke(width = lado * 0.012f * k),
            )
        }
        drawCircle(color = Azul.copy(alpha = intensidad), radius = rAnillo, center = c, style = Stroke(width = lado * 0.01f))
        drawCircle(color = Cian.copy(alpha = 0.45f * intensidad), radius = rAnillo * 1.07f, center = c, style = Stroke(width = lado * 0.004f))

        // Ondas que salen hacia afuera (escuchando y respondiendo)
        if (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.RESPONDIENDO) {
            for (k in 0 until 3) {
                val p = ((f * velocidad + k / 3.0) % 1.0).toFloat()
                val radio = rAnillo * (1.05f + 0.35f * p)
                drawCircle(
                    color = Cian.copy(alpha = (1f - p) * 0.35f * (0.4f + energia)),
                    radius = radio, center = c, style = Stroke(width = lado * 0.006f),
                )
            }
        }

        // Arcos giratorios
        val giro = (f * 360.0 * velocidad).toFloat()
        val d = rAnillo * 2f * 1.14f
        val esquina = Offset(c.x - d / 2f, c.y - d / 2f)
        drawArc(
            color = Cian.copy(alpha = intensidad), startAngle = giro, sweepAngle = 70f, useCenter = false,
            topLeft = esquina, size = Size(d, d), style = Stroke(width = lado * 0.012f, cap = StrokeCap.Round),
        )
        drawArc(
            color = Azul.copy(alpha = intensidad), startAngle = 200f - giro, sweepAngle = 45f, useCenter = false,
            topLeft = esquina, size = Size(d, d), style = Stroke(width = lado * 0.012f, cap = StrokeCap.Round),
        )

        // Barras radiales alrededor del anillo (ecualizador circular)
        val barras = 64
        val rBase = rAnillo * 1.2f
        for (i in 0 until barras) {
            val ang = dosPi * i / barras
            val osc = abs(sin(f * dosPi * velocidad + i * 0.55)).toFloat()
            val largo = lado * 0.008f + lado * 0.075f * energia * (0.25f + 0.75f * osc)
            val ux = cos(ang).toFloat()
            val uy = sin(ang).toFloat()
            drawLine(
                color = Cian.copy(alpha = 0.85f * intensidad),
                start = Offset(c.x + ux * rBase, c.y + uy * rBase),
                end = Offset(c.x + ux * (rBase + largo), c.y + uy * (rBase + largo)),
                strokeWidth = lado * 0.006f, cap = StrokeCap.Round,
            )
        }

        // Gorila: mismo dibujo, con la quijada que se abre al hablar
        val ancho = gorila.width
        val corte = (ancho * 0.528f).roundToInt()       // borde superior de la boca
        val k = 1f + 0.09f * apertura                   // cuánto se estira la parte de abajo
        val escalaLatido = 1f + 0.02f * apertura + (if (estado == EstadoVoz.ESCUCHANDO) 0.03f * nivel else 0f)
        val factor = (rGorila * 2f) / ancho * escalaLatido
        val izquierda = c.x - ancho * factor / 2f
        val arriba = c.y - ancho * factor / 2f - lado * 0.004f * apertura
        val circulo = Path().apply { addOval(Rect(center = c, radius = rGorila * escalaLatido)) }

        clipPath(circulo) {
            withTransform({
                translate(izquierda, arriba)
                scale(factor, factor, pivot = Offset.Zero)
            }) {
                // Parte de abajo (boca y mentón), estirada
                withTransform({
                    translate(0f, corte.toFloat())
                    scale(1f, k, pivot = Offset.Zero)
                }) {
                    drawImage(
                        image = gorila,
                        srcOffset = IntOffset(0, corte),
                        srcSize = IntSize(ancho, ancho - corte),
                        dstOffset = IntOffset.Zero,
                        dstSize = IntSize(ancho, ancho - corte),
                        filterQuality = FilterQuality.High,
                    )
                }
                // Parte de arriba (ojos, nariz), quieta
                drawImage(
                    image = gorila,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(ancho, corte),
                    dstOffset = IntOffset.Zero,
                    dstSize = IntSize(ancho, corte),
                    filterQuality = FilterQuality.High,
                )
            }
        }
        // Borde del gorila
        drawCircle(
            color = Cian.copy(alpha = 0.7f * intensidad),
            radius = rGorila * escalaLatido, center = c, style = Stroke(width = lado * 0.005f),
        )
    }
}
