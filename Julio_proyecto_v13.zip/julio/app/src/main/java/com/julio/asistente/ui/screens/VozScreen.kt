package com.julio.asistente.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.ui.components.Orbe
import com.julio.asistente.voz.EstadoVoz
import com.julio.asistente.voz.VozViewModel

private class CategoriaGuia(val titulo: String, val ejemplos: List<String>)

/** Solo ejemplos que el intérprete realmente entiende hoy (verificados con pruebas de la lógica). */
private val GUIA = listOf(
    CategoriaGuia("Horario", listOf(
        "¿Qué tengo programado hoy?",
        "Agrega laboratorio de química mañana a las dos de la tarde",
        "¿Qué clases tengo el lunes?",
    )),
    CategoriaGuia("Lista de tareas", listOf(
        "Agrega estudiar anatomía a mis tareas",
        "¿Qué tareas tengo pendientes?",
        "Marca como terminada la tarea del informe",
    )),
    CategoriaGuia("Alarmas", listOf(
        "Pon una alarma para mañana a las seis de la mañana",
        "Desactiva la alarma del domingo",
    )),
    CategoriaGuia("Modo enfoque", listOf(
        "Inicia una sesión de enfoque de 35 minutos",
        "Quiero estudiar durante una hora y veinte minutos",
        "Configura un descanso de diez minutos",
    )),
    CategoriaGuia("Mis metas", listOf(
        "Muéstrame mis metas",
        "Quiero agregar una meta nueva",
        "Actualiza el progreso de mi meta",
    )),
)

@Composable
fun VozScreen(vm: VozViewModel = viewModel()) {
    val ctx = LocalContext.current
    val estado by vm.estado.collectAsStateWithLifecycle()
    val transcripcion by vm.transcripcion.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val historial by vm.historial.collectAsStateWithLifecycle()
    val nivel by vm.nivel.collectAsStateWithLifecycle()
    val palabras by vm.palabras.collectAsStateWithLifecycle()
    var categoria by rememberSaveable { mutableStateOf(-1) }
    val hablar by vm.hablarRespuestas.collectAsStateWithLifecycle()
    var texto by remember { mutableStateOf("") }

    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        if (concedido) vm.escuchar() else vm.reportarPermisoDenegado()
    }

    fun enviar() {
        vm.enviarTexto(texto)
        texto = ""
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            "J U L I O",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Orbe(
            estado = estado,
            nivel = nivel,
            palabras = palabras,
            modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp).align(Alignment.CenterHorizontally),
        )
        Text(
            when (estado) {
                EstadoVoz.REPOSO -> "Listo"
                EstadoVoz.ESCUCHANDO -> "Escuchando..."
                EstadoVoz.PROCESANDO -> "Procesando..."
                EstadoVoz.RESPONDIENDO -> "Respondiendo..."
            },
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )

        // Controles principales
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val ocupado = estado == EstadoVoz.PROCESANDO
            Button(
                enabled = !ocupado && estado != EstadoVoz.ESCUCHANDO,
                onClick = {
                    if (vm.permisoMicrofono()) vm.escuchar() else pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.height(56.dp),
            ) {
                Icon(Icons.Filled.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Hablar con Julio")
            }
            if (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.RESPONDIENDO) {
                OutlinedButton(onClick = { vm.detener() }, modifier = Modifier.height(56.dp)) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Detener")
                }
            }
        }

        // Transcripción en vivo
        if (transcripcion.isNotBlank() && (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.PROCESANDO)) {
            Text("Dijiste: $transcripcion", style = MaterialTheme.typography.bodyMedium)
        }

        // Errores claros
        error?.let { mensaje ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(mensaje, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    Row {
                        if (!vm.permisoMicrofono()) {
                            TextButton(onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")),
                                )
                            }) { Text("Abrir ajustes de la app") }
                        }
                        TextButton(onClick = { vm.limpiarError() }) { Text("Cerrar") }
                    }
                }
            }
        }

        // Escribir en vez de hablar
        OutlinedTextField(
            value = texto,
            onValueChange = { texto = it },
            label = { Text("O escríbele a Julio") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { enviar() }),
            trailingIcon = {
                IconButton(enabled = texto.isNotBlank(), onClick = { enviar() }) {
                    Icon(Icons.Filled.Send, contentDescription = "Enviar")
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Respuestas habladas", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = hablar, onCheckedChange = { vm.alternarHablar() })
        }

        // Conversación (solo de esta sesión)
        if (historial.isNotEmpty()) {
            Text("Conversación", style = MaterialTheme.typography.titleMedium)
            historial.takeLast(8).forEach { m ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (m.deUsuario) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            if (m.deUsuario) "Tú" else "Julio",
                            style = MaterialTheme.typography.labelSmall,
                        )
                        Text(m.texto, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Text(
                "La conversación no se guarda: se borra al cerrar la app. Tus tareas, horario, alarmas y metas sí se guardan.",
                style = MaterialTheme.typography.labelSmall,
            )
        }

        // Guía de comandos en pestañas: ocupa espacio solo cuando abres una
        Text("¿Qué puedo decirle a Julio?", style = MaterialTheme.typography.titleLarge)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            GUIA.forEachIndexed { indice, cat ->
                FilterChip(
                    selected = categoria == indice,
                    onClick = { categoria = if (categoria == indice) -1 else indice },
                    label = { Text(cat.titulo) },
                )
            }
        }
        val abierta = GUIA.getOrNull(categoria)
        AnimatedVisibility(visible = abierta != null) {
            if (abierta != null) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "Puedes decirle a Julio:",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        abierta.ejemplos.forEach { ejemplo ->
                            Text(
                                "«$ejemplo»",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.enviarTexto(ejemplo) }
                                    .padding(vertical = 8.dp),
                            )
                        }
                        Text(
                            "Toca un ejemplo para probarlo.",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
        }

        MetasSection()
    }
}
