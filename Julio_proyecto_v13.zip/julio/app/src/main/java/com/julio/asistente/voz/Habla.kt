package com.julio.asistente.voz

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Voz de Julio con el motor de síntesis de Android. Usa español y un tono algo más grave y pausado.
 * Android no permite garantizar que la voz sea masculina: depende de las voces instaladas en el teléfono.
 */
class Habla(context: Context) {
    private var tts: TextToSpeech? = null
    private var inicializado = false
    private var listo = false
    private var alTerminar: (() -> Unit)? = null
    private var pendiente: Pair<String, () -> Unit>? = null
    private val principal = Handler(Looper.getMainLooper())

    private val _palabras = MutableStateFlow(0)
    /** Sube en 1 cada vez que el motor empieza una palabra: sirve para animar la boca del gorila. */
    val palabras: StateFlow<Int> = _palabras.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { estado ->
            inicializado = true
            if (estado == TextToSpeech.SUCCESS) configurar()
            val p = pendiente
            pendiente = null
            if (p != null) hablar(p.first, p.second)
        }
    }

    private fun configurar() {
        val t = tts ?: return
        val candidatos = listOf(Locale("es", "MX"), Locale("es", "US"), Locale("es", "ES"), Locale("es"))
        val elegido = candidatos.firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE }
        if (elegido == null) {
            listo = false
            return
        }
        t.setLanguage(elegido)
        t.setPitch(0.85f)
        t.setSpeechRate(0.95f)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                _palabras.value = _palabras.value + 1
            }
            override fun onDone(utteranceId: String?) { terminar() }
            @Deprecated("Requerido por la API")
            override fun onError(utteranceId: String?) { terminar() }
        })
        listo = true
    }

    private fun terminar() {
        principal.post {
            val cb = alTerminar
            alTerminar = null
            cb?.invoke()
        }
    }

    /** Si la voz no está disponible, llama a [alTerminar] enseguida: la respuesta igual se ve en pantalla. */
    fun hablar(texto: String, alTerminar: () -> Unit) {
        val t = tts
        if (t == null) { alTerminar(); return }
        if (!inicializado) { pendiente = texto to alTerminar; return }
        if (!listo) { alTerminar(); return }
        this.alTerminar = alTerminar
        val r = t.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "julio")
        if (r == TextToSpeech.ERROR) {
            this.alTerminar = null
            alTerminar()
        }
    }

    fun detener() {
        alTerminar = null
        pendiente = null
        tts?.stop()
    }

    val disponible: Boolean get() = !inicializado || listo

    fun cerrar() {
        detener()
        tts?.shutdown()
        tts = null
    }
}
