package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.memoria.MemoriaAjustes
import com.julio.asistente.memoria.MemoriaLogica

/**
 * Memoria de Julio (v59): lo que Julio recuerda de ti. Se llena con la voz («recuerda que…») o con la lista de abajo; se puede borrar dato por dato
 * o todo. Todo queda en este teléfono. Lo que parece una instrucción o un secreto queda en «cuarentena»: se ve aquí, pero la IA nunca lo recibe.
 */
@Composable
fun MemoriaPanel() {
    val ctx = LocalContext.current
    val hechos by MemoriaAjustes.hechos.collectAsStateWithLifecycle()
    val usarEnIa by MemoriaAjustes.usarEnIa.collectAsStateWithLifecycle()
    val automatica by MemoriaAjustes.automatica.collectAsStateWithLifecycle()
    var nuevo by remember { mutableStateOf("") }
    var avisoNuevo by remember { mutableStateOf("") }
    var confirmarTodo by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Lo que Julio recuerda de ti. Díselo así: «Julio, recuerda que mi parcial es el 5 de diciembre». Para borrar: «olvida lo del parcial». " +
                "Todo queda en este teléfono.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("La IA usa mi memoria", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = usarEnIa, onCheckedChange = { MemoriaAjustes.fijarUsarEnIa(ctx, it) })
        }
        Text(
            "Encendido: cuando le preguntas algo a la IA, se le manda en ese mensaje (a Google/tu proveedor) solo lo poco que viene al caso. " +
                "Nunca se manda lo que lleva números largos, correos, contraseñas ni lo que está en cuarentena.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Aprender sola de mis charlas con la IA", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = automatica, onCheckedChange = { MemoriaAjustes.fijarAutomatica(ctx, it) })
        }
        Text(
            "Apagado de fábrica. Encendido: después de cada charla, Julio le pide a la IA (una consulta más) sacar datos duraderos y los guarda.",
            style = MaterialTheme.typography.bodySmall,
        )

        OutlinedTextField(
            value = nuevo,
            onValueChange = { nuevo = it.take(MemoriaLogica.MAX_CHARS) },
            label = { Text("Agregar un dato") },
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                val (lista, estado) = MemoriaLogica.agregar(MemoriaAjustes.leer(ctx), nuevo, MemoriaLogica.FUENTE_VOZ, System.currentTimeMillis())
                MemoriaAjustes.guardar(ctx, lista)
                avisoNuevo = when (estado) {
                    com.julio.asistente.memoria.EstadoAgregado.NUEVO -> "Guardado."
                    com.julio.asistente.memoria.EstadoAgregado.DUPLICADO -> "Eso ya estaba."
                    com.julio.asistente.memoria.EstadoAgregado.CUARENTENA -> "Guardado en cuarentena (parece una instrucción o un secreto)."
                    com.julio.asistente.memoria.EstadoAgregado.VACIO -> "Escribe algo primero."
                }
                nuevo = ""
            },
            enabled = nuevo.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Agregar") }
        if (avisoNuevo.isNotEmpty()) Text(avisoNuevo, style = MaterialTheme.typography.bodySmall)

        Text(
            if (hechos.isEmpty()) "Todavía no hay nada guardado." else "${hechos.size} ${if (hechos.size == 1) "dato" else "datos"}:",
            style = MaterialTheme.typography.labelLarge,
        )
        hechos.reversed().forEach { h ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(h.texto, style = MaterialTheme.typography.bodyMedium)
                    val marca = when {
                        h.confianza == MemoriaLogica.CONFIANZA_CUARENTENA -> "En cuarentena: la IA no lo ve"
                        h.fuente == MemoriaLogica.FUENTE_AUTO -> "Aprendido de una charla"
                        else -> "Me lo pediste tú"
                    }
                    Text(marca, style = MaterialTheme.typography.labelSmall)
                }
                IconButton(onClick = { MemoriaAjustes.guardar(ctx, MemoriaAjustes.leer(ctx).filterNot { it == h }) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Borrar este dato")
                }
            }
        }
        if (hechos.isNotEmpty()) {
            OutlinedButton(onClick = { confirmarTodo = true }, modifier = Modifier.fillMaxWidth()) { Text("Borrar toda la memoria") }
        }
    }

    if (confirmarTodo) {
        AlertDialog(
            onDismissRequest = { confirmarTodo = false },
            title = { Text("¿Borrar toda la memoria?") },
            text = { Text("Julio olvidará los ${hechos.size} datos. No se puede deshacer.") },
            confirmButton = { TextButton(onClick = { MemoriaAjustes.guardar(ctx, emptyList()); confirmarTodo = false }) { Text("Borrar todo") } },
            dismissButton = { TextButton(onClick = { confirmarTodo = false }) { Text("Cancelar") } },
        )
    }
}
