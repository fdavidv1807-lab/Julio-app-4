package com.julio.asistente.cuerpo

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.julio.asistente.escritorio.EscritorioControl
import java.util.UUID

/**
 * Corre en el Cuerpo de Julio (el teléfono del escritorio), NO en el teléfono principal. Ve las notificaciones que llegan a ESTE
 * teléfono (WhatsApp vinculado como dispositivo complementario, Gmail, etc.) y deja en cola las de las apps que la persona eligió,
 * para que Julio las lea. No usa la red ni manda nada a ningún lado. Requiere el permiso «Acceso a notificaciones» (Ajustes).
 * Solo trabaja con el modo escritorio abierto y la lectura encendida; si no, no hace nada.
 */
class AvisosListener : NotificationListenerService() {
    private val dedupe = Deduplicador()

    override fun onCreate() {
        super.onCreate()
        CuerpoAjustes.cargar(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!CuerpoAjustes.activo.value || !EscritorioControl.activo.value) return
            val n = sbn.notification ?: return
            val extras = n.extras
            val titulo = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val texto = (extras?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras?.getCharSequence(Notification.EXTRA_TEXT))
                ?.toString().orEmpty()
            val cruda = NotificacionCruda(
                paquete = sbn.packageName.orEmpty(),
                titulo = titulo,
                texto = texto,
                categoria = n.category,
                enCurso = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0,
                resumenGrupo = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0,
            )
            if (FiltroAvisos.motivoDescarte(cruda, packageName, CuerpoAjustes.permitidas.value) != null) return
            val ahora = System.currentTimeMillis()
            if (dedupe.repetido(cruda.paquete, titulo, texto, ahora)) return
            val aviso = Sensibles.sanear(
                Aviso(UUID.randomUUID().toString(), ahora, nombreDeApp(cruda.paquete), cruda.paquete, titulo, texto),
            )
            CuerpoAvisos.recibir(aviso)
        } catch (e: Exception) {
            // Un aviso raro nunca debe tumbar el servicio.
        }
    }

    /** Samsung y otros matan estos servicios: se pide al sistema que lo vuelva a conectar. */
    override fun onListenerDisconnected() {
        try {
            NotificationListenerService.requestRebind(ComponentName(this, AvisosListener::class.java))
        } catch (e: Exception) { }
    }

    private fun nombreDeApp(paquete: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(paquete, 0)).toString()
    } catch (e: Exception) {
        paquete.substringAfterLast('.')
    }
}
