package com.julio.asistente.cuerpo

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Avisos esperando turno para ser leídos en voz alta. Solo en memoria (nunca en disco); caducan a los 10 minutos. */
object CuerpoAvisos {
    private val cola = ColaAvisos(capacidad = 20, vidaMs = 10 * 60_000L)
    private val _pendientes = MutableStateFlow(0)
    val pendientes: StateFlow<Int> = _pendientes.asStateFlow()

    private fun ahora() = System.currentTimeMillis()
    private fun actualizar() { _pendientes.value = cola.tamano(ahora()) }

    fun recibir(a: Aviso) { if (cola.agregar(a, ahora())) actualizar() }
    fun siguiente(): Entrada? = cola.siguiente(ahora()).also { actualizar() }
    fun devolver(e: Entrada) { cola.devolver(e); actualizar() }
    fun perdidos(): Int = cola.tomarPerdidos()
    fun vaciar() { cola.vaciar(); actualizar() }
}
