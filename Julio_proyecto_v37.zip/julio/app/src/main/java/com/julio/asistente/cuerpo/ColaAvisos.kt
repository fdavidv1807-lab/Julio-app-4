package com.julio.asistente.cuerpo

/** Un aviso esperando turno, con la hora (ms) a la que LLEGÓ a este teléfono. */
data class Entrada(val aviso: Aviso, val recibido: Long)

/**
 * Cola de avisos en memoria (nunca en disco), limitada y con caducidad.
 * Si se llena se pierde el más viejo y se cuenta; lo que pasa de [vidaMs] se tira sin avisar.
 * Guarda los avisos que esperan turno para leerse en voz alta. Lógica pura.
 */
class ColaAvisos(private val capacidad: Int = 20, private val vidaMs: Long = 10 * 60_000L) {
    private val items = ArrayDeque<Entrada>()
    private val ids = ArrayDeque<String>()
    private var perdidos = 0

    @Synchronized
    private fun caducar(ahora: Long) {
        while (items.isNotEmpty() && ahora - items.first().recibido > vidaMs) items.removeFirst()
    }

    /** false si ese aviso ya estaba o ya se sacó hace poco (mismo id). */
    @Synchronized
    fun agregar(a: Aviso, ahora: Long): Boolean {
        caducar(ahora)
        if (ids.contains(a.id)) return false
        ids.addLast(a.id)
        while (ids.size > 200) ids.removeFirst()
        items.addLast(Entrada(a, ahora))
        while (items.size > capacidad) {
            items.removeFirst()
            perdidos++
        }
        return true
    }

    /** Saca el siguiente aviso (el más antiguo que no caducó) o null. */
    @Synchronized
    fun siguiente(ahora: Long): Entrada? {
        caducar(ahora)
        return if (items.isEmpty()) null else items.removeFirst()
    }

    /** Lo devuelve al frente (por ejemplo si Julio no pudo hablar en ese momento). */
    @Synchronized
    fun devolver(e: Entrada) {
        items.addFirst(e)
    }

    @Synchronized
    fun tamano(ahora: Long): Int {
        caducar(ahora)
        return items.size
    }

    /** Cuántos avisos se perdieron por cola llena desde la última vez que se preguntó (y lo pone a cero). */
    @Synchronized
    fun tomarPerdidos(): Int {
        val p = perdidos
        perdidos = 0
        return p
    }

    @Synchronized
    fun vaciar() {
        items.clear()
        ids.clear()
        perdidos = 0
    }
}
