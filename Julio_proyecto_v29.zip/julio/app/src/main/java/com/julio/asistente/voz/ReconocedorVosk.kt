package com.julio.asistente.voz

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.Executors

/** Datos para comprobar el reconocimiento sin internet (se muestran en Configuración > Voz). */
data class DiagnosticoVosk(
    val motor: String = "Aún no se ha usado",
    val cargaModeloMs: Long = 0,
    val respuestaMs: Long = 0,
    val memoriaNativaMb: Long = 0,
    val ultimoTexto: String = "",
)

/**
 * Reconocimiento de voz LOCAL con Vosk (Kaldi), modelo en español. Lee el micrófono con AudioRecord y pasa el audio
 * directamente al motor dentro del teléfono: no usa SpeechRecognizer, ni Google, ni ningún servicio en red.
 * El audio solo vive en memoria; no se guarda ni se envía a ningún lado.
 */
class ReconocedorVosk {
    interface Oyente {
        fun alPreparar()
        fun alEscuchar()
        fun alNivel(nivel: Float)
        fun alParcial(texto: String)
        fun alFinal(texto: String)
        fun alSinVoz()
        fun alError(mensaje: String)
    }

    private val _diagnostico = MutableStateFlow(DiagnosticoVosk())
    val diagnostico: StateFlow<DiagnosticoVosk> = _diagnostico.asStateFlow()

    private val hilo = Executors.newSingleThreadExecutor()
    private val principal = Handler(Looper.getMainLooper())
    @Volatile private var generacion = 0
    @Volatile private var escuchando = false
    private var modelo: Model? = null
    private var rutaModelo: String? = null

    private val soltarModelo = Runnable {
        hilo.execute { if (!escuchando) cerrarModelo() }
    }

    private fun cerrarModelo() {
        try { modelo?.close() } catch (e: Exception) { /* ya cerrado */ }
        modelo = null
        rutaModelo = null
    }

    /** Escucha una intervención y entrega el texto. Si ya había una escucha, la reemplaza. */
    fun escuchar(ruta: String, oyente: Oyente) {
        generacion++
        val mia = generacion
        principal.removeCallbacks(soltarModelo)
        escuchando = true
        hilo.execute { bucle(ruta, oyente, mia) }
    }

    /**
     * Vigía de interrupción: mientras Julio habla, escucha SOLO unas pocas palabras clave (vocabulario limitado)
     * para no oír su propia voz ni gastar batería. Al detectar una, llama a [alDetectar] (en el hilo principal)
     * y se apaga. Usa el micrófono de «comunicación» y, si el teléfono lo trae, cancelación de eco.
     * Cualquier otra escucha ([escuchar]) o [detener] lo reemplaza o lo corta.
     */
    fun vigilarPalabrasClave(ruta: String, alDetectar: () -> Unit) {
        generacion++
        val mia = generacion
        principal.removeCallbacks(soltarModelo)
        escuchando = true
        hilo.execute { bucleClave(ruta, mia, alDetectar) }
    }

    private fun bucleClave(ruta: String, mia: Int, alDetectar: () -> Unit) {
        var grabadora: AudioRecord? = null
        var reconocedor: Recognizer? = null
        var eco: AcousticEchoCanceler? = null
        try {
            if (modelo == null || rutaModelo != ruta) {
                cerrarModelo()
                modelo = Model(ruta)
                rutaModelo = ruta
            }
            if (mia != generacion) return
            reconocedor = Recognizer(modelo, MUESTREO.toFloat(), GRAMATICA)

            val minimo = AudioRecord.getMinBufferSize(MUESTREO, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimo <= 0) return
            grabadora = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, MUESTREO,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimo * 4, 16384),
            )
            if (grabadora.state != AudioRecord.STATE_INITIALIZED) return
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    eco = AcousticEchoCanceler.create(grabadora.audioSessionId)
                    eco?.enabled = true
                }
            } catch (e: Throwable) {
                // Sin cancelación de eco: se sigue con el vocabulario limitado.
            }
            grabadora.startRecording()

            val trozo = ShortArray(MUESTREO / 10) // 100 ms de audio
            while (mia == generacion) {
                val n = grabadora.read(trozo, 0, trozo.size)
                if (n < 0) return
                if (n == 0) continue
                val detectada = if (reconocedor.acceptWaveForm(trozo, n)) {
                    ReconocimientoUtil.hayInterrupcion(ReconocimientoUtil.extraer(reconocedor.result, "text"), true)
                } else {
                    ReconocimientoUtil.hayInterrupcion(ReconocimientoUtil.extraer(reconocedor.partialResult, "partial"), false)
                }
                if (detectada) {
                    if (mia == generacion) principal.post { alDetectar() }
                    return
                }
            }
        } catch (e: Throwable) {
            // Sin vigía no pasa nada grave: queda el toque en el orbe para interrumpir.
        } finally {
            try { eco?.release() } catch (e: Throwable) { /* ya liberado */ }
            try { grabadora?.stop() } catch (e: Exception) { /* ya detenida */ }
            grabadora?.release()
            try { reconocedor?.close() } catch (e: Exception) { /* ya cerrado */ }
            if (mia == generacion) {
                escuchando = false
                programarLiberacion()
            }
        }
    }

    /** Cancela la escucha en curso (no entrega resultado). */
    fun detener() {
        generacion++
        escuchando = false
        programarLiberacion()
    }

    fun liberar() {
        generacion++
        escuchando = false
        principal.removeCallbacks(soltarModelo)
        hilo.execute { cerrarModelo() }
    }

    /** Pasados 2 minutos sin usar, se libera la memoria del modelo (se vuelve a cargar al hablar). */
    private fun programarLiberacion() {
        principal.removeCallbacks(soltarModelo)
        principal.postDelayed(soltarModelo, 120_000L)
    }

    private fun bucle(ruta: String, oyente: Oyente, mia: Int) {
        var grabadora: AudioRecord? = null
        var reconocedor: Recognizer? = null
        try {
            if (modelo == null || rutaModelo != ruta) {
                oyente.alPreparar()
                cerrarModelo()
                val t0 = SystemClock.elapsedRealtime()
                modelo = Model(ruta)
                rutaModelo = ruta
                _diagnostico.value = _diagnostico.value.copy(cargaModeloMs = SystemClock.elapsedRealtime() - t0)
            }
            if (mia != generacion) return
            reconocedor = Recognizer(modelo, MUESTREO.toFloat())

            val minimo = AudioRecord.getMinBufferSize(MUESTREO, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimo <= 0) throw IllegalStateException("Este teléfono no permite abrir el micrófono con este formato.")
            grabadora = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, MUESTREO,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimo * 4, 16384),
            )
            if (grabadora.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("No pude abrir el micrófono (¿otra app lo está usando?).")
            }
            grabadora.startRecording()
            if (mia != generacion) return
            oyente.alEscuchar()

            val trozo = ShortArray(MUESTREO / 10) // 100 ms de audio
            val inicio = SystemClock.elapsedRealtime()
            var hablo = false
            var ultimoParcial = ""
            var ultimoCambio = inicio
            while (mia == generacion) {
                val n = grabadora.read(trozo, 0, trozo.size)
                if (n < 0) throw IllegalStateException("Falló la lectura del micrófono (código $n).")
                if (n == 0) continue
                oyente.alNivel(ReconocimientoUtil.nivel(trozo, n))
                val ahora = SystemClock.elapsedRealtime()
                if (reconocedor.acceptWaveForm(trozo, n)) {
                    val texto = ReconocimientoUtil.extraer(reconocedor.result, "text")
                    if (texto.isNotBlank()) {
                        entregar(texto, ahora - ultimoCambio, oyente, mia)
                        return
                    }
                } else {
                    val parcial = ReconocimientoUtil.extraer(reconocedor.partialResult, "partial")
                    if (parcial.isNotBlank()) {
                        hablo = true
                        if (parcial != ultimoParcial) {
                            ultimoParcial = parcial
                            ultimoCambio = ahora
                            oyente.alParcial(parcial)
                        }
                    }
                }
                if (!hablo && ahora - inicio > ESPERA_SIN_VOZ_MS) {
                    if (mia == generacion) oyente.alSinVoz()
                    return
                }
                if (ahora - inicio > MAXIMO_MS) {
                    val texto = ReconocimientoUtil.extraer(reconocedor.finalResult, "text")
                    if (texto.isBlank()) { if (mia == generacion) oyente.alSinVoz() } else entregar(texto, ahora - ultimoCambio, oyente, mia)
                    return
                }
            }
        } catch (e: Throwable) {
            if (mia == generacion) oyente.alError(e.message ?: e.javaClass.simpleName)
        } finally {
            try { grabadora?.stop() } catch (e: Exception) { /* ya detenida */ }
            grabadora?.release()
            try { reconocedor?.close() } catch (e: Exception) { /* ya cerrado */ }
            if (mia == generacion) {
                escuchando = false
                programarLiberacion()
            }
        }
    }

    private fun entregar(texto: String, respuestaMs: Long, oyente: Oyente, mia: Int) {
        if (mia != generacion) return
        _diagnostico.value = _diagnostico.value.copy(
            motor = "Vosk (sin internet), modelo ${VoskModelo.NOMBRE}",
            respuestaMs = respuestaMs,
            memoriaNativaMb = Debug.getNativeHeapAllocatedSize() / 1_000_000,
            ultimoTexto = texto,
        )
        oyente.alFinal(texto)
    }

    companion object {
        const val MUESTREO = 16000

        /** Vocabulario limitado para Vosk (lo demás cae en «[unk]»). «para» y «no» solo cuentan con las reglas de [ReconocimientoUtil.hayInterrupcion]. */
        private val GRAMATICA = (ReconocimientoUtil.PALABRAS_FUERTES + "para" + "no" + "[unk]")
            .joinToString(prefix = "[", postfix = "]") { "\"$it\"" }
        private const val ESPERA_SIN_VOZ_MS = 8_000L
        private const val MAXIMO_MS = 30_000L
    }
}
