# Julio 2.0 — Especificación definitiva (acordada con el dueño, 11-nov-2026)

> Manda sobre la hoja de ruta anterior de `PROMPT_PARA_CONTINUAR.md`. Una cosa por versión. Las ideas nuevas van a la sección «Ideas en espera», NO a un rediseño.
> Actualizada el 11-nov-2026 (noche) con todo lo hablado por voz: ver secciones 14, 15 y 16. Si algo choca, mandan 14–16.
> Estado: SOLO diseño. No hay código nuevo desde v43. Nada de lo de abajo está compilado ni probado.

## 0. Lo que el dueño quiere (en sus palabras, resumido)
Un Julio definitivo: un secretario / JARVIS, no una app cualquiera. Todo por voz y automatizado; botones y ajustes escondidos que aparecen con animación cuando él lo pide. Dejar de reinstalar y rehacer: por eso este documento congela el alcance. Responder siempre en español, corto y claro (lee desde el celular). No se disculpe de más: decir qué falló, qué hacemos y el siguiente paso.

## 1. Flujo de primer arranque (una sola vez)
1. **Permisos**, una pantalla con un botón por permiso (micrófono, notificaciones de Julio, batería sin restricciones, acceso a notificaciones, acceso de uso de apps, cámara solo la usa el lector de Google). Marca cada uno al concederse y lleva directo a la pantalla de Android cuando es especial.
2. **Entrenar la voz** (estilo Asistente de Google): Julio pide decir frases tipo «Julio, haz esto / aquello» varias veces, con tonos distintos (normal, bajo, rápido, cansado). Se guarda una **huella numérica** de la voz, NUNCA audio. Base existente: `voz/HablanteMath.kt`, `VozDueno.kt`, «Mi voz» de v34.
3. **¿Este teléfono es el Diario o el Cuerpo de Julio?**
   - **Cuerpo:** muestra el QR solo; entra al modo escritorio y se queda ahí siempre.
   - **Diario:** abre solo el escáner del QR.
4. **Vinculación automática (queda dentro del paso 3):** el QR se usa UNA sola vez. Después se reconectan solos (como Bluetooth): IP guardada + búsqueda NSD, reintento en segundo plano. Si algo falla, se le dice a Julio «vincula de nuevo» y repite el proceso.
5. **Último paso del arranque: «Si quieres hablar con la inteligencia artificial, haz esto».** Un solo botón que REDIRIGE a Google AI Studio para sacar la clave gratis de Gemini. Nada más: la clave se pega después a mano en Configuración > «IA de consulta» (campo que ya existe en v43). Julio no puede sacar la clave solo: Google pide entrar con la cuenta del dueño. El paso se puede omitir.
6. Android NO deja automatizar: «Acceso a notificaciones», «Acceso de uso» y escanear el QR. Julio lleva directo a esa pantalla y avisa cuando quedó.

## 2. Interfaz
- **Cuerpo:** HUD de la imagen de referencia (`docs/referencia_voz_orbe.jpg` y la imagen JARVIS del dueño): negro puro (#000), cian #00E5FF, turquesa #2DD4BF, ámbar #FFB300 (alertas), rojo #FF3D5A (errores), marcos de esquinas cortadas, anillos con escala, diales y partículas (decorativos, marcados en el código), paneles a los lados con DATOS REALES. Horizontal y vertical (vertical: avatar arriba, paneles como tarjetas). Siempre en modo escritorio, brillo bajo, anti-quemado (`OffsetEscritorio`), ~30 fps, pausa cuando no se ve.
- **Diario:** el holograma de Julio (gorila) con el mismo estilo Cyber, con botones, pero **SIN los textos explicativos** de cada modalidad. Lo explicativo pasa a Configuración > **Modo guía** (comandos y cómo funciona cada cosa).
- **Botones ocultos:** «Julio, configuración», «Julio, modo manual» → aparecen botones con animación y se esconden solos. Quiero menos ventanas, no más.
- **Se QUITAN las Metas desde v44** (el dueño no las usa): fuera de la pantalla Voz, de los comandos de voz («meta», `Intencion.ConsultarMetas/CrearMeta/ActualizarMeta`, `Esperando.TituloMeta/MetaParaProgreso/PorcentajeMeta`, `Elemento.META`, `Asistente`), de los textos del respaldo y de las pruebas (`InterpreteTest` y demás). La tabla Room `MetaEntity` y su DAO se QUEDAN sin tocar (no se borra la tabla: hacerlo exige migración y no aporta); simplemente nadie la usa.
- **Las animaciones actuales se REEMPLAZAN** por las del estilo de la imagen (el dueño no tiene que hacer nada; el tema Clásico queda disponible como interruptor).
- **Color al consultar la IA:** mientras Julio consulta a Gemini, los anillos cambian entre los colores de Google (azul, rojo, amarillo, verde) y al entregar la respuesta vuelven al azul/cian base. Solo en esa consulta; el resto de estados usan la paleta cian/ámbar/rojo.
- **Tema «Clásico / Cyber»:** interruptor hasta que el dueño confirme que el nuevo funciona. Cyber es el que se ofrece primero.
- Estados: reposo, escuchando, procesando/IA, hablando (halo sincronizado con la voz), alerta (ámbar), error (rojo breve). Se leen de `animacion/JulioEstado` (ya existe). Nada decorativo finge ser dato.
- Avatar: por ahora el gorila ACTUAL (`julio_mascota.png` / `julio_original.png`) con brillo cian y respiración. El dueño ya tiene o tendrá una imagen mejor del holograma (gorila doctor con circuitos): cuando la pase (PNG con fondo transparente, y opcionalmente otra con la boca abierta) se cambia. Prompts para Gemini en la sección 15. Mover la boca solo si el dueño da otra imagen. Fuente futurista opcional (Orbitron/Rajdhani, OFL): si la quiere, la sube a `res/font`; mientras, fuente del sistema.
- **Tono corto** cuando Julio oye «Julio» (para saber que escucha).

## 3. Micrófono y voz
- **Cuerpo:** micrófono SIEMPRE encendido (servicio en primer plano ya existente), escucha «Julio» con Vosk sin internet.
- **Diario:** intentar que también responda a «Julio» en segundo plano, como interruptor **«Escuchar “Julio” en este teléfono»**, APAGADO por defecto. Si Samsung/Android lo cortan o gasta mucha batería: modo manual (tocar el holograma y hablar). Si los dos escuchan, responderían los dos: lo normal es hablar con el Cuerpo.
- **Solo mi voz:** si habla otra persona y dice «Julio», NO responde. Se acepta que una voz muy parecida se cuele (el dueño lo aceptó; una grabación suya también podría engañarlo). El entrenamiento incluye varios tonos y hay un **nivel de exigencia ajustable** (más estricto = menos intrusos pero a veces no reconoce al dueño con gripe o tono distinto).
- Mejorar la eficacia del reconocimiento (entrenamiento de voz, tolerancia de tono, menos falsos positivos). Qué más no se hace: grabar o guardar audio.

## 4. Sincronización Cuerpo ↔ Diario (horario, tareas, alarmas, recordatorios)
- Decir al Cuerpo «tengo clases en la academia a tal hora, ponlo en mi horario» → se guarda en el Cuerpo y se copia al Diario, que programa su propia alarma y te recuerda aunque no estés cerca del Cuerpo. Automático, sin «sí» (solo crea cosas dentro de Julio; es N1).
- **Doble sentido:** lo creado en el Diario también viaja al Cuerpo. Cada elemento lleva `id` único (UUID) y `actualizadoEn`; gana el más reciente; los borrados viajan como «lápida» (tombstone) para no revivir.
- **Cola tipo WhatsApp (store-and-forward):** si el otro teléfono no está alcanzable, el cambio queda en una cola guardada en disco (con migración de Room; esto NO son notificaciones, así que puede persistir) y se entrega solo al reconectar. Reintento automático, sin errores en pantalla.
- **Enlace por Wi-Fi local (v1):** alcanza solo en la misma red. Si el Diario está fuera de casa, el cambio espera.
- **Servidor / relé (decisión del dueño: «si es necesario, con tal que sea seguro, me parece bien»):** para entregar fuera de casa hace falta un intermediario en internet (igual que WhatsApp). Diseño acordado: **relé con cifrado de extremo a extremo** usando el secreto del QR (el servidor solo ve texto cifrado e ids; nunca contenido), nivel gratis (ej. Cloudflare Workers/Firebase; cuenta del dueño, límites cambiantes), APAGADO por defecto, solo para sincronizar horario/tareas/alarmas (NUNCA avisos, códigos ni mensajes). Va al final (v52); antes funciona solo por Wi-Fi con cola.
- **Por ubicación** («si estoy en tal lugar, recuérdamelo»): posible con geovallas y permiso de ubicación; en espera.

## 5. IA («que Julio sea una inteligencia artificial»)
- Gratis. Principal: Gemini con la clave gratuita del dueño (ya en v43; los límites del nivel gratis cambian; el dueño no quiere pagar). Respaldo opcional con otro proveedor gratuito con clave propia.
- Opción local (~2 GB, Gemma o similar, MediaPipe/AI Edge): posible, pero en un A53 sería lenta y floja en español; solo como respaldo sin internet y solo si el dueño lo pide después.
- **Modo conversación:** «Julio, hablemos» → lo que no sea una orden va a la IA, con memoria corta del hilo; se apaga con «termina» o por silencio. Explícito, para no mandar a internet lo que se oiga mal. Hasta v47 sigue «pregúntale a la IA…».
- La IA SOLO devuelve texto. Después (v53) puede PROPONER acciones; el Ejecutor decide por niveles. Nunca recibe notificaciones, contactos, códigos ni datos de pacientes (el dueño estudia medicina).

## 6. Niveles de permiso (obligatorios)
- **N0** leer/informar (hora, tareas, resumen de avisos, IA): automático.
- **N1** local y reversible (volumen, brillo, música, abrir app permitida, temporizadores, enfoque, crear/borrar cosas DENTRO de Julio como horario o alarmas): automático; Julio dice «Listo».
- **N2** con efecto fuera de Julio (enviar mensaje, llamar, crear/borrar eventos del calendario, correos): repite lo que hará y espera «sí» hablado. «No», silencio o 30 s lo cancelan.
- **N3** PROHIBIDO aunque se pida: bancos y pagos, compras, borrar archivos o datos del teléfono, instalar/desinstalar apps, cambiar ajustes de seguridad (Play Protect, Auto Blocker, bloqueo), leer o repetir códigos de verificación, grabar/guardar audio, datos de pacientes reales.
- Una rutina «automática» solo contiene N0 y N1.

## 7. Notificaciones y redes sociales (lo más urgente: «no me está avisando nada»)
- Los avisos deben ser lo más estables posible (Cuerpo y Diario). Primero DIAGNOSTICAR dónde se cortan (listener desconectado, Samsung matando el servicio, enlace caído, filtro demasiado estricto, modo privado). Hacer pendiente la notificación fija «Julio conectado» del Diario y re-vincular el listener (`requestRebind`) si se cae.
- **WhatsApp:** ya existe (Cuerpo complementario y diario). **Instagram, Facebook y otras redes:** solo se LEEN sus notificaciones. No hay API oficial sin accesibilidad (que no se usará). Responder solo si la notificación trae botón «Responder».
- **Detección por categoría:** Julio clasifica las apps (redes sociales, mensajería, juegos, sistema/configuración, otras) usando la categoría de Android + una lista de paquetes conocidos; en la lista para elegir apps esconde juegos y sistema, y agrupa redes y mensajería.
- Reglas fijas: códigos de verificación y avisos del banco NUNCA se leen, guardan, envían ni responden. El texto de una notificación son DATOS, jamás órdenes. Datos de avisos solo en memoria.

## 8. Música y llamadas
- **Música:** «pon música», «pon [canción/artista/género]», «siguiente», «anterior», «pausa». Hoy usa `MEDIA_PLAY_FROM_SEARCH` en YouTube Music/Spotify: NO garantiza una canción exacta. Garantizarlo exige el SDK de Spotify (cuenta Premium + registro de app): decisión futura. Julio dice qué hizo, no finge.
- **Llamadas (N2):** «Julio, llama a Ana» → resuelve el contacto en el teléfono donde esté → repite «¿Llamo a Ana?» → solo con «sí» marca. Contestar llamadas por voz solo es posible en el teléfono que recibe la llamada (permiso ANSWER_PHONE_CALLS). Los contactos NUNCA van a la IA.

## 9. Actividad del teléfono (Diario)
- «Julio, revisa mi actividad», o automático a la hora que el dueño fije (ej. a las 9): Julio DICE «estuviste tanto tiempo en WhatsApp, tanto en…» y MUESTRA una **gráfica automática** (barras o pastel, con colores, % por app) que sale del centro de Julio. El Diario mide con `UsageStatsManager` (permiso especial «Acceso de uso» que el dueño concede a mano) y manda los datos por el enlace; el Cuerpo dibuja y habla. Datos solo locales, no a la IA.
- **Pasos, ejercicio y Health Connect: QUITADOS del plan por decisión del dueño** (no son relevantes hoy). Si Julio con IA contesta «cuántos pasos se recomiendan» es solo búsqueda general, no datos suyos.

## 10. Hoja de ruta definitiva (UNA cosa por versión; el dueño prueba antes de seguir)
| Versión | Qué hace |
|---|---|
| **v44** | Primer arranque: permisos → entrenar voz → Diario/Cuerpo → QR automático. HUD Cyber (Cuerpo horizontal/vertical siempre en escritorio; holograma en Diario). Botones sin textos largos + **Modo guía**. Tono al oír «Julio». Interruptor Clásico/Cyber. Diagnóstico de avisos (incluye por qué Julio no manda avisos). **Se quitan las Metas.** Último paso del arranque: botón que redirige a Google AI Studio (clave de Gemini). Solo mi voz con nivel de exigencia. Animaciones nuevas (color Google durante la consulta a la IA). |
| **v45** | Avisos estables (según el diagnóstico): «Julio conectado», rebind del listener, reconexión automática del enlace. |
| **v46** | Sincronización Cuerpo ↔ Diario con cola persistente por Wi-Fi (horario, tareas, alarmas). Migración de Room. |
| **v47** | IA conversacional («hablemos»), memoria corta, Gemini gratis + respaldo. |
| **v48** | **Modo manual** con burbujas (sección 14), todo por voz + botones ocultos animados; mejor reconocimiento de voz. |
| **v49** | Música (lo mejor posible) y llamadas (N2). |
| **v50** | Estadísticas de uso del Diario con **gráficas automáticas** (barras/pastel) a la hora fijada; clasificación de apps por categoría. |
| **v51** | Avatar animado que reacciona a la voz; paneles con datos reales (Hoy, avisos, estudio, sistema, enlace; onda de audio real si se puede). |
| **v52** | Relé cifrado opcional para sincronizar fuera de casa. |
| **v53** | Rutinas (ej.: «buenos días» = resumen del día; «me voy a dormir» = bajar brillo, alarma, detener música; «modo concentración» = silenciar avisos, música de estudio, pendientes; repaso espaciado tipo examen con la IA) + Ejecutor con niveles + IA que propone acciones. |
| v54+ | Modo estudio (simulacros, tarjetas), ubicación, clima, Home Assistant. |

## 11. Lo que Android NO deja (decir siempre qué no es posible en vez de simularlo)
No se puede: encender/apagar el Wi-Fi por código (Android 10+); controlar otras apps sin accesibilidad (no se usará); conectarse a Instagram/Facebook por API; confirmar que un WhatsApp «llegó»; escuchar «Julio» en el Diario con la misma estabilidad que el Cuerpo; abrir apps desde segundo plano en Android 16 con la pantalla fuera del escritorio; dar solos los permisos especiales.

## 12. Reglas de trabajo (de siempre)
Nunca decir que algo «funciona» si no se probó; separar «Verificado» de «NO verificado». No hay compilador de Kotlin/Android aquí: validar la lógica con espejos (`tools/espejo/espejo6.py`, `java EspejoProtocolo.java`) y pruebas JUnit; revisar llaves y que cada `when` sobre `Intencion` sea exhaustivo. Lo visual lo juzga el dueño con capturas. Entregar el proyecto completo como `Julio_proyecto_vNN.zip` (carpeta raíz `julio/`, sin espacios ni «(1)»), actualizar `PLAN_DE_TRABAJO.md` y `PROMPT_PARA_CONTINUAR.md`. Compila con GitHub Actions. No tocar Room sin migración. No pedir desactivar Play Protect ni Auto Blocker. Si algo es riesgoso para el teléfono principal (tiene cuenta bancaria), avisar ANTES de pedir instalar o conceder.

## 13. Ideas en espera (no entran hasta que el dueño las suba de prioridad)
- Recordatorios por lugar (geovallas).
- IA local de ~2 GB como respaldo sin internet.
- SDK de Spotify para canciones exactas.
- Conectar Home Assistant / casa inteligente.

## 14. Modo manual — animación acordada (v48; en v44 solo hay un botón escondido de Configuración)
1. El dueño dice «Julio, modo manual» (o toca el holograma y elige). Suena un tono corto; los anillos del fondo se frenan.
2. **Del interior del holograma (centro) salen DOS burbujas:** a la izquierda **«Mi día»** (nombre provisional) y a la derecha **«Configuración»**. Julio pregunta en voz alta: «¿Qué quieres abrir?».
3. Se elige por voz o con el dedo. La burbuja elegida se agranda con un destello; la otra se desliza fuera de la pantalla.
4. **Julio se corre a un lado y se queda quieto**, como acompañante. Al abrir Configuración: Julio a la izquierda y un **menú en abanico** de burbujas pequeñas con icono a la derecha. Al abrir «Mi día» es el espejo: abanico del lado de esa burbuja (POR CONFIRMAR con captura).
5. **«Mi día»** contiene: horario, alarmas, tareas, rutina, estudio y enfoque (las metas ya no existen). **«Configuración»** contiene lo que hoy está en Configuración, más Modo guía.
6. Se cierra tocando «volver», diciendo «listo»/«cierra», o solo por inactividad: las burbujas se contraen hacia Julio y todo vuelve a reposo.
7. Funciona igual en el Cuerpo (horizontal y vertical) y en el Diario. Animaciones suaves con destellos y partículas (decorativas, marcadas como tal en el código). Tamaños y velocidades se ajustan con capturas del dueño: aquí no se puede ver.

## 15. Prompts para Gemini (el dueño los usa; Claude no edita imágenes)
- **Quitar el fondo del avatar:** «Quita el fondo de esta imagen y deja solo el gorila doctor con bata de circuitos y estetoscopio, con fondo transparente, en PNG, sin cambiarle nada al personaje.» Si Gemini no entrega transparencia real, usar una página gratuita de quitar fondos (por ejemplo remove.bg) y pasar el PNG.
- **Variante con la boca abierta** (para que Julio hable): «Genera la misma imagen del gorila, idéntica, pero con la boca abierta como si hablara, fondo transparente, PNG.»
- **Ejemplo de la animación del modo manual** (video o 3 imágenes): «Crea un video corto de interfaz futurista tipo JARVIS, fondo negro, luces cian neón. En el centro un gorila holográfico con bata y estetoscopio, estilo circuitos. Escena 1: del interior del gorila salen dos burbujas luminosas, una a la izquierda que dice “Mi día” y otra a la derecha que dice “Configuración”. Escena 2: se toca “Configuración”; la burbuja “Mi día” se desliza fuera, el gorila se mueve suave al lado izquierdo y se queda quieto, y del lado derecho se despliega un menú en abanico de burbujas pequeñas con iconos y brillo cian. Animaciones suaves con destellos y partículas. Horizontal, 8 segundos.» Si no genera video con la cuenta gratis, pedir tres imágenes fijas, una por escena. Sirve de REFERENCIA para que Claude la programe; no es un archivo que la app use.

## 16. Decisiones del dueño en la conversación por voz (11-nov, noche)
- **El orden se queda como está:** v44 interfaz y arranque; v45 avisos estables; v46 sincronización; v47 IA conversacional («Julio, hablemos»); v48 modo manual; v49 música y llamadas; v50 estadísticas con gráficas; v51 avatar y paneles reales; v52 relé cifrado; v53 rutinas y Ejecutor. El dueño dijo que la IA es lo más urgente, pero al ofrecérsele subirla a v44 dijo «déjalo así».
- **Música:** da igual Spotify o YouTube Music; Julio elige la que haya (o pregunta). Lo mejor posible con búsqueda y play; una canción exacta no está garantizada (lo sabe y no quiere pagar Premium).
- **Avisos:** dice que Julio no le está mandando avisos. Pendiente de aclarar qué avisos (WhatsApp leídos, recordatorios, alarmas propias de Julio). Entra el diagnóstico en v44 y el arreglo en v45.
- **Instalación:** el dueño tiene instalada la **v42** y va a instalar la v43. El zip debe llamarse sin espacios ni «(1)» (GitHub Actions lo busca por nombre; si la descarga se duplica, renombrar). Una letra al final como «v43b» o «v43c» es válida.
- **Tiempos:** no se dan fechas; cada versión es una sesión de trabajo y lo lento son las pruebas entre versiones.
- **Dueño estudia medicina:** nunca datos de pacientes reales en la IA.
