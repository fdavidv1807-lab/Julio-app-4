package com.julio.asistente.ui.screens

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.EnlaceCuerpo
import com.julio.asistente.enlace.EnlaceDiario
import com.julio.asistente.enlace.Protocolo
import com.julio.asistente.enlace.Qr
import com.julio.asistente.enlace.QrImagen
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.ui.components.PanelJulio
import kotlinx.coroutines.delay

/**
 * Configuración > Enlace entre teléfonos. El Cuerpo muestra un QR (un rato) y el diario lo escanea: así quedan emparejados.
 * El diario manda al Cuerpo (por la misma Wi-Fi, cifrado) los avisos de las apps que elijas; los códigos de verificación y los
 * avisos del banco viajan sin su contenido.
 */
@Composable
fun EnlacePanel() {
    val ctx = LocalContext.current
    val rol by EnlaceAjustes.rol.collectAsStateWithLifecycle()
    val codigo by EnlaceAjustes.codigo.collectAsStateWithLifecycle()
    val estado by EnlaceAjustes.estado.collectAsStateWithLifecycle()
    val puerto by EnlaceAjustes.puertoLocal.collectAsStateWithLifecycle()
    val escritorio by EscritorioControl.activo.collectAsStateWithLifecycle()
    val leerAvisos by CuerpoAjustes.activo.collectAsStateWithLifecycle()
    var ipLocal by remember { mutableStateOf(EnlaceCuerpo.ipLocal()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        EnlaceAjustes.cargar(ctx)
        ipLocal = EnlaceCuerpo.ipLocal()
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("¿Qué hace este teléfono?", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Nada" to RolEnlace.NINGUNO,
                    "Teléfono de diario" to RolEnlace.DIARIO,
                    "Cuerpo de Julio" to RolEnlace.CUERPO,
                ).forEach { (titulo, valor) ->
                    FilterChip(
                        selected = rol == valor,
                        onClick = {
                            EnlaceAjustes.fijarRol(ctx, valor)
                            if (valor == RolEnlace.CUERPO && EnlaceAjustes.codigo.value == null) EnlaceAjustes.nuevoCodigo(ctx)
                            EnlaceCuerpo.reiniciar(ctx)
                        },
                        label = { Text(titulo) },
                    )
                }
            }

            when (rol) {
                RolEnlace.NINGUNO -> Text(
                    "Sin enlace. Elige «Cuerpo de Julio» en el teléfono del escritorio y «Teléfono de diario» en el que llevas contigo.",
                    style = MaterialTheme.typography.bodySmall,
                )
                RolEnlace.CUERPO -> CuerpoBloque(codigo, ipLocal, puerto, escritorio, leerAvisos)
                RolEnlace.DIARIO -> DiarioBloque(codigo)
            }

            if (estado.isNotBlank() && rol != RolEnlace.NINGUNO) Text(estado, style = MaterialTheme.typography.bodySmall)
            Text(
                "Los códigos de verificación y los avisos del banco nunca se envían, se leen ni se guardan: Julio solo dice que llegó uno. " +
                    "Todo viaja directo entre tus dos teléfonos por la Wi-Fi de casa, cifrado; no pasa por internet.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun CuerpoBloque(codigo: String?, ipLocal: String?, puerto: Int, escritorio: Boolean, leerAvisos: Boolean) {
    val ctx = LocalContext.current
    var verQr by remember { mutableStateOf(false) }
    // El QR contiene el secreto: se esconde solo a los 2 minutos.
    LaunchedEffect(verQr) {
        if (verQr) {
            delay(120_000L)
            verQr = false
        }
    }
    Text("1. Abre el modo escritorio (Inicio > Modo escritorio): solo recibe con él abierto.", style = MaterialTheme.typography.bodySmall,
        color = if (escritorio) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)
    if (!leerAvisos) Text(
        "La lectura de avisos está apagada: enciéndela en «Avisos del Cuerpo» o el Cuerpo no leerá lo que mande el diario.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.error,
    )
    Text("2. Muestra el QR y escanéalo con el teléfono de diario.", style = MaterialTheme.typography.bodySmall)
    OutlinedButton(onClick = { verQr = !verQr }, enabled = codigo != null) { Text(if (verQr) "Ocultar el QR" else "Mostrar el QR") }
    val secreto = EnlaceAjustes.secreto()
    if (verQr && secreto != null) {
        val contenido = remember(codigo, ipLocal, puerto) { Qr.contenido(secreto, ipLocal, if (puerto > 0) puerto else Protocolo.PUERTO) }
        val imagen = remember(contenido) { QrImagen.crear(contenido).asImageBitmap() }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Image(
                bitmap = imagen,
                contentDescription = "Código QR para emparejar",
                modifier = Modifier.size(260.dp).background(Color.White).padding(6.dp),
            )
        }
        Text("Solo para ti: quien lo escanee puede mandar avisos al Cuerpo. Se esconde solo en 2 minutos.", style = MaterialTheme.typography.bodySmall)
        Text("Si el lector no funciona, escribe este código a mano en el diario:", style = MaterialTheme.typography.bodySmall)
        Text(codigo ?: "", style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace)
    }
    TextButton(onClick = { EnlaceAjustes.nuevoCodigo(ctx); EnlaceCuerpo.reiniciar(ctx); verQr = false }) { Text("Crear un código nuevo") }
    Text(
        "Con un código nuevo, el diario deja de poder enviar hasta que lo vuelvas a escanear.",
        style = MaterialTheme.typography.bodySmall,
    )
    Text(
        if (puerto > 0) "Escuchando en ${ipLocal ?: "?"}:$puerto" else "No está escuchando (hace falta el modo escritorio abierto).",
        style = MaterialTheme.typography.bodySmall,
    )
}

@Composable
private fun DiarioBloque(codigo: String?) {
    val ctx = LocalContext.current
    val ipManual by EnlaceAjustes.ipManual.collectAsStateWithLifecycle()
    val permitidas by EnlaceAjustes.permitidas.collectAsStateWithLifecycle()
    val diagnostico by EnlaceAjustes.diagnostico.collectAsStateWithLifecycle()
    var mensaje by remember { mutableStateOf<String?>(null) }
    var texto by rememberSaveable { mutableStateOf("") }
    var ip by rememberSaveable(ipManual) { mutableStateOf(ipManual) }
    var verApps by remember { mutableStateOf(false) }
    var acceso by remember { mutableStateOf(CuerpoAjustes.accesoANotificaciones(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { acceso = CuerpoAjustes.accesoANotificaciones(ctx) }

    Text("1. Acceso a notificaciones", style = MaterialTheme.typography.labelLarge)
    Text(
        if (acceso) "Concedido." else "Falta. Sin esto el diario no ve tus notificaciones.",
        style = MaterialTheme.typography.bodySmall,
        color = if (acceso) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
    )
    if (!acceso) {
        Button(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
            shape = MaterialTheme.shapes.small,
        ) { Text("Abrir «Acceso a notificaciones»") }
        Text(
            "Si «Julio» aparece en gris: Ajustes > Aplicaciones > Julio > ⋮ (arriba a la derecha) > «Permitir ajustes restringidos», y vuelve a intentarlo.",
            style = MaterialTheme.typography.bodySmall,
        )
    }

    Text("2. Emparejar con el Cuerpo", style = MaterialTheme.typography.labelLarge)
    if (codigo != null) Text("Emparejado.", style = MaterialTheme.typography.bodySmall)
    Button(
        onClick = {
            val opciones = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(ctx, opciones).startScan()
                .addOnSuccessListener { b ->
                    mensaje = if (EnlaceAjustes.usarQr(ctx, b.rawValue.orEmpty())) "Emparejado. Ahora toca «Probar conexión»." else "Ese QR no es de Julio."
                }
                .addOnCanceledListener { mensaje = "Escaneo cancelado." }
                .addOnFailureListener { e -> mensaje = "No pude abrir el lector de QR: ${e.message ?: e.javaClass.simpleName}. Escribe el código a mano." }
        },
        shape = MaterialTheme.shapes.small,
    ) { Text(if (codigo == null) "Escanear el QR del Cuerpo" else "Escanear otro QR") }
    OutlinedTextField(
        value = texto,
        onValueChange = { texto = it.take(80) },
        label = { Text("O escribe el código a mano") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    TextButton(onClick = { mensaje = if (EnlaceAjustes.usarQr(ctx, texto)) "Emparejado." else "Ese código no es válido: son 16 letras y números."; texto = "" }) {
        Text("Emparejar con este código")
    }
    if (codigo != null) TextButton(onClick = { EnlaceAjustes.borrarCodigo(ctx); mensaje = "Emparejamiento borrado." }) { Text("Olvidar el emparejamiento") }

    Text("3. Probar conexión", style = MaterialTheme.typography.labelLarge)
    Button(onClick = { EnlaceDiario.diagnosticar(ctx) }, enabled = codigo != null, shape = MaterialTheme.shapes.small) { Text("Probar conexión") }
    diagnostico.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }

    Text("4. Qué apps se reenvían (solo las que enciendas)", style = MaterialTheme.typography.labelLarge)
    TextButton(onClick = { verApps = !verApps }) { Text(if (verApps) "Ocultar apps" else "Elegir apps (${permitidas.size} elegidas)") }
    if (verApps) AppsReenviadas(permitidas)

    Text("Opcional: IP del Cuerpo (solo si no se encuentran solos)", style = MaterialTheme.typography.bodyMedium)
    OutlinedTextField(
        value = ip,
        onValueChange = { ip = it.take(21) },
        label = { Text("Ej.: 192.168.1.25") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    TextButton(onClick = { mensaje = if (EnlaceAjustes.fijarIpManual(ctx, ip)) "IP guardada." else "Esa IP no es válida." }) { Text("Guardar IP") }
    Text(
        "Para que Samsung no cierre a Julio: Ajustes > Aplicaciones > Julio > Batería > «Sin restricciones».",
        style = MaterialTheme.typography.bodySmall,
    )
    mensaje?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
}

@Composable
private fun AppsReenviadas(permitidas: Set<String>) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }
    Text("Se reenvían los avisos de las apps con el interruptor encendido.", style = MaterialTheme.typography.bodySmall)
    apps.forEach { (nombre, paquete) ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(nombre, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = paquete in permitidas, onCheckedChange = { EnlaceAjustes.permitir(ctx, paquete, it) })
        }
    }
}
