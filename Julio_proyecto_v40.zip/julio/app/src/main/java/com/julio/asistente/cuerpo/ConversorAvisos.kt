package com.julio.asistente.cuerpo

import android.app.Notification
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import java.util.UUID

/**
 * Convierte una notificación de Android en un [Aviso] listo para leerse (o enviarse): filtra lo que no es un aviso, deja solo las
 * apps elegidas, dice SOLO los mensajes nuevos de cada chat y quita el contenido de códigos y bancos. Lo usan el listener del
 * Cuerpo y el del diario. WhatsApp vuelve a publicar la misma notificación con cada mensaje y trae los anteriores; por eso se
 * compara con lo ya avisado ([SeguimientoChats]). Los mensajes tuyos (respuestas) no se leen.
 */
class ConversorAvisos(private val contexto: Context) {
    private val dedupe = Deduplicador(ventanaMs = 60_000L)
    private val seguimiento = SeguimientoChats()

    /** null = no hay nada que avisar (filtrada, repetida o sin mensajes nuevos). */
    fun convertir(sbn: StatusBarNotification, permitidas: Set<String>): Aviso? {
        val n = sbn.notification ?: return null
        val extras = n.extras
        val tituloExtra = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val textoExtra = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val mensajes = leerMensajes(extras)
        val cruda = NotificacionCruda(
            paquete = sbn.packageName.orEmpty(),
            titulo = tituloExtra,
            texto = if (mensajes.isNotEmpty()) mensajes.last().texto else textoExtra,
            categoria = n.category,
            enCurso = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0,
            resumenGrupo = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0,
        )
        if (FiltroAvisos.motivoDescarte(cruda, contexto.packageName, permitidas) != null) return null
        val ahora = System.currentTimeMillis()
        val app = nombreDeApp(cruda.paquete)
        val aviso = if (mensajes.isNotEmpty()) {
            avisoDeMensajes(sbn, extras, mensajes, app, tituloExtra, ahora) ?: return null
        } else {
            if (dedupe.repetido(cruda.paquete, tituloExtra, textoExtra, ahora)) return null
            Aviso(UUID.randomUUID().toString(), ahora, app, cruda.paquete, tituloExtra, textoExtra, chat = sbn.key.orEmpty())
        }
        return Sensibles.sanear(aviso)
    }

    private fun avisoDeMensajes(
        sbn: StatusBarNotification,
        extras: Bundle?,
        mensajes: List<MensajeCrudo>,
        app: String,
        tituloExtra: String,
        ahora: Long,
    ): Aviso? {
        val clave = sbn.key.orEmpty()
        val nuevos = seguimiento.nuevos(clave, mensajes, ahora)
        if (nuevos.isEmpty()) return null
        val ultimo = nuevos.last()
        val esGrupo = extras?.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) == true
        val tituloConversacion = extras?.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()
        val grupo = if (esGrupo) tituloConversacion.ifBlank { tituloExtra } else ""
        // En un chat de una persona el título de la notificación es su nombre; si falta, el del mensaje.
        val remitente = if (esGrupo) ultimo.remitente else tituloExtra.ifBlank { ultimo.remitente }
        val tipo = Sensibles.clasificar(app, sbn.packageName.orEmpty(), tituloExtra, nuevos.joinToString(" ") { it.texto })
        return Aviso(
            id = UUID.randomUUID().toString(),
            tiempo = ahora,
            app = app,
            paquete = sbn.packageName.orEmpty(),
            titulo = remitente,
            texto = ultimo.texto,
            tipo = tipo,
            chat = clave,
            remitente = remitente,
            grupo = grupo,
            cantidad = nuevos.size,
            mensajeria = true,
        )
    }

    /** Mensajes de la notificación (estilo mensajería), sin los tuyos. Vacío si la app no usa ese estilo. */
    @Suppress("DEPRECATION")
    private fun leerMensajes(extras: Bundle?): List<MensajeCrudo> {
        val arreglo = extras?.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return emptyList()
        return Notification.MessagingStyle.Message.getMessagesFromBundleArray(arreglo).mapNotNull { m ->
            val nombre: String = if (Build.VERSION.SDK_INT >= 28) {
                val persona = m.senderPerson ?: return@mapNotNull null // sin remitente = mensaje tuyo
                persona.name?.toString().orEmpty()
            } else {
                m.sender?.toString() ?: return@mapNotNull null
            }
            MensajeCrudo(m.text?.toString().orEmpty(), m.timestamp, nombre)
        }
    }

    private fun nombreDeApp(paquete: String): String = try {
        val pm = contexto.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(paquete, 0)).toString()
    } catch (e: Exception) {
        paquete.substringAfterLast('.')
    }
}
