package com.julio.asistente.ui.screens

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.julio.asistente.cuerpo.Aviso
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.cuerpo.CuerpoAvisos
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.EnlaceCuerpo
import com.julio.asistente.enlace.EnlaceDiario
import com.julio.asistente.enlace.Protocolo
import com.julio.asistente.enlace.Qr
import com.julio.asistente.enlace.QrImagen
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.ui.components.PanelJulio
import kotlinx.coroutines.delay
import java.util.UUID

/**
 * Configuración > Notificaciones y enlace (v41): TODO lo de avisos en una sola sección, según lo que haga este teléfono.
 * Cuerpo: leer avisos en voz alta, modo privado, apps, y el QR para emparejar el teléfono de diario.
 * Diario: acceso a notificaciones, escanear el QR, probar la conexión y elegir qué apps se reenvían.
 * Los códigos de verificación y los avisos del banco nunca se leen, se envían ni se guardan.
 */
@Composable
fun NotificacionesPanel() {
    val ctx = LocalContext.current
    val rol by EnlaceAjustes.rol.collectAsStateWithLifecycle()
    val estado by EnlaceAjustes.estado.collectAsStateWithLifecycle()
    var acceso by remember { mutableStateOf(CuerpoAjustes.accesoANotificaciones(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        EnlaceAjustes.cargar(ctx)
        CuerpoAjustes.cargar(ctx)
        acceso = CuerpoAjustes.accesoANotificaciones(ctx)
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Nada" to RolEnlace.NINGUNO, "Cuerpo (escritorio)" to RolEnlace.CUERPO, "Teléfono de diario" to RolEnlace.DIARIO)
                    .forEach { (titulo, valor) ->
                        FilterChip(
                            selected = rol == valor,
                            onClick = {
                                EnlaceAjustes.fijarRol(ctx, valor)
                                if (valor == RolEnlace.CUERPO && EnlaceAjustes.codigo.value == null) EnlaceAjustes.nuevoCodigo(ctx)
                                EnlaceCuerpo.reiniciar(ctx)
                            },
                            label = { Text(titulo) },
                        )
                    }
            }
            when (rol) {
                RolEnlace.NINGUNO -> Text(
                    "Elige «Cuerpo» en el teléfono del escritorio y «Teléfono de diario» en el que llevas contigo.",
                    style = MaterialTheme.typography.bodySmall,
                )
                RolEnlace.CUERPO -> BloqueCuerpo(acceso)
                RolEnlace.DIARIO -> BloqueDiario(acceso)
            }
            if (rol != RolEnlace.NINGUNO) BloqueSincronizacionYDiagnostico(rol)
            if (estado.isNotBlank() && rol != RolEnlace.NINGUNO) Text(estado, style = MaterialTheme.typography.bodySmall)
            Text(
                "Códigos de verificación y avisos del banco: nunca se leen, se envían ni se guardan. Todo viaja directo entre tus teléfonos, sin internet.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

/** v52: sincronización de horario, tareas y alarmas con el otro teléfono, y el diagnóstico de por qué no llegan avisos. */
@Composable
private fun BloqueSincronizacionYDiagnostico(rol: RolEnlace) {
    val ctx = LocalContext.current
    val sincronizar by com.julio.asistente.sync.SyncAjustes.activo.collectAsStateWithLifecycle()
    val estadoSync by com.julio.asistente.sync.SyncAjustes.estado.collectAsStateWithLifecycle()
    val enCola by com.julio.asistente.sync.SyncAjustes.pendientes.collectAsStateWithLifecycle()
    var lineas by remember { mutableStateOf<List<com.julio.asistente.avisos.LineaDiagnostico>>(emptyList()) }

    FilaInterruptor("Sincronizar horario, tareas y alarmas con el otro teléfono", sincronizar) {
        com.julio.asistente.sync.SyncAjustes.fijarActivo(ctx, it)
    }
    Text(
        estadoSync + if (enCola > 0) " En cola: $enCola." else "",
        style = MaterialTheme.typography.bodySmall,
    )
    if (rol == RolEnlace.DIARIO) {
        OutlinedButton(onClick = { com.julio.asistente.sync.SyncDiario.sincronizarYa(ctx) }, enabled = sincronizar) { Text("Sincronizar ahora") }
    }
    BloqueRele()
    OutlinedButton(onClick = { lineas = com.julio.asistente.avisos.DiagnosticoAvisosAndroid.diagnosticar(ctx) }) { Text("Diagnóstico de avisos") }
    lineas.forEach {
        Text(
            when (it.gravedad) {
                com.julio.asistente.avisos.Gravedad.OK -> "✓ "
                com.julio.asistente.avisos.Gravedad.AVISO -> "! "
                com.julio.asistente.avisos.Gravedad.FALLA -> "✗ "
            } + it.texto,
            style = MaterialTheme.typography.bodySmall,
            color = if (it.gravedad == com.julio.asistente.avisos.Gravedad.FALLA) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
        )
    }
}

/**
 * Relé cifrado (v57): sincronizar horario, tareas y alarmas FUERA de casa. Apagado de fábrica. Necesita una base de datos gratis de
 * Firebase (los pasos están en GUIA_RELE.md). Todo viaja cifrado con el secreto del QR; nunca avisos, códigos ni el uso del teléfono.
 */
@Composable
private fun BloqueRele() {
    val ctx = LocalContext.current
    val alcance = rememberCoroutineScope()
    val activo by com.julio.asistente.sync.ReleAjustes.activo.collectAsStateWithLifecycle()
    val urlGuardada by com.julio.asistente.sync.ReleAjustes.url.collectAsStateWithLifecycle()
    var url by rememberSaveable(urlGuardada) { mutableStateOf(urlGuardada) }
    var resultado by remember { mutableStateOf("") }

    Text("Fuera de casa (relé cifrado)", style = MaterialTheme.typography.titleSmall)
    Text(
        "Opcional y apagado. Sirve para que el horario, las tareas y las alarmas se sincronicen aunque el diario no esté en tu Wi-Fi. " +
            "Pasan por una base de datos gratis de Firebase TUYA, siempre cifrados con el secreto del QR: el servidor solo ve texto ilegible. " +
            "Nunca viajan avisos, códigos ni el uso del teléfono. Pasos para crearla: archivo GUIA_RELE.md del proyecto.",
        style = MaterialTheme.typography.bodySmall,
    )
    FilaInterruptor("Usar el relé fuera de casa", activo) { com.julio.asistente.sync.ReleAjustes.fijar(ctx, it, url) }
    OutlinedTextField(
        value = url,
        onValueChange = { url = it.take(150) },
        label = { Text("Dirección de tu Firebase (https://…firebaseio.com)") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            if (!com.julio.asistente.sync.ReleLogica.urlValida(url)) {
                resultado = "Esa dirección no es de Firebase (debe empezar con https:// y terminar en firebaseio.com o firebasedatabase.app)."
            } else {
                com.julio.asistente.sync.ReleAjustes.fijar(ctx, activo, url)
                resultado = "Guardada."
            }
        }) { Text("Guardar") }
        OutlinedButton(onClick = {
            resultado = "Probando…"
            alcance.launch {
                val r = withContext(Dispatchers.IO) { com.julio.asistente.sync.ReleCliente.probar(url) }
                resultado = r ?: "✓ El relé funciona (se pudo escribir, leer y borrar)."
            }
        }) { Text("Probar") }
    }
    if (resultado.isNotEmpty()) Text(resultado, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun FilaInterruptor(texto: String, activo: Boolean, alCambiar: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(texto, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = activo, onCheckedChange = alCambiar)
    }
}

/** Una línea con el estado del permiso y, si falta, el botón para darlo (con la ayuda de «ajustes restringidos»). */
@Composable
private fun AccesoANotificaciones(acceso: Boolean) {
    val ctx = LocalContext.current
    if (acceso) {
        Text("✓ Acceso a notificaciones", style = MaterialTheme.typography.bodySmall)
        return
    }
    Text("Falta el acceso a notificaciones.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
    Button(
        onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
        shape = MaterialTheme.shapes.small,
    ) { Text("Dar acceso") }
    Text(
        "Si «Julio» sale en gris: Ajustes > Aplicaciones > Julio > ⋮ > «Permitir ajustes restringidos».",
        style = MaterialTheme.typography.bodySmall,
    )
}

@Composable
private fun BloqueCuerpo(acceso: Boolean) {
    val ctx = LocalContext.current
    val activo by CuerpoAjustes.activo.collectAsStateWithLifecycle()
    val privado by CuerpoAjustes.privado.collectAsStateWithLifecycle()
    val permitidas by CuerpoAjustes.permitidas.collectAsStateWithLifecycle()
    val codigo by EnlaceAjustes.codigo.collectAsStateWithLifecycle()
    val puerto by EnlaceAjustes.puertoLocal.collectAsStateWithLifecycle()
    val escritorio by EscritorioControl.activo.collectAsStateWithLifecycle()
    val enEspera by CuerpoAvisos.pendientes.collectAsStateWithLifecycle()
    var ipLocal by remember { mutableStateOf(EnlaceCuerpo.ipLocal()) }
    var verApps by remember { mutableStateOf(false) }
    var verQr by remember { mutableStateOf(false) }
    var mas by remember { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { ipLocal = EnlaceCuerpo.ipLocal() }
    // El QR contiene el secreto: se esconde solo a los 2 minutos.
    LaunchedEffect(verQr) {
        if (verQr) {
            delay(120_000L)
            verQr = false
        }
    }

    FilaInterruptor("Leer avisos en voz alta", activo) { CuerpoAjustes.fijarActivo(ctx, it) }
    if (activo) FilaInterruptor("Modo privado (solo dice la app)", privado) { CuerpoAjustes.alternarPrivado(ctx) }
    AccesoANotificaciones(acceso)
    TextButton(onClick = { verApps = !verApps }) { Text(if (verApps) "Ocultar apps" else "Apps que se leen (${permitidas.size})") }
    if (verApps) ListaApps(permitidas) { paquete, leer -> CuerpoAjustes.permitir(ctx, paquete, leer) }

    Text("Emparejar con el teléfono de diario", style = MaterialTheme.typography.labelLarge)
    OutlinedButton(onClick = { verQr = !verQr }, enabled = codigo != null) { Text(if (verQr) "Ocultar el QR" else "Mostrar el QR") }
    val secreto = EnlaceAjustes.secreto()
    if (verQr && secreto != null) {
        val contenido = remember(codigo, ipLocal, puerto) { Qr.contenido(secreto, ipLocal, if (puerto > 0) puerto else Protocolo.PUERTO) }
        val imagen = remember(contenido) { QrImagen.crear(contenido).asImageBitmap() }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            Image(imagen, "Código QR para emparejar", Modifier.size(260.dp).background(Color.White).padding(6.dp))
        }
        Text("Escanéalo con el teléfono de diario. Se esconde solo en 2 minutos.", style = MaterialTheme.typography.bodySmall)
        Text("O escribe a mano:  ${codigo ?: ""}", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
    }
    Text(
        when {
            !escritorio -> "Abre el modo escritorio para recibir avisos."
            puerto > 0 -> "Escuchando en ${ipLocal ?: "?"}:$puerto"
            else -> "No está escuchando."
        },
        style = MaterialTheme.typography.bodySmall,
        color = if (escritorio) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
    )
    if (enEspera > 0) Text("Avisos por leer: $enEspera", style = MaterialTheme.typography.bodySmall)

    TextButton(onClick = { mas = !mas }) { Text(if (mas) "Menos" else "Más") }
    if (mas) {
        OutlinedButton(
            onClick = {
                CuerpoAvisos.recibir(Aviso(UUID.randomUUID().toString(), System.currentTimeMillis(), "Julio", "com.julio.asistente", "Prueba", "Este es un aviso de prueba."))
            },
        ) { Text("Crear un aviso de prueba") }
        OutlinedButton(onClick = { EnlaceAjustes.nuevoCodigo(ctx); EnlaceCuerpo.reiniciar(ctx); verQr = false }) { Text("Crear un código nuevo") }
        Text("Con un código nuevo, el diario deja de enviar hasta que escanee el QR otra vez.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun BloqueDiario(acceso: Boolean) {
    val ctx = LocalContext.current
    val codigo by EnlaceAjustes.codigo.collectAsStateWithLifecycle()
    val ipManual by EnlaceAjustes.ipManual.collectAsStateWithLifecycle()
    val permitidas by EnlaceAjustes.permitidas.collectAsStateWithLifecycle()
    val diagnostico by EnlaceAjustes.diagnostico.collectAsStateWithLifecycle()
    val permitirRespuestas by EnlaceAjustes.permitirRespuestas.collectAsStateWithLifecycle()
    var mensaje by remember { mutableStateOf<String?>(null) }
    var texto by rememberSaveable { mutableStateOf("") }
    var ip by rememberSaveable(ipManual) { mutableStateOf(ipManual) }
    var verApps by remember { mutableStateOf(false) }
    var mas by remember { mutableStateOf(false) }

    AccesoANotificaciones(acceso)
    Button(
        onClick = {
            val opciones = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(ctx, opciones).startScan()
                .addOnSuccessListener { b ->
                    mensaje = if (EnlaceAjustes.usarQr(ctx, b.rawValue.orEmpty())) "Emparejado. Toca «Probar conexión»." else "Ese QR no es de Julio."
                }
                .addOnCanceledListener { mensaje = "Escaneo cancelado." }
                .addOnFailureListener { e -> mensaje = "No pude abrir el lector de QR: ${e.message ?: e.javaClass.simpleName}. Escribe el código en «Más»." }
        },
        shape = MaterialTheme.shapes.small,
    ) { Text(if (codigo == null) "Escanear el QR del Cuerpo" else "Escanear otro QR") }
    if (codigo != null) Text("✓ Emparejado", style = MaterialTheme.typography.bodySmall)

    Button(onClick = { EnlaceDiario.diagnosticar(ctx) }, enabled = codigo != null, shape = MaterialTheme.shapes.small) { Text("Probar conexión") }
    diagnostico.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }

    FilaInterruptor("Permitir que el Cuerpo responda mensajes por mí", permitirRespuestas) { EnlaceAjustes.fijarPermitirRespuestas(ctx, it) }
    if (permitirRespuestas) Text(
        "Solo responde a chats que acabas de recibir, hasta 3 minutos después, y únicamente si dices «sí» en el Cuerpo.",
        style = MaterialTheme.typography.bodySmall,
    )
    TextButton(onClick = { verApps = !verApps }) { Text(if (verApps) "Ocultar apps" else "Apps que se reenvían (${permitidas.size})") }
    if (verApps) ListaApps(permitidas) { paquete, enviar -> EnlaceAjustes.permitir(ctx, paquete, enviar) }

    TextButton(onClick = { mas = !mas }) { Text(if (mas) "Menos" else "Más") }
    if (mas) {
        OutlinedTextField(
            value = texto,
            onValueChange = { texto = it.take(80) },
            label = { Text("Código a mano (si el QR no sirve)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        TextButton(onClick = { mensaje = if (EnlaceAjustes.usarQr(ctx, texto)) "Emparejado." else "Código no válido: son 16 letras y números."; texto = "" }) {
            Text("Emparejar con este código")
        }
        OutlinedTextField(
            value = ip,
            onValueChange = { ip = it.take(21) },
            label = { Text("IP del Cuerpo (si no se encuentran solos)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        TextButton(onClick = { mensaje = if (EnlaceAjustes.fijarIpManual(ctx, ip)) "IP guardada." else "Esa IP no es válida." }) { Text("Guardar IP") }
        if (codigo != null) TextButton(onClick = { EnlaceAjustes.borrarCodigo(ctx); mensaje = "Emparejamiento borrado." }) { Text("Olvidar el emparejamiento") }
        Text("Para que Samsung no cierre a Julio: Ajustes > Aplicaciones > Julio > Batería > «Sin restricciones».", style = MaterialTheme.typography.bodySmall)
    }
    mensaje?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
}

/** Apps con un interruptor: encendido = se leen (Cuerpo) o se reenvían (diario). Ninguna viene encendida salvo lo que se eligió al preparar. */
@Composable
private fun ListaApps(permitidas: Set<String>, alCambiar: (String, Boolean) -> Unit) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }
    apps.forEach { (nombre, paquete) -> FilaInterruptor(nombre, paquete in permitidas) { alCambiar(paquete, it) } }
}
