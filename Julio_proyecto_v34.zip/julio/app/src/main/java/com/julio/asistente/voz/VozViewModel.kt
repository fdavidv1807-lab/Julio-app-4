package com.julio.asistente.voz

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.animacion.JulioEstado
import com.julio.asistente.comandos.Asistente
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import java.util.Locale

enum class EstadoVoz { REPOSO, ESCUCHANDO, PROCESANDO, RESPONDIENDO }

data class Mensaje(val deUsuario: Boolean, val texto: String)

class VozViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _estado = MutableStateFlow(EstadoVoz.REPOSO)
    val estado: StateFlow<EstadoVoz> = _estado.asStateFlow()

    private val _llamada = MutableStateFlow(false)
    /** Modo llamada: el micrófono se reabre solo después de que Julio habla; con 8 s de silencio se cuelga. */
    val llamada: StateFlow<Boolean> = _llamada.asStateFlow()

    private val _transcripcion = MutableStateFlow("")
    val transcripcion: StateFlow<String> = _transcripcion.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _historial = MutableStateFlow<List<Mensaje>>(emptyList())
    /** Solo de esta sesión: se borra al cerrar la app (no se guarda en el teléfono). */
    val historial: StateFlow<List<Mensaje>> = _historial.asStateFlow()

    private val _nivel = MutableStateFlow(0f)
    val nivel: StateFlow<Float> = _nivel.asStateFlow()

    private val _hablarRespuestas = MutableStateFlow(true)
    val hablarRespuestas: StateFlow<Boolean> = _hablarRespuestas.asStateFlow()

    private val asistente = Asistente(app)
    private val habla = Habla(app)
    private val prefs = app.getSharedPreferences("julio_voz", android.content.Context.MODE_PRIVATE)

    // ----- Estado único de Julio (animaciones) -----
    init {
        viewModelScope.launch { _estado.collect { JulioEstado.ponerVoz(it) } }
        viewModelScope.launch { _error.collect { if (it != null) JulioEstado.error() } }
    }

    /** Volumen real de la voz de Julio (0 a 1) si habla con Dave; -1 si no hay dato. Anima la boca y el orbe. */
    fun nivelHabla(): Float = habla.nivelHabla()

    // ----- Interrupción: Julio habla y tú lo cortas con una palabra clave o tocando el orbe -----
    private var vigiando = false
    private var interrupcion: Job? = null

    private fun puedeEscucharAhora(): Boolean {
        if (!permisoMicrofono()) return false
        return if (_usarVosk.value) VoskModelo.ruta(app) != null else SpeechRecognizer.isRecognitionAvailable(app)
    }

    private fun iniciarVigia() {
        if (!_usarVosk.value || !permisoMicrofono()) return
        val ruta = VoskModelo.ruta(app) ?: return
        vigiando = true
        vosk.vigilarPalabrasClave(ruta) { interrumpir() }
    }

    private fun detenerVigia() {
        if (vigiando) {
            vigiando = false
            vosk.detener()
        }
    }

    /** Habla con el vigía de interrupción encendido solo mientras suena la voz. */
    private fun hablarConVigia(texto: String, alTerminar: () -> Unit) {
        iniciarVigia()
        habla.hablar(texto) {
            detenerVigia()
            alTerminar()
        }
    }

    /**
     * Corta a Julio: la voz baja a cero en ~0.2 s, el orbe pasa a «escuchando» al instante y enseguida te escucha.
     * Sin micrófono o sin reconocimiento disponible, solo se calla.
     */
    fun interrumpir() {
        if (_estado.value != EstadoVoz.RESPONDIENDO) return
        vigiando = false
        habla.desvanecer(200L)
        if (!puedeEscucharAhora()) {
            vosk.detener()
            _estado.value = EstadoVoz.REPOSO
            return
        }
        _estado.value = EstadoVoz.ESCUCHANDO
        interrupcion?.cancel()
        interrupcion = viewModelScope.launch {
            delay(220L)
            escuchar(desdeInterrupcion = true)
        }
    }

    // ----- Modo llamada -----
    private var reabrir: Job? = null
    private var vigilanteSilencio: Job? = null
    private var oyoVoz = false

    /** Entra al modo llamada y empieza a escuchar. Se llama con el permiso del micrófono ya concedido. */
    fun iniciarLlamada() {
        _llamada.value = true
        escuchar()
        // Si no pudo empezar a escuchar (sin permiso, sin modelo...), no se queda «en llamada».
        if (_estado.value != EstadoVoz.ESCUCHANDO) terminarLlamada()
    }

    /** Sale del modo llamada (no toca lo que Julio esté haciendo). */
    private fun terminarLlamada() {
        _llamada.value = false
        reabrir?.cancel()
        vigilanteSilencio?.cancel()
    }

    /** Pasaron 8 segundos sin que hablaras: se cuelga en silencio (sin mensaje de error) y Julio vuelve a reposo. */
    private fun colgarPorSilencio() {
        terminarLlamada()
        _nivel.value = 0f
        _estado.value = EstadoVoz.REPOSO
    }

    /** Si la app pasa al fondo o sales de la pantalla de voz, la llamada se cuelga: el micrófono no queda abierto. */
    fun salirDeLlamada() {
        if (_llamada.value) detener()
    }

    /**
     * Julio ya terminó de responder (hablando o, si no habla, escribiendo en pantalla).
     * En llamada: una pausa corta (para que no se oiga a sí mismo) y el micrófono se vuelve a abrir.
     * Fuera de llamada: queda en reposo, como siempre.
     */
    private fun alTerminarDeHablar() {
        if (_llamada.value && puedeEscucharAhora()) {
            reabrir?.cancel()
            reabrir = viewModelScope.launch {
                delay(PAUSA_ANTI_ECO_MS)
                if (_llamada.value && _estado.value != EstadoVoz.ESCUCHANDO) escuchar(desdeInterrupcion = true)
            }
        } else {
            terminarLlamada()
            _estado.value = EstadoVoz.REPOSO
        }
    }

    // ----- Voz de Julio (selector, tono y velocidad) -----
    val ajustesVoz: StateFlow<AjustesVoz> = habla.ajustes
    fun vocesDisponibles(): List<VozInfo> = habla.voces()
    fun elegirVoz(nombre: String?) = habla.elegirVoz(nombre)
    fun cambiarTono(t: Float) = habla.cambiarTono(t)
    fun cambiarVelocidad(v: Float) = habla.cambiarVelocidad(v)
    fun probarVoz() {
        if (_estado.value == EstadoVoz.ESCUCHANDO || _estado.value == EstadoVoz.PROCESANDO) return
        _estado.value = EstadoVoz.RESPONDIENDO
        hablarConVigia("Hola, soy Julio. Así sueno con esta voz. ¿En qué te ayudo?") { _estado.value = EstadoVoz.REPOSO }
    }

    // ----- Voz neuronal Dave (Piper es_ES-davefx-medium, con sherpa-onnx) -----
    val piperEstado: StateFlow<EstadoPiper> = PiperModelo.estado
    val usarPiper: StateFlow<Boolean> = habla.usarPiper
    val errorPiper: StateFlow<String?> = habla.errorPiper
    val piperDisponible: Boolean get() = habla.piperDisponible
    fun descargarPiper() = PiperModelo.descargar(app)
    fun instalarPiperDesdeArchivos(archivos: List<android.net.Uri>) = PiperModelo.instalarDesdeArchivos(app, archivos)
    fun reintentarPiper() = PiperModelo.reintentar(app)
    fun cancelarDescargaPiper() = PiperModelo.cancelar()
    fun alternarPiper(activar: Boolean) = habla.activarPiper(activar)
    fun eliminarPiper() {
        habla.activarPiper(false)
        habla.olvidarPiper()
        PiperModelo.eliminar(app)
    }

    init {
        // Al terminar la descarga, la voz neuronal se activa sola.
        viewModelScope.launch {
            var anterior: EstadoPiper? = null
            PiperModelo.estado.collect { e ->
                if (e is EstadoPiper.Lista && anterior is EstadoPiper.Descargando) habla.activarPiper(true)
                anterior = e
            }
        }
    }

    // ----- Reconocimiento de voz SIN internet (Vosk, modelo en español dentro del teléfono) -----
    private val vosk = ReconocedorVosk()
    val voskEstado: StateFlow<EstadoVosk> = VoskModelo.estado
    val voskDiagnostico: StateFlow<DiagnosticoVosk> = vosk.diagnostico
    private val _usarVosk = MutableStateFlow(prefs.getBoolean("usarVosk", false))
    val usarVosk: StateFlow<Boolean> = _usarVosk.asStateFlow()
    fun alternarVosk(activar: Boolean) {
        _usarVosk.value = activar
        prefs.edit().putBoolean("usarVosk", activar).apply()
        if (!activar) vosk.detener()
    }
    fun descargarVosk() = VoskModelo.descargar(app)
    fun instalarVoskDesdeZip(archivo: android.net.Uri) = VoskModelo.instalarDesdeZip(app, archivo)
    fun cancelarVosk() = VoskModelo.cancelar()
    fun eliminarVosk() {
        alternarVosk(false)
        vosk.liberar()
        VoskModelo.eliminar(app)
    }

    init {
        VoskModelo.iniciar(app)
        // Al terminar de instalar el modelo, el reconocimiento sin internet se activa solo.
        viewModelScope.launch {
            var anterior: EstadoVosk? = null
            VoskModelo.estado.collect { e ->
                if (e is EstadoVosk.Listo && anterior is EstadoVosk.Instalando) alternarVosk(true)
                anterior = e
            }
        }
    }

    // ----- Color del orbe según lo que hace -----
    private val _orbeColor = MutableStateFlow(prefs.getBoolean("orbeColor", true))
    val orbeColor: StateFlow<Boolean> = _orbeColor.asStateFlow()
    fun alternarOrbeColor() {
        _orbeColor.value = !_orbeColor.value
        prefs.edit().putBoolean("orbeColor", _orbeColor.value).apply()
    }

    // ----- Saludo al abrir -----
    private val _saludoActivo = MutableStateFlow(prefs.getBoolean("saludo", true))
    val saludoActivo: StateFlow<Boolean> = _saludoActivo.asStateFlow()
    fun alternarSaludo() {
        _saludoActivo.value = !_saludoActivo.value
        prefs.edit().putBoolean("saludo", _saludoActivo.value).apply()
    }

    init {
        viewModelScope.launch { saludarSiCorresponde() }
    }

    private suspend fun saludarSiCorresponde() {
        if (!_saludoActivo.value) return
        val ahora = System.currentTimeMillis()
        if (ahora - ultimoSaludo < 30 * 60_000L) return
        ultimoSaludo = ahora
        val texto = try { asistente.saludo() } catch (e: Exception) { return }
        _historial.value = (_historial.value + Mensaje(false, texto)).takeLast(40)
        if (_hablarRespuestas.value && habla.disponible) {
            _estado.value = EstadoVoz.RESPONDIENDO
            hablarConVigia(texto) { if (_estado.value == EstadoVoz.RESPONDIENDO) _estado.value = EstadoVoz.REPOSO }
        }
    }

    companion object {
        /** Para no repetir el saludo cada vez que se recrea la pantalla: como mucho uno cada 30 minutos. */
        private var ultimoSaludo = 0L

        /** Pausa entre que Julio termina de hablar y se reabre el micrófono (evita oír su propia voz). */
        private const val PAUSA_ANTI_ECO_MS = 350L
        /** Frases seguidas de voces ajenas que se ignoran antes de dejar de esperar. */
        private const val MAX_VOCES_AJENAS = 3
        /** Pausa antes de volver a vigilar «Julio» tras una conversación (evita que oiga el final de la respuesta). */
        private const val DESPERTAR_PAUSA_MS = 1500L

        /** Silencio que cuelga la llamada. */
        private const val SILENCIO_LLAMADA_MS = 8_000L
    }
    /** Pulsos por palabra hablada (animación del gorila). */
    val palabras: StateFlow<Int> = habla.palabras
    private var reconocedor: SpeechRecognizer? = null
    private var cancelado = false

    fun alternarHablar() {
        _hablarRespuestas.value = !_hablarRespuestas.value
        if (!_hablarRespuestas.value) habla.detener()
    }

    fun permisoMicrofono(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun reportarPermisoDenegado() {
        _error.value = "Sin el permiso del micrófono no puedo escucharte. Puedes activarlo en los ajustes de la app, " +
            "o escribirme los comandos abajo."
    }

    fun limpiarError() { _error.value = null }

    private fun obtenerReconocedor(): SpeechRecognizer? {
        reconocedor?.let { return it }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            _error.value = "Este teléfono no tiene un servicio de reconocimiento de voz disponible. " +
                "Instala o activa «Servicios de voz de Google», o escríbeme los comandos abajo."
            return null
        }
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { oyoVoz = true }
            override fun onRmsChanged(rmsdB: Float) { _nivel.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _nivel.value = 0f }
            override fun onError(error: Int) {
                _nivel.value = 0f
                vigilanteSilencio?.cancel()
                if (cancelado) return
                if (_llamada.value && (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT || error == SpeechRecognizer.ERROR_NO_MATCH)) {
                    colgarPorSilencio()
                    return
                }
                terminarLlamada() // cualquier otro error: se cuelga y se muestra el mensaje
                _estado.value = EstadoVoz.REPOSO
                _error.value = when (error) {
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "No hay conexión y el reconocimiento de voz de este teléfono la necesita. " +
                            "Revisa tu internet o escríbeme el comando."
                    SpeechRecognizer.ERROR_AUDIO -> "Hubo un problema con el micrófono."
                    SpeechRecognizer.ERROR_SERVER -> "El servicio de voz falló. Inténtalo de nuevo."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No te escuché. Toca el micrófono y habla otra vez."
                    SpeechRecognizer.ERROR_NO_MATCH -> "No entendí lo que dijiste. Inténtalo otra vez."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El reconocimiento de voz está ocupado. Inténtalo en un momento."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Falta el permiso del micrófono. Actívalo en los ajustes de la app."
                    else -> "No pude escucharte (código $error). Inténtalo de nuevo."
                }
            }
            override fun onResults(results: Bundle?) {
                _nivel.value = 0f
                vigilanteSilencio?.cancel()
                val texto = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (texto.isNullOrBlank()) {
                    if (_llamada.value) {
                        colgarPorSilencio()
                    } else {
                        _estado.value = EstadoVoz.REPOSO
                        _error.value = "No entendí lo que dijiste. Inténtalo otra vez."
                    }
                } else {
                    procesar(texto)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) { oyoVoz = true; _transcripcion.value = p }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        reconocedor = r
        return r
    }

    /** Debe llamarse con el permiso del micrófono ya concedido. */
    fun escuchar(desdeInterrupcion: Boolean = false) {
        if (!desdeInterrupcion) habla.detener()
        vigiando = false
        if (!desdeInterrupcion && (_estado.value == EstadoVoz.ESCUCHANDO || _estado.value == EstadoVoz.PROCESANDO)) return
        _error.value = null
        _transcripcion.value = ""
        if (!permisoMicrofono()) { reportarPermisoDenegado(); return }
        // Con «sin internet» activado NUNCA se usa el reconocimiento del sistema/Google, ni como respaldo.
        if (_usarVosk.value) { escucharSinInternet(); return }
        val r = obtenerReconocedor() ?: run {
            if (desdeInterrupcion) _estado.value = EstadoVoz.REPOSO
            return
        }
        cancelado = false
        _estado.value = EstadoVoz.ESCUCHANDO
        oyoVoz = false
        vigilanteSilencio?.cancel()
        if (_llamada.value) {
            vigilanteSilencio = viewModelScope.launch {
                delay(SILENCIO_LLAMADA_MS)
                if (!oyoVoz && _llamada.value && _estado.value == EstadoVoz.ESCUCHANDO) {
                    cancelado = true
                    reconocedor?.cancel()
                    colgarPorSilencio()
                }
            }
        }
        val idioma = if (Locale.getDefault().language == "es") Locale.getDefault().toLanguageTag() else "es-ES"
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, idioma)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
            },
        )
    }

    private fun escucharSinInternet() {
        val ruta = VoskModelo.ruta(app)
        if (ruta == null) {
            _error.value = "El reconocimiento sin internet está activado, pero falta instalar el modelo en Configuración > Voz. " +
                "No uso el reconocimiento de Google a escondidas: instálalo o desactiva esa opción."
            if (_estado.value == EstadoVoz.ESCUCHANDO) _estado.value = EstadoVoz.REPOSO
            return
        }
        cancelado = false
        _estado.value = EstadoVoz.ESCUCHANDO
        vosk.escuchar(ruta, object : ReconocedorVosk.Oyente {
            override fun alPreparar() { _transcripcion.value = "Preparando el reconocimiento sin internet…" }
            override fun alEscuchar() { if (_transcripcion.value.startsWith("Preparando")) _transcripcion.value = "" }
            override fun alNivel(nivel: Float) { _nivel.value = nivel }
            override fun alParcial(texto: String) { _transcripcion.value = texto }
            override fun alFinal(texto: String) {
                _nivel.value = 0f
                if (cancelado) return
                // Tras despertar con «Julio», el final de esa palabra puede colarse al principio: se quita.
                val limpio = ReconocimientoUtil.quitarVocativo(texto)
                if (limpio.isBlank()) { escucharSinInternet(); return } // solo se oyó «julio»: se sigue escuchando
                ajenasSeguidas = 0
                procesar(limpio)
            }
            override fun alVozAjena(distancia: Float) {
                _nivel.value = 0f
                if (cancelado) return
                // Otra voz (la tele, otra persona): se ignora y se sigue esperando la tuya, pero no para siempre.
                ajenasSeguidas++
                if (ajenasSeguidas >= MAX_VOCES_AJENAS) {
                    ajenasSeguidas = 0
                    if (_llamada.value) { colgarPorSilencio(); return }
                    _estado.value = EstadoVoz.REPOSO
                    _error.value = "Oí voces que no son la tuya y las ignoré. Toca el micrófono y habla otra vez."
                    return
                }
                escucharSinInternet()
            }
            override fun alSinVoz() {
                _nivel.value = 0f
                if (cancelado) return
                if (_llamada.value) { colgarPorSilencio(); return }
                _estado.value = EstadoVoz.REPOSO
                _error.value = "No te escuché. Toca el micrófono y habla otra vez."
            }
            override fun alError(mensaje: String) {
                _nivel.value = 0f
                if (cancelado) return
                terminarLlamada()
                _estado.value = EstadoVoz.REPOSO
                _error.value = "El reconocimiento sin internet falló: $mensaje"
            }
        }, VozDueno.verificacion(app))
    }

    /** Cancela escuchar o hablar. Si ya se está ejecutando una orden, esta termina por seguridad. */
    fun detener() {
        terminarLlamada()
        cancelado = true
        vigiando = false
        interrupcion?.cancel()
        vosk.detener()
        reconocedor?.cancel()
        habla.detener()
        _nivel.value = 0f
        if (_estado.value != EstadoVoz.PROCESANDO) _estado.value = EstadoVoz.REPOSO
    }

    // ----- Mi voz: «solo obedece al dueño» (reconocimiento de hablante con Vosk) -----
    private var ajenasSeguidas = 0
    val duenoModelo: StateFlow<EstadoVosk> = VozDueno.modelo
    val duenoHuella: StateFlow<Boolean> = VozDueno.tieneHuella
    val soloMiVoz: StateFlow<Boolean> = VozDueno.soloMiVoz
    val duenoUmbral: StateFlow<Float> = VozDueno.umbral
    val duenoEntrenamiento: StateFlow<EntrenamientoVoz> = VozDueno.entrenamiento
    val duenoMensaje: StateFlow<String?> = VozDueno.mensaje

    init { VozDueno.iniciar(app) }

    fun descargarModeloDueno() = VozDueno.descargarModelo(app)
    fun cancelarModeloDueno() = VozDueno.cancelarDescarga()
    fun eliminarModeloDueno() {
        VozDueno.fijarSoloMiVoz(app, false)
        VozDueno.eliminarModelo(app)
    }
    fun alternarSoloMiVoz(activar: Boolean) = VozDueno.fijarSoloMiVoz(app, activar)
    fun cambiarSensibilidadDueno(umbral: Float) = VozDueno.fijarUmbral(app, umbral)
    fun borrarMiVoz() = VozDueno.borrarHuella(app)

    /** Suelta el micrófono antes de grabar la huella (la vigilancia de «Julio» se retoma sola al terminar). */
    private fun prepararCaptura() {
        if (_llamada.value) detener()
        _despertarActivo.value = false
        vosk.detener()
        VozDueno.avisar(null)
    }

    private fun rutasDueno(): Pair<String, String>? {
        val vosk = VoskModelo.ruta(app)
        val hablante = VozDueno.rutaModelo(app)
        if (vosk == null || hablante == null) {
            VozDueno.avisar("Faltan modelos: instala el reconocimiento sin internet y el modelo de hablante.")
            return null
        }
        if (!permisoMicrofono()) {
            VozDueno.avisar("Falta el permiso del micrófono.")
            return null
        }
        return vosk to hablante
    }

    /** Entrena tu voz: [VozDueno.MUESTRAS] muestras de [VozDueno.SEGUNDOS_MUESTRA] s hablando con naturalidad. */
    fun entrenarMiVoz() {
        val (rutaVosk, rutaHablante) = rutasDueno() ?: return
        prepararCaptura()
        val vectores = mutableListOf<FloatArray>()
        val pesos = mutableListOf<Int>()
        fun terminarConError(m: String) {
            VozDueno.marcarEntrenamiento(EntrenamientoVoz.Error(m))
            arrancarDespertar()
        }
        fun paso(i: Int) {
            VozDueno.marcarEntrenamiento(EntrenamientoVoz.Grabando(i, VozDueno.MUESTRAS, VozDueno.SEGUNDOS_MUESTRA))
            vosk.capturarHuella(rutaVosk, rutaHablante, VozDueno.SEGUNDOS_MUESTRA) { huella, frames, error ->
                when {
                    error != null -> terminarConError("No pude grabar tu voz: $error")
                    huella == null || frames < HablanteMath.FRAMES_MINIMOS_ENTRENAMIENTO ->
                        terminarConError("No te oí hablar lo suficiente en la muestra $i. Habla con naturalidad y más cerca del teléfono.")
                    else -> {
                        vectores.add(huella)
                        pesos.add(frames)
                        if (i < VozDueno.MUESTRAS) {
                            viewModelScope.launch { delay(1200L); paso(i + 1) }
                        } else {
                            val maxima = HablanteMath.distanciaMaxima(vectores)
                            val perfil = HablanteMath.mediaPonderada(vectores.zip(pesos))
                            if (perfil == null || maxima > HablanteMath.DISTANCIA_MAX_ENTRE_MUESTRAS) {
                                terminarConError(
                                    "Mis muestras de tu voz se parecieron poco entre sí (diferencia ${"%.2f".format(maxima)}). " +
                                        "Repite en un lugar silencioso y hablando igual las tres veces.",
                                )
                            } else {
                                VozDueno.guardarHuella(app, perfil)
                                VozDueno.fijarSoloMiVoz(app, true)
                                VozDueno.marcarEntrenamiento(EntrenamientoVoz.Inactivo)
                                VozDueno.avisar("Listo, aprendí tu voz (las 3 muestras se parecen entre sí: ${"%.2f".format(maxima)}). Pruébala abajo.")
                                arrancarDespertar()
                            }
                        }
                    }
                }
            }
        }
        paso(1)
    }

    /** Graba unos segundos y dice a qué distancia está tu voz del perfil (y si Julio la aceptaría). */
    fun probarMiVoz() {
        val referencia = VozDueno.huella(app)
        if (referencia == null) {
            VozDueno.avisar("Primero entrena tu voz.")
            return
        }
        val (rutaVosk, rutaHablante) = rutasDueno() ?: return
        prepararCaptura()
        VozDueno.marcarEntrenamiento(EntrenamientoVoz.Grabando(1, 1, VozDueno.SEGUNDOS_PRUEBA))
        vosk.capturarHuella(rutaVosk, rutaHablante, VozDueno.SEGUNDOS_PRUEBA) { huella, frames, error ->
            VozDueno.marcarEntrenamiento(EntrenamientoVoz.Inactivo)
            val umbral = VozDueno.umbral.value
            val texto = when {
                error != null -> "No pude grabar: $error"
                huella == null || frames < HablanteMath.FRAMES_MINIMOS ->
                    "No te oí hablar lo suficiente. Habla durante los 5 segundos."
                else -> {
                    val d = HablanteMath.distanciaCoseno(huella, referencia)
                    "Distancia ${"%.2f".format(d)} (acepto hasta ${"%.2f".format(umbral)}): " +
                        if (d <= umbral) "sí te reconozco." else "NO te reconozco. Si eras tú, usa «Más permisivo» o vuelve a entrenar."
                }
            }
            VozDueno.avisar(texto)
            arrancarDespertar()
        }
    }

    // ----- Despertar por «Julio» (Etapa 2 del Proyecto Cuerpo) -----
    // Solo escucha la palabra «julio» (Vosk, sin internet, vocabulario limitado) mientras el modo escritorio está abierto
    // y Julio está en reposo. Al oírla abre una llamada normal (escucha completa, responde y se cuelga a los 8 s de silencio).
    private val _despertarActivo = MutableStateFlow(false)
    val despertarActivo: StateFlow<Boolean> = _despertarActivo.asStateFlow()
    private val _despertarError = MutableStateFlow<String?>(null)
    val despertarError: StateFlow<String?> = _despertarError.asStateFlow()
    private var despertarSolicitado = false

    init {
        viewModelScope.launch {
            combine(_estado, _llamada) { e, l -> e == EstadoVoz.REPOSO && !l }
                .distinctUntilChanged()
                .collectLatest { libre ->
                    if (!libre) {
                        _despertarActivo.value = false // otra escucha tomó el micrófono
                    } else {
                        delay(DESPERTAR_PAUSA_MS)
                        arrancarDespertar()
                    }
                }
        }
    }

    fun activarDespertar() {
        despertarSolicitado = true
        arrancarDespertar()
    }

    fun desactivarDespertar() {
        despertarSolicitado = false
        if (_despertarActivo.value) {
            _despertarActivo.value = false
            vosk.detener()
        }
    }

    private fun arrancarDespertar() {
        if (!despertarSolicitado || _despertarActivo.value) return
        if (_estado.value != EstadoVoz.REPOSO || _llamada.value) return
        if (!permisoMicrofono()) {
            _despertarError.value = "Falta el permiso del micrófono para oír «Julio»."
            return
        }
        val ruta = VoskModelo.ruta(app)
        if (ruta == null) {
            _despertarError.value = "Para oír «Julio» falta instalar el modelo de voz sin internet (Configuración > Voz)."
            return
        }
        if (!_usarVosk.value) alternarVosk(true) // la escucha tras despertar tiene que ser sin internet
        _despertarError.value = null
        _despertarActivo.value = true
        vosk.vigilarDespertar(
            ruta,
            alDetectar = {
                _despertarActivo.value = false
                JulioEstado.despertar()
                iniciarLlamada()
            },
            alFallar = { motivo ->
                _despertarActivo.value = false
                _despertarError.value = "No pude oír «Julio»: $motivo"
            },
        )
    }

    fun enviarTexto(t: String) {
        val limpio = t.trim()
        if (limpio.isEmpty()) return
        if (_estado.value == EstadoVoz.PROCESANDO) return
        // Escribir también entra en modo llamada: cuando Julio termine de responder, el micrófono se abre solo
        // (si hay permiso y reconocimiento disponible). Con 8 s de silencio se cuelga.
        reabrir?.cancel()
        vigilanteSilencio?.cancel()
        _llamada.value = puedeEscucharAhora()
        vigiando = false
        interrupcion?.cancel()
        vosk.detener()
        reconocedor?.cancel()
        habla.detener()
        _error.value = null
        procesar(limpio)
    }

    private fun procesar(texto: String) {
        _transcripcion.value = texto
        _historial.value = (_historial.value + Mensaje(true, texto)).takeLast(40)
        _estado.value = EstadoVoz.PROCESANDO
        viewModelScope.launch {
            val respuesta = try {
                asistente.procesar(texto)
            } catch (e: Exception) {
                "Ocurrió un error (${e.message ?: e.javaClass.simpleName}) y no puedo confirmar que la orden se completara. " +
                    "Revisa la pantalla correspondiente."
            }
            _historial.value = (_historial.value + Mensaje(false, respuesta)).takeLast(40)
            if (_hablarRespuestas.value && habla.disponible) {
                _estado.value = EstadoVoz.RESPONDIENDO
                hablarConVigia(respuesta) { alTerminarDeHablar() }
            } else {
                alTerminarDeHablar()
            }
        }
    }

    override fun onCleared() {
        reconocedor?.destroy()
        reconocedor = null
        vosk.liberar()
        habla.cerrar()
        super.onCleared()
    }
}
