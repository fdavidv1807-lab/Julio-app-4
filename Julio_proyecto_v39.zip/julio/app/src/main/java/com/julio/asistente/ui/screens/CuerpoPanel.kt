package com.julio.asistente.ui.screens

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.cuerpo.Aviso
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.cuerpo.CuerpoAvisos
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.ui.components.PanelJulio
import java.util.UUID

/**
 * Configuración > Avisos del Cuerpo. Para usar en el teléfono del escritorio: Julio lee en voz alta las notificaciones de las apps
 * que elijas (por ejemplo WhatsApp vinculado como «dispositivo complementario»). No usa la red ni toca tu teléfono principal.
 */
@Composable
fun CuerpoPanel() {
    val ctx = LocalContext.current
    val activo by CuerpoAjustes.activo.collectAsStateWithLifecycle()
    val privado by CuerpoAjustes.privado.collectAsStateWithLifecycle()
    val permitidas by CuerpoAjustes.permitidas.collectAsStateWithLifecycle()
    val enEspera by CuerpoAvisos.pendientes.collectAsStateWithLifecycle()
    val escritorio by EscritorioControl.activo.collectAsStateWithLifecycle()
    var acceso by remember { mutableStateOf(accesoANotificaciones(ctx)) }
    var verApps by remember { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        CuerpoAjustes.cargar(ctx)
        acceso = accesoANotificaciones(ctx)
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                "Solo para el teléfono del escritorio (el Cuerpo). Aquí NO se conecta tu teléfono principal.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Leer en voz alta los avisos de este teléfono", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = activo, onCheckedChange = { CuerpoAjustes.fijarActivo(ctx, it) })
            }
            if (activo) {
                Text("1. Acceso a notificaciones", style = MaterialTheme.typography.labelLarge)
                Text(
                    if (acceso) "Concedido." else "Falta. Sin esto Julio no ve las notificaciones.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (acceso) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                )
                Button(
                    onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                    shape = MaterialTheme.shapes.small,
                ) { Text("Abrir «Acceso a notificaciones»") }
                Text(
                    "Si Julio aparece en gris: Ajustes > Aplicaciones > Julio > ⋮ (arriba a la derecha) > «Permitir ajustes restringidos», y vuelve a intentarlo.",
                    style = MaterialTheme.typography.bodySmall,
                )

                Text("2. Elige qué apps se leen (ninguna por defecto)", style = MaterialTheme.typography.labelLarge)
                TextButton(onClick = { verApps = !verApps }) {
                    Text(if (verApps) "Ocultar apps" else "Elegir apps (${permitidas.size} elegidas)")
                }
                if (verApps) AppsElegidas(permitidas)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Modo privado: solo dice la app, sin el contenido", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = privado, onCheckedChange = { CuerpoAjustes.alternarPrivado(ctx) })
                }

                Text("3. Probar", style = MaterialTheme.typography.labelLarge)
                Button(
                    onClick = {
                        CuerpoAvisos.recibir(Aviso(UUID.randomUUID().toString(), System.currentTimeMillis(), "Julio", "com.julio.asistente", "Prueba", "Este es un aviso de prueba."))
                    },
                    shape = MaterialTheme.shapes.small,
                ) { Text("Crear un aviso de prueba") }
                Text(
                    if (escritorio) "Lo leerá en unos segundos." else "Hay que abrir el modo escritorio (Inicio > Modo escritorio): solo se leen avisos con él abierto.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (escritorio) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                )
                if (enEspera > 0) Text("Avisos esperando ser leídos: $enEspera", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "Los códigos de verificación y los avisos del banco nunca se leen ni se guardan: Julio solo dice que llegó uno. " +
                    "No instales apps de banco en este teléfono. Todo ocurre dentro de este teléfono, sin red.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun AppsElegidas(permitidas: Set<String>) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }
    Text("Julio lee los avisos de las apps con el interruptor encendido.", style = MaterialTheme.typography.bodySmall)
    apps.forEach { (nombre, paquete) ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(nombre, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = paquete in permitidas, onCheckedChange = { CuerpoAjustes.permitir(ctx, paquete, it) })
        }
    }
}

private fun accesoANotificaciones(ctx: android.content.Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
