package com.julio.asistente.cuerpo

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Avisos esperando turno para ser leídos en voz alta. Solo en memoria (nunca en disco); caducan a los 3 minutos. */
object CuerpoAvisos {
    // Lo viejo ya no sirve: caduca a los 3 minutos y se lee primero lo más nuevo.
    private val cola = ColaAvisos(capacidad = 20, vidaMs = 3 * 60_000L, masNuevoPrimero = true)
    private val historial = HistorialAvisos()
    private val _pendientes = MutableStateFlow(0)
    val pendientes: StateFlow<Int> = _pendientes.asStateFlow()

    private fun ahora() = System.currentTimeMillis()
    private fun actualizar() { _pendientes.value = cola.tamano(ahora()) }

    fun recibir(a: Aviso) {
        if (cola.agregar(a, ahora())) {
            historial.registrar(a, ahora())
            actualizar()
        }
    }

    /** Lo que llegó en los últimos 30 minutos (para «¿qué notificaciones tengo?»). */
    fun recientes(): List<Aviso> = historial.lista(ahora())
    fun siguiente(): Entrada? = cola.siguiente(ahora()).also { actualizar() }
    fun devolver(e: Entrada) { cola.devolver(e); actualizar() }
    fun perdidos(): Int = cola.tomarPerdidos()
    fun vaciar() { cola.vaciar(); historial.vaciar(); actualizar() }
}
