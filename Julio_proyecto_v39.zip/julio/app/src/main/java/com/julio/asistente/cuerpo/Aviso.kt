package com.julio.asistente.cuerpo

/** Qué clase de aviso es. Los códigos y los avisos del banco NUNCA llevan su contenido (ni se lee ni se guarda). */
enum class TipoAviso(val codigo: Int) {
    NORMAL(0), CODIGO(1), BANCO(2);

    companion object {
        /** Un valor desconocido se trata como BANCO (lo más restrictivo: sin contenido). */
        fun de(codigo: Int): TipoAviso = entries.firstOrNull { it.codigo == codigo } ?: BANCO
    }
}

/**
 * Una notificación de este teléfono, ya filtrada. Para NORMAL lleva el texto; para códigos y bancos va vacía.
 * Si es de mensajería (WhatsApp, etc.) trae [remitente], [grupo] (vacío si es un chat de una persona) y [cantidad] de mensajes
 * nuevos; [chat] identifica la conversación para juntar varios mensajes seguidos en un solo aviso.
 */
data class Aviso(
    val id: String,
    /** Hora (ms) en que se vio la notificación. */
    val tiempo: Long,
    /** Nombre de la app que la lanzó («WhatsApp»). */
    val app: String,
    val paquete: String,
    val titulo: String,
    /** Texto del mensaje más reciente. */
    val texto: String,
    val tipo: TipoAviso = TipoAviso.NORMAL,
    val chat: String = "",
    val remitente: String = "",
    val grupo: String = "",
    val cantidad: Int = 1,
    /** true si viene de una app de mensajería (usa [remitente], [grupo] y [cantidad]). */
    val mensajeria: Boolean = false,
) {
    /** Junta este aviso (más viejo, aún sin leer) con uno nuevo de la misma conversación. Lo sensible gana. */
    fun fusionarCon(nuevo: Aviso): Aviso {
        val t = if (tipo != TipoAviso.NORMAL) tipo else nuevo.tipo
        val junto = nuevo.copy(cantidad = cantidad + nuevo.cantidad, tipo = t)
        return if (t == TipoAviso.NORMAL) junto else junto.copy(titulo = "", texto = "", remitente = "", grupo = "")
    }
}
