package com.julio.asistente

import android.app.Application
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.avisos.AvisosAjustes
import com.julio.asistente.avisos.AvisosProgramador
import com.julio.asistente.bloqueo.BloqueoConfig
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.estudio.EstudioAviso
import com.julio.asistente.estudio.EstudioRepo

class JulioApp : Application() {
    /** Base de datos local única (Room). Se crea al primer uso. */
    val database: JulioDatabase by lazy { JulioDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        Canales.crear(this)
        BloqueoConfig.cargar(this)
        com.julio.asistente.ui.theme.Apariencia.cargar(this)
        EnfoqueControl.cargar(this)
        com.julio.asistente.escritorio.EscritorioControl.cargar(this)
        EstudioRepo.cargar(this)
        EstudioAviso.programar(this)
        AvisosAjustes.cargar(this)
        com.julio.asistente.cuerpo.CuerpoAjustes.cargar(this)
        AvisosProgramador.programar(this)
    }
}
