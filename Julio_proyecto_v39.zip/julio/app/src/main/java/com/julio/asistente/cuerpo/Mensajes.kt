package com.julio.asistente.cuerpo

/** Un mensaje dentro de una notificación de mensajería. [tiempo] es la hora del mensaje, no de la notificación. */
data class MensajeCrudo(val texto: String, val tiempo: Long, val remitente: String)

object Remitentes {
    private val SOLO_NUMERO = Regex("^[+()\\-\\s0-9.]+$")

    /** ¿Es un número de teléfono (sin nombre guardado)? */
    fun esNumero(s: String): Boolean = SOLO_NUMERO.matches(s.trim()) && s.count { it.isDigit() } >= 6

    /** Cómo se dice en voz alta: el nombre, o «un número desconocido» si solo hay número o nada. */
    fun nombreHablado(s: String): String {
        val t = PoliticaLectura.limpiar(s)
        return if (t.isBlank() || esNumero(t)) "un número desconocido" else t
    }
}

/**
 * Recuerda qué mensajes de cada conversación ya se avisaron, para decir SOLO lo nuevo (WhatsApp vuelve a publicar la misma
 * notificación con cada mensaje y trae los anteriores). Cuenta copias por hora+texto: dos «hola» iguales en el mismo segundo
 * son dos mensajes; un mensaje ya avisado no se repite. Ignora mensajes de hace más de [maxEdadMs] (historial viejo).
 * Solo guarda números de conteo en memoria, no el texto. Lógica pura.
 */
class SeguimientoChats(private val maxEdadMs: Long = 5 * 60_000L, private val maxChats: Int = 100) {
    private val vistos = LinkedHashMap<String, Map<Int, Int>>()

    private fun clave(m: MensajeCrudo) = listOf(m.tiempo, m.texto, m.remitente).hashCode()

    @Synchronized
    fun nuevos(chat: String, mensajes: List<MensajeCrudo>, ahora: Long): List<MensajeCrudo> {
        val previo = vistos[chat] ?: emptyMap()
        val usados = HashMap<Int, Int>()
        val resultado = ArrayList<MensajeCrudo>()
        for (m in mensajes.sortedBy { it.tiempo }) {
            val k = clave(m)
            val n = (usados[k] ?: 0) + 1
            usados[k] = n
            if (n > (previo[k] ?: 0) && ahora - m.tiempo <= maxEdadMs) resultado += m
        }
        vistos.remove(chat)
        vistos[chat] = usados
        while (vistos.size > maxChats) {
            val primero = vistos.entries.iterator()
            primero.next()
            primero.remove()
        }
        return resultado
    }
}
