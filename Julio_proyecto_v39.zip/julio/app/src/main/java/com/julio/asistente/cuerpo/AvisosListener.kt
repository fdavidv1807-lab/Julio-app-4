package com.julio.asistente.cuerpo

import android.app.Notification
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.julio.asistente.escritorio.EscritorioControl
import java.util.UUID

/**
 * Corre en el Cuerpo de Julio (el teléfono del escritorio). Ve las notificaciones que llegan a ESTE teléfono (WhatsApp vinculado
 * como dispositivo complementario, Gmail, etc.) y deja en cola las de las apps que la persona eligió, para que Julio las lea.
 * No usa la red ni manda nada a ningún lado. Requiere el permiso «Acceso a notificaciones» (Ajustes).
 * Solo trabaja con el modo escritorio abierto y la lectura encendida; si no, no hace nada.
 *
 * Mensajería: WhatsApp vuelve a publicar la misma notificación con cada mensaje y trae los anteriores; por eso se compara con lo
 * ya avisado ([SeguimientoChats]) y solo se dice lo nuevo. Los mensajes tuyos (respuestas) no se leen.
 */
class AvisosListener : NotificationListenerService() {
    private val dedupe = Deduplicador(ventanaMs = 60_000L)
    private val seguimiento = SeguimientoChats()

    override fun onCreate() {
        super.onCreate()
        CuerpoAjustes.cargar(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!CuerpoAjustes.activo.value || !EscritorioControl.activo.value) return
            val n = sbn.notification ?: return
            val extras = n.extras
            val tituloExtra = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val textoExtra = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val mensajes = leerMensajes(extras)
            val cruda = NotificacionCruda(
                paquete = sbn.packageName.orEmpty(),
                titulo = tituloExtra,
                texto = if (mensajes.isNotEmpty()) mensajes.last().texto else textoExtra,
                categoria = n.category,
                enCurso = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0,
                resumenGrupo = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0,
            )
            if (FiltroAvisos.motivoDescarte(cruda, packageName, CuerpoAjustes.permitidas.value) != null) return
            val ahora = System.currentTimeMillis()
            val app = nombreDeApp(cruda.paquete)
            val aviso = if (mensajes.isNotEmpty()) {
                avisoDeMensajes(sbn, extras, mensajes, app, tituloExtra, ahora) ?: return
            } else {
                if (dedupe.repetido(cruda.paquete, tituloExtra, textoExtra, ahora)) return
                Aviso(UUID.randomUUID().toString(), ahora, app, cruda.paquete, tituloExtra, textoExtra, chat = sbn.key.orEmpty())
            }
            CuerpoAvisos.recibir(Sensibles.sanear(aviso))
        } catch (e: Exception) {
            // Un aviso raro nunca debe tumbar el servicio.
        }
    }

    private fun avisoDeMensajes(
        sbn: StatusBarNotification,
        extras: Bundle?,
        mensajes: List<MensajeCrudo>,
        app: String,
        tituloExtra: String,
        ahora: Long,
    ): Aviso? {
        val clave = sbn.key.orEmpty()
        val nuevos = seguimiento.nuevos(clave, mensajes, ahora)
        if (nuevos.isEmpty()) return null
        val ultimo = nuevos.last()
        val esGrupo = extras?.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) == true
        val tituloConversacion = extras?.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()
        val grupo = if (esGrupo) tituloConversacion.ifBlank { tituloExtra } else ""
        // En un chat de una persona el título de la notificación es su nombre; si falta, el del mensaje.
        val remitente = if (esGrupo) ultimo.remitente else tituloExtra.ifBlank { ultimo.remitente }
        val tipo = Sensibles.clasificar(app, sbn.packageName.orEmpty(), tituloExtra, nuevos.joinToString(" ") { it.texto })
        return Aviso(
            id = UUID.randomUUID().toString(),
            tiempo = ahora,
            app = app,
            paquete = sbn.packageName.orEmpty(),
            titulo = remitente,
            texto = ultimo.texto,
            tipo = tipo,
            chat = clave,
            remitente = remitente,
            grupo = grupo,
            cantidad = nuevos.size,
            mensajeria = true,
        )
    }

    /** Mensajes de la notificación (estilo mensajería), sin los tuyos. Vacío si la app no usa ese estilo. */
    @Suppress("DEPRECATION")
    private fun leerMensajes(extras: Bundle?): List<MensajeCrudo> {
        val arreglo = extras?.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return emptyList()
        return Notification.MessagingStyle.Message.getMessagesFromBundleArray(arreglo).mapNotNull { m ->
            val nombre: String = if (Build.VERSION.SDK_INT >= 28) {
                val persona = m.senderPerson ?: return@mapNotNull null // sin remitente = mensaje tuyo
                persona.name?.toString().orEmpty()
            } else {
                m.sender?.toString() ?: return@mapNotNull null
            }
            MensajeCrudo(m.text?.toString().orEmpty(), m.timestamp, nombre)
        }
    }

    /** Samsung y otros matan estos servicios: se pide al sistema que lo vuelva a conectar. */
    override fun onListenerDisconnected() {
        try {
            NotificationListenerService.requestRebind(ComponentName(this, AvisosListener::class.java))
        } catch (e: Exception) { }
    }

    private fun nombreDeApp(paquete: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(paquete, 0)).toString()
    } catch (e: Exception) {
        paquete.substringAfterLast('.')
    }
}
