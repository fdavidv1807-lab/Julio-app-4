package com.julio.asistente.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.avisos.AjustesAvisos
import com.julio.asistente.avisos.AvisosAjustes
import com.julio.asistente.avisos.AvisosProgramador
import com.julio.asistente.bloqueo.BloqueoControl
import com.julio.asistente.core.Permisos
import com.julio.asistente.recordatorios.RecordatorioProgramador
import com.julio.asistente.ui.components.PanelJulio
import com.julio.asistente.ui.components.RespaldoPanel
import com.julio.asistente.ui.theme.Apariencia
import com.julio.asistente.voz.EstadoPiper
import com.julio.asistente.voz.EstadoVosk
import com.julio.asistente.voz.PiperModelo
import com.julio.asistente.voz.VoskModelo
import com.julio.asistente.voz.VozViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Panel de configuración (a la derecha): apariencia, permisos, voz, guía de comandos y copia de seguridad.
 * Reúne controles que ya existían; no cambia ninguna lógica.
 */
@Composable
fun ConfiguracionPanel(
    vm: VozViewModel,
    alCerrar: (() -> Unit)?,
    alProbarEjemplo: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val modo by Apariencia.modo.collectAsStateWithLifecycle()
    val orbeColor by vm.orbeColor.collectAsStateWithLifecycle()

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Configuración", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            if (alCerrar != null) {
                IconButton(onClick = alCerrar) { Icon(Icons.Filled.Close, contentDescription = "Cerrar la configuración") }
            }
        }

        Seccion("Apariencia", abiertaAlInicio = true) {
            PanelJulio(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tema", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Automático" to 0, "Claro" to 1, "Oscuro" to 2).forEach { (titulo, valor) ->
                            FilterChip(
                                selected = modo == valor,
                                onClick = { Apariencia.cambiar(ctx, valor) },
                                label = { Text(titulo) },
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("El orbe cambia de color", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = orbeColor, onCheckedChange = { vm.alternarOrbeColor() })
                    }
                }
            }
        }

        Seccion("Permisos") { PermisosLista() }

        Seccion("Avisos") { AvisosPanel() }

        Seccion("Avisos del Cuerpo (leer notificaciones)") { CuerpoPanel() }

        Seccion("Voz") {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                VoskPanel(vm)
                VozDuenoPanel(vm)
                PiperPanel(vm)
                AjustesVozPanel(vm = vm, alAbrirSistema = { abrirAjustesDeVoz(ctx) })
            }
        }

        Seccion("Guía de comandos") { GuiaComandos(alProbarEjemplo) }

        Seccion("Copia de seguridad") { RespaldoPanel() }
    }
}

/** Sección que se abre y se cierra tocando su título. */
@Composable
private fun Seccion(titulo: String, abiertaAlInicio: Boolean = false, contenido: @Composable () -> Unit) {
    var abierta by rememberSaveable(titulo) { mutableStateOf(abiertaAlInicio) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable { abierta = !abierta }.padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Icon(
                if (abierta) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (abierta) "Ocultar $titulo" else "Mostrar $titulo",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        AnimatedVisibility(visible = abierta) { Box { contenido() } }
    }
}

/** Voz neuronal «Dave» (Piper, español de España): se instala una vez y después funciona sin internet. */
@Composable
private fun PiperPanel(vm: VozViewModel) {
    val estado by vm.piperEstado.collectAsStateWithLifecycle()
    val usar by vm.usarPiper.collectAsStateWithLifecycle()
    val fallo by vm.errorPiper.collectAsStateWithLifecycle()
    val selector = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { archivos ->
        if (archivos.isNotEmpty()) vm.instalarPiperDesdeArchivos(archivos)
    }
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Voz neuronal sin internet", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Voz «Dave» en español de España (Piper). Elige sus dos archivos, es_ES-davefx-medium.onnx y su .json, " +
                    "o descárgala (unos ${PiperModelo.TAMANO_APROX_MB} MB, mejor con Wi‑Fi). Se instala una sola vez y después " +
                    "Julio habla con ella sin conexión. Si algo falla, usa la voz del teléfono. " +
                    "El tono y la velocidad de abajo también la afectan.",
                style = MaterialTheme.typography.bodySmall,
            )
            if (!vm.piperDisponible) {
                Text(
                    "Esta compilación de Julio no incluyó el motor neuronal (no se pudo descargar al compilar). " +
                        "Vuelve a compilar con internet y aparecerá.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            when (val e = estado) {
                EstadoPiper.NoDescargada -> {
                    Button(
                        onClick = { selector.launch(arrayOf("*/*")) },
                        enabled = vm.piperDisponible,
                        shape = MaterialTheme.shapes.small,
                    ) { Text("Instalar con mis archivos de Dave") }
                    TextButton(onClick = { vm.descargarPiper() }, enabled = vm.piperDisponible) { Text("Descargar Dave (sin archivos)") }
                }
                is EstadoPiper.Descargando -> {
                    if (e.progreso >= 0f) LinearProgressIndicator(progress = { e.progreso }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("${e.etapa}… ${e.mb} MB", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.cancelarDescargaPiper() }) { Text("Cancelar") }
                }
                EstadoPiper.Lista -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Usar la voz neuronal Dave", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = usar, onCheckedChange = { vm.alternarPiper(it) })
                    }
                    TextButton(onClick = { vm.eliminarPiper() }) { Text("Eliminar voz instalada") }
                }
                is EstadoPiper.Error -> {
                    Text(e.mensaje, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    Button(onClick = { vm.reintentarPiper() }, shape = MaterialTheme.shapes.small) { Text("Reintentar") }
                    TextButton(onClick = { selector.launch(arrayOf("*/*")) }, enabled = vm.piperDisponible) { Text("Elegir otros archivos") }
                }
            }
            fallo?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        }
    }
}

/** Reconocimiento de voz sin internet (Vosk + modelo en español). Nada se baja hasta que la persona lo pide. */
@Composable
private fun VoskPanel(vm: VozViewModel) {
    val estado by vm.voskEstado.collectAsStateWithLifecycle()
    val usar by vm.usarVosk.collectAsStateWithLifecycle()
    val diag by vm.voskDiagnostico.collectAsStateWithLifecycle()
    val selector = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { archivo ->
        if (archivo != null) vm.instalarVoskDesdeZip(archivo)
    }
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Reconocimiento de voz sin internet", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Julio puede entenderte sin conexión con Vosk (código abierto, ${VoskModelo.LICENCIA}) y el modelo " +
                    "«${VoskModelo.NOMBRE}» (español, ${VoskModelo.TAMANO_ZIP_MB} MB, de ${VoskModelo.ORIGEN}). " +
                    "No se descarga nada hasta que toques el botón. Después tu voz se procesa dentro del teléfono " +
                    "y no sale de él. Es menos precisa que el reconocimiento de Google: habla claro y sin ruido.",
                style = MaterialTheme.typography.bodySmall,
            )
            when (val e = estado) {
                EstadoVosk.NoInstalado -> {
                    Button(onClick = { vm.descargarVosk() }, shape = MaterialTheme.shapes.small) {
                        Text("Descargar modelo (${VoskModelo.TAMANO_ZIP_MB} MB)")
                    }
                    TextButton(onClick = { selector.launch(arrayOf("*/*")) }) { Text("Elegir el .zip que ya tengo") }
                }
                is EstadoVosk.Instalando -> {
                    if (e.progreso >= 0f) LinearProgressIndicator(progress = { e.progreso }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("${e.etapa}… ${e.mb} MB", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.cancelarVosk() }) { Text("Cancelar") }
                }
                EstadoVosk.Listo -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Entender mi voz sin internet", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = usar, onCheckedChange = { vm.alternarVosk(it) })
                    }
                    Text(
                        if (usar) "Motor al escuchar: Vosk, sin internet. Julio no usa el reconocimiento de Google."
                        else "Motor al escuchar: el del sistema (Google), que puede necesitar internet.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (diag.ultimoTexto.isNotEmpty()) {
                        Text(
                            "Última prueba: «${diag.ultimoTexto}». Modelo cargado en ${diag.cargaModeloMs} ms; " +
                                "texto listo ${diag.respuestaMs} ms después de dejar de hablar; " +
                                "memoria nativa de la app ${diag.memoriaNativaMb} MB.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    TextButton(onClick = { vm.eliminarVosk() }) { Text("Eliminar modelo instalado") }
                }
                is EstadoVosk.Error -> {
                    Text(e.mensaje, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    Button(onClick = { vm.descargarVosk() }, shape = MaterialTheme.shapes.small) { Text("Reintentar descarga") }
                    TextButton(onClick = { selector.launch(arrayOf("*/*")) }) { Text("Elegir el .zip que ya tengo") }
                }
            }
        }
    }
}

/** «Solo mi voz»: Julio aprende tu voz y deja de hacer caso a la tele u otras personas. Nada se baja hasta que lo pides. */
@Composable
private fun VozDuenoPanel(vm: VozViewModel) {
    val vosk by vm.voskEstado.collectAsStateWithLifecycle()
    val modelo by vm.duenoModelo.collectAsStateWithLifecycle()
    val huella by vm.duenoHuella.collectAsStateWithLifecycle()
    val solo by vm.soloMiVoz.collectAsStateWithLifecycle()
    val umbral by vm.duenoUmbral.collectAsStateWithLifecycle()
    val entreno by vm.duenoEntrenamiento.collectAsStateWithLifecycle()
    val mensaje by vm.duenoMensaje.collectAsStateWithLifecycle()
    val pedirParaEntrenar = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.entrenarMiVoz()
    }
    val pedirParaProbar = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.probarMiVoz()
    }
    val permiso = "android.permission.RECORD_AUDIO"
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Mi voz (solo obedece a quien entrene)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Julio aprende tu voz con 3 muestras de ${com.julio.asistente.voz.VozDueno.SEGUNDOS_MUESTRA} segundos y después ignora " +
                    "las frases de otras voces (la tele, otras personas). Usa el modelo «${com.julio.asistente.voz.VozDueno.NOMBRE}» " +
                    "(${com.julio.asistente.voz.VozDueno.TAMANO_ZIP_MB} MB, de ${com.julio.asistente.voz.VozDueno.ORIGEN}), que no se baja " +
                    "hasta que toques el botón. Solo se guarda un perfil numérico de tu voz, no audio, y no sale del teléfono. " +
                    "No es una cerradura: una grabación tuya podría pasar.",
                style = MaterialTheme.typography.bodySmall,
            )
            if (vosk !is EstadoVosk.Listo) {
                Text("Primero instala el reconocimiento de voz sin internet (arriba).", style = MaterialTheme.typography.bodySmall)
            } else when (val m = modelo) {
                EstadoVosk.NoInstalado -> Button(onClick = { vm.descargarModeloDueno() }, shape = MaterialTheme.shapes.small) {
                    Text("Descargar modelo de voz (${com.julio.asistente.voz.VozDueno.TAMANO_ZIP_MB} MB)")
                }
                is EstadoVosk.Instalando -> {
                    if (m.progreso >= 0f) LinearProgressIndicator(progress = { m.progreso }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("${m.etapa}… ${m.mb} MB", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.cancelarModeloDueno() }) { Text("Cancelar") }
                }
                is EstadoVosk.Error -> {
                    Text(m.mensaje, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    Button(onClick = { vm.descargarModeloDueno() }, shape = MaterialTheme.shapes.small) { Text("Reintentar descarga") }
                }
                EstadoVosk.Listo -> {
                    when (val e = entreno) {
                        is com.julio.asistente.voz.EntrenamientoVoz.Grabando -> {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text(
                                if (e.total > 1) "Muestra ${e.paso} de ${e.total}: habla con naturalidad durante ${e.segundos} segundos " +
                                    "(por ejemplo, cuenta qué hiciste hoy)."
                                else "Habla durante ${e.segundos} segundos…",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        is com.julio.asistente.voz.EntrenamientoVoz.Error ->
                            Text(e.mensaje, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        com.julio.asistente.voz.EntrenamientoVoz.Inactivo -> {}
                    }
                    val grabando = entreno is com.julio.asistente.voz.EntrenamientoVoz.Grabando
                    if (!huella) {
                        Button(
                            enabled = !grabando,
                            onClick = { if (vm.permisoMicrofono()) vm.entrenarMiVoz() else pedirParaEntrenar.launch(permiso) },
                            shape = MaterialTheme.shapes.small,
                        ) { Text("Entrenar mi voz (3 muestras)") }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Solo obedecer a mi voz", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            Switch(checked = solo, onCheckedChange = { vm.alternarSoloMiVoz(it) })
                        }
                        Text("Qué tan estricto:", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                "Más estricto" to com.julio.asistente.voz.HablanteMath.UMBRAL_ESTRICTO,
                                "Normal" to com.julio.asistente.voz.HablanteMath.UMBRAL_NORMAL,
                                "Más permisivo" to com.julio.asistente.voz.HablanteMath.UMBRAL_PERMISIVO,
                            ).forEach { (nombre, valor) ->
                                if (umbral == valor) Button(onClick = { vm.cambiarSensibilidadDueno(valor) }, shape = MaterialTheme.shapes.small) { Text(nombre) }
                                else TextButton(onClick = { vm.cambiarSensibilidadDueno(valor) }) { Text(nombre) }
                            }
                        }
                        Button(
                            enabled = !grabando,
                            onClick = { if (vm.permisoMicrofono()) vm.probarMiVoz() else pedirParaProbar.launch(permiso) },
                            shape = MaterialTheme.shapes.small,
                        ) { Text("Probar mi voz (5 s)") }
                        TextButton(
                            enabled = !grabando,
                            onClick = { if (vm.permisoMicrofono()) vm.entrenarMiVoz() else pedirParaEntrenar.launch(permiso) },
                        ) { Text("Volver a entrenar") }
                        TextButton(onClick = { vm.borrarMiVoz() }) { Text("Borrar mi perfil de voz") }
                    }
                    mensaje?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    TextButton(onClick = { vm.eliminarModeloDueno() }) { Text("Eliminar modelo de hablante") }
                }
            }
        }
    }
}

/** Notificaciones de Julio: permiso, resumen de la mañana, pendientes de la tarde y avisos automáticos. */
@Composable
private fun AvisosPanel() {
    val ctx = LocalContext.current
    val alcance = rememberCoroutineScope()
    val ajustes by AvisosAjustes.ajustes.collectAsStateWithLifecycle()
    var permiso by remember { mutableStateOf(Permisos.notificaciones(ctx)) }
    val pedir = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { permiso = Permisos.notificaciones(ctx) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        AvisosAjustes.cargar(ctx)
        permiso = Permisos.notificaciones(ctx)
    }

    fun cambiar(nuevo: AjustesAvisos) {
        AvisosAjustes.guardar(ctx, nuevo)
        AvisosProgramador.programar(ctx)
        alcance.launch(Dispatchers.IO) { RecordatorioProgramador.reprogramarTodos(ctx) }
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!permiso) {
                Text(
                    "Las notificaciones están apagadas: sin ellas Julio no puede avisarte de nada (tareas, horario ni el fin del enfoque).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
                Button(
                    onClick = {
                        if (android.os.Build.VERSION.SDK_INT >= 33) pedir.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else ctx.startActivity(Permisos.ajustesNotificaciones(ctx))
                    },
                    shape = MaterialTheme.shapes.small,
                ) { Text("Activar notificaciones") }
                TextButton(onClick = { ctx.startActivity(Permisos.ajustesNotificaciones(ctx)) }) { Text("Abrir ajustes de notificaciones") }
            }

            FilaAviso("Resumen de la mañana", ajustes.resumenManana) { cambiar(ajustes.copy(resumenManana = it)) }
            if (ajustes.resumenManana) {
                OpcionesAviso(listOf(6 * 60, 7 * 60, 8 * 60, 9 * 60), ajustes.horaManana, { "${it / 60}:00" }) {
                    cambiar(ajustes.copy(horaManana = it))
                }
            }

            FilaAviso("Recordar las tareas pendientes por la tarde", ajustes.pendientesTarde) { cambiar(ajustes.copy(pendientesTarde = it)) }
            if (ajustes.pendientesTarde) {
                OpcionesAviso(listOf(17 * 60, 18 * 60, 19 * 60, 20 * 60), ajustes.horaTarde, { "${it / 60}:00" }) {
                    cambiar(ajustes.copy(horaTarde = it))
                }
            }

            Text("Avisar mis actividades del horario (las que no tengan aviso propio)", style = MaterialTheme.typography.bodyMedium)
            OpcionesAviso(
                listOf(-1, 0, 5, 10, 15, 30), ajustes.horarioMin,
                { if (it < 0) "Sin aviso" else if (it == 0) "Al empezar" else "$it min antes" },
            ) { cambiar(ajustes.copy(horarioMin = it)) }

            FilaAviso("Avisar las tareas con fecha límite a las 8:00 del día", ajustes.tareasAutomaticas) {
                cambiar(ajustes.copy(tareasAutomaticas = it))
            }
            Text(
                "Las alarmas, el plan de estudio y el fin del modo enfoque avisan siempre que las notificaciones estén permitidas. " +
                    "En Xiaomi, Samsung y otros, deja a Julio «sin restricciones» de batería para que los avisos lleguen con la app cerrada.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun FilaAviso(titulo: String, activo: Boolean, alCambiar: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(titulo, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = activo, onCheckedChange = alCambiar)
    }
}

@Composable
private fun OpcionesAviso(valores: List<Int>, actual: Int, etiqueta: (Int) -> String, alElegir: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (v in valores) {
            FilterChip(selected = v == actual, onClick = { alElegir(v) }, label = { Text(etiqueta(v)) })
        }
    }
}

private class FilaPermiso(val nombre: String, val detalle: String, val concedido: Boolean, val abrir: () -> Intent)

/** Estado de los permisos (solo lectura); «Abrir» lleva a los mismos ajustes del sistema que ya usa la app. */
@Composable
private fun PermisosLista() {
    val ctx = LocalContext.current
    var version by remember { mutableStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { version++ }
    val filas = remember(version) {
        val bloqueo = BloqueoControl.permisos(ctx)
        listOf(
            FilaPermiso(
                "Micrófono", "Para hablar con Julio",
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            ) { Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")) },
            FilaPermiso("Notificaciones", "Para avisos y recordatorios", Permisos.notificaciones(ctx)) { Permisos.ajustesNotificaciones(ctx) },
            FilaPermiso("Alarmas exactas", "Para que las alarmas suenen a su hora", Permisos.alarmasExactas(ctx)) { Permisos.ajustesAlarmasExactas(ctx) },
            FilaPermiso("Alarma en pantalla completa", "Para mostrar la alarma con el teléfono bloqueado", Permisos.pantallaCompleta(ctx)) { Permisos.ajustesPantallaCompleta(ctx) },
            FilaPermiso("Acceso de uso", "Solo para el bloqueo de apps", bloqueo.acceso) { BloqueoControl.ajustesAcceso(ctx) },
            FilaPermiso("Mostrar sobre otras apps", "Solo para el bloqueo de apps", bloqueo.superposicion) { BloqueoControl.ajustesSuperposicion(ctx) },
        )
    }
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            filas.forEach { f ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.nombre, style = MaterialTheme.typography.bodyMedium)
                        Text(f.detalle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (f.concedido) {
                        Text("Concedido", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    } else {
                        TextButton(onClick = {
                            try {
                                ctx.startActivity(f.abrir().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) {
                                // Si el teléfono no tiene esa pantalla de ajustes, no pasa nada.
                            }
                        }) { Text("Abrir") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuiaComandos(alProbarEjemplo: (String) -> Unit) {
    var categoria by rememberSaveable { mutableStateOf(-1) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            GUIA.forEachIndexed { indice, cat ->
                FilterChip(
                    selected = categoria == indice,
                    onClick = { categoria = if (categoria == indice) -1 else indice },
                    label = { Text(cat.titulo) },
                )
            }
        }
        val abierta = GUIA.getOrNull(categoria)
        AnimatedVisibility(visible = abierta != null) {
            if (abierta != null) {
                PanelJulio(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "Puedes decirle a Julio:",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        abierta.ejemplos.forEach { ejemplo ->
                            Text(
                                "«$ejemplo»",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { alProbarEjemplo(ejemplo) }
                                    .padding(vertical = 8.dp),
                            )
                        }
                        Text("Toca un ejemplo para probarlo.", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

private class CategoriaGuia(val titulo: String, val ejemplos: List<String>)

/** Solo ejemplos que el intérprete realmente entiende hoy (verificados con pruebas de la lógica). */
private val GUIA = listOf(
    CategoriaGuia("Horario", listOf(
        "¿Qué tengo programado hoy?",
        "Agrega laboratorio de química mañana a las dos de la tarde",
        "Agrega clase de anatomía mañana de 8 a 10",
        "Programa clases de lunes a viernes a las siete de la mañana",
        "Agrega estudio de medicina los lunes, miércoles y viernes a las cuatro de la tarde",
        "Programa gimnasio todos los días a las dos de la tarde",
        "Repite esta actividad todos los martes y jueves",
        "¿Qué clases tengo el lunes?",
        "Mueve el laboratorio de química para el viernes a las cuatro de la tarde",
        "Elimina la clase de anatomía",
    )),
    CategoriaGuia("Lista de tareas", listOf(
        "Agrega estudiar anatomía a mis tareas",
        "¿Qué tareas tengo pendientes?",
        "Marca como terminada la tarea del informe",
        "Cambia el nombre de la tarea informe por informe final",
        "Elimina la tarea del informe",
    )),
    CategoriaGuia("Estudio", listOf(
        "Tengo examen de anatomía el 5 de noviembre con los temas huesos, músculos y nervios",
        "¿Qué me toca estudiar hoy?",
        "Empieza mi sesión de estudio",
        "Ya estudié",
        "¿Cómo va mi racha?",
    )),
    CategoriaGuia("Alarmas", listOf(
        "Pon una alarma para mañana a las seis de la mañana",
        "Desactiva la alarma del domingo",
        "Cambia la alarma de las seis a las siete",
        "Elimina la alarma de las seis",
    )),
    CategoriaGuia("Modo enfoque", listOf(
        "Inicia una sesión de enfoque de 35 minutos",
        "Quiero estudiar durante una hora y veinte minutos",
        "Configura un descanso de diez minutos",
    )),
    CategoriaGuia("Teléfono", listOf(
        "Sube el volumen",
        "Pon el volumen al 40 por ciento",
        "Silencia el teléfono",
        "Baja el brillo",
        "Abre WhatsApp",
    )),
)

private fun abrirAjustesDeVoz(ctx: Context) {
    try {
        ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

@Composable
private fun AjustesVozPanel(vm: VozViewModel, alAbrirSistema: () -> Unit) {
    val ajustes by vm.ajustesVoz.collectAsStateWithLifecycle()
    var voces by remember { mutableStateOf(vm.vocesDisponibles()) }
    var menu by remember { mutableStateOf(false) }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Voz de Julio", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Si Dave está instalado y activado arriba, Julio habla con él. Si no, usa las voces de tu teléfono " +
                    "(las del motor de voz predeterminado de Android); este selector elige esa voz. " +
                    "Si la quieres más grave, baja el tono.",
                style = MaterialTheme.typography.bodySmall,
            )
            val actual = voces.firstOrNull { it.nombre == ajustes.voz }?.etiqueta ?: "Automática"
            Box {
                OutlinedButton(
                    onClick = { voces = vm.vocesDisponibles(); menu = true },
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(actual, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Automática") },
                        onClick = { vm.elegirVoz(null); menu = false },
                    )
                    voces.forEach { v ->
                        DropdownMenuItem(
                            text = { Text(v.etiqueta) },
                            onClick = { vm.elegirVoz(v.nombre); menu = false },
                        )
                    }
                }
            }
            if (voces.isEmpty()) {
                Text(
                    "Todavía no se cargó la lista de voces. Toca el selector otra vez en unos segundos.",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Text("Tono (más grave ← → más agudo)", style = MaterialTheme.typography.labelMedium)
            Slider(value = ajustes.tono, onValueChange = { vm.cambiarTono(it) }, valueRange = 0.5f..1.4f)
            Text("Velocidad (más lenta ← → más rápida)", style = MaterialTheme.typography.labelMedium)
            Slider(value = ajustes.velocidad, onValueChange = { vm.cambiarVelocidad(it) }, valueRange = 0.6f..1.3f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.probarVoz() }, shape = MaterialTheme.shapes.small) { Text("Probar voz") }
                TextButton(onClick = alAbrirSistema) { Text("Más voces (Ajustes)") }
            }
        }
    }
}
