package com.julio.asistente.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.animacion.JulioAnimado
import com.julio.asistente.animacion.JulioEstado
import com.julio.asistente.animacion.Principal
import com.julio.asistente.escritorio.CalculoEscritorio
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.voz.VozViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private tailrec fun Context.actividad(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.actividad()
    else -> null
}

/**
 * Modo escritorio (Etapa 1 del Proyecto Cuerpo): pantalla siempre encendida, fondo negro, brillo bajo (más bajo de noche),
 * barras del sistema ocultas y la imagen se desplaza unos píxeles cada pocos minutos para no quemar la pantalla AMOLED.
 * Tocar la pantalla muestra el botón para salir; también sale con «atrás».
 */
@Composable
fun EscritorioScreen(vm: VozViewModel) {
    val ctx = LocalContext.current
    val act = remember(ctx) { ctx.actividad() }
    val principal by JulioEstado.principal.collectAsStateWithLifecycle()
    val capa by JulioEstado.capa.collectAsStateWithLifecycle()
    val orbeColor by vm.orbeColor.collectAsStateWithLifecycle()
    val despertarError by vm.despertarError.collectAsStateWithLifecycle()
    var controles by remember { mutableStateOf(false) }
    var minutos by remember { mutableLongStateOf(System.currentTimeMillis() / 60_000L) }

    BackHandler { EscritorioControl.salir(ctx) }

    // Pantalla encendida y sin barras mientras dure el modo; al salir todo vuelve a como estaba.
    DisposableEffect(act) {
        val w = act?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val ctl = w?.let { WindowCompat.getInsetsController(it, it.decorView) }
        ctl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            ctl?.show(WindowInsetsCompat.Type.systemBars())
            w?.let { it.attributes = it.attributes.also { a -> a.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE } }
        }
    }

    // Etapa 2: oír «Julio» mientras este modo esté abierto.
    DisposableEffect(vm) {
        EscritorioControl.asegurarServicio(ctx)
        vm.activarDespertar()
        onDispose { vm.desactivarDespertar() }
    }

    // Brillo según la hora (se revisa cada minuto) y reloj/desplazamiento (cada 15 s).
    LaunchedEffect(act) {
        while (true) {
            val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            act?.window?.let { it.attributes = it.attributes.also { a -> a.screenBrightness = CalculoEscritorio.brilloPorHora(hora) } }
            minutos = System.currentTimeMillis() / 60_000L
            delay(15_000L)
        }
    }

    // En reposo, Julio pasa pronto a «dormido» (orbe casi apagado, sin partículas ni barrido).
    LaunchedEffect(principal) {
        if (principal == Principal.REPOSO) {
            delay(CalculoEscritorio.DORMIR_SEG * 1000L)
            JulioEstado.dormir()
        }
    }

    // El botón de salir se esconde solo.
    LaunchedEffect(controles) {
        despertarError?.let {
            Text(
                it,
                color = Color(0xFF7F1D1D),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp, start = 24.dp, end = 24.dp),
            )
        }
        if (controles) {
            delay(5_000L)
            controles = false
        }
    }

    val (dx, dy) = CalculoEscritorio.desplazamiento(minutos)
    val ox by animateDpAsState(dx.dp, tween(4000), label = "dx")
    val oy by animateDpAsState(dy.dp, tween(4000), label = "dy")
    val hora = remember(minutos) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(minutos * 60_000L)) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) { detectTapGestures(onTap = { controles = true }) },
    ) {
        Column(
            Modifier.align(Alignment.Center).offset(ox, oy).padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            JulioAnimado(
                principal = principal,
                capa = capa,
                nivelMic = { vm.nivel.value },
                nivelHabla = { vm.nivelHabla() },
                palabras = { vm.palabras.value },
                alToque = {
                    controles = true
                    vm.interrumpir()
                },
                colorPorEstado = orbeColor,
                modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp),
            )
            Text(
                hora,
                color = Color(0xFF4B5563),
                fontSize = 40.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Monospace,
            )
        }
        if (controles) {
            OutlinedButton(
                onClick = { EscritorioControl.salir(ctx) },
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp),
            ) { Text("Salir del modo escritorio") }
        }
    }
}
