package com.julio.asistente.avisos

import java.time.LocalTime

/** Lógica pura (sin Android) de los avisos: qué aviso corresponde y qué texto llevan. */
object CalculoAvisos {
    class ItemAgenda(val hora: LocalTime, val titulo: String)

    /** El aviso propio manda; si no tiene, el de por defecto (null = sin aviso). */
    fun minutosAviso(propio: Int?, porDefecto: Int?): Int? = propio ?: porDefecto

    private fun hhmm(t: LocalTime): String = "${t.hour}:${t.minute.toString().padStart(2, '0')}"

    private fun unir(items: List<String>, max: Int = 4): String =
        if (items.size <= max) items.joinToString(", ")
        else items.take(max).joinToString(", ") + " y ${items.size - max} más"

    /** Resumen de la mañana: (título, texto), o null si no hay nada que decir. */
    fun resumenManana(actividades: List<ItemAgenda>, tareasHoy: List<String>, vencidas: List<String>): Pair<String, String>? {
        if (actividades.isEmpty() && tareasHoy.isEmpty() && vencidas.isEmpty()) return null
        val partes = mutableListOf<String>()
        if (actividades.isNotEmpty()) partes += "Actividades: " + unir(actividades.map { "${hhmm(it.hora)} ${it.titulo}" }) + "."
        if (tareasHoy.isNotEmpty()) partes += "Tareas para hoy: " + unir(tareasHoy) + "."
        if (vencidas.isNotEmpty()) partes += "Vencidas: " + unir(vencidas) + "."
        return "Buenos días, esto tienes hoy" to partes.joinToString(" ")
    }

    /** Aviso de la tarde con lo que sigue sin hacer: (título, texto), o null si no falta nada. */
    fun pendientesTarde(tareasHoy: List<String>, vencidas: List<String>): Pair<String, String>? {
        if (tareasHoy.isEmpty() && vencidas.isEmpty()) return null
        val partes = mutableListOf<String>()
        if (tareasHoy.isNotEmpty()) partes += "Para hoy: " + unir(tareasHoy) + "."
        if (vencidas.isNotEmpty()) partes += "Vencidas: " + unir(vencidas) + "."
        return "Hey, te faltan tareas por hacer" to partes.joinToString(" ")
    }
}
