package com.julio.asistente.avisos

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Lo que Julio te avisa por notificación. Todo viene encendido de fábrica. Horas = minutos desde medianoche. */
data class AjustesAvisos(
    val resumenManana: Boolean = true,
    val horaManana: Int = 7 * 60,
    val pendientesTarde: Boolean = true,
    val horaTarde: Int = 19 * 60,
    /** Aviso de las actividades del horario que no tienen aviso propio: minutos antes (0 = al empezar, -1 = ninguno). */
    val horarioMin: Int = 10,
    /** Las tareas con fecha límite avisan solas el día del vencimiento, a la hora de [tareaMinutoDia]. */
    val tareasAutomaticas: Boolean = true,
    val tareaMinutoDia: Int = 8 * 60,
)

object AvisosAjustes {
    private val _ajustes = MutableStateFlow(AjustesAvisos())
    val ajustes: StateFlow<AjustesAvisos> = _ajustes.asStateFlow()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("julio_avisos", Context.MODE_PRIVATE)

    fun cargar(c: Context) {
        val p = sp(c)
        val base = AjustesAvisos()
        _ajustes.value = AjustesAvisos(
            resumenManana = p.getBoolean("resumenManana", base.resumenManana),
            horaManana = p.getInt("horaManana", base.horaManana),
            pendientesTarde = p.getBoolean("pendientesTarde", base.pendientesTarde),
            horaTarde = p.getInt("horaTarde", base.horaTarde),
            horarioMin = p.getInt("horarioMin", base.horarioMin),
            tareasAutomaticas = p.getBoolean("tareasAutomaticas", base.tareasAutomaticas),
            tareaMinutoDia = p.getInt("tareaMinutoDia", base.tareaMinutoDia),
        )
    }

    fun guardar(c: Context, nuevo: AjustesAvisos) {
        sp(c).edit()
            .putBoolean("resumenManana", nuevo.resumenManana)
            .putInt("horaManana", nuevo.horaManana)
            .putBoolean("pendientesTarde", nuevo.pendientesTarde)
            .putInt("horaTarde", nuevo.horaTarde)
            .putInt("horarioMin", nuevo.horarioMin)
            .putBoolean("tareasAutomaticas", nuevo.tareasAutomaticas)
            .putInt("tareaMinutoDia", nuevo.tareaMinutoDia)
            .apply()
        _ajustes.value = nuevo
    }

    /** Aviso por defecto de las actividades sin aviso propio (null = ninguno). */
    fun horarioPorDefecto(c: Context): Int? {
        cargar(c)
        return _ajustes.value.horarioMin.takeIf { it >= 0 }
    }

    /** Hora (minutos desde medianoche) por defecto del aviso de tareas con fecha límite (null = ninguno). */
    fun tareaPorDefecto(c: Context): Int? {
        cargar(c)
        return if (_ajustes.value.tareasAutomaticas) _ajustes.value.tareaMinutoDia else null
    }
}
