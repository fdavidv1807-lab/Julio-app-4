package com.julio.asistente.recordatorios

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.julio.asistente.avisos.AvisosAjustes
import com.julio.asistente.core.Permisos
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.data.local.TareaEntity
import kotlinx.coroutines.flow.first
import java.time.ZonedDateTime

/** Programa con AlarmManager el próximo aviso de cada actividad/tarea (uno por elemento). */
object RecordatorioProgramador {
    const val ACCION = "com.julio.asistente.RECORDATORIO"
    const val EXTRA_TIPO = "tipo"
    const val EXTRA_ID = "id"
    const val TIPO_ACTIVIDAD = "A"
    const val TIPO_TAREA = "T"

    private fun alarmManager(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pendiente(c: Context, tipo: String, id: Long, flags: Int): PendingIntent? {
        val intent = Intent(c, RecordatorioReceiver::class.java).apply {
            action = ACCION
            data = Uri.parse("julio://recordatorio/$tipo/$id")
            putExtra(EXTRA_TIPO, tipo)
            putExtra(EXTRA_ID, id)
        }
        val codigo = id.toInt() * 2 + if (tipo == TIPO_TAREA) 1 else 0
        return PendingIntent.getBroadcast(c, codigo, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    fun cancelar(c: Context, tipo: String, id: Long) {
        pendiente(c, tipo, id, PendingIntent.FLAG_NO_CREATE)?.let {
            alarmManager(c).cancel(it)
            it.cancel()
        }
    }

    private fun armar(c: Context, tipo: String, id: Long, momento: ZonedDateTime?) {
        if (momento == null) {
            cancelar(c, tipo, id)
            return
        }
        val pi = pendiente(c, tipo, id, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        val ms = momento.toInstant().toEpochMilli()
        val am = alarmManager(c)
        try {
            if (Permisos.alarmasExactas(c)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }

    /** Si la actividad no tiene aviso propio, usa el de «Configuración > Avisos» (10 min antes de fábrica). */
    fun programarActividad(c: Context, a: ActividadEntity, ahora: ZonedDateTime = ZonedDateTime.now()) =
        armar(c, TIPO_ACTIVIDAD, a.id, CalculoRecordatorio.proximoActividad(a, ahora, AvisosAjustes.horarioPorDefecto(c)))

    /** Si la tarea tiene fecha límite pero no aviso propio, avisa ese día a la hora de «Configuración > Avisos». */
    fun programarTarea(c: Context, t: TareaEntity, ahora: ZonedDateTime = ZonedDateTime.now()) =
        armar(c, TIPO_TAREA, t.id, CalculoRecordatorio.proximoTarea(t, ahora, AvisosAjustes.tareaPorDefecto(c)))

    /** Tras reiniciar, actualizar la app o cambiar la hora, el sistema olvida las alarmas. */
    suspend fun reprogramarTodos(c: Context) {
        val db = JulioDatabase.get(c)
        db.actividadDao().observarTodas().first().forEach { programarActividad(c, it) }
        db.tareaDao().observarTodas().first().filter { !it.completada }.forEach { programarTarea(c, it) }
    }
}
