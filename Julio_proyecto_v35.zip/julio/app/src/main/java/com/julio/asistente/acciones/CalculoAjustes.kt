package com.julio.asistente.acciones

import com.julio.asistente.comandos.AccionNivel
import kotlin.math.ceil
import kotlin.math.roundToInt

/** Cuentas puras (sin Android) del volumen y el brillo, para poder probarlas. */
object CalculoAjustes {
    const val PASO_PCT = 15

    /** Nuevo porcentaje (0 a 100) tras subir, bajar o fijar. Las demás acciones lo dejan igual. */
    fun nuevoPorcentaje(actual: Int, accion: AccionNivel, nivel: Int?, paso: Int = PASO_PCT): Int = when (accion) {
        AccionNivel.SUBIR -> (actual + paso).coerceAtMost(100)
        AccionNivel.BAJAR -> (actual - paso).coerceAtLeast(0)
        AccionNivel.FIJAR -> (nivel ?: actual).coerceIn(0, 100)
        else -> actual
    }

    fun pasosDeVolumen(porcentaje: Int, max: Int): Int = (porcentaje * max / 100f).roundToInt().coerceIn(0, max)

    fun porcentajeDeVolumen(pasos: Int, max: Int): Int = if (max <= 0) 0 else (pasos * 100f / max).roundToInt().coerceIn(0, 100)

    /**
     * Pasos del volumen del sistema (0..max) tras la acción. Subir y bajar siempre mueven al menos un paso
     * (salvo en el tope). [previo] = volumen antes de silenciar, para «activa el sonido».
     */
    fun nuevoVolumenPasos(actual: Int, max: Int, accion: AccionNivel, nivel: Int?, previo: Int?): Int {
        if (max <= 0) return 0
        val porcentaje = porcentajeDeVolumen(actual, max)
        return when (accion) {
            AccionNivel.SILENCIAR -> 0
            AccionNivel.ACTIVAR -> if (actual > 0) actual else (previo?.takeIf { it > 0 } ?: ceil(max / 2f).toInt()).coerceIn(1, max)
            AccionNivel.SUBIR -> {
                val t = pasosDeVolumen(nuevoPorcentaje(porcentaje, accion, null), max)
                if (t <= actual) minOf(actual + 1, max) else t
            }
            AccionNivel.BAJAR -> {
                val t = pasosDeVolumen(nuevoPorcentaje(porcentaje, accion, null), max)
                if (t >= actual) maxOf(actual - 1, 0) else t
            }
            AccionNivel.FIJAR -> pasosDeVolumen(nivel ?: porcentaje, max)
            else -> actual
        }
    }

    /** Brillo del sistema: nunca 0 (pantalla negra imposible de recuperar sin tocar). */
    fun limitarBrilloSistema(porcentaje: Int): Int = porcentaje.coerceIn(1, 100)

    /** Valor 1..255 de Settings.System.SCREEN_BRIGHTNESS para un porcentaje. */
    fun brilloSistemaValor(porcentaje: Int): Int = (limitarBrilloSistema(porcentaje) * 255 / 100).coerceIn(1, 255)

    fun brilloSistemaPorcentaje(valor: Int): Int = (valor * 100f / 255f).roundToInt().coerceIn(0, 100)
}
