package com.julio.asistente.voz

import android.content.Context
import android.content.res.AssetManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Habla con la voz neuronal Piper usando sherpa-onnx. La librería se usa por reflexión: si no está en esta
 * compilación (o falla), [hablar] avisa con [alFallar] y Julio usa la voz del teléfono; nunca se queda mudo.
 *
 * El tono y la velocidad de Julio también funcionan aquí: el tono cambia la frecuencia de reproducción
 * (más grave = más bajo) y la velocidad del modelo se compensa para que la rapidez total sea la elegida.
 */
class MotorPiper(private val contexto: Context) {
    private val hilo = Executors.newSingleThreadExecutor { r -> Thread(r, "julio-piper") }
    private val principal = Handler(Looper.getMainLooper())
    @Volatile private var generacion = 0
    @Volatile private var pistaActual: AudioTrack? = null
    private var motor: Any? = null
    private var tasaMotor = 22050

    /** Volumen de lo que va a sonar: cada trozo trae su hora de inicio y un nivel (0 a 1) cada [VENTANA_MS]. */
    private class Segmento(val inicioMs: Long, val niveles: FloatArray)
    private val segmentos = CopyOnWriteArrayList<Segmento>()
    private val desvanecedor = Handler(Looper.getMainLooper())

    /** Volumen (0 a 1) de lo que suena AHORA: sirve para mover la boca y el orbe. 0 si no suena nada. */
    fun nivelAhora(): Float {
        val ahora = SystemClock.elapsedRealtime()
        for (s in segmentos) {
            val i = ((ahora - s.inicioMs) / VENTANA_MS).toInt()
            if (ahora >= s.inicioMs && i < s.niveles.size) return s.niveles[i]
        }
        return 0f
    }

    /** Baja el volumen de la voz hasta cero en [ms] milisegundos y la corta (interrupción suave). */
    fun desvanecer(ms: Long) {
        val pista = pistaActual
        if (pista == null) {
            detener()
            return
        }
        val miGeneracion = generacion
        val inicio = SystemClock.elapsedRealtime()
        val paso = object : Runnable {
            override fun run() {
                val x = ((SystemClock.elapsedRealtime() - inicio).toFloat() / ms).coerceIn(0f, 1f)
                try {
                    pista.setVolume(1f - x)
                } catch (e: Throwable) {
                }
                if (x < 1f) desvanecedor.postDelayed(this, 20L) else if (miGeneracion == generacion) detener()
            }
        }
        desvanecedor.post(paso)
    }

    /** Nivel de cada ventana de [VENTANA_MS] ms, normalizado con la parte más fuerte de la frase. */
    private fun envolvente(muestras: FloatArray, tasa: Int): FloatArray {
        val por = max(1, tasa * VENTANA_MS / 1000)
        val n = (muestras.size + por - 1) / por
        val rms = FloatArray(n)
        var pico = 0f
        for (i in 0 until n) {
            val ini = i * por
            val fin = min(muestras.size, ini + por)
            var suma = 0f
            for (j in ini until fin) suma += muestras[j] * muestras[j]
            rms[i] = sqrt(suma / max(1, fin - ini))
            if (rms[i] > pico) pico = rms[i]
        }
        if (pico <= 0.0001f) return FloatArray(n)
        return FloatArray(n) { (rms[it] / (0.6f * pico)).coerceIn(0f, 1f) }
    }

    /** ¿Esta compilación incluye el motor neuronal? */
    val libreriaDisponible: Boolean by lazy {
        try {
            Class.forName("com.k2fsa.sherpa.onnx.OfflineTts", false, MotorPiper::class.java.classLoader)
            true
        } catch (e: Throwable) {
            false
        }
    }

    fun listo(): Boolean = libreriaDisponible && PiperModelo.estado.value == EstadoPiper.Lista

    fun hablar(
        texto: String, tono: Float, velocidad: Float,
        alPalabra: () -> Unit, alTerminar: () -> Unit, alFallar: (String) -> Unit,
    ) {
        val miGeneracion = ++generacion
        principal.removeCallbacksAndMessages(null)
        segmentos.clear()
        pausarPista()
        hilo.execute {
            try {
                val tts = cargarMotor() ?: throw IllegalStateException("el motor neuronal no está disponible")
                reproducir(tts, texto, tono, velocidad, miGeneracion, alPalabra)
                if (miGeneracion == generacion) principal.post { alTerminar() }
            } catch (e: Throwable) {
                if (miGeneracion == generacion) principal.post { alFallar(e.message ?: e.javaClass.simpleName) }
            }
        }
    }

    fun detener() {
        generacion++
        principal.removeCallbacksAndMessages(null)
        segmentos.clear()
        pausarPista()
    }

    /** Libera el modelo de la memoria (por ejemplo, al borrar la voz). */
    fun olvidar() {
        detener()
        hilo.execute {
            try {
                motor?.let { it.javaClass.getMethod("release").invoke(it) }
            } catch (e: Throwable) {
            }
            motor = null
        }
    }

    fun cerrar() {
        olvidar()
        hilo.shutdown()
    }

    private fun pausarPista() {
        try {
            pistaActual?.pause()
            pistaActual?.flush()
        } catch (e: Throwable) {
        }
    }

    // ---------- sherpa-onnx por reflexión ----------

    private fun poner(objeto: Any, metodo: String, valor: String) {
        objeto.javaClass.getMethod(metodo, String::class.java).invoke(objeto, valor)
    }

    private fun cargarMotor(): Any? {
        motor?.let { return it }
        val rutas = PiperModelo.rutas(contexto) ?: return null
        val pkg = "com.k2fsa.sherpa.onnx"
        val claseVits = Class.forName("$pkg.OfflineTtsVitsModelConfig")
        val claseModelo = Class.forName("$pkg.OfflineTtsModelConfig")
        val claseConfig = Class.forName("$pkg.OfflineTtsConfig")
        val claseTts = Class.forName("$pkg.OfflineTts")

        val vits = claseVits.getDeclaredConstructor().newInstance()
        poner(vits, "setModel", rutas.modelo)
        poner(vits, "setTokens", rutas.tokens)
        poner(vits, "setDataDir", rutas.datos)
        val modelo = claseModelo.getDeclaredConstructor().newInstance()
        claseModelo.getMethod("setVits", claseVits).invoke(modelo, vits)
        claseModelo.getMethod("setNumThreads", Int::class.javaPrimitiveType).invoke(modelo, 2)
        claseModelo.getMethod("setProvider", String::class.java).invoke(modelo, "cpu")
        val config = claseConfig.getDeclaredConstructor().newInstance()
        claseConfig.getMethod("setModel", claseModelo).invoke(config, modelo)

        val constructor = claseTts.constructors.firstOrNull { c ->
            c.parameterTypes.size == 2 && c.parameterTypes[0] == AssetManager::class.java && c.parameterTypes[1] == claseConfig
        }
        val tts = if (constructor != null) {
            constructor.newInstance(null, config)
        } else {
            claseTts.getConstructor(claseConfig).newInstance(config)
        }
        tasaMotor = (claseTts.getMethod("sampleRate").invoke(tts) as Number).toInt()
        motor = tts
        return tts
    }

    private fun generar(tts: Any, texto: String, velocidad: Float): FloatArray? {
        val metodo = tts.javaClass.getMethod("generate", String::class.java, Int::class.javaPrimitiveType, Float::class.javaPrimitiveType)
        val audio = metodo.invoke(tts, texto, 0, velocidad) ?: return null
        return audio.javaClass.getMethod("getSamples").invoke(audio) as? FloatArray
    }

    // ---------- texto y reproducción ----------

    /** Quita símbolos y escribe la hora como se dice, para que la pronunciación sea natural. */
    private fun limpiar(texto: String): String = texto
        .replace("a. m.", "de la mañana").replace("p. m.", "de la tarde")
        .replace(Regex("\\b(\\d{1,2}):00\\b"), "$1")
        .replace(Regex("\\b(\\d{1,2}):(\\d{2})\\b"), "$1 y $2")
        .replace(Regex("[«»\"*_#•·]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    /** Frases cortas: la primera suena enseguida y la siguiente se prepara mientras suena. */
    private fun dividir(texto: String): List<String> {
        val frases = limpiar(texto).split(Regex("(?<=[.!?…:;])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val resultado = ArrayList<String>()
        for (frase in frases) {
            if (frase.length <= 220) {
                resultado += frase
            } else {
                var actual = StringBuilder()
                for (trozo in frase.split(Regex("(?<=,)\\s+"))) {
                    if (actual.isNotEmpty() && actual.length + trozo.length > 200) {
                        resultado += actual.toString().trim()
                        actual = StringBuilder()
                    }
                    actual.append(trozo).append(' ')
                }
                if (actual.isNotBlank()) resultado += actual.toString().trim()
            }
        }
        return resultado
    }

    private fun crearPista(tasa: Int): AudioTrack {
        val atributos = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val formato = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
            .setSampleRate(tasa)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        val minimo = AudioTrack.getMinBufferSize(tasa, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        return AudioTrack.Builder()
            .setAudioAttributes(atributos)
            .setAudioFormat(formato)
            .setBufferSizeInBytes(max(minimo * 4, tasa * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun programarPalabras(frase: String, inicioMs: Long, duracionMs: Long, generacionActual: Int, alPalabra: () -> Unit) {
        val palabras = frase.split(" ").count { it.isNotBlank() }
        if (palabras == 0) return
        val ahora = SystemClock.elapsedRealtime()
        for (i in 0 until palabras) {
            val retraso = max(0L, inicioMs - ahora) + duracionMs * i / palabras
            principal.postDelayed({ if (generacionActual == generacion) alPalabra() }, retraso)
        }
    }

    private fun reproducir(tts: Any, texto: String, tono: Float, velocidad: Float, generacionActual: Int, alPalabra: () -> Unit) {
        val factorTono = tono.coerceIn(0.5f, 1.4f)
        val velocidadModelo = (velocidad / factorTono).coerceIn(0.4f, 2.5f)
        val tasaReproduccion = (tasaMotor * factorTono).roundToInt().coerceIn(8000, 48000)
        val pista = crearPista(tasaReproduccion)
        pistaActual = pista
        try {
            pista.play()
            var finMs = SystemClock.elapsedRealtime()
            var totalMuestras = 0L
            for (frase in dividir(texto)) {
                if (generacionActual != generacion) return
                val muestras = generar(tts, frase, velocidadModelo) ?: continue
                if (generacionActual != generacion) return
                val duracionMs = muestras.size * 1000L / tasaReproduccion
                val inicio = max(SystemClock.elapsedRealtime(), finMs)
                programarPalabras(frase, inicio, duracionMs, generacionActual, alPalabra)
                segmentos.add(Segmento(inicio + LATENCIA_MS, envolvente(muestras, tasaReproduccion)))
                finMs = inicio + duracionMs
                var posicion = 0
                while (posicion < muestras.size) {
                    if (generacionActual != generacion) return
                    val n = pista.write(muestras, posicion, min(4096, muestras.size - posicion), AudioTrack.WRITE_BLOCKING)
                    if (n < 0) throw IllegalStateException("error de audio ($n)")
                    posicion += n
                }
                totalMuestras += muestras.size
            }
            // Esperar a que termine de sonar lo que falta.
            val limite = SystemClock.elapsedRealtime() + (totalMuestras * 1000L / tasaReproduccion) + 3000
            while (generacionActual == generacion && pista.playbackHeadPosition < totalMuestras &&
                SystemClock.elapsedRealtime() < limite
            ) {
                Thread.sleep(40)
            }
        } finally {
            try {
                pista.stop()
            } catch (e: Throwable) {
            }
            pista.release()
            if (pistaActual === pista) pistaActual = null
        }
    }

    companion object {
        /** Cada cuántos milisegundos se mide el volumen de la voz. */
        private const val VENTANA_MS = 40

        /** Retraso entre escribir el audio y que se oiga; ajustable si la boca se adelanta o se atrasa. */
        private const val LATENCIA_MS = 80L
    }
}
