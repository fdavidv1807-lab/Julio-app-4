package com.julio.asistente.comandos

/** Una app instalada con pantalla de inicio. */
data class AppInfo(val nombre: String, val paquete: String)

sealed class BusquedaApp {
    data class Una(val app: AppInfo) : BusquedaApp()
    data class Varias(val apps: List<AppInfo>) : BusquedaApp()
    /** Es una app de banco o pagos: Julio nunca la abre por voz. */
    data class Bloqueada(val app: AppInfo) : BusquedaApp()
    object Ninguna : BusquedaApp()
}

/** Busca entre las apps instaladas la que la persona nombró. Lógica pura (se prueba sin Android). */
object Apps {
    /** Cómo suele transcribir Vosk los nombres en inglés. */
    private val ALIAS = mapOf(
        "guasap" to "whatsapp", "wasap" to "whatsapp", "whatsap" to "whatsapp", "guatsap" to "whatsapp", "wats" to "whatsapp",
        "feisbuk" to "facebook", "feis" to "facebook", "yutub" to "youtube", "iutub" to "youtube",
        "espotifai" to "spotify", "tiktok" to "tiktok", "yimeil" to "gmail", "imeil" to "gmail",
    )

    /** Pedazos de nombre o paquete que delatan banco o pagos. Si hay duda, no se abre (la persona la abre a mano). */
    private val SENSIBLES = listOf(
        "banco", "bank", "bancolombia", "davivienda", "daviplata", "nequi", "paypal", "wallet", "billetera",
        "pagos", "pago", "pay", "paisa", "transfer", "cartera", "nubank", "tarjeta",
    )

    fun esSensible(a: AppInfo): Boolean {
        val n = Texto.normalizar(a.nombre)
        val p = a.paquete.lowercase()
        return SENSIBLES.any { n.contains(it) || p.contains(it) }
    }

    private fun normalizarConsulta(consulta: String): String =
        Texto.normalizar(consulta).split(" ").filter { it.isNotEmpty() }.joinToString(" ") { ALIAS[it] ?: it }

    fun buscar(consulta: String, apps: List<AppInfo>): BusquedaApp {
        val q = normalizarConsulta(consulta)
        if (q.isBlank()) return BusquedaApp.Ninguna
        val tokens = q.split(" ")
        val conNombre = apps.map { it to Texto.normalizar(it.nombre) }

        val exactas = conNombre.filter { it.second == q }.map { it.first }
        if (exactas.size == 1) return resultado(exactas[0])
        if (exactas.size > 1) return BusquedaApp.Varias(exactas.take(4))

        val parecidas = conNombre.filter { (_, n) ->
            val palabras = n.split(" ")
            n.contains(q) || tokens.all { t -> palabras.any { it == t || it.startsWith(t) } }
        }.map { it.first }
        if (parecidas.isEmpty()) return BusquedaApp.Ninguna
        if (parecidas.size == 1) return resultado(parecidas[0])

        val alInicio = parecidas.filter { Texto.normalizar(it.nombre).startsWith(q) }
        if (alInicio.size == 1) return resultado(alInicio[0])
        return BusquedaApp.Varias(parecidas.sortedBy { it.nombre.length }.take(4))
    }

    private fun resultado(a: AppInfo): BusquedaApp = if (esSensible(a)) BusquedaApp.Bloqueada(a) else BusquedaApp.Una(a)
}
