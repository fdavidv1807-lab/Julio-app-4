package com.julio.asistente.voz

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.Executors

/** Datos para comprobar el reconocimiento sin internet (se muestran en Configuración > Voz). */
data class DiagnosticoVosk(
    val motor: String = "Aún no se ha usado",
    val cargaModeloMs: Long = 0,
    val respuestaMs: Long = 0,
    val memoriaNativaMb: Long = 0,
    val ultimoTexto: String = "",
    /** Resultado de comprobar que la voz era la del dueño (vacío = no se comprobó). */
    val verificacion: String = "",
)

/**
 * Reconocimiento de voz LOCAL con Vosk (Kaldi), modelo en español. Lee el micrófono con AudioRecord y pasa el audio
 * directamente al motor dentro del teléfono: no usa SpeechRecognizer, ni Google, ni ningún servicio en red.
 * El audio solo vive en memoria; no se guarda ni se envía a ningún lado.
 */
class ReconocedorVosk {
    interface Oyente {
        fun alPreparar()
        fun alEscuchar()
        fun alNivel(nivel: Float)
        fun alParcial(texto: String)
        fun alFinal(texto: String)
        fun alSinVoz()
        fun alError(mensaje: String)
        /** La voz oída no es la del dueño (distancia al perfil entrenado). Por defecto no se hace nada. */
        fun alVozAjena(distancia: Float) {}
    }

    private val _diagnostico = MutableStateFlow(DiagnosticoVosk())
    val diagnostico: StateFlow<DiagnosticoVosk> = _diagnostico.asStateFlow()

    private val hilo = Executors.newSingleThreadExecutor()
    private val principal = Handler(Looper.getMainLooper())
    @Volatile private var generacion = 0
    @Volatile private var escuchando = false
    private var modelo: Model? = null
    private var rutaModelo: String? = null

    private val soltarModelo = Runnable {
        hilo.execute { if (!escuchando) cerrarModelo() }
    }

    private fun cerrarModelo() {
        try { modelo?.close() } catch (e: Exception) { /* ya cerrado */ }
        modelo = null
        rutaModelo = null
    }

    /** Escucha una intervención y entrega el texto. Si ya había una escucha, la reemplaza. */
    fun escuchar(ruta: String, oyente: Oyente, verificar: VerificacionHablante? = null) {
        generacion++
        val mia = generacion
        principal.removeCallbacks(soltarModelo)
        escuchando = true
        hilo.execute { bucle(ruta, oyente, mia, verificar) }
    }

    /**
     * Graba [segundos] de tu voz y calcula su huella (vector de hablante) con el modelo de hablante de Vosk.
     * [alTerminar] (hilo principal): huella (null si no hubo suficiente voz), cantidad de audio con voz usada, error.
     * Reemplaza cualquier escucha en curso.
     */
    fun capturarHuella(ruta: String, rutaHablante: String, segundos: Int, alTerminar: (FloatArray?, Int, String?) -> Unit) {
        generacion++
        val mia = generacion
        principal.removeCallbacks(soltarModelo)
        escuchando = true
        hilo.execute { bucleHuella(ruta, rutaHablante, segundos, mia, alTerminar) }
    }

    private fun bucleHuella(ruta: String, rutaHablante: String, segundos: Int, mia: Int, alTerminar: (FloatArray?, Int, String?) -> Unit) {
        var grabadora: AudioRecord? = null
        var reconocedor: Recognizer? = null
        var error: String? = null
        val muestras = ArrayList<Pair<FloatArray, Int>>()
        try {
            if (modelo == null || rutaModelo != ruta) {
                cerrarModelo()
                modelo = Model(ruta)
                rutaModelo = ruta
            }
            val hablante = VozDueno.cargarModeloHablante(rutaHablante)
            if (mia != generacion) return
            reconocedor = Recognizer(modelo, MUESTREO.toFloat(), hablante)
            val minimo = AudioRecord.getMinBufferSize(MUESTREO, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimo <= 0) throw IllegalStateException("Este teléfono no permite abrir el micrófono con este formato.")
            grabadora = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, MUESTREO,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimo * 4, 16384),
            )
            if (grabadora.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("No pude abrir el micrófono (¿otra app lo está usando?).")
            }
            grabadora.startRecording()
            val trozo = ShortArray(MUESTREO / 10)
            val fin = SystemClock.elapsedRealtime() + segundos * 1000L
            while (mia == generacion && SystemClock.elapsedRealtime() < fin) {
                val n = grabadora.read(trozo, 0, trozo.size)
                if (n < 0) throw IllegalStateException("Falló la lectura del micrófono (código $n).")
                if (n == 0) continue
                if (reconocedor.acceptWaveForm(trozo, n)) HablanteMath.agregarMuestra(reconocedor.result, muestras)
            }
            if (mia != generacion) return
            HablanteMath.agregarMuestra(reconocedor.finalResult, muestras)
        } catch (e: Throwable) {
            error = e.message ?: e.javaClass.simpleName
        } finally {
            try { grabadora?.stop() } catch (e: Exception) { /* ya detenida */ }
            grabadora?.release()
            try { reconocedor?.close() } catch (e: Exception) { /* ya cerrado */ }
            if (mia == generacion) {
                escuchando = false
                programarLiberacion()
            }
        }
        if (mia != generacion) return
        val huella = HablanteMath.mediaPonderada(muestras)
        val total = muestras.sumOf { it.second }
        principal.post { alTerminar(huella, total, error) }
    }

    /**
     * Vigía de interrupción: mientras Julio habla, escucha SOLO unas pocas palabras clave (vocabulario limitado)
     * para no oír su propia voz ni gastar batería. Al detectar una, llama a [alDetectar] (en el hilo principal)
     * y se apaga. Usa el micrófono de «comunicación» y, si el teléfono lo trae, cancelación de eco.
     * Cualquier otra escucha ([escuchar]) o [detener] lo reemplaza o lo corta.
     */
    fun vigilarPalabrasClave(ruta: String, alDetectar: () -> Unit) {
        generacion++
        val mia = generacion
        principal.removeCallbacks(soltarModelo)
        escuchando = true
        hilo.execute { bucleClave(ruta, mia, alDetectar) }
    }

    /**
     * Vigía de despertar (Etapa 2): escucha SOLO la palabra «julio» (vocabulario limitado, todo lo demás cae en «[unk]»).
     * Funciona sin internet y el audio solo vive en memoria. Al oírla llama a [alDetectar] (hilo principal) y se apaga;
     * si falla algo llama a [alFallar] con el motivo real. Cualquier otra escucha o [detener] lo reemplaza o lo corta.
     */
    fun vigilarDespertar(ruta: String, alDetectar: () -> Unit, alFallar: (String) -> Unit) {
        generacion++
        val mia = generacion
        principal.removeCallbacks(soltarModelo)
        escuchando = true
        hilo.execute { bucleDespertar(ruta, mia, alDetectar, alFallar) }
    }

    private fun bucleDespertar(ruta: String, mia: Int, alDetectar: () -> Unit, alFallar: (String) -> Unit) {
        var grabadora: AudioRecord? = null
        var reconocedor: Recognizer? = null
        try {
            if (modelo == null || rutaModelo != ruta) {
                cerrarModelo()
                modelo = Model(ruta)
                rutaModelo = ruta
            }
            if (mia != generacion) return
            reconocedor = Recognizer(modelo, MUESTREO.toFloat(), GRAMATICA_DESPERTAR)
            val minimo = AudioRecord.getMinBufferSize(MUESTREO, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimo <= 0) throw IllegalStateException("Este teléfono no permite abrir el micrófono con este formato.")
            grabadora = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, MUESTREO,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimo * 4, 16384),
            )
            if (grabadora.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("No pude abrir el micrófono (¿otra app lo está usando?).")
            }
            grabadora.startRecording()
            val trozo = ShortArray(MUESTREO / 10) // 100 ms de audio
            while (mia == generacion) {
                val n = grabadora.read(trozo, 0, trozo.size)
                if (n < 0) throw IllegalStateException("Falló la lectura del micrófono (código $n).")
                if (n == 0) continue
                val texto = if (reconocedor.acceptWaveForm(trozo, n)) {
                    ReconocimientoUtil.extraer(reconocedor.result, "text")
                } else {
                    ReconocimientoUtil.extraer(reconocedor.partialResult, "partial")
                }
                if (ReconocimientoUtil.esDespertar(texto)) {
                    if (mia == generacion) principal.post { alDetectar() }
                    return
                }
            }
        } catch (e: Throwable) {
            if (mia == generacion) {
                val motivo = e.message ?: e.javaClass.simpleName
                principal.post { alFallar(motivo) }
            }
        } finally {
            try { grabadora?.stop() } catch (e: Exception) { /* ya detenida */ }
            grabadora?.release()
            try { reconocedor?.close() } catch (e: Exception) { /* ya cerrado */ }
            if (mia == generacion) {
                escuchando = false
                programarLiberacion()
            }
        }
    }

    private fun bucleClave(ruta: String, mia: Int, alDetectar: () -> Unit) {
        var grabadora: AudioRecord? = null
        var reconocedor: Recognizer? = null
        var eco: AcousticEchoCanceler? = null
        try {
            if (modelo == null || rutaModelo != ruta) {
                cerrarModelo()
                modelo = Model(ruta)
                rutaModelo = ruta
            }
            if (mia != generacion) return
            reconocedor = Recognizer(modelo, MUESTREO.toFloat(), GRAMATICA)

            val minimo = AudioRecord.getMinBufferSize(MUESTREO, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimo <= 0) return
            grabadora = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, MUESTREO,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimo * 4, 16384),
            )
            if (grabadora.state != AudioRecord.STATE_INITIALIZED) return
            try {
                if (AcousticEchoCanceler.isAvailable()) {
                    eco = AcousticEchoCanceler.create(grabadora.audioSessionId)
                    eco?.enabled = true
                }
            } catch (e: Throwable) {
                // Sin cancelación de eco: se sigue con el vocabulario limitado.
            }
            grabadora.startRecording()

            val trozo = ShortArray(MUESTREO / 10) // 100 ms de audio
            val inicioVigia = SystemClock.elapsedRealtime()
            var seguidas = 0
            while (mia == generacion) {
                val n = grabadora.read(trozo, 0, trozo.size)
                if (n < 0) return
                if (n == 0) continue
                val esFinal = reconocedor.acceptWaveForm(trozo, n)
                val deteccion = if (esFinal) {
                    ReconocimientoUtil.hayInterrupcion(ReconocimientoUtil.extraer(reconocedor.result, "text"), true)
                } else {
                    ReconocimientoUtil.hayInterrupcion(ReconocimientoUtil.extraer(reconocedor.partialResult, "partial"), false)
                }
                seguidas = if (deteccion) seguidas + 1 else 0
                // Un ruido suelto o el arranque de la propia voz de Julio no cortan: hay que oír la palabra
                // pasado el primer momento y confirmada (resultado final, o dos lecturas seguidas).
                val pasoLaGracia = SystemClock.elapsedRealtime() - inicioVigia > GRACIA_INTERRUPCION_MS
                if (pasoLaGracia && deteccion && (esFinal || seguidas >= 2)) {
                    if (mia == generacion) principal.post { alDetectar() }
                    return
                }
            }
        } catch (e: Throwable) {
            // Sin vigía no pasa nada grave: queda el toque en el orbe para interrumpir.
        } finally {
            try { eco?.release() } catch (e: Throwable) { /* ya liberado */ }
            try { grabadora?.stop() } catch (e: Exception) { /* ya detenida */ }
            grabadora?.release()
            try { reconocedor?.close() } catch (e: Exception) { /* ya cerrado */ }
            if (mia == generacion) {
                escuchando = false
                programarLiberacion()
            }
        }
    }

    /** Cancela la escucha en curso (no entrega resultado). */
    fun detener() {
        generacion++
        escuchando = false
        programarLiberacion()
    }

    fun liberar() {
        generacion++
        escuchando = false
        principal.removeCallbacks(soltarModelo)
        hilo.execute { cerrarModelo() }
    }

    /** Pasados 2 minutos sin usar, se libera la memoria del modelo (se vuelve a cargar al hablar). */
    private fun programarLiberacion() {
        principal.removeCallbacks(soltarModelo)
        principal.postDelayed(soltarModelo, 120_000L)
    }

    private fun bucle(ruta: String, oyente: Oyente, mia: Int, verificar: VerificacionHablante?) {
        var grabadora: AudioRecord? = null
        var reconocedor: Recognizer? = null
        try {
            if (modelo == null || rutaModelo != ruta) {
                oyente.alPreparar()
                cerrarModelo()
                val t0 = SystemClock.elapsedRealtime()
                modelo = Model(ruta)
                rutaModelo = ruta
                _diagnostico.value = _diagnostico.value.copy(cargaModeloMs = SystemClock.elapsedRealtime() - t0)
            }
            if (mia != generacion) return
            // Con «solo mi voz» activado se carga también el modelo de hablante; si falla, falla a la vista (no se baja la guardia).
            val hablante = verificar?.let { VozDueno.cargarModeloHablante(it.rutaModelo) }
            reconocedor = if (hablante != null) Recognizer(modelo, MUESTREO.toFloat(), hablante) else Recognizer(modelo, MUESTREO.toFloat())

            val minimo = AudioRecord.getMinBufferSize(MUESTREO, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (minimo <= 0) throw IllegalStateException("Este teléfono no permite abrir el micrófono con este formato.")
            grabadora = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION, MUESTREO,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimo * 4, 16384),
            )
            if (grabadora.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("No pude abrir el micrófono (¿otra app lo está usando?).")
            }
            grabadora.startRecording()
            if (mia != generacion) return
            oyente.alEscuchar()

            val trozo = ShortArray(MUESTREO / 10) // 100 ms de audio
            val inicio = SystemClock.elapsedRealtime()
            var hablo = false
            var ultimoParcial = ""
            var ultimoCambio = inicio
            while (mia == generacion) {
                val n = grabadora.read(trozo, 0, trozo.size)
                if (n < 0) throw IllegalStateException("Falló la lectura del micrófono (código $n).")
                if (n == 0) continue
                oyente.alNivel(ReconocimientoUtil.nivel(trozo, n))
                val ahora = SystemClock.elapsedRealtime()
                if (reconocedor.acceptWaveForm(trozo, n)) {
                    val json = reconocedor.result
                    val texto = ReconocimientoUtil.extraer(json, "text")
                    if (texto.isNotBlank()) {
                        entregar(texto, ahora - ultimoCambio, oyente, mia, json, verificar)
                        return
                    }
                } else {
                    val parcial = ReconocimientoUtil.extraer(reconocedor.partialResult, "partial")
                    if (parcial.isNotBlank()) {
                        hablo = true
                        if (parcial != ultimoParcial) {
                            ultimoParcial = parcial
                            ultimoCambio = ahora
                            oyente.alParcial(parcial)
                        }
                    }
                }
                if (!hablo && ahora - inicio > ESPERA_SIN_VOZ_MS) {
                    if (mia == generacion) oyente.alSinVoz()
                    return
                }
                if (ahora - inicio > MAXIMO_MS) {
                    val json = reconocedor.finalResult
                    val texto = ReconocimientoUtil.extraer(json, "text")
                    if (texto.isBlank()) { if (mia == generacion) oyente.alSinVoz() } else entregar(texto, ahora - ultimoCambio, oyente, mia, json, verificar)
                    return
                }
            }
        } catch (e: Throwable) {
            if (mia == generacion) oyente.alError(e.message ?: e.javaClass.simpleName)
        } finally {
            try { grabadora?.stop() } catch (e: Exception) { /* ya detenida */ }
            grabadora?.release()
            try { reconocedor?.close() } catch (e: Exception) { /* ya cerrado */ }
            if (mia == generacion) {
                escuchando = false
                programarLiberacion()
            }
        }
    }

    private fun entregar(texto: String, respuestaMs: Long, oyente: Oyente, mia: Int, json: String, verificar: VerificacionHablante?) {
        if (mia != generacion) return
        var textoVerificacion = ""
        if (verificar != null) {
            val v = HablanteMath.veredicto(json, verificar.referencia, verificar.umbral)
            textoVerificacion = when (v.tipo) {
                HablanteMath.Tipo.MISMA -> "Voz del dueño (distancia ${"%.2f".format(v.distancia)})"
                HablanteMath.Tipo.AJENA -> "Voz ajena ignorada (distancia ${"%.2f".format(v.distancia)})"
                HablanteMath.Tipo.SIN_DATO -> "Frase muy corta para comprobar la voz: se aceptó"
            }
            if (v.tipo == HablanteMath.Tipo.AJENA) {
                _diagnostico.value = _diagnostico.value.copy(verificacion = textoVerificacion)
                oyente.alVozAjena(v.distancia ?: 1f)
                return
            }
        }
        _diagnostico.value = _diagnostico.value.copy(
            motor = "Vosk (sin internet), modelo ${VoskModelo.NOMBRE}",
            respuestaMs = respuestaMs,
            memoriaNativaMb = Debug.getNativeHeapAllocatedSize() / 1_000_000,
            ultimoTexto = texto,
            verificacion = textoVerificacion,
        )
        oyente.alFinal(texto)
    }

    companion object {
        const val MUESTREO = 16000

        /** Vocabulario limitado para Vosk (lo demás cae en «[unk]»). «para» y «no» solo cuentan con las reglas de [ReconocimientoUtil.hayInterrupcion]. */
        private val GRAMATICA = (ReconocimientoUtil.PALABRAS_FUERTES + ReconocimientoUtil.SUMIDEROS + "[unk]")
            .joinToString(prefix = "[", postfix = "]") { "\"$it\"" }
        private const val GRAMATICA_DESPERTAR = "[\"julio\", \"[unk]\"]"
        private const val GRACIA_INTERRUPCION_MS = 1_500L
        private const val ESPERA_SIN_VOZ_MS = 8_000L
        private const val MAXIMO_MS = 30_000L
    }
}
