package com.julio.asistente.avisos

import com.julio.asistente.animacion.JulioAviso
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.horario.Ocurrencias
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/** Llega aquí el resumen de la mañana o el aviso de pendientes de la tarde. Deja armado el del día siguiente. */
class AvisosReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val accion = intent.action ?: return
        val app = context.applicationContext
        val pendiente = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AvisosAjustes.cargar(app)
                val ajustes = AvisosAjustes.ajustes.value
                val db = JulioDatabase.get(app)
                val hoy = LocalDate.now()
                val tareas = db.tareaDao().observarTodas().first().filter { !it.completada && it.fechaLimite != null }
                val deHoy = tareas.filter { Fechas.deMillisUtc(it.fechaLimite!!) == hoy }.map { it.titulo }
                val vencidas = tareas.filter { Fechas.deMillisUtc(it.fechaLimite!!).isBefore(hoy) }.map { it.titulo }
                if (accion == AvisosProgramador.ACCION_MANANA && ajustes.resumenManana) {
                    val actividades = Ocurrencias.entre(db.actividadDao().observarTodas().first(), hoy, hoy, ZoneId.systemDefault())
                        .map { CalculoAvisos.ItemAgenda(it.horaInicio, it.actividad.titulo) }
                    CalculoAvisos.resumenManana(actividades, deHoy, vencidas)?.let { (t, x) -> enviar(app, 7201, t, x) }
                } else if (accion == AvisosProgramador.ACCION_TARDE && ajustes.pendientesTarde) {
                    CalculoAvisos.pendientesTarde(deHoy, vencidas)?.let { (t, x) -> enviar(app, 7202, t, x) }
                }
            } finally {
                AvisosProgramador.programar(app)
                pendiente.finish()
            }
        }
    }

    private fun enviar(c: Context, id: Int, titulo: String, texto: String) {
        val abrir = PendingIntent.getActivity(
            c, 41, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(c, Canales.AVISOS)
            .setSmallIcon(R.drawable.ic_alarma)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setStyle(NotificationCompat.BigTextStyle().bigText(texto))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(abrir)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(id, n)
            JulioAviso.emitir(c)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones no se puede avisar; Configuración > Avisos lo advierte.
        }
    }
}
