package com.julio.asistente.animacion

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp as mezclarColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.julio.asistente.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

// Un color por estado.
private val AZUL = Color(0xFF3B82F6)
private val CIAN = Color(0xFF22D3EE)
private val VIOLETA = Color(0xFF8B5CF6)
private val VERDE = Color(0xFF22C55E)
private val INDIGO = Color(0xFF3730A3)
private val AMBAR = Color(0xFFF59E0B)
private val ROJO = Color(0xFFEF4444)

// Imágenes que se usan (las PNG no se editan; los efectos se mezclan al dibujarlas).
private const val IMG_ORIGINAL = 0 // boca abierta
private const val IMG_MEDIA = 1 // boca a medio abrir
private const val IMG_CERRADA = 2 // boca cerrada
private const val IMG_OJOS_CERRADA = 3 // ojos a medio cerrar, boca cerrada

private val DOS_PI = (2.0 * PI).toFloat()
private val UN_PI = PI.toFloat()

// ----- Ajustes del holograma (se afinan aquí, sin tocar nada más) -----
private const val BORDE_BRILLO = 0.38f // brillo del borde luminoso alrededor del gorila (0 = sin borde)
private const val ESCANEO_ALFA = 0.10f // fuerza de las líneas de escaneo (0 = sin líneas)
private const val TINTE_ALFA = 0.06f // tinte suave del color del estado sobre el gorila
private const val FUNDIDO_INICIO = 0.60f // altura de la imagen donde empieza a desvanecerse la bata (0 arriba, 1 abajo)
private const val FUNDIDO_FIN = 0.82f // altura donde ya es del todo transparente (así no se ve la caja de abajo)
private const val NUM_PARTICULAS = 14
private val CICLO_GIRO = 100f * DOS_PI // el ángulo se reinicia aquí sin dar saltos (todos los multiplicadores son enteros o medios)

/** Sin tocar ni hablar durante este rato (con Julio en reposo y la pantalla abierta), Julio se duerme. */
private const val DORMIR_MS = 10 * 60_000L

/**
 * Calcula, cuadro por cuadro, cómo se ve Julio. No dibuja: solo deja listos los números que usa el Canvas.
 * Un solo bucle de animación. Partículas: pocas (14), y solo se mueven cuando Julio está activo.
 */
private class Animador {
    // ----- Lo que se dibuja -----
    var color: Color = AZUL
    var orbeEscala = 1f
    var orbeSx = 1f
    var orbeSy = 1f
    var orbeAlfa = 0.5f
    var imagen = IMG_CERRADA
    var gorilaEscala = 1f
    var dx = 0f // temblor horizontal (fracción del ancho)
    var dy = 0f // saltito (fracción del ancho; negativo = hacia arriba)

    // Holograma
    var energia = 0.05f // 0 a 1: qué tan fuerte pulsa el ecualizador
    var giro = 0f // ángulo acumulado de los anillos (radianes)
    var faseBarras = 0f
    var faseOnda = 0f // 0 a 1: ondas que salen de la plataforma
    var ondas = false
    var barrido = -1f // 0 a 1: posición del barrido de luz; -1 = apagado
    var inclinacion = 0f // grados (el gorila se inclina un poco al escuchar)
    var particulasVisibles = false
    val pX = FloatArray(NUM_PARTICULAS) // posición dentro de una esfera de radio 1
    val pY = FloatArray(NUM_PARTICULAS)
    val pZ = FloatArray(NUM_PARTICULAS)
    val pTam = FloatArray(NUM_PARTICULAS)
    private val pLon = FloatArray(NUM_PARTICULAS)
    private val pLat = FloatArray(NUM_PARTICULAS)
    private val pRadio = FloatArray(NUM_PARTICULAS)
    private val pVel = FloatArray(NUM_PARTICULAS)

    /** Cuánto esperar para el próximo cuadro: 0 = al ritmo de la pantalla; si no, milisegundos. */
    var esperaMs = 100L

    // ----- Memoria interna -----
    private var ultimo = 0L
    private var principalPrevio: Principal? = null
    private var capaVista = -1
    private var capaTipo = Capa.NINGUNA
    private var capaInicio = 0L
    private var nivelMic = 0f
    private var nivelVoz = 0f
    private var boca = 0 // 0 cerrada, 1 media, 2 abierta
    private var palabrasVistas = 0
    private var impulsoInicio = -10_000L
    private var proximoParpadeo = 0L
    private var parpadeoHasta = 0L

    init {
        val azar = Random(7) // siempre las mismas posiciones
        for (i in 0 until NUM_PARTICULAS) {
            pLon[i] = azar.nextFloat() * DOS_PI
            pLat[i] = (azar.nextFloat() - 0.5f) * UN_PI * 0.9f
            pRadio[i] = 0.55f + azar.nextFloat() * 0.5f
            pTam[i] = 0.6f + azar.nextFloat() * 1.2f
            pVel[i] = 0.6f + azar.nextFloat() * 0.9f
        }
        calcularParticulas()
    }

    private fun calcularParticulas() {
        for (i in 0 until NUM_PARTICULAS) {
            val cl = cos(pLat[i])
            pX[i] = pRadio[i] * cl * cos(pLon[i])
            pY[i] = pRadio[i] * sin(pLat[i]) * 0.95f
            pZ[i] = pRadio[i] * cl * sin(pLon[i])
        }
    }

    private fun intervaloParpadeo(p: Principal): Long =
        if (p == Principal.ENFOCADO) Random.nextLong(14_000L, 24_000L) else Random.nextLong(3_000L, 6_000L)

    /**
     * @param mic nivel del micrófono (0 a 1).
     * @param habla nivel real de la voz de Julio (0 a 1), o -1 si no hay dato real (voz del teléfono):
     *              entonces la boca sigue el ritmo de las palabras.
     */
    fun actualizar(
        ahora: Long, p: Principal, ev: EventoCapa,
        mic: Float, habla: Float, palabras: Int, colorPorEstado: Boolean,
    ) {
        val dt = if (ultimo == 0L) 16L else (ahora - ultimo).coerceIn(1L, 500L)
        ultimo = ahora
        val t = ahora / 1000f

        // ----- Capa (aviso / error) -----
        if (capaVista == -1) capaVista = ev.id // un aviso viejo no se vuelve a animar al abrir la pantalla
        if (ev.id != capaVista) {
            capaVista = ev.id
            capaTipo = ev.capa
            capaInicio = ahora
        }
        val capaDur = when (capaTipo) {
            Capa.AVISO -> if (p == Principal.ENFOCADO) 900L else 1400L
            Capa.ERROR -> 800L
            Capa.NINGUNA -> 0L
        }
        val capaT = ahora - capaInicio
        val capaViva = capaTipo != Capa.NINGUNA && capaT < capaDur
        val x = if (capaViva) capaT.toFloat() / capaDur.toFloat() else 1f

        // Un impulso por cada palabra (solo se usa si no hay nivel real de la voz).
        if (palabras != palabrasVistas) {
            palabrasVistas = palabras
            impulsoInicio = ahora
        }

        // ----- Estado principal -----
        var colorObjetivo: Color
        var escala: Float
        var alfa: Float
        var respira = 0f
        var sx = 1f
        var sy = 1f
        when (p) {
            Principal.REPOSO -> {
                // Azul tenue, respiración lenta (5 s).
                colorObjetivo = AZUL
                alfa = 0.55f
                val r = sin(t * DOS_PI / 5f)
                escala = 0.95f + 0.03f * r
                respira = 0.012f * r
            }
            Principal.DORMIDO -> {
                // Orbe casi apagado, brillo bajo, respiración muy lenta.
                colorObjetivo = AZUL
                alfa = 0.14f
                val r = sin(t * DOS_PI / 7f)
                escala = 0.86f + 0.01f * r
                respira = 0.006f * r
            }
            Principal.ESCUCHANDO -> {
                // Cian brillante: se agranda un poco y pulsa con el volumen de tu voz.
                colorObjetivo = CIAN
                alfa = 0.9f
                nivelMic += (mic - nivelMic) * (if (mic > nivelMic) 0.6f else 0.15f)
                escala = 1.06f + 0.16f * nivelMic
                respira = 0.008f * nivelMic
            }
            Principal.PENSANDO -> {
                // Violeta: respira más rápido y se deforma levemente.
                colorObjetivo = VIOLETA
                alfa = 0.8f
                val r = sin(t * DOS_PI / 1.1f)
                escala = 1.02f + 0.05f * r
                sx = 1f + 0.05f * sin(t * DOS_PI / 1.7f)
                sy = 1f + 0.05f * sin(t * DOS_PI / 1.3f + 1f)
                respira = 0.01f * r
            }
            Principal.HABLANDO -> {
                // Verde: pulsa con el volumen de su propia voz.
                colorObjetivo = VERDE
                alfa = 0.9f
                val objetivo = if (habla >= 0f) habla else max(0f, 1f - (ahora - impulsoInicio) / 200f)
                nivelVoz += (objetivo - nivelVoz) * (if (objetivo > nivelVoz) 0.7f else 0.35f)
                escala = 1.04f + 0.16f * nivelVoz
                respira = 0.008f * nivelVoz
            }
            Principal.ENFOCADO -> {
                // Índigo oscuro, más pequeño, firme y casi inmóvil.
                colorObjetivo = INDIGO
                alfa = 0.6f
                val r = sin(t * DOS_PI / 8f)
                escala = 0.78f + 0.004f * r
                respira = 0.003f * r
            }
        }
        if (p != Principal.ESCUCHANDO) nivelMic = 0f
        if (p != Principal.HABLANDO) nivelVoz = 0f
        if (!colorPorEstado) colorObjetivo = CIAN

        // ----- Efectos de la capa -----
        var salto = 0f
        var temblor = 0f
        if (capaViva) {
            when (capaTipo) {
                Capa.AVISO -> {
                    if (p == Principal.ENFOCADO) {
                        // En enfoque: solo un pulso suave.
                        escala += 0.05f * sin(UN_PI * x)
                        colorObjetivo = mezclarColor(colorObjetivo, AMBAR, 0.6f)
                    } else {
                        // 3 pulsos rápidos y un saltito pequeño de la imagen completa; luego se calma.
                        escala += 0.20f * abs(sin(3f * UN_PI * x)) * (1f - 0.4f * x)
                        colorObjetivo = AMBAR
                        if (capaT < 450L) salto = -0.02f * sin(UN_PI * capaT.toFloat() / 450f)
                    }
                }
                Capa.ERROR -> {
                    // Temblor corto de la imagen completa y el orbe se encoge; luego vuelve a respirar normal.
                    colorObjetivo = ROJO
                    val f = 1f - x
                    escala *= 1f - 0.30f * f * f
                    if (capaT < 450L) temblor = 0.014f * sin(capaT.toFloat() * 0.085f) * (1f - capaT.toFloat() / 450f)
                }
                Capa.NINGUNA -> {}
            }
            alfa = max(alfa, 0.75f)
        }

        // ----- Color: cambia suave, salvo al interrumpir (verde a cian al instante) -----
        val interrupcion = principalPrevio == Principal.HABLANDO && p == Principal.ESCUCHANDO
        principalPrevio = p
        color = if (interrupcion) colorObjetivo else mezclarColor(color, colorObjetivo, 1f - exp(-dt / 120f))

        // ----- Parpadeo (solo en reposo y, muy raro, en enfoque; nunca mientras habla) -----
        val puedeParpadear = p == Principal.REPOSO || p == Principal.ENFOCADO
        if (puedeParpadear) {
            if (proximoParpadeo == 0L) proximoParpadeo = ahora + intervaloParpadeo(p)
            if (ahora >= proximoParpadeo) {
                parpadeoHasta = ahora + 135L
                proximoParpadeo = ahora + intervaloParpadeo(p)
            }
        }

        // ----- Boca al hablar: según el volumen, con histéresis para que no parpadee entre imágenes -----
        if (p == Principal.HABLANDO) {
            boca = when (boca) {
                0 -> if (nivelVoz > 0.42f) 2 else if (nivelVoz > 0.14f) 1 else 0
                1 -> if (nivelVoz > 0.42f) 2 else if (nivelVoz < 0.09f) 0 else 1
                else -> if (nivelVoz < 0.09f) 0 else if (nivelVoz < 0.32f) 1 else 2
            }
        } else {
            boca = 0
        }

        imagen = when (p) {
            Principal.DORMIDO -> IMG_OJOS_CERRADA
            Principal.HABLANDO -> when (boca) {
                0 -> IMG_CERRADA
                1 -> IMG_MEDIA
                else -> IMG_ORIGINAL
            }
            else -> if (puedeParpadear && ahora < parpadeoHasta) IMG_OJOS_CERRADA else IMG_CERRADA
        }

        // ----- Holograma: energía, anillos, partículas, ondas y barrido (todo según el estado) -----
        val dts = dt / 1000f
        energia = when (p) {
            Principal.ESCUCHANDO -> 0.15f + 0.85f * nivelMic
            Principal.PENSANDO -> 0.45f + 0.15f * sin(t * DOS_PI / 0.9f)
            Principal.HABLANDO -> 0.2f + 0.8f * nivelVoz
            Principal.ENFOCADO -> 0.03f
            Principal.DORMIDO -> 0f
            Principal.REPOSO -> 0.06f
        }
        val vGiro = when (p) { // radianes por segundo; casi quieto en reposo
            Principal.REPOSO -> 0.10f
            Principal.DORMIDO -> 0f
            Principal.ESCUCHANDO -> 0.5f
            Principal.PENSANDO -> 2.2f
            Principal.HABLANDO -> 0.8f
            Principal.ENFOCADO -> 0.04f
        }
        giro += vGiro * dts
        if (giro > CICLO_GIRO) giro -= CICLO_GIRO

        val activo = p == Principal.ESCUCHANDO || p == Principal.PENSANDO || p == Principal.HABLANDO
        ondas = p == Principal.ESCUCHANDO || p == Principal.HABLANDO
        if (activo) {
            faseBarras += dts * (if (p == Principal.PENSANDO) 8f else 4f)
            if (faseBarras > CICLO_GIRO) faseBarras -= CICLO_GIRO
            faseOnda = (faseOnda + dts * 0.6f) % 1f
        }

        // Partículas: solo se mueven si Julio está activo; en reposo quedan quietas; en enfoque y dormido no se ven.
        particulasVisibles = p != Principal.DORMIDO && p != Principal.ENFOCADO
        val vPart = when (p) {
            Principal.ESCUCHANDO -> 0.5f
            Principal.PENSANDO -> 1.6f
            Principal.HABLANDO -> 0.7f
            else -> 0f
        }
        if (vPart > 0f) {
            for (i in 0 until NUM_PARTICULAS) {
                pLon[i] += vPart * pVel[i] * dts
                if (pLon[i] > CICLO_GIRO) pLon[i] -= CICLO_GIRO
            }
            calcularParticulas()
        }

        // Barrido de luz sobre el gorila: lento en reposo, más rápido si está activo, ninguno en enfoque ni dormido.
        val periodoBarrido = when (p) {
            Principal.REPOSO -> 8000L
            Principal.ESCUCHANDO, Principal.PENSANDO, Principal.HABLANDO -> 3000L
            else -> 0L
        }
        barrido = if (periodoBarrido == 0L) -1f else (ahora % periodoBarrido).toFloat() / periodoBarrido.toFloat()

        // Inclinación leve al escuchar (se mueve la imagen COMPLETA, no se deforma).
        val inclObjetivo = if (p == Principal.ESCUCHANDO) -4f else 0f
        inclinacion += (inclObjetivo - inclinacion) * (1f - exp(-dt / 220f))

        // ----- Resultado para dibujar -----
        orbeEscala = escala
        orbeSx = sx
        orbeSy = sy
        orbeAlfa = alfa
        gorilaEscala = 1f + respira
        dx = temblor
        dy = salto

        // ----- Batería: movimiento en vivo solo si hay actividad; en reposo casi quieto -----
        val vivo = capaViva || p == Principal.ESCUCHANDO || p == Principal.PENSANDO || p == Principal.HABLANDO
        esperaMs = when {
            vivo -> 0L
            ahora < parpadeoHasta || (puedeParpadear && proximoParpadeo - ahora < 150L) -> 33L
            p == Principal.ENFOCADO -> 150L
            p == Principal.DORMIDO -> 250L
            else -> 100L
        }
    }
}

/**
 * Julio animado, estilo holograma: el gorila médico «proyectado» sobre una plataforma, con anillos que giran en 3D,
 * pocas partículas, ecualizador en la base y un orbe de luz detrás.
 *
 * REGLA (v29): los 5 PNG no se editan, ni se redibujan, ni se deforman, ni se les cambian los colores base.
 * Sí se permiten efectos de mezcla al dibujar: borde luminoso, fundido de la bata, líneas de escaneo,
 * barrido de luz y un tinte MUY suave del color del estado. Se cambia entre imágenes y se mueve/escala/inclina la imagen COMPLETA.
 *
 * @param nivelMic nivel del micrófono (0 a 1) mientras escucha.
 * @param nivelHabla nivel real de la voz de Julio (0 a 1), o -1 si no hay dato real.
 * @param palabras contador de palabras dichas (respaldo para la boca con la voz del teléfono).
 * @param alToque tocar el orbe (si Julio está hablando, lo interrumpe).
 */
@Composable
fun JulioAnimado(
    principal: Principal,
    capa: EventoCapa,
    nivelMic: () -> Float,
    nivelHabla: () -> Float,
    palabras: () -> Int,
    alToque: () -> Unit,
    modifier: Modifier = Modifier,
    colorPorEstado: Boolean = true,
) {
    val original = ImageBitmap.imageResource(R.drawable.julio_original)
    val media = ImageBitmap.imageResource(R.drawable.julio_boca_media)
    val cerrada = ImageBitmap.imageResource(R.drawable.julio_boca_cerrada)
    val ojosCerrada = ImageBitmap.imageResource(R.drawable.julio_ojos_medio_boca_cerrada)
    val imagenes = remember(original, media, cerrada, ojosCerrada) { arrayOf(original, media, cerrada, ojosCerrada) }

    val animador = remember { Animador() }
    var tick by remember { mutableLongStateOf(0L) }
    var toques by remember { mutableIntStateOf(0) }

    val principalAct by rememberUpdatedState(principal)
    val capaAct by rememberUpdatedState(capa)
    val micAct by rememberUpdatedState(nivelMic)
    val hablaAct by rememberUpdatedState(nivelHabla)
    val palabrasAct by rememberUpdatedState(palabras)
    val colorAct by rememberUpdatedState(colorPorEstado)
    val toqueAct by rememberUpdatedState(alToque)

    // Pausar todo cuando la app no está visible.
    val dueno = LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(dueno.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(dueno) {
        val observador = LifecycleEventObserver { _, evento ->
            if (evento == Lifecycle.Event.ON_START) visible = true
            if (evento == Lifecycle.Event.ON_STOP) visible = false
        }
        dueno.lifecycle.addObserver(observador)
        onDispose { dueno.lifecycle.removeObserver(observador) }
    }

    // Un solo bucle de animación.
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (isActive) {
            animador.actualizar(
                ahora = SystemClock.uptimeMillis(),
                p = principalAct,
                ev = capaAct,
                mic = micAct(),
                habla = hablaAct(),
                palabras = palabrasAct(),
                colorPorEstado = colorAct,
            )
            tick++
            if (animador.esperaMs == 0L) withFrameNanos { } else delay(animador.esperaMs)
        }
    }

    // Dormido: tras mucho rato en reposo sin que nadie hable ni toque.
    LaunchedEffect(principal, capa.id, toques, visible) {
        if (principal == Principal.REPOSO && visible) {
            delay(DORMIR_MS)
            JulioEstado.dormir()
        }
    }

    Canvas(
        modifier
            .aspectRatio(0.8f)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    toques++
                    JulioEstado.despertar()
                    toqueAct()
                })
            },
    ) {
        if (tick < 0L) return@Canvas // leer «tick» hace que se redibuje en cada cuadro

        val w = size.width
        val h = size.height
        val gw = w * 0.80f
        val gh = gw * 1200f / 896f
        val gx = (w - gw) / 2f
        val gy = (h - gh) / 2f
        val centro = Offset(w / 2f, gy + gh * 0.48f)
        val c = animador.color
        val a = animador.orbeAlfa // intensidad general: baja en reposo/dormido, alta al escuchar o hablar
        val esc = animador.orbeEscala
        val rs = 0.9f + 0.1f * esc // los anillos casi no crecen: así nunca se cortan en el borde
        val yPlat = h * 0.90f // altura de la plataforma
        val rx = w * 0.36f
        val ry = w * 0.055f

        // 1) Resplandor suave del orbe (sin borde duro) y un círculo fino.
        val radio = w * 0.50f * esc
        withTransform({ scale(animador.orbeSx, animador.orbeSy, centro) }) {
            drawCircle(
                brush = Brush.radialGradient(
                    0f to c.copy(alpha = a * 0.55f),
                    0.7f to c.copy(alpha = a * 0.22f),
                    1f to Color.Transparent,
                    center = centro,
                    radius = radio,
                ),
                radius = radio,
                center = centro,
            )
            drawCircle(
                color = c.copy(alpha = a * 0.7f),
                radius = radio * 0.8f,
                center = centro,
                style = Stroke(width = 2.dp.toPx()),
            )
        }

        // Anillo inclinado en 3D: «frente» dibuja la mitad que pasa por delante del gorila; si no, la de atrás.
        fun anillo(r: Float, incl: Float, plano: Float, giroAnillo: Float, alfa: Float, grosor: Float, frente: Boolean) {
            val n = 56
            val ci = cos(incl)
            val si = sin(incl)
            val cp = cos(plano)
            val sp = sin(plano)
            var px = 0f
            var py = 0f
            var pz = 0f
            for (i in 0..n) {
                val fi = giroAnillo + DOS_PI * i / n
                val x0 = r * cos(fi)
                val y0 = r * sin(fi) * ci
                val z0 = r * sin(fi) * si
                val x = centro.x + x0 * cp - y0 * sp
                val y = centro.y + x0 * sp + y0 * cp
                if (i > 0 && ((z0 + pz) >= 0f) == frente) {
                    val prof = ((z0 + pz) / (2f * r) + 1f) / 2f
                    drawLine(
                        color = c.copy(alpha = (alfa * a * (0.3f + 0.7f * prof)).coerceIn(0f, 1f)),
                        start = Offset(px, py),
                        end = Offset(x, y),
                        strokeWidth = grosor,
                        cap = StrokeCap.Round,
                    )
                }
                px = x
                py = y
                pz = z0
            }
        }

        fun particulas(frente: Boolean) {
            if (!animador.particulasVisibles) return
            val base = w * 0.44f * rs
            for (i in 0 until NUM_PARTICULAS) {
                val z = animador.pZ[i]
                if ((z >= 0f) != frente) continue
                val prof = (z / 1.05f + 1f) / 2f
                drawCircle(
                    color = c.copy(alpha = ((0.25f + 0.65f * prof) * a).coerceIn(0f, 1f)),
                    radius = w * 0.0045f * animador.pTam[i] * (0.7f + 0.6f * prof),
                    center = Offset(centro.x + animador.pX[i] * base, centro.y + animador.pY[i] * base),
                )
            }
        }

        val g0 = animador.giro
        val incA = 1.15f + 0.25f * sin(g0 * 0.5f)
        val incB = 0.55f + 0.30f * sin(g0)
        val incC = 1.45f + 0.15f * sin(g0 * 0.5f)
        val rA = w * 0.43f * rs
        val rB = w * 0.39f * rs
        val rC = w * 0.46f * rs
        val grosor = w * 0.0045f

        // 2) Mitad de atrás de anillos y partículas (detrás del gorila).
        anillo(rA, incA, 0.4f, g0, 0.95f, grosor * 1.4f, false)
        anillo(rB, incB, -0.9f, -g0 * 1.3f, 0.8f, grosor * 1.2f, false)
        anillo(rC, incC, 2.2f, g0 * 0.7f, 0.65f, grosor, false)
        particulas(false)

        // 3) Plataforma de proyección, ondas y ecualizador de la base.
        for (k in 0 until 3) {
            val e = 1f - 0.2f * k
            drawOval(
                color = c.copy(alpha = ((0.75f - 0.2f * k) * a).coerceIn(0f, 1f)),
                topLeft = Offset(centro.x - rx * e, yPlat - ry * e),
                size = Size(rx * 2f * e, ry * 2f * e),
                style = Stroke(width = w * 0.0035f),
            )
        }
        if (animador.ondas) {
            for (k in 0 until 3) {
                val q = (animador.faseOnda + k / 3f) % 1f
                val e = 1f + 0.35f * q
                drawOval(
                    color = c.copy(alpha = ((1f - q) * 0.35f * (0.4f + animador.energia)).coerceIn(0f, 1f)),
                    topLeft = Offset(centro.x - rx * e, yPlat - ry * e),
                    size = Size(rx * 2f * e, ry * 2f * e),
                    style = Stroke(width = w * 0.003f),
                )
            }
        }
        val barras = 48
        for (i in 0 until barras) {
            val ang = DOS_PI * i / barras + g0 * 0.5f
            val osc = abs(sin(animador.faseBarras + i * 0.55f))
            val alto = w * 0.006f + w * 0.085f * animador.energia * (0.25f + 0.75f * osc)
            val bx = centro.x + rx * 1.02f * cos(ang)
            val by = yPlat + ry * 1.02f * sin(ang)
            val delante = sin(ang) > 0f
            drawLine(
                color = c.copy(alpha = ((if (delante) 0.9f else 0.45f) * a).coerceIn(0f, 1f)),
                start = Offset(bx, by),
                end = Offset(bx, by - alto),
                strokeWidth = w * 0.0055f,
                cap = StrokeCap.Round,
            )
        }

        // 4) Gorila holográfico, en su propia capa: así los fundidos solo le quitan transparencia a él (no al fondo).
        //    Las imágenes no se modifican: solo se mezcla luz y transparencia al dibujarlas.
        val imagen = imagenes[animador.imagen]
        val dstOffset = IntOffset(gx.roundToInt(), gy.roundToInt())
        val dstSize = IntSize(gw.roundToInt(), gh.roundToInt())
        val pivote = Offset(w / 2f, gy + gh)
        val luz = mezclarColor(c, Color.White, 0.5f)

        drawIntoCanvas { it.saveLayer(Rect(0f, 0f, size.width, size.height), Paint()) }
        withTransform({
            translate(animador.dx * w, animador.dy * w)
            rotate(animador.inclinacion, Offset(w / 2f, gy + gh * 0.9f))
            scale(animador.gorilaEscala, animador.gorilaEscala, pivote)
        }) {
            // Borde luminoso: la misma silueta, un poco más grande y teñida, DETRÁS del gorila.
            if (BORDE_BRILLO > 0f) {
                withTransform({ scale(1.035f, 1.035f, Offset(w / 2f, gy + gh * 0.45f)) }) {
                    drawImage(
                        image = imagen,
                        dstOffset = dstOffset,
                        dstSize = dstSize,
                        alpha = (BORDE_BRILLO * a).coerceIn(0f, 1f),
                        colorFilter = ColorFilter.tint(c),
                        filterQuality = FilterQuality.Medium,
                    )
                }
            }

            // El gorila: la imagen completa, sin tocarla.
            drawImage(
                image = imagen,
                dstOffset = dstOffset,
                dstSize = dstSize,
                filterQuality = FilterQuality.Medium,
            )

            // Fundido de la bata hacia abajo: aquí desaparece la «caja» del recorte.
            val yF0 = gy + gh * FUNDIDO_INICIO
            val yF1 = gy + gh * FUNDIDO_FIN
            drawRect(
                brush = Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.25f to Color.Black.copy(alpha = 0.08f),
                    0.5f to Color.Black.copy(alpha = 0.30f),
                    0.75f to Color.Black.copy(alpha = 0.65f),
                    1f to Color.Black,
                    startY = yF0,
                    endY = yF1,
                ),
                topLeft = Offset(gx, yF0),
                size = Size(gw, gy + gh - yF0),
                blendMode = BlendMode.DstOut,
            )
            // Fundido de los lados de la bata (los hombros se difuminan en vez de cortarse recto).
            drawRect(
                brush = Brush.horizontalGradient(
                    0f to Color.Black,
                    0.35f to Color.Black.copy(alpha = 0.62f),
                    0.7f to Color.Black.copy(alpha = 0.22f),
                    1f to Color.Transparent,
                    startX = gx + gw * 0.04f,
                    endX = gx + gw * 0.26f,
                ),
                topLeft = Offset(gx, gy),
                size = Size(gw * 0.26f, gh),
                blendMode = BlendMode.DstOut,
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    0f to Color.Transparent,
                    0.3f to Color.Black.copy(alpha = 0.22f),
                    0.65f to Color.Black.copy(alpha = 0.62f),
                    1f to Color.Black,
                    startX = gx + gw * 0.74f,
                    endX = gx + gw * 0.96f,
                ),
                topLeft = Offset(gx + gw * 0.74f, gy),
                size = Size(gw * 0.26f, gh),
                blendMode = BlendMode.DstOut,
            )

            // Líneas de escaneo (restan un poco de opacidad; no pintan nada encima).
            if (ESCANEO_ALFA > 0f) {
                val paso = w * 0.014f
                var yl = gy + gh * 0.16f
                val fin = gy + gh * 0.84f
                while (yl < fin) {
                    drawRect(
                        color = Color.Black.copy(alpha = ESCANEO_ALFA),
                        topLeft = Offset(gx, yl),
                        size = Size(gw, paso * 0.4f),
                        blendMode = BlendMode.DstOut,
                    )
                    yl += paso
                }
            }

            // Tinte muy suave del color del estado, solo sobre lo que ya está dibujado.
            drawRect(
                color = c.copy(alpha = TINTE_ALFA * a),
                topLeft = Offset(gx, gy),
                size = Size(gw, gh),
                blendMode = BlendMode.SrcAtop,
            )

            // Barrido de luz que sube y baja por el gorila.
            if (animador.barrido >= 0f) {
                val yB = gy + gh * (0.12f + 0.72f * animador.barrido)
                val semi = gh * 0.08f
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.5f to luz.copy(alpha = 0.16f * a),
                        1f to Color.Transparent,
                        startY = yB - semi,
                        endY = yB + semi,
                    ),
                    topLeft = Offset(gx, yB - semi),
                    size = Size(gw, semi * 2f),
                    blendMode = BlendMode.SrcAtop,
                )
            }
        }
        drawIntoCanvas { it.restore() }

        // 5) Mitad de adelante de anillos y partículas (cruzan por delante del gorila).
        anillo(rA, incA, 0.4f, g0, 0.55f, grosor * 1.4f, true)
        anillo(rB, incB, -0.9f, -g0 * 1.3f, 0.45f, grosor * 1.2f, true)
        anillo(rC, incC, 2.2f, g0 * 0.7f, 0.4f, grosor, true)
        particulas(true)
    }
}
