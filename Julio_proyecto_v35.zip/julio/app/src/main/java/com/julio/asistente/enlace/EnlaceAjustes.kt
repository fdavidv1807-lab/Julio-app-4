package com.julio.asistente.enlace

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Qué hace este teléfono en el enlace de la Etapa 4. */
enum class RolEnlace { NINGUNO, DIARIO, CUERPO }

/**
 * Ajustes del enlace entre los dos teléfonos (SharedPreferences «julio_enlace»; no toca la base de datos Room).
 * El código de emparejamiento queda en el almacenamiento privado de la app (allowBackup = false); no está cifrado aparte.
 */
object EnlaceAjustes {
    private const val ARCHIVO = "julio_enlace"
    private val IPV4 = Regex("^[0-9]{1,3}(\\.[0-9]{1,3}){3}(:[0-9]{1,5})?$")

    private val _rol = MutableStateFlow(RolEnlace.NINGUNO)
    val rol: StateFlow<RolEnlace> = _rol.asStateFlow()

    /** Código de emparejamiento con formato (XXXX-XXXX-XXXX-XXXX) o null si aún no hay. */
    private val _codigo = MutableStateFlow<String?>(null)
    val codigo: StateFlow<String?> = _codigo.asStateFlow()

    private val _privado = MutableStateFlow(false)
    val privado: StateFlow<Boolean> = _privado.asStateFlow()

    private val _silenciadas = MutableStateFlow<Set<String>>(emptySet())
    val silenciadas: StateFlow<Set<String>> = _silenciadas.asStateFlow()

    private val _ipManual = MutableStateFlow("")
    val ipManual: StateFlow<String> = _ipManual.asStateFlow()

    /** Línea de estado para mostrar (nunca contiene texto de avisos). */
    private val _estado = MutableStateFlow("")
    val estado: StateFlow<String> = _estado.asStateFlow()
    fun ponerEstado(texto: String) { _estado.value = texto }

    /** Puerto en el que escucha el Cuerpo (0 = no está escuchando). */
    private val _puertoLocal = MutableStateFlow(0)
    val puertoLocal: StateFlow<Int> = _puertoLocal.asStateFlow()
    fun ponerPuertoLocal(p: Int) { _puertoLocal.value = p }

    @Volatile private var ipCache: String = ""

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun cargar(c: Context) {
        val p = sp(c)
        _rol.value = runCatching { RolEnlace.valueOf(p.getString("rol", "NINGUNO") ?: "NINGUNO") }.getOrDefault(RolEnlace.NINGUNO)
        val cod = p.getString("codigo", null)
        _codigo.value = if (cod != null && CodigoEmparejamiento.leer(cod) != null) cod else null
        _privado.value = p.getBoolean("privado", false)
        _silenciadas.value = p.getStringSet("silenciadas", emptySet())?.toSet() ?: emptySet()
        _ipManual.value = p.getString("ipManual", "") ?: ""
        ipCache = p.getString("ipCache", "") ?: ""
    }

    fun fijarRol(c: Context, rol: RolEnlace) {
        sp(c).edit().putString("rol", rol.name).apply()
        _rol.value = rol
    }

    /** Crea un código nuevo (el teléfono de diario tendrá que volver a emparejarse). */
    fun nuevoCodigo(c: Context): String {
        val f = CodigoEmparejamiento.formatear(CodigoEmparejamiento.nuevoSecreto())
        sp(c).edit().putString("codigo", f).putString("ipCache", "").apply()
        ipCache = ""
        _codigo.value = f
        return f
    }

    /** Guarda el código que tecleaste en el teléfono de diario. false si no es válido. */
    fun usarCodigo(c: Context, texto: String): Boolean {
        val secreto = CodigoEmparejamiento.leer(texto) ?: return false
        val f = CodigoEmparejamiento.formatear(secreto)
        sp(c).edit().putString("codigo", f).putString("ipCache", "").apply()
        ipCache = ""
        _codigo.value = f
        return true
    }

    fun borrarCodigo(c: Context) {
        sp(c).edit().remove("codigo").putString("ipCache", "").apply()
        ipCache = ""
        _codigo.value = null
    }

    fun secreto(): ByteArray? = _codigo.value?.let { CodigoEmparejamiento.leer(it) }

    fun alternarPrivado(c: Context) {
        val nuevo = !_privado.value
        sp(c).edit().putBoolean("privado", nuevo).apply()
        _privado.value = nuevo
    }

    fun silenciar(c: Context, paquete: String, silenciar: Boolean) {
        val nuevo = if (silenciar) _silenciadas.value + paquete else _silenciadas.value - paquete
        sp(c).edit().putStringSet("silenciadas", nuevo).apply()
        _silenciadas.value = nuevo
    }

    /** IP del Cuerpo escrita a mano (por si la red no deja que se encuentren solos). Vacía = automático. */
    fun fijarIpManual(c: Context, texto: String): Boolean {
        val t = texto.trim()
        if (t.isNotEmpty() && !IPV4.matches(t)) return false
        sp(c).edit().putString("ipManual", t).apply()
        _ipManual.value = t
        return true
    }

    fun guardarDestino(c: Context, host: String, puerto: Int) {
        ipCache = "$host:$puerto"
        sp(c).edit().putString("ipCache", ipCache).apply()
    }

    /** Direcciones a probar antes de buscar en la red: la escrita a mano y la última que funcionó. */
    fun destinos(): List<Pair<String, Int>> {
        val lista = mutableListOf<Pair<String, Int>>()
        for (t in listOf(_ipManual.value, ipCache)) {
            if (t.isBlank()) continue
            val partes = t.split(":")
            val puerto = partes.getOrNull(1)?.toIntOrNull() ?: Protocolo.PUERTO
            val par = partes[0] to puerto
            if (par !in lista) lista += par
        }
        return lista
    }
}
