package com.julio.asistente.enlace

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.security.GeneralSecurityException
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Formato del mensaje entre los dos teléfonos (sin HTTP, sin servidor externo, sin internet).
 *
 * Trama = «J» «U» versión(1) longitud(4) | nonce(12) | AES-256-GCM(aviso) con etiqueta de 16 bytes.
 * La clave sale del código de emparejamiento (HMAC-SHA256). El encabezado va autenticado (AAD): si alguien cambia
 * un solo byte, o no tiene el código, el mensaje se rechaza. La respuesta es un byte (ACK_*).
 * Lógica pura (solo java.*): se prueba sin Android.
 */
object Protocolo {
    const val VERSION = 1
    const val PUERTO = 48217
    const val TIPO_SERVICIO = "_julio._tcp."
    const val MAX_TRAMA = 8192

    const val ACK_OK = 6
    const val ACK_HORA = 17
    const val ACK_REPETIDO = 18
    const val ACK_NO_AUTORIZADO = 19
    const val ACK_MALFORMADO = 20

    private const val TAM_NONCE = 12
    private const val TAM_ETIQUETA_BITS = 128
    private const val TAM_ENCABEZADO = 7
    private val MAGIA = byteArrayOf('J'.code.toByte(), 'U'.code.toByte())

    fun claveDe(secreto: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secreto, "HmacSHA256"))
        return mac.doFinal("julio-enlace-v1".toByteArray(Charsets.UTF_8))
    }

    /** 6 letras/cifras que identifican a este Cuerpo en la red sin revelar el código. */
    fun idPublico(secreto: ByteArray): String {
        val h = MessageDigest.getInstance("SHA-256").digest("julio-id-v1".toByteArray(Charsets.UTF_8) + secreto)
        return h.take(3).joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun cortar(s: String, max: Int) = if (s.length <= max) s else s.substring(0, max)

    fun codificar(a: Aviso, clave: ByteArray, azar: SecureRandom = SecureRandom()): ByteArray {
        val cuerpo = ByteArrayOutputStream()
        DataOutputStream(cuerpo).use {
            it.writeLong(a.tiempo)
            it.writeByte(a.tipo.codigo)
            it.writeUTF(cortar(a.id, 40))
            it.writeUTF(cortar(a.app, 80))
            it.writeUTF(cortar(a.paquete, 200))
            it.writeUTF(cortar(a.titulo, 200))
            it.writeUTF(cortar(a.texto, 600))
        }
        val nonce = ByteArray(TAM_NONCE).also { azar.nextBytes(it) }
        val cifrado = cifrar(clave, nonce, cuerpo.toByteArray())
        val largo = nonce.size + cifrado.size
        val encabezadoFinal = encabezado(largo)
        return encabezadoFinal + nonce + cifrado
    }

    private fun encabezado(largo: Int): ByteArray {
        val b = ByteArrayOutputStream()
        DataOutputStream(b).use {
            it.write(MAGIA)
            it.writeByte(VERSION)
            it.writeInt(largo)
        }
        return b.toByteArray()
    }

    // El AAD son solo magia + versión (3 bytes), para no depender del largo.
    private fun aad(): ByteArray = byteArrayOf(MAGIA[0], MAGIA[1], VERSION.toByte())

    private fun cifrar(clave: ByteArray, nonce: ByteArray, datos: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(clave, "AES"), GCMParameterSpec(TAM_ETIQUETA_BITS, nonce))
        c.updateAAD(aad())
        return c.doFinal(datos)
    }

    /** Lee una trama completa del flujo. Lanza IOException si el encabezado no es de Julio o es demasiado grande. */
    fun leerTrama(entrada: InputStream): ByteArray {
        val d = DataInputStream(entrada)
        val enc = ByteArray(TAM_ENCABEZADO)
        d.readFully(enc)
        if (enc[0] != MAGIA[0] || enc[1] != MAGIA[1] || enc[2].toInt() != VERSION) throw IOException("encabezado inválido")
        val largo = DataInputStream(ByteArrayInputStream(enc, 3, 4)).readInt()
        if (largo < TAM_NONCE + TAM_ETIQUETA_BITS / 8 || largo > MAX_TRAMA) throw IOException("largo inválido")
        val resto = ByteArray(largo)
        d.readFully(resto)
        return enc + resto
    }

    /** null si no es auténtica (clave distinta, mensaje alterado o mal formado). */
    fun decodificar(trama: ByteArray, clave: ByteArray): Aviso? {
        if (trama.size < TAM_ENCABEZADO + TAM_NONCE + TAM_ETIQUETA_BITS / 8) return null
        if (trama[0] != MAGIA[0] || trama[1] != MAGIA[1] || trama[2].toInt() != VERSION) return null
        val nonce = trama.copyOfRange(TAM_ENCABEZADO, TAM_ENCABEZADO + TAM_NONCE)
        val cifrado = trama.copyOfRange(TAM_ENCABEZADO + TAM_NONCE, trama.size)
        val claro = try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(clave, "AES"), GCMParameterSpec(TAM_ETIQUETA_BITS, nonce))
            c.updateAAD(aad())
            c.doFinal(cifrado)
        } catch (e: GeneralSecurityException) {
            return null
        }
        return try {
            DataInputStream(ByteArrayInputStream(claro)).use {
                val tiempo = it.readLong()
                val tipo = TipoAviso.de(it.readUnsignedByte())
                val id = it.readUTF()
                val app = it.readUTF()
                val paquete = it.readUTF()
                val titulo = it.readUTF()
                val texto = it.readUTF()
                Aviso(id, tiempo, app, paquete, titulo, texto, tipo)
            }
        } catch (e: IOException) {
            null
        }
    }
}

/** Rechaza avisos con la hora muy distinta (ventana) o repetidos (alguien que graba y reenvía). Lógica pura. */
class Verificador(private val ventanaMs: Long = 10 * 60_000L, private val memoria: Int = 200) {
    private val vistos = LinkedHashSet<String>()

    @Synchronized
    fun revisar(a: Aviso, ahora: Long): Int {
        if (kotlin.math.abs(ahora - a.tiempo) > ventanaMs) return Protocolo.ACK_HORA
        if (!vistos.add(a.id)) return Protocolo.ACK_REPETIDO
        while (vistos.size > memoria) vistos.remove(vistos.first())
        return Protocolo.ACK_OK
    }
}

/** Código que se teclea en el teléfono de diario: 16 caracteres (80 bits) en grupos de 4, sin letras que se confundan. */
object CodigoEmparejamiento {
    private const val ALFABETO = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    const val BYTES = 10
    const val CARACTERES = 16

    fun nuevoSecreto(azar: SecureRandom = SecureRandom()): ByteArray = ByteArray(BYTES).also { azar.nextBytes(it) }

    fun formatear(secreto: ByteArray): String {
        val sb = StringBuilder()
        var acumulado = 0
        var bits = 0
        for (b in secreto) {
            acumulado = (acumulado shl 8) or (b.toInt() and 0xff)
            bits += 8
            while (bits >= 5) {
                sb.append(ALFABETO[(acumulado shr (bits - 5)) and 31])
                bits -= 5
            }
            acumulado = acumulado and ((1 shl bits) - 1)
        }
        return sb.toString().chunked(4).joinToString("-")
    }

    /** Acepta minúsculas, espacios y guiones; O -> 0, I y L -> 1. null si no es un código válido. */
    fun leer(texto: String): ByteArray? {
        val limpio = texto.uppercase().filter { it != '-' && !it.isWhitespace() }
            .replace('O', '0').replace('I', '1').replace('L', '1')
        if (limpio.length != CARACTERES) return null
        val salida = ByteArray(BYTES)
        var acumulado = 0
        var bits = 0
        var n = 0
        for (ch in limpio) {
            val v = ALFABETO.indexOf(ch)
            if (v < 0) return null
            acumulado = (acumulado shl 5) or v
            bits += 5
            if (bits >= 8) {
                salida[n++] = ((acumulado shr (bits - 8)) and 0xff).toByte()
                bits -= 8
                acumulado = acumulado and ((1 shl bits) - 1)
            }
        }
        return salida
    }
}
