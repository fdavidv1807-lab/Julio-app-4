package com.julio.asistente

import android.Manifest
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.julio.asistente.core.Permisos
import com.julio.asistente.ui.JulioRoot
import com.julio.asistente.ui.theme.Apariencia
import com.julio.asistente.ui.theme.JulioTheme
import com.julio.asistente.ui.theme.esOscuro

class MainActivity : ComponentActivity() {
    private val pedirNotificaciones = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    /** Sin el permiso de notificaciones (Android 13+) Julio no puede avisar de nada. Se pide al abrir, máximo dos veces. */
    private fun pedirNotificacionesAlAbrir() {
        if (Build.VERSION.SDK_INT < 33 || Permisos.notificaciones(this)) return
        val sp = getSharedPreferences("julio_avisos", MODE_PRIVATE)
        val veces = sp.getInt("pedidoVeces", 0)
        if (veces >= 2) return
        sp.edit().putInt("pedidoVeces", veces + 1).apply()
        pedirNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Apariencia.cargar(applicationContext)
        pedirNotificacionesAlAbrir()
        setContent {
            val modo by Apariencia.modo.collectAsState()
            val oscuro = esOscuro(modo)
            // Iconos de la barra de estado y de navegación claros u oscuros según el tema.
            DisposableEffect(oscuro) {
                val estilo = if (oscuro) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = estilo, navigationBarStyle = estilo)
                onDispose { }
            }
            JulioTheme(modo) {
                JulioRoot()
            }
        }
    }
}
