package com.julio.asistente.ui.screens

import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.enlace.CuerpoAvisos
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.EnlaceCuerpo
import com.julio.asistente.enlace.EnlaceDiario
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.ui.components.PanelJulio

/** Configuración > Enlace entre teléfonos (Etapa 4): elegir si este teléfono es el «diario» o el «Cuerpo» y emparejarlos. */
@Composable
fun EnlacePanel() {
    val ctx = LocalContext.current
    val rol by EnlaceAjustes.rol.collectAsStateWithLifecycle()
    val codigo by EnlaceAjustes.codigo.collectAsStateWithLifecycle()
    val privado by EnlaceAjustes.privado.collectAsStateWithLifecycle()
    val estado by EnlaceAjustes.estado.collectAsStateWithLifecycle()
    val silenciadas by EnlaceAjustes.silenciadas.collectAsStateWithLifecycle()
    val ipManual by EnlaceAjustes.ipManual.collectAsStateWithLifecycle()
    val puerto by EnlaceAjustes.puertoLocal.collectAsStateWithLifecycle()
    val enEspera by CuerpoAvisos.pendientes.collectAsStateWithLifecycle()
    val escritorio by EscritorioControl.activo.collectAsStateWithLifecycle()
    var acceso by remember { mutableStateOf(accesoANotificaciones(ctx)) }
    var ipLocal by remember { mutableStateOf(EnlaceCuerpo.ipLocal()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        EnlaceAjustes.cargar(ctx)
        acceso = accesoANotificaciones(ctx)
        ipLocal = EnlaceCuerpo.ipLocal()
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("¿Qué hace este teléfono?", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Nada" to RolEnlace.NINGUNO,
                    "Teléfono de diario" to RolEnlace.DIARIO,
                    "Cuerpo de Julio" to RolEnlace.CUERPO,
                ).forEach { (titulo, valor) ->
                    FilterChip(
                        selected = rol == valor,
                        onClick = {
                            EnlaceAjustes.fijarRol(ctx, valor)
                            if (valor == RolEnlace.CUERPO && EnlaceAjustes.codigo.value == null) EnlaceAjustes.nuevoCodigo(ctx)
                            EnlaceCuerpo.reiniciar(ctx)
                        },
                        label = { Text(titulo) },
                    )
                }
            }

            when (rol) {
                RolEnlace.NINGUNO -> Text(
                    "Sin enlace. Elige «Cuerpo de Julio» en el teléfono fijo del escritorio y «Teléfono de diario» en el que llevas contigo.",
                    style = MaterialTheme.typography.bodySmall,
                )

                RolEnlace.CUERPO -> {
                    Text("Código de emparejamiento (escríbelo en el teléfono de diario):", style = MaterialTheme.typography.bodyMedium)
                    Text(codigo ?: "—", style = MaterialTheme.typography.headlineSmall, fontFamily = FontFamily.Monospace)
                    OutlinedButton(
                        onClick = {
                            EnlaceAjustes.nuevoCodigo(ctx)
                            EnlaceCuerpo.reiniciar(ctx)
                        },
                    ) { Text("Crear un código nuevo") }
                    Text(
                        "Con un código nuevo, el teléfono de diario deja de poder enviar hasta que lo vuelvas a emparejar.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Modo privado: solo dice la app, sin el contenido", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = privado, onCheckedChange = { EnlaceAjustes.alternarPrivado(ctx) })
                    }
                    Text(
                        if (puerto > 0) "Escuchando en ${ipLocal ?: "?"}:$puerto" else "No está escuchando (hace falta el modo escritorio abierto).",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (!escritorio) {
                        Text(
                            "Los avisos se reciben y se leen solo con el modo escritorio abierto (Inicio > Modo escritorio).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                    if (enEspera > 0) Text("Avisos esperando ser leídos: $enEspera", style = MaterialTheme.typography.bodySmall)
                }

                RolEnlace.DIARIO -> DiarioBloque(
                    acceso = acceso,
                    emparejado = codigo != null,
                    ipManual = ipManual,
                    silenciadas = silenciadas,
                )
            }

            if (estado.isNotBlank() && rol != RolEnlace.NINGUNO) {
                Text(estado, style = MaterialTheme.typography.bodySmall)
            }
            Text(
                "Los códigos de verificación y los avisos del banco nunca se envían, se leen ni se guardan: Julio solo dice que llegó uno. " +
                    "En los dos teléfonos pon a Julio «sin restricciones» de batería.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun DiarioBloque(acceso: Boolean, emparejado: Boolean, ipManual: String, silenciadas: Set<String>) {
    val ctx = LocalContext.current
    var texto by rememberSaveable { mutableStateOf("") }
    var mensaje by remember { mutableStateOf<String?>(null) }
    var ip by rememberSaveable(ipManual) { mutableStateOf(ipManual) }
    var verApps by remember { mutableStateOf(false) }

    Text("1. Acceso a notificaciones", style = MaterialTheme.typography.labelLarge)
    Text(
        if (acceso) "Concedido." else "Falta. Sin esto Julio no ve tus notificaciones.",
        style = MaterialTheme.typography.bodySmall,
        color = if (acceso) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
    )
    Button(
        onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
        shape = MaterialTheme.shapes.small,
    ) { Text("Abrir «Acceso a notificaciones»") }
    Text(
        "Si Julio aparece en gris: Ajustes > Aplicaciones > Julio > ⋮ (arriba a la derecha) > «Permitir ajustes restringidos», y vuelve a intentarlo.",
        style = MaterialTheme.typography.bodySmall,
    )

    Text("2. Emparejar con el Cuerpo", style = MaterialTheme.typography.labelLarge)
    if (emparejado) {
        Text("Emparejado. Para cambiar de Cuerpo, olvida el código y escribe el nuevo.", style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { EnlaceAjustes.borrarCodigo(ctx); mensaje = "Código olvidado." }) { Text("Olvidar el código") }
    } else {
        OutlinedTextField(
            value = texto,
            onValueChange = { texto = it.take(24) },
            label = { Text("Código que muestra el Cuerpo") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                mensaje = if (EnlaceAjustes.usarCodigo(ctx, texto)) "Emparejado." else "Ese código no es válido: son 16 letras y números."
                if (EnlaceAjustes.codigo.value != null) texto = ""
            },
            shape = MaterialTheme.shapes.small,
        ) { Text("Emparejar") }
    }

    Text("3. Probar", style = MaterialTheme.typography.labelLarge)
    Button(
        onClick = {
            EnlaceDiario.probar(ctx)
            mensaje = "Aviso de prueba enviado: si el Cuerpo está en modo escritorio, lo leerá."
        },
        enabled = emparejado,
        shape = MaterialTheme.shapes.small,
    ) { Text("Enviar un aviso de prueba") }

    Text("Opcional: IP del Cuerpo (solo si no se encuentran solos)", style = MaterialTheme.typography.bodyMedium)
    OutlinedTextField(
        value = ip,
        onValueChange = { ip = it.take(21) },
        label = { Text("Ej.: 192.168.1.25") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
    TextButton(onClick = { mensaje = if (EnlaceAjustes.fijarIpManual(ctx, ip)) "IP guardada." else "Esa IP no es válida." }) { Text("Guardar IP") }

    TextButton(onClick = { verApps = !verApps }) {
        Text(if (verApps) "Ocultar apps" else "Elegir apps (${silenciadas.size} silenciadas)")
    }
    if (verApps) AppsSilenciadas(silenciadas)

    mensaje?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
}

@Composable
private fun AppsSilenciadas(silenciadas: Set<String>) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != ctx.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }
    Text("Julio lee los avisos de las apps con el interruptor encendido.", style = MaterialTheme.typography.bodySmall)
    apps.forEach { (nombre, paquete) ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(nombre, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = paquete !in silenciadas, onCheckedChange = { leer -> EnlaceAjustes.silenciar(ctx, paquete, !leer) })
        }
    }
}

private fun accesoANotificaciones(ctx: android.content.Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
