package com.julio.asistente.acciones

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import com.julio.asistente.comandos.AccionNivel
import com.julio.asistente.comandos.AppInfo
import com.julio.asistente.escritorio.CalculoEscritorio
import com.julio.asistente.escritorio.EscritorioControl
import java.util.Calendar
import kotlin.math.roundToInt

class BrilloEscritorio(val porcentaje: Int, val limitado: Boolean, val automatico: Boolean)
class BrilloSistema(val porcentaje: Int, val automatico: Boolean)

/**
 * Acciones seguras sobre el propio teléfono (Etapa 3 del Proyecto Cuerpo): abrir apps, volumen y brillo.
 * Todas devuelven lo que el sistema dice DESPUÉS de cambiar, para que Julio solo afirme lo que comprobó.
 * No compra, no paga y no borra nada.
 */
object AccionesLocales {
    private var volumenPrevio: Int? = null

    // ----- Apps -----

    fun apps(c: Context): List<AppInfo> {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.paquete != c.packageName }
            .distinctBy { it.paquete }
    }

    /** null = se pidió abrir sin error; si no, el motivo. Android puede ignorar el arranque si Julio no está visible. */
    fun abrir(c: Context, paquete: String): String? {
        val intent = c.packageManager.getLaunchIntentForPackage(paquete) ?: return "esa aplicación no tiene pantalla de inicio"
        return try {
            c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }

    // ----- Volumen (de medios: el de la voz de Julio, música y videos) -----

    /** Aplica la acción y devuelve el porcentaje real que quedó (leído del sistema). */
    fun volumen(c: Context, accion: AccionNivel, nivel: Int?): Int {
        val am = c.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val actual = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (accion != AccionNivel.CONSULTAR) {
            if (accion == AccionNivel.SILENCIAR && actual > 0) volumenPrevio = actual
            val nuevo = CalculoAjustes.nuevoVolumenPasos(actual, max, accion, nivel, volumenPrevio)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, nuevo, AudioManager.FLAG_SHOW_UI)
        }
        return CalculoAjustes.porcentajeDeVolumen(am.getStreamVolume(AudioManager.STREAM_MUSIC), max)
    }

    // ----- Brillo -----

    private fun horaActual() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    /** En modo escritorio el brillo es el de la ventana (no hace falta ningún permiso) y tiene un tope para cuidar la pantalla AMOLED. */
    fun brilloEscritorio(accion: AccionNivel, nivel: Int?): BrilloEscritorio {
        val horario = CalculoEscritorio.brilloPorHora(horaActual())
        val actualPct = ((EscritorioControl.brilloManual.value ?: horario) * 100f).roundToInt()
        var pedido = actualPct
        when (accion) {
            AccionNivel.AUTOMATICO -> EscritorioControl.fijarBrilloManual(null)
            AccionNivel.CONSULTAR -> {}
            else -> {
                pedido = CalculoAjustes.nuevoPorcentaje(actualPct, accion, nivel, paso = 5)
                EscritorioControl.fijarBrilloManual(CalculoEscritorio.limitarBrilloEscritorio(pedido / 100f))
            }
        }
        val manual = EscritorioControl.brilloManual.value
        val pct = ((manual ?: horario) * 100f).roundToInt()
        val limitado = (accion == AccionNivel.SUBIR || accion == AccionNivel.FIJAR) && pedido > pct
        return BrilloEscritorio(pct, limitado, manual == null)
    }

    fun puedeCambiarBrilloSistema(c: Context): Boolean = Settings.System.canWrite(c)

    /** Abre la pantalla de Ajustes donde la persona concede «Modificar ajustes del sistema» a Julio. */
    fun abrirPermisoBrillo(c: Context) {
        try {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) {
            // Sin esa pantalla: la respuesta de Julio explica qué permiso falta.
        }
    }

    private fun leerBrilloSistema(c: Context): BrilloSistema {
        val cr = c.contentResolver
        val valor = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val auto = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL) ==
            Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
        return BrilloSistema(CalculoAjustes.brilloSistemaPorcentaje(valor), auto)
    }

    /** Fuera del modo escritorio. Hay que tener el permiso (salvo para consultar). Devuelve lo que quedó, leído del sistema. */
    fun brilloSistema(c: Context, accion: AccionNivel, nivel: Int?): BrilloSistema {
        val cr = c.contentResolver
        when (accion) {
            AccionNivel.CONSULTAR -> {}
            AccionNivel.AUTOMATICO ->
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
            else -> {
                val nuevo = CalculoAjustes.limitarBrilloSistema(
                    CalculoAjustes.nuevoPorcentaje(leerBrilloSistema(c).porcentaje, accion, nivel),
                )
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, CalculoAjustes.brilloSistemaValor(nuevo))
            }
        }
        return leerBrilloSistema(c)
    }
}
