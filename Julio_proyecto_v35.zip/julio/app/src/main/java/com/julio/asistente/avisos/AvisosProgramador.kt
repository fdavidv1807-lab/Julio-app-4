package com.julio.asistente.avisos

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.julio.asistente.core.Permisos
import java.time.ZonedDateTime

/** Programa con AlarmManager el resumen de la mañana y el aviso de pendientes de la tarde (uno al día cada uno). */
object AvisosProgramador {
    const val ACCION_MANANA = "com.julio.asistente.AVISO_MANANA"
    const val ACCION_TARDE = "com.julio.asistente.AVISO_TARDE"
    private const val COD_MANANA = 7101
    private const val COD_TARDE = 7102

    fun programar(c: Context, ahora: ZonedDateTime = ZonedDateTime.now()) {
        AvisosAjustes.cargar(c)
        val a = AvisosAjustes.ajustes.value
        armarDiario(c, ACCION_MANANA, COD_MANANA, a.resumenManana, a.horaManana, ahora)
        armarDiario(c, ACCION_TARDE, COD_TARDE, a.pendientesTarde, a.horaTarde, ahora)
    }

    private fun armarDiario(c: Context, accion: String, codigo: Int, activo: Boolean, minutoDia: Int, ahora: ZonedDateTime) {
        val pi = PendingIntent.getBroadcast(
            c, codigo, Intent(c, AvisosReceiver::class.java).setAction(accion),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!activo) {
            am.cancel(pi)
            return
        }
        var momento = ahora.toLocalDate().atTime(minutoDia / 60, minutoDia % 60).atZone(ahora.zone)
        if (!momento.isAfter(ahora.plusSeconds(30))) momento = momento.plusDays(1)
        val ms = momento.toInstant().toEpochMilli()
        try {
            if (Permisos.alarmasExactas(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }
}
