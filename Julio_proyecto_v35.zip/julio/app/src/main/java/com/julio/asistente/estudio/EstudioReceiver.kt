package com.julio.asistente.estudio

import com.julio.asistente.animacion.JulioAviso
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import java.time.LocalDate
import java.time.ZonedDateTime

/** Llega aquí el aviso diario: dice qué toca estudiar hoy y deja armado el de mañana. */
class EstudioReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        EstudioRepo.cargar(app)
        val hoy = LocalDate.now()
        val examenes = EstudioRepo.examenes.value
        val deHoy = Agenda.deHoy(examenes, hoy)
        val atrasadas = Agenda.atrasadas(examenes, hoy)
        if (deHoy.isNotEmpty() || atrasadas.isNotEmpty()) {
            val texto = StringBuilder()
            if (deHoy.isNotEmpty()) {
                val (e, s) = deHoy[0]
                texto.append("${e.materia}: ${s.titulo} · ${s.minutos} min")
                if (deHoy.size > 1) texto.append(" (y ${deHoy.size - 1} más)")
            }
            if (atrasadas.isNotEmpty()) {
                if (texto.isNotEmpty()) texto.append(". ")
                texto.append("Atrasadas: ${atrasadas.size}")
            }
            enviar(app, if (deHoy.isNotEmpty()) "Hoy toca estudiar" else "Tienes estudio atrasado", texto.toString())
        }
        EstudioAviso.programar(app, ZonedDateTime.now().plusSeconds(60))
    }

    private fun enviar(c: Context, titulo: String, texto: String) {
        val abrir = PendingIntent.getActivity(
            c, 41, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(c, Canales.RECORDATORIOS)
            .setSmallIcon(R.drawable.ic_alarma)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setStyle(NotificationCompat.BigTextStyle().bigText(texto))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(abrir)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(300_000, n)
            JulioAviso.emitir(c)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones no se puede avisar.
        }
    }
}
