package com.julio.asistente.enlace

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.UUID

/**
 * Teléfono de diario: ve las notificaciones nuevas (permiso «Acceso a notificaciones», que se concede en Ajustes),
 * descarta las que no son avisos, quita el contenido de códigos y bancos y las manda al Cuerpo.
 * Si el teléfono no está en el rol «diario», no hace nada.
 */
class DiarioListener : NotificationListenerService() {
    private val dedupe = Deduplicador()

    override fun onCreate() {
        super.onCreate()
        EnlaceAjustes.cargar(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (EnlaceAjustes.rol.value != RolEnlace.DIARIO) return
            val n = sbn.notification ?: return
            val extras = n.extras
            val titulo = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val texto = (extras?.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras?.getCharSequence(Notification.EXTRA_TEXT))
                ?.toString().orEmpty()
            val cruda = NotificacionCruda(
                paquete = sbn.packageName.orEmpty(),
                titulo = titulo,
                texto = texto,
                categoria = n.category,
                enCurso = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0,
                resumenGrupo = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0,
            )
            if (FiltroAvisos.motivoDescarte(cruda, packageName, EnlaceAjustes.silenciadas.value) != null) return
            val ahora = System.currentTimeMillis()
            if (dedupe.repetido(cruda.paquete, titulo, texto, ahora)) return
            val aviso = Sensibles.sanear(
                Aviso(UUID.randomUUID().toString(), ahora, nombreDeApp(cruda.paquete), cruda.paquete, titulo, texto),
            )
            EnlaceDiario.enviar(applicationContext, aviso)
        } catch (e: Exception) {
            // Un aviso raro nunca debe tumbar el servicio.
        }
    }

    /** Samsung y otros matan estos servicios: se pide al sistema que lo vuelva a conectar. */
    override fun onListenerDisconnected() {
        try {
            NotificationListenerService.requestRebind(ComponentName(this, DiarioListener::class.java))
        } catch (e: Exception) { }
    }

    private fun nombreDeApp(paquete: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(paquete, 0)).toString()
    } catch (e: Exception) {
        paquete.substringAfterLast('.')
    }
}
