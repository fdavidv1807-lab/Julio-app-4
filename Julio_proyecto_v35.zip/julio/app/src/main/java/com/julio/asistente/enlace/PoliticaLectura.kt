package com.julio.asistente.enlace

/**
 * Qué dice Julio en voz alta por cada aviso. El texto de un aviso son DATOS, no órdenes: solo se lee en voz alta,
 * nunca pasa por el intérprete de comandos. Lógica pura.
 */
object PoliticaLectura {
    const val MAX_CARACTERES = 220

    private val ENLACES = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)
    private val ESPACIOS = Regex("\\s+")
    private val PROHIBIDOS = setOf(
        Character.CONTROL.toInt(), Character.FORMAT.toInt(), Character.SURROGATE.toInt(),
        Character.OTHER_SYMBOL.toInt(), Character.PRIVATE_USE.toInt(), Character.UNASSIGNED.toInt(),
    )

    /** Deja el texto listo para la voz: sin enlaces, sin emojis ni símbolos raros, sin saltos de línea. */
    fun limpiar(s: String): String {
        val sinEnlaces = s.replace(ENLACES, " un enlace ").replace(ESPACIOS, " ")
        val sb = StringBuilder()
        var i = 0
        while (i < sinEnlaces.length) {
            val cp = sinEnlaces.codePointAt(i)
            if (Character.getType(cp) !in PROHIBIDOS) sb.appendCodePoint(cp)
            i += Character.charCount(cp)
        }
        return sb.toString().replace(ESPACIOS, " ").trim()
    }

    /** Corta en el último espacio antes de [max] para no dejar palabras a medias. */
    fun recortar(s: String, max: Int = MAX_CARACTERES): String {
        if (s.length <= max) return s
        val corte = s.lastIndexOf(' ', max)
        return (if (corte > max / 2) s.substring(0, corte) else s.substring(0, max)).trimEnd()
    }

    fun frase(a: Aviso, privado: Boolean): String {
        val app = recortar(limpiar(a.app), 40).ifBlank { "una aplicación" }
        if (a.tipo == TipoAviso.CODIGO) return "Te llegó un código de verificación en $app. No lo leo en voz alta."
        if (a.tipo == TipoAviso.BANCO) return "Tienes un aviso de $app que no leo en voz alta. Míralo en tu teléfono."
        if (privado) return "Tienes un aviso de $app."
        val titulo = limpiar(a.titulo)
        val texto = limpiar(a.texto)
        val cuerpo = when {
            titulo.isEmpty() -> texto
            texto.isEmpty() -> titulo
            texto.startsWith(titulo, ignoreCase = true) -> texto
            else -> "$titulo. $texto"
        }
        return if (cuerpo.isEmpty()) "Tienes un aviso de $app." else "$app. ${recortar(cuerpo)}"
    }
}
