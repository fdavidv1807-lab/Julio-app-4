package com.julio.asistente.recordatorios

import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.TareaEntity
import com.julio.asistente.horario.Ocurrencias
import com.julio.asistente.horario.Recurrencia
import java.time.Instant
import java.time.LocalTime
import java.time.ZonedDateTime

/** Lógica pura: ¿cuándo toca el próximo aviso? (null = ninguno pendiente). */
object CalculoRecordatorio {

    fun proximoActividad(a: ActividadEntity, ahora: ZonedDateTime, porDefecto: Int? = null): ZonedDateTime? {
        val min = a.recordatorioMin ?: porDefecto ?: return null
        val zona = ahora.zone
        if (Recurrencia.de(a.recurrencia) == Recurrencia.NINGUNA) {
            val aviso = Instant.ofEpochMilli(a.inicio).atZone(zona).minusMinutes(min.toLong())
            return if (aviso.isAfter(ahora)) aviso else null
        }
        val hoy = ahora.toLocalDate()
        for (o in Ocurrencias.entre(listOf(a), hoy, hoy.plusDays(70), zona)) {
            val aviso = ZonedDateTime.of(o.fecha, o.horaInicio, zona).minusMinutes(min.toLong())
            if (aviso.isAfter(ahora)) return aviso
        }
        return null
    }

    fun proximoTarea(t: TareaEntity, ahora: ZonedDateTime, porDefecto: Int? = null): ZonedDateTime? {
        if (t.completada) return null
        val limite = t.fechaLimite ?: return null
        val minutoDia = t.recordatorioMinutoDia ?: porDefecto ?: return null
        val aviso = ZonedDateTime.of(
            Fechas.deMillisUtc(limite),
            LocalTime.of(minutoDia / 60, minutoDia % 60),
            ahora.zone,
        )
        return if (aviso.isAfter(ahora)) aviso else null
    }
}
