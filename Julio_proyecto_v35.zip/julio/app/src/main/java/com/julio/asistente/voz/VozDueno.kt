package com.julio.asistente.voz

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.vosk.SpeakerModel
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

sealed class EntrenamientoVoz {
    object Inactivo : EntrenamientoVoz()
    data class Grabando(val paso: Int, val total: Int, val segundos: Int) : EntrenamientoVoz()
    data class Error(val mensaje: String) : EntrenamientoVoz()
}

/**
 * «Solo mi voz» (como Voice Match de Google, pero dentro del teléfono): Julio aprende tu voz con 3 muestras y después
 * ignora las frases de otras voces (la tele, otras personas). Usa el modelo de hablante de Vosk
 * (https://alphacephei.com/vosk/models, Apache 2.0, ~13 MB), que se baja SOLO cuando tú lo pides.
 * Lo único que se guarda es un vector de 128 números (tu perfil de voz), no audio, y no sale del teléfono.
 * Límite honesto: no es seguridad. Una grabación tuya o una voz muy parecida podría pasar.
 */
object VozDueno {
    const val NOMBRE = "vosk-model-spk-0.4"
    const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip"
    const val ORIGEN = "alphacephei.com/vosk/models"
    const val TAMANO_ZIP_MB = 13
    const val MUESTRAS = 3
    const val SEGUNDOS_MUESTRA = 6
    const val SEGUNDOS_PRUEBA = 5

    private val _modelo = MutableStateFlow<EstadoVosk>(EstadoVosk.NoInstalado)
    val modelo: StateFlow<EstadoVosk> = _modelo.asStateFlow()
    private val _tieneHuella = MutableStateFlow(false)
    val tieneHuella: StateFlow<Boolean> = _tieneHuella.asStateFlow()
    private val _soloMiVoz = MutableStateFlow(true)
    val soloMiVoz: StateFlow<Boolean> = _soloMiVoz.asStateFlow()
    private val _umbral = MutableStateFlow(HablanteMath.UMBRAL_NORMAL)
    val umbral: StateFlow<Float> = _umbral.asStateFlow()
    private val _entrenamiento = MutableStateFlow<EntrenamientoVoz>(EntrenamientoVoz.Inactivo)
    val entrenamiento: StateFlow<EntrenamientoVoz> = _entrenamiento.asStateFlow()
    private val _mensaje = MutableStateFlow<String?>(null)
    /** Resultado de la última prueba o entrenamiento, en palabras. */
    val mensaje: StateFlow<String?> = _mensaje.asStateFlow()

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var cancelado = false
    private var hablanteCargado: SpeakerModel? = null
    private var rutaCargada: String? = null

    private fun carpeta(c: Context) = File(c.applicationContext.filesDir, "vosk/hablante")
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("julio_dueno", Context.MODE_PRIVATE)

    private fun localizar(raiz: File): File? {
        if (!raiz.isDirectory) return null
        return raiz.walkTopDown().maxDepth(3).firstOrNull { d ->
            d.isDirectory && File(d, "final.ext.raw").isFile && File(d, "mfcc.conf").isFile && File(d, "mean.vec").isFile
        }
    }

    fun rutaModelo(c: Context): String? = localizar(carpeta(c))?.absolutePath

    fun iniciar(c: Context) {
        val p = prefs(c)
        _tieneHuella.value = p.getString("huella", null)?.let { HablanteMath.deTexto(it) } != null
        _soloMiVoz.value = p.getBoolean("activo", true)
        _umbral.value = p.getFloat("umbral", HablanteMath.UMBRAL_NORMAL)
        if (_modelo.value !is EstadoVosk.Instalando) {
            File(c.applicationContext.filesDir, "vosk/.instalando-hablante").deleteRecursively()
            _modelo.value = if (rutaModelo(c) != null) EstadoVosk.Listo else EstadoVosk.NoInstalado
        }
    }

    /** Qué hay que comprobar al escuchar, o null si «solo mi voz» no está listo o está apagado. */
    fun verificacion(c: Context): VerificacionHablante? {
        if (!_soloMiVoz.value) return null
        val huella = prefs(c).getString("huella", null)?.let { HablanteMath.deTexto(it) } ?: return null
        val ruta = rutaModelo(c) ?: return null
        return VerificacionHablante(ruta, huella, _umbral.value)
    }

    fun huella(c: Context): FloatArray? = prefs(c).getString("huella", null)?.let { HablanteMath.deTexto(it) }

    /** Carga (una vez) el modelo de hablante. Se llama desde el hilo del reconocedor. */
    @Synchronized
    fun cargarModeloHablante(ruta: String): SpeakerModel {
        val actual = hablanteCargado
        if (actual != null && rutaCargada == ruta) return actual
        try { actual?.close() } catch (e: Exception) { /* ya cerrado */ }
        val nuevo = SpeakerModel(ruta)
        hablanteCargado = nuevo
        rutaCargada = ruta
        return nuevo
    }

    @Synchronized
    private fun soltarModeloHablante() {
        try { hablanteCargado?.close() } catch (e: Exception) { /* ya cerrado */ }
        hablanteCargado = null
        rutaCargada = null
    }

    fun guardarHuella(c: Context, huella: FloatArray) {
        prefs(c).edit().putString("huella", HablanteMath.aTexto(huella)).apply()
        _tieneHuella.value = true
    }

    fun borrarHuella(c: Context) {
        prefs(c).edit().remove("huella").apply()
        _tieneHuella.value = false
        _mensaje.value = "Borré tu perfil de voz."
    }

    fun fijarSoloMiVoz(c: Context, activo: Boolean) {
        prefs(c).edit().putBoolean("activo", activo).apply()
        _soloMiVoz.value = activo
    }

    fun fijarUmbral(c: Context, umbral: Float) {
        prefs(c).edit().putFloat("umbral", umbral).apply()
        _umbral.value = umbral
    }

    fun marcarEntrenamiento(e: EntrenamientoVoz) { _entrenamiento.value = e }
    fun avisar(texto: String?) { _mensaje.value = texto }

    // ----- Modelo de hablante (se baja solo cuando la persona lo pide) -----

    fun descargarModelo(c: Context) {
        if (_modelo.value is EstadoVosk.Instalando) return
        val app = c.applicationContext
        cancelado = false
        _modelo.value = EstadoVosk.Instalando(-1f, 0, "Descargando")
        alcance.launch {
            val temporal = File(app.filesDir, "vosk/.instalando-hablante")
            try {
                temporal.deleteRecursively()
                temporal.mkdirs()
                val conexion = URL(URL_ZIP).openConnection() as HttpURLConnection
                conexion.connectTimeout = 20_000
                conexion.readTimeout = 30_000
                conexion.instanceFollowRedirects = true
                try {
                    if (conexion.responseCode !in 200..299) throw IOException("el servidor respondió ${conexion.responseCode}")
                    extraer(conexion.inputStream, temporal, conexion.contentLengthLong)
                } finally {
                    conexion.disconnect()
                }
                if (localizar(temporal) == null) throw IOException("El archivo no es un modelo de hablante completo.")
                val destino = carpeta(app)
                destino.deleteRecursively()
                destino.parentFile?.mkdirs()
                if (!temporal.renameTo(destino)) throw IOException("No pude guardar el modelo en la memoria de Julio.")
                _modelo.value = if (localizar(destino) != null) EstadoVosk.Listo else EstadoVosk.Error("El modelo no quedó completo.")
            } catch (e: Exception) {
                temporal.deleteRecursively()
                _modelo.value = if (cancelado) EstadoVosk.NoInstalado
                else EstadoVosk.Error("No pude descargar el modelo de voz: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun cancelarDescarga() { cancelado = true }

    fun eliminarModelo(c: Context) {
        cancelado = true
        soltarModeloHablante()
        carpeta(c).deleteRecursively()
        _modelo.value = EstadoVosk.NoInstalado
    }

    private class Contador(entrada: InputStream, private val alLeer: (Long) -> Unit) : FilterInputStream(entrada) {
        private var total = 0L
        override fun read(): Int {
            val b = super.read()
            if (b >= 0) { total++; alLeer(total) }
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { total += n; alLeer(total) }
            return n
        }
    }

    private fun extraer(entrada: InputStream, destino: File, total: Long) {
        var publicado = -1L
        val contado = Contador(entrada) { leidos ->
            if (cancelado) throw IOException("Descarga cancelada")
            val mb = leidos / 1_000_000
            if (mb != publicado) {
                publicado = mb
                _modelo.value = EstadoVosk.Instalando(if (total > 0) leidos.toFloat() / total else -1f, mb, "Descargando")
            }
        }
        val raiz = destino.canonicalFile
        ZipInputStream(contado).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                val salida = File(raiz, e.name)
                if (!ReconocimientoUtil.esRutaSegura(raiz, salida)) throw IOException("El .zip trae una ruta no válida.")
                if (e.isDirectory) {
                    salida.mkdirs()
                } else {
                    salida.parentFile?.mkdirs()
                    salida.outputStream().use { fuera -> zip.copyTo(fuera) }
                }
                zip.closeEntry()
                e = zip.nextEntry
            }
        }
    }
}
