package com.julio.asistente.enlace

import com.julio.asistente.comandos.AppInfo
import com.julio.asistente.comandos.Apps
import java.text.Normalizer

/**
 * Reconoce códigos de verificación y avisos de banco (regla del Proyecto: «no guardar códigos de verificación
 * ni avisos del banco»). Si hay duda se prefiere tratarlo como sensible: Julio solo dice que llegó, sin el contenido.
 * Lógica pura: se prueba sin Android.
 */
object Sensibles {
    private val ACENTOS = Regex("\\p{M}+")
    private val NO_ALFANUM = Regex("[^a-z0-9 ]")
    private val ESPACIOS = Regex("\\s+")
    private val DIGITOS_PARTIDOS = Regex("([0-9]{3}) ([0-9]{3})")
    private val DIGITOS = Regex("(?<![0-9])[0-9]{4,8}(?![0-9])")

    /** Minúsculas, sin acentos ni signos: «Tu código: 123-456» -> «tu codigo 123 456». */
    internal fun norm(s: String): String {
        val sinAcentos = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(ACENTOS, "")
        return sinAcentos.replace(NO_ALFANUM, " ").replace(ESPACIOS, " ").trim()
    }

    private val FRASES_CODIGO = listOf(
        "codigo de verificacion", "verification code", "one time password", "one time passcode",
        "no compartas", "do not share", "dont share", "clave temporal", "clave dinamica", "contrasena temporal",
        "codigo de seguridad", "codigo de acceso", "codigo de confirmacion", "codigo de un solo uso",
    )
    private val PALABRAS_CODIGO = setOf(
        "codigo", "code", "otp", "clave", "contrasena", "password", "pin", "token", "verificacion", "verification",
        "passcode", "2fa", "autenticacion",
    )
    private val PALABRAS_BANCO = setOf(
        "banco", "bancos", "bank", "bancario", "bancaria", "bancolombia", "davivienda", "daviplata", "nequi", "bbva",
        "itau", "scotiabank", "colpatria", "avvillas", "tarjeta", "saldo", "transferencia", "transferencias",
        "pse", "cvv", "paypal",
    )

    /** ¿El texto parece traer un código de verificación? */
    fun esCodigo(titulo: String, texto: String): Boolean {
        val t = " " + norm("$titulo $texto").replace(DIGITOS_PARTIDOS, "$1$2") + " "
        if (FRASES_CODIGO.any { t.contains(" $it ") }) return true
        val palabras = t.trim().split(" ").toSet()
        return palabras.any { it in PALABRAS_CODIGO } && DIGITOS.containsMatchIn(t)
    }

    /** ¿El texto parece de un banco o de pagos? */
    fun esBanco(titulo: String, texto: String): Boolean =
        norm("$titulo $texto").split(" ").any { it in PALABRAS_BANCO }

    /** Misma lista de apps de banco y pagos que usa Julio para negarse a abrirlas (Etapa 3). */
    fun appEsBanco(app: String, paquete: String): Boolean = Apps.esSensible(AppInfo(app, paquete))

    fun clasificar(app: String, paquete: String, titulo: String, texto: String): TipoAviso = when {
        appEsBanco(app, paquete) -> TipoAviso.BANCO
        esCodigo(titulo, texto) -> TipoAviso.CODIGO
        esBanco(titulo, texto) -> TipoAviso.BANCO
        else -> TipoAviso.NORMAL
    }

    /** Devuelve el aviso listo para viajar y leerse: si es sensible, sin título ni texto. Se usa en AMBOS teléfonos. */
    fun sanear(a: Aviso): Aviso {
        val tipo = if (a.tipo != TipoAviso.NORMAL) a.tipo else clasificar(a.app, a.paquete, a.titulo, a.texto)
        return if (tipo == TipoAviso.NORMAL) a else a.copy(tipo = tipo, titulo = "", texto = "")
    }
}
