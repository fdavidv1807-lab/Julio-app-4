package com.julio.asistente.enfoque

import kotlin.random.Random

/**
 * Reglas del enfoque ESTRICTO (lógica pura, sin Android, para poder probarla):
 * no se puede pausar ni terminar antes de tiempo; salir cuesta una espera de 10 minutos, escribir una frase larga
 * sin pegar, resolver cuentas y escribir una palabra final. Durante la sesión también se bloquean Ajustes y las
 * tiendas/instaladores de apps, para que no se puedan quitar permisos ni desinstalar desde el teléfono.
 */
object Estricto {
    const val MAX_MIN = 180
    const val ESPERA_SALIDA_MS = 10 * 60_000L
    const val FRASE = "Elijo rendirme y dejar mi enfoque a medias, aunque sé que después me voy a arrepentir de no haber aguantado."
    const val PALABRA_FINAL = "ME RINDO"

    /** Apps que solo se bloquean en modo estricto (en el enfoque normal Ajustes sigue libre). */
    val EXTRA_BLOQUEADAS: Set<String> = setOf(
        "com.android.settings",
        "com.android.vending",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller",
        "com.google.android.permissioncontroller",
        "com.samsung.android.packageinstaller",
    )

    fun duracionValida(min: Int): Boolean = min in 1..MAX_MIN

    /** Apps que se cubren: las elegidas, más Ajustes y tiendas si es estricto. */
    fun bloqueadas(elegidas: Set<String>, estricto: Boolean): Set<String> =
        if (estricto) elegidas + EXTRA_BLOQUEADAS else elegidas

    /** Apps que nunca se cubren (llamadas, inicio, Julio…). En estricto Ajustes deja de estar protegido. */
    fun protegidas(base: Set<String>, estricto: Boolean): Set<String> =
        if (estricto) base - EXTRA_BLOQUEADAS else base

    /** Cuánto falta para poder salir. [solicitadaMs] = cuándo se pidió salir (0 = aún no). */
    fun esperaRestanteMs(solicitadaMs: Long, ahoraMs: Long): Long =
        if (solicitadaMs <= 0L) ESPERA_SALIDA_MS
        else (solicitadaMs + ESPERA_SALIDA_MS - ahoraMs).coerceIn(0L, ESPERA_SALIDA_MS)

    private fun limpiar(s: String): String = s.trim().replace(Regex("\\s+"), " ")

    fun fraseCorrecta(escrita: String): Boolean = limpiar(escrita).equals(limpiar(FRASE), ignoreCase = true)

    fun palabraFinalCorrecta(escrita: String): Boolean = limpiar(escrita).equals(PALABRA_FINAL, ignoreCase = true)

    /** Un cambio de texto de más de 12 letras de golpe es un pegado: no se acepta. */
    fun pegado(anterior: String, nuevo: String): Boolean = nuevo.length - anterior.length > 12

    class Problema(val texto: String, val respuesta: Int)

    fun problemas(azar: Random, cantidad: Int = 6): List<Problema> = List(cantidad) { i ->
        val a = azar.nextInt(12, 50)
        val b = azar.nextInt(6, 20)
        val c = azar.nextInt(11, 90)
        if (i % 2 == 0) Problema("$a × $b", a * b) else Problema("$a × $b + $c", a * b + c)
    }

    fun respuestaCorrecta(p: Problema, escrita: String): Boolean = escrita.trim().toIntOrNull() == p.respuesta
}
