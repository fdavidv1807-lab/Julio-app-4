package com.julio.asistente.enlace

/** Qué clase de aviso es. Los códigos y los avisos del banco NUNCA llevan su contenido (ni viaja por la red ni se lee ni se guarda). */
enum class TipoAviso(val codigo: Int) {
    NORMAL(0), CODIGO(1), BANCO(2);

    companion object {
        /** Un valor desconocido se trata como BANCO (lo más restrictivo: sin contenido). */
        fun de(codigo: Int): TipoAviso = entries.firstOrNull { it.codigo == codigo } ?: BANCO
    }
}

/** Una notificación del teléfono de diario, ya filtrada. Para NORMAL lleva título y texto; para el resto van vacíos. */
data class Aviso(
    val id: String,
    /** Hora (ms) del teléfono de diario al verla. */
    val tiempo: Long,
    /** Nombre de la app que la lanzó («WhatsApp»). */
    val app: String,
    val paquete: String,
    val titulo: String,
    val texto: String,
    val tipo: TipoAviso = TipoAviso.NORMAL,
)
