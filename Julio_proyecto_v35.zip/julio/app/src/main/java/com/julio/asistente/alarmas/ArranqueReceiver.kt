package com.julio.asistente.alarmas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.julio.asistente.avisos.AvisosProgramador
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.estudio.EstudioAviso
import com.julio.asistente.recordatorios.RecordatorioProgramador
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Reprograma las alarmas tras reiniciar, actualizar la app o cambiar la hora/zona horaria. */
class ArranqueReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Si el modo escritorio estaba activo, se levanta el servicio (la pantalla se abre al abrir la app).
            com.julio.asistente.escritorio.EscritorioControl.reanudarServicio(app)
        }
        val pendiente = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AlarmaProgramador.reprogramarTodas(app)
                EnfoqueControl.reprogramar(app)
                RecordatorioProgramador.reprogramarTodos(app)
                EstudioAviso.programar(app)
                AvisosProgramador.programar(app)
            } finally {
                pendiente.finish()
            }
        }
    }
}
