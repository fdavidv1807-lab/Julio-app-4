package com.julio.asistente.enfoque

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Cada minuto de un enfoque estricto: si el bloqueo se apagó (el sistema lo cerró), lo vuelve a encender. */
class VigilanteReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        EnfoqueControl.vigilar(context.applicationContext)
    }
}
