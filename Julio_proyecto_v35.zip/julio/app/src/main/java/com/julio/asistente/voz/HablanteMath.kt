package com.julio.asistente.voz

import kotlin.math.sqrt

/** Lo que hace falta para comprobar que quien habla es el dueño: rutas y perfil entrenado. */
class VerificacionHablante(val rutaModelo: String, val referencia: FloatArray, val umbral: Float)

/**
 * Cuentas puras (sin Android) del reconocimiento de la voz del dueño.
 * Vosk, con su modelo de hablante, entrega junto al texto un vector («spk») y cuánto audio con voz usó («spk_frames»).
 * Dos vectores de la misma persona quedan cerca (distancia de coseno baja); de personas distintas, lejos.
 */
object HablanteMath {
    /** Menos audio que esto no alcanza para juzgar la voz: la frase se acepta sin comprobar. */
    const val FRAMES_MINIMOS = 60
    /** Mínimo de audio con voz para considerar buena una muestra de entrenamiento. */
    const val FRAMES_MINIMOS_ENTRENAMIENTO = 100

    const val UMBRAL_ESTRICTO = 0.35f
    const val UMBRAL_NORMAL = 0.45f
    const val UMBRAL_PERMISIVO = 0.60f

    /** Si las muestras de entrenamiento se alejan más que esto entre sí, se pide repetir. */
    const val DISTANCIA_MAX_ENTRE_MUESTRAS = 0.6f

    enum class Tipo { SIN_DATO, MISMA, AJENA }
    data class Veredicto(val tipo: Tipo, val distancia: Float?)

    fun parseSpk(json: String): FloatArray? {
        val m = Regex("\"spk\"\\s*:\\s*\\[([^\\]]*)\\]").find(json) ?: return null
        val partes = m.groupValues[1].split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (partes.isEmpty()) return null
        return try {
            FloatArray(partes.size) { partes[it].toFloat() }
        } catch (e: NumberFormatException) {
            null
        }
    }

    fun parseFrames(json: String): Int =
        Regex("\"spk_frames\"\\s*:\\s*(\\d+)").find(json)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    /** 0 = misma dirección (misma voz), 1 = sin relación. Si no se pueden comparar, 1. */
    fun distanciaCoseno(a: FloatArray, b: FloatArray): Float {
        if (a.isEmpty() || a.size != b.size) return 1f
        var punto = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in a.indices) {
            punto += a[i].toDouble() * b[i]
            na += a[i].toDouble() * a[i]
            nb += b[i].toDouble() * b[i]
        }
        if (na == 0.0 || nb == 0.0) return 1f
        return (1.0 - punto / (sqrt(na) * sqrt(nb))).toFloat()
    }

    /** Guarda el vector de un resultado de Vosk, con el audio con voz que usó, si trae suficiente información. */
    fun agregarMuestra(json: String, destino: MutableList<Pair<FloatArray, Int>>) {
        val v = parseSpk(json) ?: return
        val f = parseFrames(json)
        if (f > 0) destino.add(v to f)
    }

    private fun unitario(v: FloatArray): FloatArray? {
        var n = 0.0
        for (x in v) n += x.toDouble() * x
        if (n == 0.0) return null
        val r = sqrt(n).toFloat()
        return FloatArray(v.size) { v[it] / r }
    }

    /** Promedio de vectores (cada uno pesa según cuánta voz tuvo). null si no hay ninguno utilizable. */
    fun mediaPonderada(muestras: List<Pair<FloatArray, Int>>): FloatArray? {
        val validas = muestras.mapNotNull { (v, f) -> unitario(v)?.let { it to f } }
        if (validas.isEmpty()) return null
        val largo = validas[0].first.size
        if (validas.any { it.first.size != largo }) return null
        val suma = DoubleArray(largo)
        var pesos = 0.0
        for ((v, f) in validas) {
            for (i in 0 until largo) suma[i] += v[i].toDouble() * f
            pesos += f
        }
        if (pesos == 0.0) return null
        return unitario(FloatArray(largo) { (suma[it] / pesos).toFloat() })
    }

    fun veredicto(json: String, referencia: FloatArray, umbral: Float): Veredicto {
        val spk = parseSpk(json)
        if (spk == null || parseFrames(json) < FRAMES_MINIMOS) return Veredicto(Tipo.SIN_DATO, null)
        val d = distanciaCoseno(spk, referencia)
        return Veredicto(if (d <= umbral) Tipo.MISMA else Tipo.AJENA, d)
    }

    /** Distancia más grande entre dos de las muestras (para saber si se parecen entre sí). */
    fun distanciaMaxima(vectores: List<FloatArray>): Float {
        var m = 0f
        for (i in vectores.indices) for (j in i + 1 until vectores.size) m = maxOf(m, distanciaCoseno(vectores[i], vectores[j]))
        return m
    }

    fun aTexto(v: FloatArray): String = v.joinToString(",")

    fun deTexto(s: String): FloatArray? {
        val partes = s.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (partes.isEmpty()) return null
        return try {
            FloatArray(partes.size) { partes[it].toFloat() }
        } catch (e: NumberFormatException) {
            null
        }
    }
}
