package com.julio.asistente.animacion

import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.enfoque.Fase
import com.julio.asistente.voz.EstadoVoz
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

/** Estado principal de Julio: solo uno a la vez. «Dormido» es una variante de reposo. */
enum class Principal { REPOSO, DORMIDO, ESCUCHANDO, PENSANDO, HABLANDO, ENFOCADO }

/** Detalle que se pone encima del estado principal, sin quitarlo. */
enum class Capa { NINGUNA, AVISO, ERROR }

/** Cada aviso o error trae un número nuevo (id) para que se anime aunque se repita. */
data class EventoCapa(val capa: Capa, val id: Int)

/**
 * UN solo «estado actual» de Julio. La pantalla de animación lo lee; más adelante las luces, los sonidos
 * y el cuerpo físico (Proyecto Cuerpo) pueden leer exactamente este mismo estado.
 *
 * No tiene lógica propia de voz, enfoque ni avisos: solo recibe lo que ellos ya hacen.
 *  - La voz lo alimenta con [ponerVoz] (desde VozViewModel).
 *  - El enfoque se lee directo de EnfoqueControl.sesion.
 *  - Los avisos llaman a [aviso] (vía JulioAviso) y los errores a [error].
 */
object JulioEstado {
    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _voz = MutableStateFlow(EstadoVoz.REPOSO)
    private val _dormido = MutableStateFlow(false)
    private val _capa = MutableStateFlow(EventoCapa(Capa.NINGUNA, 0))
    private var contador = 0

    /** Último aviso o error (con su número). */
    val capa: StateFlow<EventoCapa> = _capa.asStateFlow()

    /** Estado principal actual. La voz manda; si no hay voz, el enfoque; si no, dormido o reposo. */
    val principal: StateFlow<Principal> = combine(_voz, EnfoqueControl.sesion, _dormido) { voz, sesion, dormido ->
        when {
            voz == EstadoVoz.ESCUCHANDO -> Principal.ESCUCHANDO
            voz == EstadoVoz.PROCESANDO -> Principal.PENSANDO
            voz == EstadoVoz.RESPONDIENDO -> Principal.HABLANDO
            sesion.estado == EstadoSesion.CORRIENDO && sesion.fase == Fase.ENFOQUE -> Principal.ENFOCADO
            dormido -> Principal.DORMIDO
            else -> Principal.REPOSO
        }
    }.stateIn(alcance, SharingStarted.Eagerly, Principal.REPOSO)

    /** Lo llama VozViewModel cada vez que cambia su estado. Cualquier actividad de voz despierta a Julio. */
    fun ponerVoz(v: EstadoVoz) {
        if (v != EstadoVoz.REPOSO) _dormido.value = false
        _voz.value = v
    }

    /** Tras mucho rato sin uso (lo decide la pantalla). */
    fun dormir() { _dormido.value = true }

    /** Por toque (la voz despierta sola vía [ponerVoz]). */
    fun despertar() { _dormido.value = false }

    @Synchronized
    private fun nuevoEvento(c: Capa) {
        contador++
        _capa.value = EventoCapa(c, contador)
    }

    /** Julio emitió una notificación o aviso. */
    fun aviso() = nuevoEvento(Capa.AVISO)

    /** Algo salió mal y se le muestra un error a la persona. */
    fun error() = nuevoEvento(Capa.ERROR)
}
