package com.julio.asistente.animacion

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/**
 * Cada vez que Julio emite una notificación o aviso se llama a [emitir]:
 *  1. pone la capa «aviso» en el estado de Julio (pulsos ámbar y saltito), y
 *  2. suena un sonido corto (gorila o banana).
 *
 * El sonido es el archivo res/raw/julio_aviso (.mp3, .ogg o .wav). Si todavía no existe, no suena nada y
 * nada se rompe: basta con copiar el archivo con ese nombre y volver a compilar.
 *
 * Decisiones: suena SIEMPRE, incluso en silencio / No molestar y durante el modo enfoque. Para lograrlo se
 * reproduce como sonido de alarma (usa el volumen de alarma; si ese volumen está en cero, no se oye).
 */
object JulioAviso {
    private const val NOMBRE_SONIDO = "julio_aviso"

    fun emitir(contexto: Context) {
        JulioEstado.aviso()
        sonar(contexto.applicationContext)
    }

    private fun sonar(c: Context) {
        val id = c.resources.getIdentifier(NOMBRE_SONIDO, "raw", c.packageName)
        if (id == 0) return // todavía no hay archivo de sonido
        try {
            val reproductor = MediaPlayer()
            reproductor.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            c.resources.openRawResourceFd(id).use { archivo ->
                reproductor.setDataSource(archivo.fileDescriptor, archivo.startOffset, archivo.length)
            }
            reproductor.setOnPreparedListener { it.start() }
            reproductor.setOnCompletionListener { it.release() }
            reproductor.setOnErrorListener { m, _, _ -> m.release(); true }
            reproductor.prepareAsync()
        } catch (e: Exception) {
            // Sin sonido no pasa nada grave: la notificación igual se muestra.
        }
    }
}
