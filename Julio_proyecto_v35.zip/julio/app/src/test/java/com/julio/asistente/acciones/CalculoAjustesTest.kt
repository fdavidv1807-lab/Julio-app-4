package com.julio.asistente.acciones

import com.julio.asistente.comandos.AccionNivel
import com.julio.asistente.escritorio.CalculoEscritorio
import org.junit.Assert.assertEquals
import org.junit.Test

class CalculoAjustesTest {
    @Test fun porcentajeSubeBajaYFija() {
        assertEquals(65, CalculoAjustes.nuevoPorcentaje(50, AccionNivel.SUBIR, null))
        assertEquals(0, CalculoAjustes.nuevoPorcentaje(10, AccionNivel.BAJAR, null))
        assertEquals(100, CalculoAjustes.nuevoPorcentaje(90, AccionNivel.SUBIR, null))
        assertEquals(100, CalculoAjustes.nuevoPorcentaje(50, AccionNivel.FIJAR, 150))
        assertEquals(50, CalculoAjustes.nuevoPorcentaje(50, AccionNivel.FIJAR, null))
        assertEquals(55, CalculoAjustes.nuevoPorcentaje(50, AccionNivel.SUBIR, null, paso = 5))
    }

    @Test fun volumenSubeYBajaAlMenosUnPaso() {
        assertEquals(8, CalculoAjustes.nuevoVolumenPasos(6, 15, AccionNivel.SUBIR, null, null))
        assertEquals(15, CalculoAjustes.nuevoVolumenPasos(15, 15, AccionNivel.SUBIR, null, null))
        assertEquals(0, CalculoAjustes.nuevoVolumenPasos(1, 15, AccionNivel.BAJAR, null, null))
        assertEquals(0, CalculoAjustes.nuevoVolumenPasos(0, 15, AccionNivel.BAJAR, null, null))
    }

    @Test fun volumenSilenciarYActivar() {
        assertEquals(0, CalculoAjustes.nuevoVolumenPasos(9, 15, AccionNivel.SILENCIAR, null, null))
        assertEquals(9, CalculoAjustes.nuevoVolumenPasos(0, 15, AccionNivel.ACTIVAR, null, 9))
        assertEquals(8, CalculoAjustes.nuevoVolumenPasos(0, 15, AccionNivel.ACTIVAR, null, null))
        assertEquals(5, CalculoAjustes.nuevoVolumenPasos(5, 15, AccionNivel.ACTIVAR, null, 9))
    }

    @Test fun volumenFijar() {
        assertEquals(15, CalculoAjustes.nuevoVolumenPasos(3, 15, AccionNivel.FIJAR, 100, null))
        assertEquals(0, CalculoAjustes.nuevoVolumenPasos(3, 15, AccionNivel.FIJAR, 0, null))
        assertEquals(8, CalculoAjustes.nuevoVolumenPasos(3, 15, AccionNivel.FIJAR, 50, null))
        assertEquals(53, CalculoAjustes.porcentajeDeVolumen(8, 15))
    }

    @Test fun brilloDelSistemaNuncaEsCero() {
        assertEquals(1, CalculoAjustes.limitarBrilloSistema(0))
        assertEquals(255, CalculoAjustes.brilloSistemaValor(100))
        assertEquals(2, CalculoAjustes.brilloSistemaValor(0))
        assertEquals(100, CalculoAjustes.brilloSistemaPorcentaje(255))
        assertEquals(50, CalculoAjustes.brilloSistemaPorcentaje(128))
    }

    @Test fun brilloDeEscritorioTieneTope() {
        assertEquals(CalculoEscritorio.BRILLO_MAX_ESCRITORIO, CalculoEscritorio.limitarBrilloEscritorio(0.9f))
        assertEquals(CalculoEscritorio.BRILLO_MIN_ESCRITORIO, CalculoEscritorio.limitarBrilloEscritorio(0f))
        assertEquals(0.2f, CalculoEscritorio.limitarBrilloEscritorio(0.2f))
    }
}
