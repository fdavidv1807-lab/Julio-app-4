package com.julio.asistente.comandos

import com.julio.asistente.comandos.HuevosDePascua.Tipo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class HuevosDePascuaTest {
    @Test fun hablameDeDios() {
        for (f in listOf("háblame de Dios", "Julio, háblame de Dios", "dame un versículo", "dime un versiculo", "una palabra de Dios", "cuéntame de Dios")) {
            assertEquals(f, Tipo.DIOS, HuevosDePascua.clasificar(f))
        }
    }

    @Test fun lasFrasesGravesSiempreSeAtiendenConCuidado() {
        for (f in listOf("quiero morirme", "ya no quiero vivir", "a veces pienso en hacerme daño")) {
            assertEquals(f, Tipo.CRISIS, HuevosDePascua.clasificar(f))
            assertEquals(HuevosDePascua.MENSAJE_CRISIS, HuevosDePascua.crisis(f))
        }
        assertNull(HuevosDePascua.crisis("háblame de Dios"))
    }

    @Test fun lasOrdenesYLasEmocionesNormalesNuncaSeToman() {
        val frases = listOf(
            "¿Qué tengo pendiente para mañana?", "Agrega una clase de Anatomía el lunes a las siete",
            "Pon una alarma para las cinco de la mañana", "¿Qué actividades tengo programadas esta semana?",
            "Tengo examen de anatomía el 5 de noviembre con los temas huesos y músculos", "elimina la tarea del informe",
            "agrega tarea estudiar para el parcial", "qué me toca estudiar hoy", "inicia modo enfoque de 25 minutos",
            "mueve el laboratorio para el viernes a las cuatro", "hola Julio", "estoy desmotivado", "estoy triste", "eres un inútil",
        )
        for (f in frases) assertNull(f, HuevosDePascua.clasificar(f))
        assertNull(HuevosDePascua.responder("pon una alarma a las cinco"))
    }

    @Test fun respondeConUnVersiculoDeSuLista() {
        val r = HuevosDePascua.responder("háblame de Dios", Random(5))
        assertNotNull(r)
        assertTrue(HuevosDePascua.VERSICULOS.any { (texto, cita) -> r!!.contains(texto) && r.contains(cita) })
        assertTrue(HuevosDePascua.INTROS.any { r!!.startsWith(it) })
    }

    @Test fun noRepiteElMismoVersiculoDosVecesSeguidas() {
        val azar = Random(3)
        var anterior = HuevosDePascua.responder("dame un versículo", azar)!!
        repeat(60) {
            val actual = HuevosDePascua.responder("dame un versículo", azar)!!
            val a = HuevosDePascua.VERSICULOS.indexOfFirst { anterior.contains(it.first) }
            val b = HuevosDePascua.VERSICULOS.indexOfFirst { actual.contains(it.first) }
            assertNotEquals(a, b)
            anterior = actual
        }
    }

    @Test fun lasFrasesSonLegiblesPorLaVoz() {
        val todas = HuevosDePascua.VERSICULOS.map { it.first + " " + it.second } + HuevosDePascua.INTROS + HuevosDePascua.MENSAJE_CRISIS
        for (f in todas) assertTrue(f, f.none { it.isDigit() })
        for ((texto, cita) in HuevosDePascua.VERSICULOS) {
            assertTrue(texto, texto.length + cita.length < 330)
            assertTrue(texto, texto.isNotBlank() && cita.isNotBlank())
        }
        assertEquals(HuevosDePascua.VERSICULOS.size, HuevosDePascua.VERSICULOS.map { it.first }.toSet().size)
    }
}
