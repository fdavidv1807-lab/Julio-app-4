package com.julio.asistente.enlace

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SensiblesTest {
    private fun tipo(app: String, paquete: String, t: String, x: String) = Sensibles.clasificar(app, paquete, t, x)

    @Test fun reconoceCodigosDeVerificacion() {
        assertEquals(TipoAviso.CODIGO, tipo("Mensajes", "com.google.android.apps.messaging", "Google", "G-123456 es tu código de verificación de Google"))
        assertEquals(TipoAviso.CODIGO, tipo("WhatsApp", "com.whatsapp", "WhatsApp", "Tu código de WhatsApp: 123-456. No compartas este código"))
        assertEquals(TipoAviso.CODIGO, tipo("Mensajes", "x.y", "Uber", "Your Uber code is 4821"))
        assertEquals(TipoAviso.CODIGO, tipo("Mensajes", "x.y", "", "Tu clave temporal es 884211"))
        assertEquals(TipoAviso.CODIGO, tipo("Mensajes", "x.y", "Tu codigo de verificacion", ""))
    }

    @Test fun reconoceBancos() {
        assertEquals(TipoAviso.BANCO, tipo("Bancolombia", "com.todo1.mobile", "Compra", "Compra por 25.000"))
        assertEquals(TipoAviso.BANCO, tipo("Mensajes", "com.google.android.apps.messaging", "Davivienda", "Compra aprobada"))
        assertEquals(TipoAviso.BANCO, tipo("Mensajes", "x.y", "Aviso", "Tu saldo disponible es bajo"))
        assertEquals(TipoAviso.BANCO, tipo("Nequi", "com.nequi.MobileApp", "Nequi", "Te llegó plata"))
    }

    @Test fun lasConversacionesNormalesNoSonSensibles() {
        assertEquals(TipoAviso.NORMAL, tipo("WhatsApp", "com.whatsapp", "Ana", "¿Vamos a comer a las 12?"))
        assertEquals(TipoAviso.NORMAL, tipo("WhatsApp", "com.whatsapp", "Mamá", "Llámame cuando salgas"))
        assertEquals(TipoAviso.NORMAL, tipo("Gmail", "com.google.android.gm", "Reunión", "Mañana a las 3 en la oficina 4521"))
    }

    @Test fun saneaQuitaElContenidoDeLosSensibles() {
        val a = Aviso("1", 0L, "Mensajes", "x.y", "Google", "G-123456 es tu código de verificación")
        val s = Sensibles.sanear(a)
        assertEquals(TipoAviso.CODIGO, s.tipo)
        assertEquals("", s.titulo)
        assertEquals("", s.texto)
    }

    @Test fun saneaDejaIntactoLoNormal() {
        val a = Aviso("1", 0L, "WhatsApp", "com.whatsapp", "Ana", "Hola")
        assertEquals(a, Sensibles.sanear(a))
    }

    @Test fun unTipoYaSensibleNoVuelveANormal() {
        val a = Aviso("1", 0L, "X", "x.y", "Hola", "Hola", TipoAviso.BANCO)
        assertEquals(TipoAviso.BANCO, Sensibles.sanear(a).tipo)
        assertTrue(Sensibles.sanear(a).texto.isEmpty())
        assertFalse(Sensibles.esCodigo("Hola", "Hola"))
    }
}
