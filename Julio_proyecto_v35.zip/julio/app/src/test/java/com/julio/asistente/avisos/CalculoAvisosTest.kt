package com.julio.asistente.avisos

import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.TareaEntity
import com.julio.asistente.recordatorios.CalculoRecordatorio
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.ZonedDateTime

class CalculoAvisosTest {
    private val ahora = ZonedDateTime.of(2026, 11, 5, 9, 0, 0, 0, ZoneOffset.UTC)

    @Test fun elAvisoPropioMandaYSinElSeUsaElDePorDefecto() {
        assertEquals(30, CalculoAvisos.minutosAviso(30, 10))
        assertEquals(0, CalculoAvisos.minutosAviso(0, 10))
        assertEquals(10, CalculoAvisos.minutosAviso(null, 10))
        assertNull(CalculoAvisos.minutosAviso(null, null))
    }

    @Test fun unaActividadSinAvisoPropioAvisaConElDePorDefecto() {
        val inicio = ahora.plusHours(2).toInstant().toEpochMilli()
        val sin = ActividadEntity(titulo = "Anatomía", inicio = inicio)
        assertNull(CalculoRecordatorio.proximoActividad(sin, ahora))
        assertEquals(ahora.plusHours(2).minusMinutes(10), CalculoRecordatorio.proximoActividad(sin, ahora, 10))
        val con = sin.copy(recordatorioMin = 30)
        assertEquals(ahora.plusHours(2).minusMinutes(30), CalculoRecordatorio.proximoActividad(con, ahora, 10))
    }

    @Test fun unaTareaConFechaPeroSinAvisoPropioAvisaElDiaDelVencimientoALaHoraPorDefecto() {
        val limite = LocalDate.of(2026, 11, 6).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val t = TareaEntity(titulo = "Informe", fechaLimite = limite)
        assertNull(CalculoRecordatorio.proximoTarea(t, ahora))
        assertEquals(ZonedDateTime.of(2026, 11, 6, 8, 0, 0, 0, ZoneOffset.UTC), CalculoRecordatorio.proximoTarea(t, ahora, 8 * 60))
        assertNull(CalculoRecordatorio.proximoTarea(t.copy(completada = true), ahora, 8 * 60))
        assertNull(CalculoRecordatorio.proximoTarea(t.copy(fechaLimite = null), ahora, 8 * 60))
    }

    @Test fun elResumenDeLaMananaListaActividadesYTareas() {
        val r = CalculoAvisos.resumenManana(
            listOf(CalculoAvisos.ItemAgenda(LocalTime.of(8, 5), "Anatomía"), CalculoAvisos.ItemAgenda(LocalTime.of(14, 0), "Laboratorio")),
            listOf("Informe"), listOf("Guía de embriología"),
        )
        assertNotNull(r)
        assertEquals("Buenos días, esto tienes hoy", r!!.first)
        assertTrue(r.second.contains("8:05 Anatomía") && r.second.contains("14:00 Laboratorio"))
        assertTrue(r.second.contains("Tareas para hoy: Informe.") && r.second.contains("Vencidas: Guía de embriología."))
    }

    @Test fun conMuchosElementosResumeConYNMas() {
        val acts = (1..6).map { CalculoAvisos.ItemAgenda(LocalTime.of(7 + it, 0), "Clase $it") }
        val r = CalculoAvisos.resumenManana(acts, emptyList(), emptyList())!!
        assertTrue(r.second.contains("y 2 más"))
        assertTrue(!r.second.contains("Clase 5"))
    }

    @Test fun sinNadaNoHayAviso() {
        assertNull(CalculoAvisos.resumenManana(emptyList(), emptyList(), emptyList()))
        assertNull(CalculoAvisos.pendientesTarde(emptyList(), emptyList()))
    }

    @Test fun elAvisoDeLaTardeNombraLoPendiente() {
        val r = CalculoAvisos.pendientesTarde(listOf("Informe", "Resumen"), listOf("Guía"))!!
        assertEquals("Hey, te faltan tareas por hacer", r.first)
        assertEquals("Para hoy: Informe, Resumen. Vencidas: Guía.", r.second)
        assertEquals("Vencidas: Guía.", CalculoAvisos.pendientesTarde(emptyList(), listOf("Guía"))!!.second)
    }
}
