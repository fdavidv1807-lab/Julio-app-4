package com.julio.asistente.voz

import com.julio.asistente.comandos.HuevosDePascua
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HablanteMathTest {
    private val json = """{"result":[],"spk":[0.5, -1.0, 2.0],"spk_frames":120,"text":"hola"}"""

    @Test fun leeElVectorYLosFramesDeVosk() {
        assertArrayEquals(floatArrayOf(0.5f, -1f, 2f), HablanteMath.parseSpk(json)!!, 0f)
        assertEquals(120, HablanteMath.parseFrames(json))
        assertNull(HablanteMath.parseSpk("""{"text":"hola"}"""))
        assertEquals(0, HablanteMath.parseFrames("""{"text":"hola"}"""))
    }

    @Test fun distanciaDeCoseno() {
        assertEquals(0f, HablanteMath.distanciaCoseno(floatArrayOf(1f, 0f), floatArrayOf(1f, 0f)), 1e-6f)
        assertEquals(1f, HablanteMath.distanciaCoseno(floatArrayOf(1f, 0f), floatArrayOf(0f, 1f)), 1e-6f)
        assertEquals(2f, HablanteMath.distanciaCoseno(floatArrayOf(1f, 0f), floatArrayOf(-1f, 0f)), 1e-6f)
        assertEquals(1f, HablanteMath.distanciaCoseno(floatArrayOf(1f, 0f), floatArrayOf(1f, 0f, 0f)), 0f)
        assertEquals(1f, HablanteMath.distanciaCoseno(floatArrayOf(0f, 0f), floatArrayOf(1f, 0f)), 0f)
    }

    @Test fun veredictoDeQuienHabla() {
        val referencia = floatArrayOf(1f, 0f)
        fun voz(a: Float, b: Float, frames: Int) = """{"spk":[$a, $b],"spk_frames":$frames,"text":"x"}"""
        assertEquals(HablanteMath.Tipo.MISMA, HablanteMath.veredicto(voz(0.9f, 0.1f, 200), referencia, HablanteMath.UMBRAL_NORMAL).tipo)
        assertEquals(HablanteMath.Tipo.AJENA, HablanteMath.veredicto(voz(0f, 1f, 200), referencia, HablanteMath.UMBRAL_NORMAL).tipo)
        // Muy poco audio o sin vector: no se puede juzgar, se acepta.
        assertEquals(HablanteMath.Tipo.SIN_DATO, HablanteMath.veredicto(voz(0f, 1f, 10), referencia, HablanteMath.UMBRAL_NORMAL).tipo)
        assertEquals(HablanteMath.Tipo.SIN_DATO, HablanteMath.veredicto("""{"text":"x"}""", referencia, HablanteMath.UMBRAL_NORMAL).tipo)
    }

    @Test fun promedioPonderadoPorCantidadDeVoz() {
        val igual = HablanteMath.mediaPonderada(listOf(floatArrayOf(1f, 0f) to 100, floatArrayOf(0f, 1f) to 100))!!
        assertArrayEquals(floatArrayOf(0.70710677f, 0.70710677f), igual, 1e-4f)
        val pesado = HablanteMath.mediaPonderada(listOf(floatArrayOf(1f, 0f) to 300, floatArrayOf(0f, 1f) to 100))!!
        assertArrayEquals(floatArrayOf(0.9486833f, 0.31622776f), pesado, 1e-4f)
        assertNull(HablanteMath.mediaPonderada(emptyList()))
        assertNull(HablanteMath.mediaPonderada(listOf(floatArrayOf(1f, 0f) to 10, floatArrayOf(1f, 0f, 0f) to 10)))
    }

    @Test fun distanciaMaximaEntreMuestras() {
        val v = listOf(floatArrayOf(1f, 0f), floatArrayOf(0f, 1f), floatArrayOf(1f, 0f))
        assertEquals(1f, HablanteMath.distanciaMaxima(v), 1e-6f)
        assertEquals(0f, HablanteMath.distanciaMaxima(listOf(floatArrayOf(1f, 0f))), 0f)
    }

    @Test fun guardarYLeerElPerfil() {
        val v = floatArrayOf(0.5f, -1.25f)
        assertArrayEquals(v, HablanteMath.deTexto(HablanteMath.aTexto(v))!!, 0f)
        assertNull(HablanteMath.deTexto(""))
        assertNull(HablanteMath.deTexto("a,b"))
    }

    @Test fun agregarMuestraSoloSiTraeVoz() {
        val lista = mutableListOf<Pair<FloatArray, Int>>()
        HablanteMath.agregarMuestra(json, lista)
        HablanteMath.agregarMuestra("""{"spk":[1.0],"spk_frames":0}""", lista)
        HablanteMath.agregarMuestra("""{"text":"x"}""", lista)
        assertEquals(1, lista.size)
    }

    @Test fun julioNoSeCortaASiMismo() {
        assertFalse("espera" in ReconocimientoUtil.PALABRAS_FUERTES)
        assertTrue("respira" in ReconocimientoUtil.SUMIDEROS && "espera" in ReconocimientoUtil.SUMIDEROS)
        assertTrue(HuevosDePascua.INTROS.none { it.lowercase().contains("respira") || it.lowercase().contains("espera") })
    }
}
