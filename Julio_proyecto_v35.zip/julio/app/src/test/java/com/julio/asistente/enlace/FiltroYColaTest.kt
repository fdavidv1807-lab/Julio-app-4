package com.julio.asistente.enlace

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FiltroYColaTest {
    private fun n(paquete: String = "com.whatsapp", titulo: String = "Ana", texto: String = "Hola", cat: String? = "msg",
                  curso: Boolean = false, grupo: Boolean = false) = NotificacionCruda(paquete, titulo, texto, cat, curso, grupo)

    private fun motivo(x: NotificacionCruda, silenciadas: Set<String> = emptySet()) =
        FiltroAvisos.motivoDescarte(x, "com.julio.asistente", silenciadas)

    @Test fun reenviaUnMensajeNormal() = assertNull(motivo(n()))

    @Test fun descartaLoQueNoEsUnAviso() {
        assertNotNull(motivo(n(paquete = "com.julio.asistente")))
        assertNotNull(motivo(n(paquete = "android")))
        assertNotNull(motivo(n(curso = true)))
        assertNotNull(motivo(n(grupo = true)))
        assertNotNull(motivo(n(cat = "transport")))
        assertNotNull(motivo(n(cat = "progress")))
        assertNotNull(motivo(n(titulo = " ", texto = "")))
        assertNotNull(motivo(n(), setOf("com.whatsapp")))
    }

    @Test fun deduplicaDentroDeLaVentana() {
        val d = Deduplicador(ventanaMs = 30_000L)
        assertFalse(d.repetido("a", "t", "x", 0L))
        assertTrue(d.repetido("a", "t", "x", 10_000L))
        assertFalse(d.repetido("a", "t", "otro", 10_000L))
        assertFalse(d.repetido("a", "t", "x", 40_000L)) // ya pasó la ventana
    }

    private fun av(id: String) = Aviso(id, 0L, "App", "p", "t", "x")

    @Test fun laColaEntregaEnOrdenYSeVacia() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 1000L)
        assertTrue(c.agregar(av("1"), 0L))
        assertTrue(c.agregar(av("2"), 0L))
        assertEquals("1", c.siguiente(0L)?.aviso?.id)
        assertEquals("2", c.siguiente(0L)?.aviso?.id)
        assertNull(c.siguiente(0L))
    }

    @Test fun laColaNoRepiteIds() {
        val c = ColaAvisos()
        assertTrue(c.agregar(av("1"), 0L))
        assertFalse(c.agregar(av("1"), 1L))
        assertEquals(1, c.tamano(1L))
    }

    @Test fun laColaTiraLoViejoCuandoSeLlenaYLoCuenta() {
        val c = ColaAvisos(capacidad = 3, vidaMs = 10_000L)
        for (i in 1..5) c.agregar(av("$i"), 0L)
        assertEquals(3, c.tamano(0L))
        assertEquals("3", c.siguiente(0L)?.aviso?.id)
        assertEquals(2, c.tomarPerdidos())
        assertEquals(0, c.tomarPerdidos())
    }

    @Test fun laColaCaducaLoViejo() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 1000L)
        c.agregar(av("1"), 0L)
        c.agregar(av("2"), 900L)
        assertEquals("2", c.siguiente(1500L)?.aviso?.id)
        assertNull(c.siguiente(1500L))
    }

    @Test fun devolverPoneElAvisoAlFrente() {
        val c = ColaAvisos()
        c.agregar(av("1"), 0L)
        c.agregar(av("2"), 0L)
        val e = c.siguiente(0L)!!
        c.devolver(e)
        assertEquals("1", c.siguiente(0L)?.aviso?.id)
    }
}
