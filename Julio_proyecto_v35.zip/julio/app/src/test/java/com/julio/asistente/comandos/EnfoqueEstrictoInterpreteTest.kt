package com.julio.asistente.comandos

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class EnfoqueEstrictoInterpreteTest {
    private val hoy = LocalDate.of(2026, 11, 1)
    private val ahora = LocalTime.of(9, 0)
    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun enfoqueEstrictoDe45Minutos() =
        assertEquals(Intencion.IniciarEnfoque(45, true), i("Inicia un enfoque estricto de 45 minutos"))

    @Test fun elEnfoqueNormalSigueIgual() {
        assertEquals(Intencion.IniciarEnfoque(35, false), i("Inicia una sesión de enfoque de 35 minutos"))
        assertEquals(Intencion.IniciarEnfoque(80), i("Quiero estudiar durante una hora y veinte minutos"))
    }
}
