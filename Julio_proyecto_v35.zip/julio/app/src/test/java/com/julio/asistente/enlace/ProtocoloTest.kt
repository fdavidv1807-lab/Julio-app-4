package com.julio.asistente.enlace

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.IOException

class ProtocoloTest {
    private val secreto = ByteArray(10) { (it * 7 + 1).toByte() }
    private val clave = Protocolo.claveDe(secreto)
    private val aviso = Aviso("abc-123", 1_000_000L, "WhatsApp", "com.whatsapp", "Ana", "¿Vamos a comer? ñandú", TipoAviso.NORMAL)

    @Test fun idaYVueltaConservaTodo() {
        val trama = Protocolo.codificar(aviso, clave)
        assertEquals(aviso, Protocolo.decodificar(trama, clave))
    }

    @Test fun laTramaNoLlevaElTextoEnClaro() {
        val trama = Protocolo.codificar(aviso, clave)
        assertFalse(String(trama, Charsets.ISO_8859_1).contains("Vamos"))
    }

    @Test fun conOtraClaveSeRechaza() {
        val trama = Protocolo.codificar(aviso, clave)
        val otra = Protocolo.claveDe(ByteArray(10) { 9 })
        assertNull(Protocolo.decodificar(trama, otra))
    }

    @Test fun siSeAlteraUnByteSeRechaza() {
        val trama = Protocolo.codificar(aviso, clave)
        for (i in listOf(0, 2, 10, trama.size / 2, trama.size - 1)) {
            val mala = trama.copyOf()
            mala[i] = (mala[i].toInt() xor 1).toByte()
            assertNull("byte $i", Protocolo.decodificar(mala, clave))
        }
    }

    @Test fun dosEnviosDelMismoAvisoNoSonIguales() {
        assertFalse(Protocolo.codificar(aviso, clave).contentEquals(Protocolo.codificar(aviso, clave)))
    }

    @Test fun leerTramaLeeLaTramaCompletaYRechazaBasura() {
        val trama = Protocolo.codificar(aviso, clave)
        assertArrayEquals(trama, Protocolo.leerTrama(ByteArrayInputStream(trama + byteArrayOf(1, 2, 3))))
        try {
            Protocolo.leerTrama(ByteArrayInputStream("GET / HTTP/1.1\r\n\r\n".toByteArray()))
            throw AssertionError("debía fallar")
        } catch (e: IOException) { /* bien */ }
    }

    @Test fun elIdPublicoNoCambiaYTiene6Caracteres() {
        assertEquals(6, Protocolo.idPublico(secreto).length)
        assertEquals(Protocolo.idPublico(secreto), Protocolo.idPublico(secreto.copyOf()))
        assertNotEquals(Protocolo.idPublico(secreto), Protocolo.idPublico(ByteArray(10)))
    }

    @Test fun elVerificadorRechazaHoraYRepetidos() {
        val v = Verificador(ventanaMs = 600_000L)
        assertEquals(Protocolo.ACK_OK, v.revisar(aviso, aviso.tiempo + 1000L))
        assertEquals(Protocolo.ACK_REPETIDO, v.revisar(aviso, aviso.tiempo + 2000L))
        assertEquals(Protocolo.ACK_HORA, v.revisar(aviso.copy(id = "otro"), aviso.tiempo + 700_000L))
        assertEquals(Protocolo.ACK_HORA, v.revisar(aviso.copy(id = "otro2"), aviso.tiempo - 700_000L))
    }

    @Test fun elCodigoDeEmparejamientoIdaYVuelta() {
        val f = CodigoEmparejamiento.formatear(secreto)
        assertEquals(19, f.length) // 16 + 3 guiones
        assertArrayEquals(secreto, CodigoEmparejamiento.leer(f))
        assertArrayEquals(secreto, CodigoEmparejamiento.leer(f.lowercase().replace("-", " ")))
    }

    @Test fun elCodigoToleraConfusionesYRechazaErrores() {
        val f = CodigoEmparejamiento.formatear(ByteArray(10)) // 0000-0000-0000-0000
        assertArrayEquals(ByteArray(10), CodigoEmparejamiento.leer(f.replace('0', 'O')))
        assertNull(CodigoEmparejamiento.leer("1234"))
        assertNull(CodigoEmparejamiento.leer("UUUU-UUUU-UUUU-UUUU")) // la U no existe en el alfabeto
    }

    @Test fun losSecretosNuevosSonDistintosYValidos() {
        val a = CodigoEmparejamiento.nuevoSecreto()
        val b = CodigoEmparejamiento.nuevoSecreto()
        assertEquals(10, a.size)
        assertFalse(a.contentEquals(b))
        assertNotNull(CodigoEmparejamiento.leer(CodigoEmparejamiento.formatear(a)))
        assertTrue(CodigoEmparejamiento.formatear(a).matches(Regex("[0-9A-Z]{4}(-[0-9A-Z]{4}){3}")))
    }
}
