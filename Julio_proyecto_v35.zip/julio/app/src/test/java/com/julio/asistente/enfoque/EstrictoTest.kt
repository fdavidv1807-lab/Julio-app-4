package com.julio.asistente.enfoque

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class EstrictoTest {
    @Test fun duracionDeUnMinutoATresHoras() {
        assertTrue(Estricto.duracionValida(1))
        assertTrue(Estricto.duracionValida(180))
        assertFalse(Estricto.duracionValida(0))
        assertFalse(Estricto.duracionValida(181))
    }

    @Test fun enEstrictoTambienSeBloqueanAjustesYTiendas() {
        val elegidas = setOf("com.tiktok", "com.instagram")
        assertEquals(elegidas, Estricto.bloqueadas(elegidas, false))
        val estricto = Estricto.bloqueadas(elegidas, true)
        assertTrue("com.android.settings" in estricto && "com.android.vending" in estricto && "com.tiktok" in estricto)
    }

    @Test fun enEstrictoAjustesDejaDeEstarProtegidoPeroLlamadasSiguenLibres() {
        val base = setOf("com.julio.asistente", "com.android.settings", "com.android.dialer", "com.android.emergency")
        assertEquals(base, Estricto.protegidas(base, false))
        val estricto = Estricto.protegidas(base, true)
        assertFalse("com.android.settings" in estricto)
        assertTrue("com.julio.asistente" in estricto && "com.android.dialer" in estricto && "com.android.emergency" in estricto)
    }

    @Test fun laEsperaParaSalirEsDeDiezMinutos() {
        assertEquals(10 * 60_000L, Estricto.esperaRestanteMs(0L, 5_000L))
        assertEquals(9 * 60_000L, Estricto.esperaRestanteMs(1_000L, 61_000L))
        assertEquals(0L, Estricto.esperaRestanteMs(1_000L, 1_000L + 10 * 60_000L))
        assertEquals(0L, Estricto.esperaRestanteMs(1_000L, 99_999_999L))
    }

    @Test fun laFraseSeAceptaIgualConOSinMayusculasYEspaciosRaros() {
        assertTrue(Estricto.fraseCorrecta(Estricto.FRASE))
        assertTrue(Estricto.fraseCorrecta("  " + Estricto.FRASE.uppercase().replace(" ", "  ") + " "))
        assertFalse(Estricto.fraseCorrecta(Estricto.FRASE.dropLast(5)))
        assertFalse(Estricto.fraseCorrecta(""))
    }

    @Test fun laPalabraFinal() {
        assertTrue(Estricto.palabraFinalCorrecta("me rindo"))
        assertTrue(Estricto.palabraFinalCorrecta(" ME  RINDO "))
        assertFalse(Estricto.palabraFinalCorrecta("no me rindo"))
    }

    @Test fun pegarTextoLargoSeDetectaPeroEscribirPalabrasNo() {
        assertTrue(Estricto.pegado("", Estricto.FRASE))
        assertTrue(Estricto.pegado("Elijo", "Elijo rendirme y dejar mi enfoque"))
        assertFalse(Estricto.pegado("Elijo ", "Elijo rendirme"))
        assertFalse(Estricto.pegado("abc", "abcd"))
        assertFalse(Estricto.pegado("abcd", "abc"))
    }

    @Test fun lasCuentasTienenRespuestaYSeRevisan() {
        val ps = Estricto.problemas(Random(1))
        assertEquals(6, ps.size)
        for (p in ps) {
            assertTrue(Estricto.respuestaCorrecta(p, p.respuesta.toString()))
            assertTrue(Estricto.respuestaCorrecta(p, " ${p.respuesta} "))
            assertFalse(Estricto.respuestaCorrecta(p, (p.respuesta + 1).toString()))
            assertFalse(Estricto.respuestaCorrecta(p, ""))
            val partes = p.texto.split(" × ")
            val a = partes[0].toInt()
            val resto = partes[1].split(" + ")
            val esperado = a * resto[0].toInt() + (if (resto.size > 1) resto[1].toInt() else 0)
            assertEquals(esperado, p.respuesta)
        }
    }
}
