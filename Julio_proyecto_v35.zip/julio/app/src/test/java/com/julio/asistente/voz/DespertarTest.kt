package com.julio.asistente.voz

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DespertarTest {
    @Test fun reconocePalabraEntera() {
        assertTrue(ReconocimientoUtil.esDespertar("julio"))
        assertTrue(ReconocimientoUtil.esDespertar("Hola Julio"))
        assertTrue(ReconocimientoUtil.esDespertar("julio, ¿qué hora es?"))
    }

    @Test fun noSeActivaConOtrasPalabras() {
        assertFalse(ReconocimientoUtil.esDespertar(""))
        assertFalse(ReconocimientoUtil.esDespertar("[unk]"))
        assertFalse(ReconocimientoUtil.esDespertar("julia"))
        assertFalse(ReconocimientoUtil.esDespertar("julios"))
    }

    @Test fun quitaElVocativoDelPrincipio() {
        assertEquals("dime la hora", ReconocimientoUtil.quitarVocativo("julio dime la hora"))
        assertEquals("", ReconocimientoUtil.quitarVocativo("julio"))
        assertEquals("qué hora es", ReconocimientoUtil.quitarVocativo("julio julio qué hora es"))
        assertEquals("pon una alarma", ReconocimientoUtil.quitarVocativo("pon una alarma"))
        assertEquals("avisa a julio mañana", ReconocimientoUtil.quitarVocativo("avisa a julio mañana"))
    }
}
