package com.julio.asistente.comandos

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppsTest {
    private val whatsapp = AppInfo("WhatsApp", "com.whatsapp")
    private val spotify = AppInfo("Spotify", "com.spotify.music")
    private val youtube = AppInfo("YouTube", "com.google.android.youtube")
    private val youtubeMusic = AppInfo("YouTube Music", "com.google.android.apps.youtube.music")
    private val chrome = AppInfo("Chrome", "com.android.chrome")
    private val calculadora = AppInfo("Calculadora", "com.sec.android.app.popupcalculator")
    private val bancolombia = AppInfo("Bancolombia", "com.todo1.mobile")
    private val nequi = AppInfo("Nequi", "com.nequi.MobileApp")
    private val samsungPay = AppInfo("Samsung Pay", "com.samsung.android.spay")
    private val maps = AppInfo("Google Maps", "com.google.android.apps.maps")
    private val fotos = AppInfo("Google Fotos", "com.google.android.apps.photos")
    private val drive = AppInfo("Google Drive", "com.google.android.apps.docs")
    private val todas = listOf(whatsapp, spotify, youtube, youtubeMusic, chrome, calculadora, bancolombia, nequi, samsungPay, maps, fotos, drive)

    @Test fun encuentraPorNombreExacto() {
        assertEquals(BusquedaApp.Una(whatsapp), Apps.buscar("whatsapp", todas))
        assertEquals(BusquedaApp.Una(spotify), Apps.buscar("Spotify", todas))
        assertEquals(BusquedaApp.Una(youtube), Apps.buscar("youtube", todas))
        assertEquals(BusquedaApp.Una(youtubeMusic), Apps.buscar("youtube music", todas))
        assertEquals(BusquedaApp.Una(calculadora), Apps.buscar("calculadora", todas))
    }

    @Test fun entiendeComoSuenaEnEspanol() {
        assertEquals(BusquedaApp.Una(whatsapp), Apps.buscar("guasap", todas))
    }

    @Test fun preguntaSiHayVarias() {
        val r = Apps.buscar("google", todas)
        assertTrue(r is BusquedaApp.Varias)
        assertEquals(3, (r as BusquedaApp.Varias).apps.size)
    }

    @Test fun noAbreBancosNiPagos() {
        assertEquals(BusquedaApp.Bloqueada(bancolombia), Apps.buscar("bancolombia", todas))
        assertEquals(BusquedaApp.Bloqueada(nequi), Apps.buscar("nequi", todas))
        assertEquals(BusquedaApp.Bloqueada(samsungPay), Apps.buscar("pay", todas))
    }

    @Test fun lasAppsNormalesNoSeBloquean() {
        listOf(whatsapp, spotify, youtube, youtubeMusic, chrome, calculadora, maps, fotos, drive)
            .forEach { assertFalse(it.nombre, Apps.esSensible(it)) }
    }

    @Test fun sinCoincidenciaDiceNinguna() {
        assertEquals(BusquedaApp.Ninguna, Apps.buscar("tiktok", todas))
        assertEquals(BusquedaApp.Ninguna, Apps.buscar("", todas))
    }
}
