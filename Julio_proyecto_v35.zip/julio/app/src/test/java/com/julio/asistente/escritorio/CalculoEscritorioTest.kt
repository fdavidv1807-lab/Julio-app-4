package com.julio.asistente.escritorio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculoEscritorioTest {
    @Test fun brilloDeNocheEsMasBajoQueDeDia() {
        assertEquals(CalculoEscritorio.BRILLO_NOCHE, CalculoEscritorio.brilloPorHora(23))
        assertEquals(CalculoEscritorio.BRILLO_NOCHE, CalculoEscritorio.brilloPorHora(3))
        assertEquals(CalculoEscritorio.BRILLO_DIA, CalculoEscritorio.brilloPorHora(7))
        assertEquals(CalculoEscritorio.BRILLO_DIA, CalculoEscritorio.brilloPorHora(21))
        assertTrue(CalculoEscritorio.BRILLO_NOCHE < CalculoEscritorio.BRILLO_DIA)
    }

    @Test fun elDesplazamientoCambiaCadaPeriodoYSeRepite() {
        val a = CalculoEscritorio.desplazamiento(0)
        val b = CalculoEscritorio.desplazamiento(CalculoEscritorio.PERIODO_MIN)
        assertTrue(a != b)
        assertEquals(a, CalculoEscritorio.desplazamiento(CalculoEscritorio.PERIODO_MIN - 1))
        assertEquals(a, CalculoEscritorio.desplazamiento(CalculoEscritorio.PERIODO_MIN * 5))
    }
}
