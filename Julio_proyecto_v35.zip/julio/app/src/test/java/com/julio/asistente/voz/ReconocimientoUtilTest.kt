package com.julio.asistente.voz

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ReconocimientoUtilTest {
    @Test
    fun sacaElTextoFinalDeVosk() {
        val json = "{\n  \"text\" : \"agrega una clase de anatomia el lunes a las siete\"\n}"
        assertEquals("agrega una clase de anatomia el lunes a las siete", ReconocimientoUtil.extraer(json, "text"))
    }

    @Test
    fun sacaElTextoParcial() {
        val json = "{\n  \"partial\" : \"que tengo pendiente\"\n}"
        assertEquals("que tengo pendiente", ReconocimientoUtil.extraer(json, "partial"))
        assertEquals("", ReconocimientoUtil.extraer(json, "text"))
    }

    @Test
    fun respuestasVaciasDanTextoVacio() {
        assertEquals("", ReconocimientoUtil.extraer("{\"text\" : \"\"}", "text"))
        assertEquals("", ReconocimientoUtil.extraer("{\"partial\" : \"\"}", "partial"))
        assertEquals("", ReconocimientoUtil.extraer("", "text"))
        assertEquals("", ReconocimientoUtil.extraer("no es json", "text"))
    }

    @Test
    fun entiendeAcentosYEscapes() {
        assertEquals("qué día es", ReconocimientoUtil.extraer("{\"text\" : \"qué día es\"}", "text"))
        assertEquals("mañana", ReconocimientoUtil.extraer("{\"text\" : \"ma\\u00f1ana\"}", "text"))
        assertEquals("di \"hola\"", ReconocimientoUtil.extraer("{\"text\" : \"di \\\"hola\\\"\"}", "text"))
    }

    @Test
    fun elNivelDelSilencioEsCeroYElDeUnaVozFuerteEsAlto() {
        val silencio = ShortArray(1600)
        assertEquals(0f, ReconocimientoUtil.nivel(silencio, silencio.size), 0.0001f)
        val fuerte = ShortArray(1600) { if (it % 2 == 0) 20000 else -20000 }
        assertTrue(ReconocimientoUtil.nivel(fuerte, fuerte.size) > 0.9f)
        assertEquals(0f, ReconocimientoUtil.nivel(silencio, 0), 0.0001f)
    }

    @Test
    fun interrumpeConPalabrasFuertesYConDosNoSeguidos() {
        assertTrue(ReconocimientoUtil.hayInterrupcion("basta", false))
        assertTrue(ReconocimientoUtil.hayInterrupcion("silencio", false))
        assertTrue(ReconocimientoUtil.hayInterrupcion("Cállate", false))
        assertTrue(ReconocimientoUtil.hayInterrupcion("no no", false))
        assertTrue(ReconocimientoUtil.hayInterrupcion("no no no", true))
        assertTrue(ReconocimientoUtil.hayInterrupcion("para", true))
        // Un solo «no», «no» separado por otra cosa y «para» a medias NO interrumpen.
        assertFalse(ReconocimientoUtil.hayInterrupcion("no", false))
        // «Respira» y «espera» suenan casi igual: ninguna de las dos corta a Julio (así se cortaba a sí mismo).
        assertFalse(ReconocimientoUtil.hayInterrupcion("respira", false))
        assertFalse(ReconocimientoUtil.hayInterrupcion("espera", true))
        assertFalse(ReconocimientoUtil.hayInterrupcion("respira y escucha", true))
        assertFalse(ReconocimientoUtil.hayInterrupcion("no [unk] no", false))
        assertFalse(ReconocimientoUtil.hayInterrupcion("para", false))
        assertFalse(ReconocimientoUtil.hayInterrupcion("", true))
    }

    @Test
    fun noDejaDescomprimirFueraDeLaCarpeta() {
        val raiz = File("/tmp/julio_prueba_raiz")
        assertTrue(ReconocimientoUtil.esRutaSegura(raiz, File(raiz, "modelo/am/final.mdl")))
        assertFalse(ReconocimientoUtil.esRutaSegura(raiz, File(raiz, "../fuera.txt")))
        assertFalse(ReconocimientoUtil.esRutaSegura(raiz, File("/tmp/julio_prueba_raiz_otro/x")))
    }
}
