import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URI

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// --- Voz neuronal (Piper) con sherpa-onnx ---
// El motor se baja al compilar. Si no hay red o falla la descarga, la app se compila igual SIN voz neuronal
// (Julio avisa y usa la voz del teléfono).
val sherpaVersion = "1.13.7"
val sherpaAar = layout.projectDirectory.file("libs/sherpa-onnx-$sherpaVersion.aar").asFile
if (!sherpaAar.exists() || sherpaAar.length() < 1_000_000L) {
    try {
        sherpaAar.parentFile.mkdirs()
        val direccion = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v$sherpaVersion/sherpa-onnx-$sherpaVersion.aar"
        val conexion = URI(direccion).toURL().openConnection() as HttpURLConnection
        conexion.instanceFollowRedirects = true
        conexion.connectTimeout = 30_000
        conexion.readTimeout = 120_000
        conexion.inputStream.use { entrada: InputStream ->
            sherpaAar.outputStream().use { salida: OutputStream -> entrada.copyTo(salida) }
        }
    } catch (e: Exception) {
        logger.warn("Julio: no se pudo descargar sherpa-onnx ($e). Se compila sin voz neuronal.")
        sherpaAar.delete()
    }
}

android {
    namespace = "com.julio.asistente"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.julio.asistente"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        // Solo las arquitecturas de teléfonos reales (reduce el tamaño del APK).
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // La firma de release se configura en la Etapa 9 (keystore propio, nunca en el repositorio).
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.kotlinx.coroutines.android)

    // Para descomprimir la voz (.tar.bz2) descargada
    implementation("org.apache.commons:commons-compress:1.27.1")
    // Motor de voz neuronal (solo si se pudo descargar)
    if (sherpaAar.exists() && sherpaAar.length() > 1_000_000L) {
        implementation(files(sherpaAar))
    }

    testImplementation(libs.junit)
}
