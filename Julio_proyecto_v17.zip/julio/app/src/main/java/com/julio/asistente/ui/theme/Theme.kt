package com.julio.asistente.ui.theme

import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Estilo «cabina»: siempre oscuro, con neón cian/azul y paneles de esquinas cortadas. */
private val EsquemaCabina = darkColorScheme(
    primary = NeonCian,
    onPrimary = AzulProfundo,
    primaryContainer = Color(0xFF0B3A5C),
    onPrimaryContainer = Color(0xFFCFF6FF),
    secondary = AzulClaro,
    onSecondary = AzulProfundo,
    secondaryContainer = Color(0xFF123A6B),
    onSecondaryContainer = Color(0xFFDCEBFF),
    tertiary = Color(0xFFFFC857),
    background = AzulProfundo,
    onBackground = Color(0xFFE6F1F8),
    surface = SuperficieOscura,
    onSurface = Color(0xFFE6F1F8),
    surfaceVariant = Color(0xFF0E2140),
    onSurfaceVariant = Color(0xFFBBD3E4),
    surfaceContainerLowest = Color(0xFF040A18),
    surfaceContainerLow = Color(0xFF07122A),
    surfaceContainer = Color(0xFF0A1830),
    surfaceContainerHigh = Color(0xFF0C1D3A),
    surfaceContainerHighest = Color(0xFF102548),
    outline = Color(0xFF5B9BC2),
    outlineVariant = Color(0xFF173B57),
    error = Color(0xFFFF6B7A),
    errorContainer = Color(0xFF5A1A24),
    onErrorContainer = Color(0xFFFFD9DD),
)

private val FormasCabina = Shapes(
    extraSmall = CutCornerShape(4.dp),
    small = CutCornerShape(8.dp),
    medium = CutCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 0.dp, bottomStart = 16.dp),
    large = CutCornerShape(topStart = 0.dp, topEnd = 20.dp, bottomEnd = 0.dp, bottomStart = 20.dp),
    extraLarge = CutCornerShape(topStart = 0.dp, topEnd = 24.dp, bottomEnd = 0.dp, bottomStart = 24.dp),
)

private val TipografiaBase = Typography()
private val TipografiaCabina = TipografiaBase.copy(
    titleLarge = TipografiaBase.titleLarge.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp),
    titleMedium = TipografiaBase.titleMedium.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp),
    titleSmall = TipografiaBase.titleSmall.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp),
    labelLarge = TipografiaBase.labelLarge.copy(letterSpacing = 0.8.sp),
    labelMedium = TipografiaBase.labelMedium.copy(letterSpacing = 0.8.sp),
    labelSmall = TipografiaBase.labelSmall.copy(letterSpacing = 0.6.sp),
)

@Composable
fun JulioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = EsquemaCabina,
        shapes = FormasCabina,
        typography = TipografiaCabina,
    ) {
        // Origen del texto negro: fuera de una Surface, el color de texto por defecto es NEGRO.
        // Aquí se fija en claro para toda la app, así ningún Text sin color explícito vuelve a quedar ilegible.
        CompositionLocalProvider(LocalContentColor provides EsquemaCabina.onBackground) {
            content()
        }
    }
}
