package com.julio.asistente.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.julio.asistente.R
import com.julio.asistente.ui.theme.AzulClaro
import com.julio.asistente.ui.theme.NeonAzul
import com.julio.asistente.ui.theme.NeonCian
import com.julio.asistente.voz.EstadoVoz
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

private val DOS_PI = (2.0 * PI).toFloat()

/** Partículas que orbitan alrededor del gorila como una esfera (posiciones fijas, se calculan por cuadro). */
private class Particulas(val n: Int) {
    val lon0 = FloatArray(n)
    val lat = FloatArray(n)
    val radio = FloatArray(n)
    val mult = IntArray(n)
    val tam = FloatArray(n)
    val x = FloatArray(n)
    val y = FloatArray(n)
    val z = FloatArray(n)

    init {
        val r = Random(7)
        for (i in 0 until n) {
            lon0[i] = r.nextFloat() * DOS_PI
            lat[i] = (r.nextFloat() - 0.5f) * 2.5f
            radio[i] = 0.82f + 0.18f * r.nextFloat()
            mult[i] = if (i % 3 == 0) 1 else 2
            tam[i] = 0.6f + 0.9f * r.nextFloat()
        }
    }
}

/**
 * Julio como holograma: el gorila «proyectado» sobre una plataforma, con anillos que giran en 3D,
 * partículas orbitando y un ecualizador alrededor de la base.
 *  - Reposo: respira muy despacio.
 *  - Escuchando: inclina la cabeza hacia ti; partículas y barras reaccionan al nivel de tu voz.
 *  - Procesando: los anillos giran rápido y los ojos brillan.
 *  - Respondiendo: la quijada se abre al ritmo de cada palabra y todo late con su voz.
 * El movimiento de la boca sigue el ritmo de las palabras que reporta el motor de voz;
 * no es sincronía exacta de labios.
 */
@Composable
fun Orbe(
    estado: EstadoVoz,
    nivel: Float,
    palabras: Int,
    modifier: Modifier = Modifier,
    colorPorEstado: Boolean = true,
) {
    // Cian al escuchar y en reposo, azul lavanda al pensar, dorado al responder (cambia suave, no de golpe).
    val colorObjetivo = if (!colorPorEstado) NeonCian else when (estado) {
        EstadoVoz.PROCESANDO -> Color(0xFF9FB4FF)
        EstadoVoz.RESPONDIENDO -> Color(0xFFFFC857)
        else -> NeonCian
    }
    val acento by animateColorAsState(colorObjetivo, tween(450), label = "acento")
    val gorila: ImageBitmap = ImageBitmap.imageResource(R.drawable.julio_orbe)
    val particulas = remember { Particulas(64) }

    val transicion = rememberInfiniteTransition(label = "holograma")
    val fase by transicion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "fase",
    )
    val inclinacion by animateFloatAsState(
        targetValue = if (estado == EstadoVoz.ESCUCHANDO) -4f else 0f,
        animationSpec = tween(500),
        label = "inclinacion",
    )

    // Un impulso por cada palabra que el motor de voz empieza a decir.
    val impulso = remember { Animatable(0f) }
    LaunchedEffect(palabras) {
        if (estado == EstadoVoz.RESPONDIENDO && palabras > 0) {
            impulso.snapTo(1f)
            impulso.animateTo(0f, tween(200))
        }
    }

    // Velocidades enteras: el bucle de 6 s se repite sin saltos.
    val velocidad = when (estado) {
        EstadoVoz.REPOSO -> 1
        EstadoVoz.ESCUCHANDO -> 2
        EstadoVoz.RESPONDIENDO -> 2
        EstadoVoz.PROCESANDO -> 6
    }

    Canvas(modifier.aspectRatio(1f)) {
        val lado = size.minDimension
        val c = Offset(size.width / 2f, lado * 0.48f)
        val f = fase
        val habla = estado == EstadoVoz.RESPONDIENDO
        val vaiven = if (habla) 0.35f * abs(sin(f * DOS_PI * 12f)) else 0f
        val apertura = if (habla) max(impulso.value, vaiven) else 0f
        val energia = when (estado) {
            EstadoVoz.REPOSO -> 0.06f
            EstadoVoz.ESCUCHANDO -> 0.15f + 0.85f * nivel
            EstadoVoz.PROCESANDO -> 0.45f
            EstadoVoz.RESPONDIENDO -> 0.2f + 0.8f * apertura
        }
        val intensidad = if (estado == EstadoVoz.REPOSO) 0.6f else 1f
        val respiracion = 1f + 0.012f * sin(f * DOS_PI)

        // ---- resplandor de fondo y haz de proyección ----
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(NeonAzul.copy(alpha = (0.30f + 0.25f * energia) * intensidad), Color.Transparent),
                center = Offset(c.x, lado * 0.46f), radius = lado * 0.52f,
            ),
            radius = lado * 0.52f, center = Offset(c.x, lado * 0.46f),
        )
        val yPlataforma = lado * 0.87f
        val haz = Path().apply {
            moveTo(c.x - lado * 0.30f, yPlataforma)
            lineTo(c.x + lado * 0.30f, yPlataforma)
            lineTo(c.x + lado * 0.20f, lado * 0.30f)
            lineTo(c.x - lado * 0.20f, lado * 0.30f)
            close()
        }
        drawPath(
            haz,
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, acento.copy(alpha = 0.13f * intensidad)),
                startY = lado * 0.30f, endY = yPlataforma,
            ),
        )

        // ---- anillos 3D y partículas: mitad de atrás (detrás del gorila) ----
        fun anillo(r: Float, incl: Float, plano: Float, giro: Float, alfa: Float, grosor: Float, frente: Boolean) {
            val n = 72
            val ci = cos(incl); val si = sin(incl)
            val cp = cos(plano); val sp = sin(plano)
            var px = 0f; var py = 0f; var pz = 0f
            for (i in 0..n) {
                val fi = giro + DOS_PI * i / n
                val x0 = r * cos(fi)
                val y0 = r * sin(fi) * ci
                val z0 = r * sin(fi) * si
                val x = c.x + x0 * cp - y0 * sp
                val y = c.y + x0 * sp + y0 * cp
                if (i > 0 && ((z0 + pz) >= 0f) == frente) {
                    val prof = ((z0 + pz) / (2f * r) + 1f) / 2f
                    drawLine(
                        color = acento.copy(alpha = (alfa * intensidad * (0.3f + 0.7f * prof)).coerceIn(0f, 1f)),
                        start = Offset(px, py), end = Offset(x, y),
                        strokeWidth = grosor, cap = StrokeCap.Round,
                    )
                }
                px = x; py = y; pz = z0
            }
        }
        val giroA = f * DOS_PI * velocidad
        val incA = 1.15f + 0.25f * sin(f * DOS_PI)
        val incB = 0.55f + 0.30f * sin(f * DOS_PI * 2f)
        val incC = 1.45f + 0.15f * sin(f * DOS_PI)
        val rA = lado * 0.43f; val rB = lado * 0.39f; val rC = lado * 0.46f
        val g = lado * 0.0045f
        anillo(rA, incA, 0.4f, giroA, 0.95f, g * 1.4f, false)
        anillo(rB, incB, -0.9f, -giroA * 1.3f, 0.8f, g * 1.2f, false)
        anillo(rC, incC, 2.2f, giroA * 0.7f, 0.65f, g, false)

        // posiciones de las partículas
        val contraccion = when (estado) {
            EstadoVoz.ESCUCHANDO -> 1f - 0.16f * nivel
            EstadoVoz.RESPONDIENDO -> 1f + 0.10f * apertura
            else -> 1f
        }
        val giroP = if (estado == EstadoVoz.PROCESANDO) 3 else 1
        for (i in 0 until particulas.n) {
            val lon = particulas.lon0[i] + f * DOS_PI * particulas.mult[i] * giroP
            val rr = lado * 0.44f * particulas.radio[i] * contraccion
            val cl = cos(particulas.lat[i])
            particulas.x[i] = rr * cl * cos(lon)
            particulas.y[i] = rr * sin(particulas.lat[i]) * 0.95f
            particulas.z[i] = rr * cl * sin(lon)
        }
        fun dibujarParticulas(frente: Boolean) {
            for (i in 0 until particulas.n) {
                val z = particulas.z[i]
                if ((z >= 0f) != frente) continue
                val prof = (z / (lado * 0.44f) + 1f) / 2f
                drawCircle(
                    color = acento.copy(alpha = ((0.25f + 0.65f * prof) * intensidad).coerceIn(0f, 1f)),
                    radius = lado * 0.0045f * particulas.tam[i] * (0.7f + 0.6f * prof),
                    center = Offset(c.x + particulas.x[i], c.y + particulas.y[i]),
                )
            }
        }
        dibujarParticulas(false)

        // ---- plataforma de proyección y ondas ----
        val rx = lado * 0.34f
        val ry = lado * 0.055f
        for ((k, escala) in listOf(1f, 0.8f, 0.6f).withIndex()) {
            drawOval(
                color = acento.copy(alpha = (0.75f - 0.2f * k) * intensidad),
                topLeft = Offset(c.x - rx * escala, yPlataforma - ry * escala),
                size = Size(rx * 2f * escala, ry * 2f * escala),
                style = Stroke(width = lado * 0.0035f),
            )
        }
        if (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.RESPONDIENDO) {
            for (k in 0 until 3) {
                val p = ((f * velocidad + k / 3f) % 1f)
                val e = 1f + 0.35f * p
                drawOval(
                    color = acento.copy(alpha = (1f - p) * 0.35f * (0.4f + energia)),
                    topLeft = Offset(c.x - rx * e, yPlataforma - ry * e),
                    size = Size(rx * 2f * e, ry * 2f * e),
                    style = Stroke(width = lado * 0.003f),
                )
            }
        }
        // ecualizador alrededor de la base: barras que suben desde la plataforma
        val barras = 56
        for (i in 0 until barras) {
            val ang = DOS_PI * i / barras + f * DOS_PI * 0.5f * (if (velocidad >= 6) 2f else 1f)
            val osc = abs(sin(f * DOS_PI * velocidad + i * 0.55f))
            val alto = lado * 0.006f + lado * 0.085f * energia * (0.25f + 0.75f * osc)
            val bx = c.x + rx * 1.02f * cos(ang)
            val by = yPlataforma + ry * 1.02f * sin(ang)
            val delante = sin(ang) > 0f
            drawLine(
                color = acento.copy(alpha = (if (delante) 0.9f else 0.45f) * intensidad),
                start = Offset(bx, by), end = Offset(bx, by - alto),
                strokeWidth = lado * 0.0055f, cap = StrokeCap.Round,
            )
        }

        // ---- gorila holográfico (en su propia capa para poder desvanecer los bordes) ----
        val ancho = gorila.width
        val alto = gorila.height
        val corte = (ancho * 0.528f).roundToInt()     // borde superior de la boca
        val banda = (ancho * 0.30f).roundToInt()      // mandíbula y mentón: se estiran al hablar
        val k = 1f + 0.10f * apertura
        val escalaLatido = respiracion + 0.02f * apertura + (if (estado == EstadoVoz.ESCUCHANDO) 0.025f * nivel else 0f)
        val gw = lado * 0.58f * escalaLatido
        val factor = gw / ancho
        val gh = alto * factor
        val gx = c.x - gw / 2f
        val gy = lado * 0.115f - lado * 0.004f * apertura
        val brilloOjos = when (estado) {
            EstadoVoz.PROCESANDO -> 0.55f + 0.35f * sin(f * DOS_PI * 6f)
            EstadoVoz.ESCUCHANDO -> 0.25f
            else -> 0f
        }

        drawIntoCanvas { it.saveLayer(Rect(0f, 0f, size.width, size.height), Paint()) }
        withTransform({
            rotate(inclinacion, pivot = Offset(c.x, gy + gh))
            translate(gx, gy)
            scale(factor, factor, pivot = Offset.Zero)
        }) {
            // resto del cuerpo: sigue a la barbilla
            withTransform({ translate(0f, corte + banda * k) }) {
                drawImage(
                    image = gorila,
                    srcOffset = IntOffset(0, corte + banda),
                    srcSize = IntSize(ancho, alto - corte - banda),
                    dstOffset = IntOffset.Zero,
                    dstSize = IntSize(ancho, alto - corte - banda),
                    filterQuality = FilterQuality.High,
                )
            }
            // mandíbula: se estira
            withTransform({
                translate(0f, corte.toFloat())
                scale(1f, k, pivot = Offset.Zero)
            }) {
                drawImage(
                    image = gorila,
                    srcOffset = IntOffset(0, corte),
                    srcSize = IntSize(ancho, banda),
                    dstOffset = IntOffset.Zero,
                    dstSize = IntSize(ancho, banda),
                    filterQuality = FilterQuality.High,
                )
            }
            // cabeza (ojos y nariz): quieta
            drawImage(
                image = gorila,
                srcOffset = IntOffset.Zero,
                srcSize = IntSize(ancho, corte),
                dstOffset = IntOffset.Zero,
                dstSize = IntSize(ancho, corte),
                filterQuality = FilterQuality.High,
            )
            // ojos que brillan
            if (brilloOjos > 0f) {
                for (ojo in listOf(Offset(ancho * 0.426f, ancho * 0.375f), Offset(ancho * 0.567f, ancho * 0.373f))) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(acento.copy(alpha = brilloOjos), Color.Transparent),
                            center = ojo, radius = ancho * 0.07f,
                        ),
                        radius = ancho * 0.07f, center = ojo,
                    )
                }
            }
        }
        // bordes que se desvanecen (así el gorila «flota» sin recuadro)
        val centroViñeta = Offset(c.x, gy + gh * 0.42f)
        val radioViñeta = gw * 0.62f
        drawRect(
            brush = Brush.radialGradient(
                0f to Color.Transparent,
                0.74f to Color.Transparent,
                1f to Color.Black,
                center = centroViñeta, radius = radioViñeta,
            ),
            blendMode = BlendMode.DstOut,
        )
        // líneas de holograma
        val paso = lado * 0.011f
        var yl = gy
        while (yl < gy + gh) {
            drawRect(
                color = Color.Black.copy(alpha = 0.16f),
                topLeft = Offset(gx, yl), size = Size(gw, paso * 0.35f),
                blendMode = BlendMode.DstOut,
            )
            yl += paso
        }
        // tinte cian y barrido de luz (solo sobre lo que ya está dibujado)
        drawRect(color = acento.copy(alpha = 0.07f), blendMode = BlendMode.SrcAtop)
        val yBarrido = gy + gh * ((f * 2f) % 1f)
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, AzulClaro.copy(alpha = 0.22f), Color.Transparent),
                startY = yBarrido - gh * 0.08f, endY = yBarrido + gh * 0.08f,
            ),
            blendMode = BlendMode.SrcAtop,
        )
        drawIntoCanvas { it.restore() }

        // ---- mitad de adelante de anillos y partículas ----
        anillo(rA, incA, 0.4f, giroA, 0.55f, g * 1.4f, true)
        anillo(rB, incB, -0.9f, -giroA * 1.3f, 0.45f, g * 1.2f, true)
        anillo(rC, incC, 2.2f, giroA * 0.7f, 0.4f, g, true)
        dibujarParticulas(true)
    }
}
