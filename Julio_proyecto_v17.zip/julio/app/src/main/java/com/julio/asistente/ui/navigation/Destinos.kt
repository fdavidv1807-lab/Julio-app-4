package com.julio.asistente.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Timer
import androidx.compose.ui.graphics.vector.ImageVector

/** Secciones de la navegación principal. Las metas viven dentro de Voz (no son una sección). */
enum class Destino(val ruta: String, val titulo: String, val icono: ImageVector) {
    VOZ("voz", "Voz", Icons.Filled.Mic),
    HORARIO("horario", "Horario", Icons.Filled.CalendarMonth),
    TAREAS("tareas", "Tareas", Icons.Filled.Checklist),
    ESTUDIO("estudio", "Estudio", Icons.Filled.School),
    ALARMAS("alarmas", "Alarmas", Icons.Filled.Alarm),
    ENFOQUE("enfoque", "Enfoque", Icons.Filled.Timer),
}
