package com.julio.asistente.voz

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.comandos.Asistente
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class EstadoVoz { REPOSO, ESCUCHANDO, PROCESANDO, RESPONDIENDO }

data class Mensaje(val deUsuario: Boolean, val texto: String)

class VozViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _estado = MutableStateFlow(EstadoVoz.REPOSO)
    val estado: StateFlow<EstadoVoz> = _estado.asStateFlow()

    private val _transcripcion = MutableStateFlow("")
    val transcripcion: StateFlow<String> = _transcripcion.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _historial = MutableStateFlow<List<Mensaje>>(emptyList())
    /** Solo de esta sesión: se borra al cerrar la app (no se guarda en el teléfono). */
    val historial: StateFlow<List<Mensaje>> = _historial.asStateFlow()

    private val _nivel = MutableStateFlow(0f)
    val nivel: StateFlow<Float> = _nivel.asStateFlow()

    private val _hablarRespuestas = MutableStateFlow(true)
    val hablarRespuestas: StateFlow<Boolean> = _hablarRespuestas.asStateFlow()

    private val asistente = Asistente(app)
    private val habla = Habla(app)
    private val prefs = app.getSharedPreferences("julio_voz", android.content.Context.MODE_PRIVATE)

    // ----- Voz de Julio (selector, tono y velocidad) -----
    val ajustesVoz: StateFlow<AjustesVoz> = habla.ajustes
    fun vocesDisponibles(): List<VozInfo> = habla.voces()
    fun elegirVoz(nombre: String?) = habla.elegirVoz(nombre)
    fun cambiarTono(t: Float) = habla.cambiarTono(t)
    fun cambiarVelocidad(v: Float) = habla.cambiarVelocidad(v)
    fun probarVoz() {
        if (_estado.value == EstadoVoz.ESCUCHANDO || _estado.value == EstadoVoz.PROCESANDO) return
        _estado.value = EstadoVoz.RESPONDIENDO
        habla.hablar("Hola, soy Julio. Así sueno con esta voz. ¿En qué te ayudo?") { _estado.value = EstadoVoz.REPOSO }
    }

    // ----- Color del orbe según lo que hace -----
    private val _orbeColor = MutableStateFlow(prefs.getBoolean("orbeColor", true))
    val orbeColor: StateFlow<Boolean> = _orbeColor.asStateFlow()
    fun alternarOrbeColor() {
        _orbeColor.value = !_orbeColor.value
        prefs.edit().putBoolean("orbeColor", _orbeColor.value).apply()
    }

    // ----- Saludo al abrir -----
    private val _saludoActivo = MutableStateFlow(prefs.getBoolean("saludo", true))
    val saludoActivo: StateFlow<Boolean> = _saludoActivo.asStateFlow()
    fun alternarSaludo() {
        _saludoActivo.value = !_saludoActivo.value
        prefs.edit().putBoolean("saludo", _saludoActivo.value).apply()
    }

    init {
        viewModelScope.launch { saludarSiCorresponde() }
    }

    private suspend fun saludarSiCorresponde() {
        if (!_saludoActivo.value) return
        val ahora = System.currentTimeMillis()
        if (ahora - ultimoSaludo < 30 * 60_000L) return
        ultimoSaludo = ahora
        val texto = try { asistente.saludo() } catch (e: Exception) { return }
        _historial.value = (_historial.value + Mensaje(false, texto)).takeLast(40)
        if (_hablarRespuestas.value && habla.disponible) {
            _estado.value = EstadoVoz.RESPONDIENDO
            habla.hablar(texto) { if (_estado.value == EstadoVoz.RESPONDIENDO) _estado.value = EstadoVoz.REPOSO }
        }
    }

    companion object {
        /** Para no repetir el saludo cada vez que se recrea la pantalla: como mucho uno cada 30 minutos. */
        private var ultimoSaludo = 0L
    }
    /** Pulsos por palabra hablada (animación del gorila). */
    val palabras: StateFlow<Int> = habla.palabras
    private var reconocedor: SpeechRecognizer? = null
    private var cancelado = false

    fun alternarHablar() {
        _hablarRespuestas.value = !_hablarRespuestas.value
        if (!_hablarRespuestas.value) habla.detener()
    }

    fun permisoMicrofono(): Boolean =
        ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun reportarPermisoDenegado() {
        _error.value = "Sin el permiso del micrófono no puedo escucharte. Puedes activarlo en los ajustes de la app, " +
            "o escribirme los comandos abajo."
    }

    fun limpiarError() { _error.value = null }

    private fun obtenerReconocedor(): SpeechRecognizer? {
        reconocedor?.let { return it }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            _error.value = "Este teléfono no tiene un servicio de reconocimiento de voz disponible. " +
                "Instala o activa «Servicios de voz de Google», o escríbeme los comandos abajo."
            return null
        }
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { _nivel.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { _nivel.value = 0f }
            override fun onError(error: Int) {
                _nivel.value = 0f
                if (cancelado) return
                _estado.value = EstadoVoz.REPOSO
                _error.value = when (error) {
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "No hay conexión y el reconocimiento de voz de este teléfono la necesita. " +
                            "Revisa tu internet o escríbeme el comando."
                    SpeechRecognizer.ERROR_AUDIO -> "Hubo un problema con el micrófono."
                    SpeechRecognizer.ERROR_SERVER -> "El servicio de voz falló. Inténtalo de nuevo."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No te escuché. Toca el micrófono y habla otra vez."
                    SpeechRecognizer.ERROR_NO_MATCH -> "No entendí lo que dijiste. Inténtalo otra vez."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El reconocimiento de voz está ocupado. Inténtalo en un momento."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Falta el permiso del micrófono. Actívalo en los ajustes de la app."
                    else -> "No pude escucharte (código $error). Inténtalo de nuevo."
                }
            }
            override fun onResults(results: Bundle?) {
                _nivel.value = 0f
                val texto = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (texto.isNullOrBlank()) {
                    _estado.value = EstadoVoz.REPOSO
                    _error.value = "No entendí lo que dijiste. Inténtalo otra vez."
                } else {
                    procesar(texto)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!p.isNullOrBlank()) _transcripcion.value = p
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        reconocedor = r
        return r
    }

    /** Debe llamarse con el permiso del micrófono ya concedido. */
    fun escuchar() {
        habla.detener()
        if (_estado.value == EstadoVoz.ESCUCHANDO || _estado.value == EstadoVoz.PROCESANDO) return
        _error.value = null
        _transcripcion.value = ""
        if (!permisoMicrofono()) { reportarPermisoDenegado(); return }
        val r = obtenerReconocedor() ?: return
        cancelado = false
        _estado.value = EstadoVoz.ESCUCHANDO
        val idioma = if (Locale.getDefault().language == "es") Locale.getDefault().toLanguageTag() else "es-ES"
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, idioma)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
            },
        )
    }

    /** Cancela escuchar o hablar. Si ya se está ejecutando una orden, esta termina por seguridad. */
    fun detener() {
        cancelado = true
        reconocedor?.cancel()
        habla.detener()
        _nivel.value = 0f
        if (_estado.value != EstadoVoz.PROCESANDO) _estado.value = EstadoVoz.REPOSO
    }

    fun enviarTexto(t: String) {
        val limpio = t.trim()
        if (limpio.isEmpty()) return
        if (_estado.value == EstadoVoz.PROCESANDO) return
        reconocedor?.cancel()
        habla.detener()
        _error.value = null
        procesar(limpio)
    }

    private fun procesar(texto: String) {
        _transcripcion.value = texto
        _historial.value = (_historial.value + Mensaje(true, texto)).takeLast(40)
        _estado.value = EstadoVoz.PROCESANDO
        viewModelScope.launch {
            val respuesta = try {
                asistente.procesar(texto)
            } catch (e: Exception) {
                "Ocurrió un error (${e.message ?: e.javaClass.simpleName}) y no puedo confirmar que la orden se completara. " +
                    "Revisa la pantalla correspondiente."
            }
            _historial.value = (_historial.value + Mensaje(false, respuesta)).takeLast(40)
            if (_hablarRespuestas.value && habla.disponible) {
                _estado.value = EstadoVoz.RESPONDIENDO
                habla.hablar(respuesta) { _estado.value = EstadoVoz.REPOSO }
            } else {
                _estado.value = EstadoVoz.REPOSO
            }
        }
    }

    override fun onCleared() {
        reconocedor?.destroy()
        reconocedor = null
        habla.cerrar()
        super.onCleared()
    }
}
