package com.julio.asistente.rutinas

import com.julio.asistente.data.local.RutinaEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

/** Mismos casos que tools/espejo/espejo10.py. */
class RutinasLogicaTest {
    private fun hora(minuto: Int = 450, mascara: Int = 0, ultima: Long? = null, activa: Boolean = true, disparador: String = "HORA") =
        RutinaEntity(nombre = "x", disparador = disparador, minutoDia = minuto, diasMascara = mascara, ultimaEjecucion = ultima, activa = activa)

    @Test fun lasHoras() {
        assertEquals(450, RutinasLogica.parsearHora("7:30"))
        assertEquals(450, RutinasLogica.parsearHora("07:30"))
        assertEquals(1439, RutinasLogica.parsearHora("23:59"))
        assertEquals(450, RutinasLogica.parsearHora("7h30"))
        assertNull(RutinasLogica.parsearHora("24:00"))
        assertNull(RutinasLogica.parsearHora("7:5"))
        assertNull(RutinasLogica.parsearHora("abc"))
        assertEquals("07:30", RutinasLogica.textoHora(450))
    }

    @Test fun laFraseDeVozEsIgualNoContiene() {
        assertTrue(RutinasLogica.coincideVoz("Buenos días", "Julio, buenos dias por favor"))
        assertTrue(RutinasLogica.coincideVoz("modo estudio", "modo estudio"))
        assertFalse(RutinasLogica.coincideVoz("buenos dias", "buenos dias de nuevo"))
        assertFalse(RutinasLogica.coincideVoz("", "algo"))
        assertFalse(RutinasLogica.coincideVoz("julio", "julio"))
    }

    @Test fun cuandoTocaUnaRutinaPorHora() {
        val lunes = LocalDateTime.of(2026, 11, 9, 7, 32) // lunes
        assertTrue(RutinasLogica.tocaAhora(hora(), lunes))
        assertFalse(RutinasLogica.tocaAhora(hora(), LocalDateTime.of(2026, 11, 9, 7, 29)))
        assertTrue(RutinasLogica.tocaAhora(hora(), LocalDateTime.of(2026, 11, 9, 7, 34)))
        assertFalse(RutinasLogica.tocaAhora(hora(), LocalDateTime.of(2026, 11, 9, 7, 35)))
        val zona = ZoneId.systemDefault()
        val yaHoy = LocalDateTime.of(2026, 11, 9, 7, 30, 20).atZone(zona).toInstant().toEpochMilli()
        val ayer = LocalDateTime.of(2026, 11, 8, 7, 30).atZone(zona).toInstant().toEpochMilli()
        assertFalse(RutinasLogica.tocaAhora(hora(ultima = yaHoy), lunes))
        assertTrue(RutinasLogica.tocaAhora(hora(ultima = ayer), lunes))
        assertFalse(RutinasLogica.tocaAhora(hora(mascara = 0b0000010), lunes)) // solo martes
        assertTrue(RutinasLogica.tocaAhora(hora(mascara = 0b0000001), lunes)) // solo lunes
        assertFalse(RutinasLogica.tocaAhora(hora(activa = false), lunes))
        assertFalse(RutinasLogica.tocaAhora(hora(disparador = "VOZ"), lunes))
    }

    @Test fun separaLasOrdenes() {
        assertEquals(
            listOf("sube el volumen", "pon musica", "baja el brillo al 30"),
            RutinasLogica.separarOrdenes("sube el volumen, pon musica y baja el brillo al 30".replace(",", " luego ")),
        )
        assertEquals(listOf("pon musica de bad bunny y karol g"), RutinasLogica.separarOrdenes("pon musica de bad bunny y karol g"))
        assertEquals(listOf("silencia", "abre whatsapp"), RutinasLogica.separarOrdenes("silencia luego abre whatsapp"))
    }

    @Test fun lasOrdenesDeVozSobreRutinas() {
        assertEquals(
            ComandoRutina.Crear("buenos dias", listOf("sube el volumen", "pon musica", "baja el brillo")),
            RutinasLogica.comando("Crea la rutina buenos días que haga sube el volumen, pon música y baja el brillo"),
        )
        assertEquals(ComandoRutina.Listar, RutinasLogica.comando("¿Qué rutinas tengo?"))
        assertEquals(ComandoRutina.Alternar("noche", false), RutinasLogica.comando("apaga la rutina noche"))
        assertEquals(ComandoRutina.Alternar("estudio", true), RutinasLogica.comando("enciende la rutina de estudio"))
        assertEquals(ComandoRutina.Ejecutar("estudio"), RutinasLogica.comando("ejecuta la rutina estudio"))
        assertEquals(ComandoRutina.Ejecutar("estudio"), RutinasLogica.comando("haz la rutina estudio"))
        assertEquals(ComandoRutina.Borrar("noche"), RutinasLogica.comando("borra la rutina noche"))
        assertNull(RutinasLogica.comando("sube el volumen"))
        assertNull(RutinasLogica.comando("cuanto dura la rutina"))
    }

    @Test fun validarNombreYDisparador() {
        assertTrue(RutinasLogica.validar("", RutinasLogica.VOZ, null, emptyList()).isNotEmpty())
        assertTrue(RutinasLogica.validar("noche", RutinasLogica.HORA, null, listOf("silencia")).any { it.contains("hora") })
        assertTrue(RutinasLogica.validar("a".repeat(41), RutinasLogica.VOZ, null, listOf("silencia")).any { it.contains("largo") })
    }
}
