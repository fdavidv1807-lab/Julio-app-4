package com.julio.asistente.ejecutor

import com.julio.asistente.comandos.Intencion

/**
 * Niveles de permiso (v49). Lógica pura (sin Android): se prueba con JUnit.
 * N0 = leer o informar. N1 = acción local y reversible (volumen, brillo, música, abrir una app, enfoque): automática y Julio dice «Listo».
 * N2 = cambia datos de Julio o tiene efecto fuera de Julio (agregar, mover, enviar un mensaje): pide un «sí» hablado.
 * N3 = prohibido para rutinas y para la IA (borrar datos).
 */
enum class Nivel { N0, N1, N2, N3 }

/** Quién pide la acción (no confundir con cuerpo.Origen, que es de dónde vino un aviso). Lo que el dueño dice directamente conserva sus confirmaciones de siempre; rutinas e IA pasan por el filtro. */
enum class Solicitante { USUARIO, RUTINA, IA }

sealed class Decision {
    /** Se ejecuta ya. */
    object Ejecutar : Decision()
    /** Hay que preguntar y esperar un «sí». */
    data class Confirmar(val nivel: Nivel) : Decision()
    /** No se hace. [motivo] se dice tal cual. */
    data class Rechazar(val motivo: String) : Decision()
}

object Ejecutor {
    /** Nivel de una intención. Lo que no se reconoce o no está en la lista cuenta como N3 (prohibido): la lista es cerrada a propósito. */
    fun nivel(i: Intencion): Nivel = when (i) {
        is Intencion.ConsultarHorario, Intencion.ConsultarTareas, Intencion.ConsultarAlarmas, Intencion.ConsultarMetas,
        Intencion.ConsultarEstudio, Intencion.ConsultarRacha, Intencion.EstadoEnfoque, Intencion.ConsultarAvisos,
        Intencion.Ayuda, is Intencion.PreguntarIA -> Nivel.N0

        is Intencion.AjustarVolumen, is Intencion.AjustarBrillo, is Intencion.Musica, is Intencion.IniciarDescanso,
        Intencion.PausarEnfoque, Intencion.ReanudarEnfoque, Intencion.FinalizarEnfoque, is Intencion.AbrirApp,
        Intencion.ModoManual, Intencion.SalirMenu, Intencion.IniciarSesionEstudio, is Intencion.CrearAlarma -> Nivel.N1

        is Intencion.IniciarEnfoque -> if (i.estricto) Nivel.N2 else Nivel.N1

        is Intencion.AgregarHorario, is Intencion.CrearExamen, Intencion.EstudioHecho, is Intencion.RepetirActividad,
        is Intencion.AgregarTarea, is Intencion.CompletarTarea, is Intencion.CambiarAlarma, is Intencion.CrearMeta,
        is Intencion.ActualizarMeta, is Intencion.MoverActividad, is Intencion.RenombrarTarea,
        is Intencion.CambiarHoraAlarma, is Intencion.ConfigurarDescanso, is Intencion.Responder -> Nivel.N2

        else -> Nivel.N3
    }

    /**
     * ¿Qué se hace con [i] pedida por [origen]?
     * USUARIO: siempre se ejecuta (cada orden ya trae sus propias preguntas de confirmación).
     * RUTINA: solo N0 y N1 (una rutina automática no puede tocar nada más).
     * IA: N0 y N1 se ejecutan; N2 pide «sí»; N3 se rechaza; la IA no puede pedirle otra consulta a la IA.
     */
    fun decidir(origen: Solicitante, i: Intencion): Decision {
        if (origen == Solicitante.USUARIO) return Decision.Ejecutar
        if (i is Intencion.Desconocida || i is Intencion.Ambigua) return Decision.Rechazar("no la entiendo como una orden")
        val n = nivel(i)
        return when (origen) {
            Solicitante.RUTINA -> when (n) {
                Nivel.N0, Nivel.N1 -> Decision.Ejecutar
                Nivel.N2 -> Decision.Rechazar("cambia datos o tiene efecto fuera de Julio (nivel 2); las rutinas solo hacen cosas de nivel 0 y 1")
                Nivel.N3 -> Decision.Rechazar("está prohibida en una rutina (nivel 3)")
            }
            Solicitante.IA -> when {
                i is Intencion.PreguntarIA -> Decision.Rechazar("la IA no puede consultarse a sí misma")
                n == Nivel.N0 || n == Nivel.N1 -> Decision.Ejecutar
                n == Nivel.N2 -> Decision.Confirmar(n)
                else -> Decision.Rechazar("está prohibida para la IA (nivel 3)")
            }
            Solicitante.USUARIO -> Decision.Ejecutar
        }
    }
}
