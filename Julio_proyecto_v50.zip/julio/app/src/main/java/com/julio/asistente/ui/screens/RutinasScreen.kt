package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.data.local.RutinaEntity
import com.julio.asistente.rutinas.RutinasLogica
import com.julio.asistente.ui.components.PanelJulio
import com.julio.asistente.ui.components.SelectorHora
import kotlinx.coroutines.launch
import java.time.LocalTime

/**
 * Mi día > Rutinas (v49). Una rutina es una lista de órdenes (solo de nivel 0 y 1) con un disparador: tu voz, una hora o conectar el
 * cargador. [alEjecutar] recibe el nombre y lo manda a Julio como «ejecuta la rutina …» (así pasa por el mismo camino que la voz).
 */
@Composable
fun RutinasScreen(alEjecutar: (String) -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { JulioDatabase.get(ctx).rutinaDao() }
    val flujo = remember { dao.observarTodas() }
    val rutinas by flujo.collectAsStateWithLifecycle(initialValue = emptyList())
    var enEdicion by remember { mutableStateOf<RutinaEntity?>(null) }
    var creando by remember { mutableStateOf(false) }
    var porEliminar by remember { mutableStateOf<RutinaEntity?>(null) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Text("Rutinas", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
            Text(
                "Una rutina hace varias cosas con una sola orden. Solo acepta cosas seguras (informar, volumen, brillo, música, enfoque, abrir una app). " +
                    "Las de hora y cargador funcionan con la app abierta.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            OutlinedButton(onClick = { creando = true }, modifier = Modifier.padding(bottom = 8.dp)) { Text("Nueva rutina") }
            if (rutinas.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay rutinas. También puedes decir: «crea la rutina noche que haga silencia el volumen y baja el brillo».")
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(rutinas, key = { it.id }) { r ->
                        PanelJulio(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(r.nombre, style = MaterialTheme.typography.titleMedium)
                                        Text(RutinasLogica.textoDisparador(r), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = r.activa, onCheckedChange = { v -> scope.launch { dao.actualizar(r.copy(activa = v)) } })
                                }
                                Text(RutinasLogica.acciones(r.acciones).joinToString("\n") { "• $it" }, style = MaterialTheme.typography.bodySmall)
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    TextButton(onClick = { alEjecutar(r.nombre) }) { Text("Ejecutar ahora") }
                                    TextButton(onClick = { enEdicion = r }) { Text("Editar") }
                                    TextButton(onClick = { porEliminar = r }) { Text("Eliminar") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (creando || enEdicion != null) {
        val inicial = enEdicion
        DialogoRutina(
            inicial = inicial,
            otrosNombres = rutinas.filter { it.id != (inicial?.id ?: -1L) }.map { RutinasLogica.normalizar(it.nombre) },
            alCancelar = { creando = false; enEdicion = null },
            alGuardar = { nueva ->
                scope.launch {
                    if (inicial == null) dao.insertar(nueva) else dao.actualizar(nueva.copy(id = inicial.id, ultimaEjecucion = inicial.ultimaEjecucion, creadaEn = inicial.creadaEn))
                    creando = false
                    enEdicion = null
                }
            },
        )
    }

    porEliminar?.let { r ->
        AlertDialog(
            onDismissRequest = { porEliminar = null },
            title = { Text("¿Eliminar la rutina?") },
            text = { Text("Se borrará «${r.nombre}». Esto no se puede deshacer.") },
            confirmButton = { TextButton(onClick = { scope.launch { dao.eliminar(r); porEliminar = null } }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { porEliminar = null }) { Text("Cancelar") } },
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DialogoRutina(
    inicial: RutinaEntity?,
    otrosNombres: List<String>,
    alCancelar: () -> Unit,
    alGuardar: (RutinaEntity) -> Unit,
) {
    var nombre by remember { mutableStateOf(inicial?.nombre ?: "") }
    var disparador by remember { mutableStateOf(inicial?.disparador ?: RutinasLogica.VOZ) }
    var minutoDia by remember { mutableStateOf(inicial?.minutoDia) }
    var dias by remember { mutableStateOf(inicial?.diasMascara ?: 0) }
    var acciones by remember { mutableStateOf(inicial?.acciones ?: "") }
    var errores by remember { mutableStateOf<List<String>>(emptyList()) }
    var eligiendoHora by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = alCancelar,
        title = { Text(if (inicial == null) "Nueva rutina" else "Editar rutina") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it.take(RutinasLogica.MAX_NOMBRE) },
                    label = { Text("Nombre (con voz, es lo que dices)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Se activa", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = disparador == RutinasLogica.VOZ, onClick = { disparador = RutinasLogica.VOZ }, label = { Text("Por voz") })
                    FilterChip(selected = disparador == RutinasLogica.HORA, onClick = { disparador = RutinasLogica.HORA }, label = { Text("A una hora") })
                    FilterChip(selected = disparador == RutinasLogica.CARGADOR, onClick = { disparador = RutinasLogica.CARGADOR }, label = { Text("Al conectar el cargador") })
                }
                if (disparador == RutinasLogica.HORA) {
                    OutlinedButton(onClick = { eligiendoHora = true }) {
                        Text(minutoDia?.let { "Hora: ${RutinasLogica.textoHora(it)}" } ?: "Elegir la hora")
                    }
                    Text("Días (sin marcar = todos los días)", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("L", "M", "X", "J", "V", "S", "D").forEachIndexed { k, letra ->
                            FilterChip(
                                selected = (dias shr k) and 1 == 1,
                                onClick = { dias = dias xor (1 shl k) },
                                label = { Text(letra) },
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = acciones,
                    onValueChange = { acciones = it.take(600) },
                    label = { Text("Órdenes, una por línea") },
                    placeholder = { Text("sube el volumen\npon música\nbaja el brillo al 30") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                )
                errores.forEach { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val lista = RutinasLogica.acciones(acciones)
                val problemas = RutinasLogica.validar(nombre, disparador, minutoDia, lista).toMutableList()
                if (otrosNombres.contains(RutinasLogica.normalizar(nombre))) problemas += "Ya existe una rutina con ese nombre."
                errores = problemas
                if (problemas.isEmpty()) {
                    alGuardar(
                        RutinaEntity(
                            nombre = nombre.trim(),
                            frase = if (disparador == RutinasLogica.VOZ) RutinasLogica.normalizar(nombre) else "",
                            disparador = disparador,
                            minutoDia = if (disparador == RutinasLogica.HORA) minutoDia else null,
                            diasMascara = if (disparador == RutinasLogica.HORA) dias else 0,
                            acciones = lista.joinToString("\n"),
                            activa = inicial?.activa ?: true,
                        ),
                    )
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = alCancelar) { Text("Cancelar") } },
    )

    if (eligiendoHora) {
        val base = minutoDia ?: (7 * 60)
        SelectorHora(
            titulo = "Hora de la rutina",
            inicial = LocalTime.of(base / 60, base % 60),
            onAceptar = { t -> minutoDia = t.hour * 60 + t.minute; eligiendoHora = false },
            onCancelar = { eligiendoHora = false },
        )
    }
}
