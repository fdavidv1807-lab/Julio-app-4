package com.julio.asistente.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [TareaEntity::class, ActividadEntity::class, AlarmaEntity::class, MetaEntity::class, RutinaEntity::class],
    version = 4,
    exportSchema = false,
)
abstract class JulioDatabase : RoomDatabase() {
    abstract fun tareaDao(): TareaDao
    abstract fun actividadDao(): ActividadDao
    abstract fun alarmaDao(): AlarmaDao
    abstract fun metaDao(): MetaDao
    abstract fun rutinaDao(): RutinaDao

    companion object {
        /** v1 -> v2: recordatorios. Solo añade columnas anulables; no toca los datos existentes. */
        val MIGRACION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE actividades ADD COLUMN recordatorioMin INTEGER")
                db.execSQL("ALTER TABLE tareas ADD COLUMN recordatorioMinutoDia INTEGER")
            }
        }

        /**
         * v2 -> v3: horarios de varios días. Solo añade columnas anulables a «actividades»;
         * las actividades existentes quedan exactamente igual (se repiten como antes).
         */
        val MIGRACION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE actividades ADD COLUMN diasMascara INTEGER")
                db.execSQL("ALTER TABLE actividades ADD COLUMN intervaloSemanas INTEGER")
                db.execSQL("ALTER TABLE actividades ADD COLUMN excluidas TEXT")
            }
        }

        /**
         * v3 -> v4: rutinas. Solo CREA una tabla nueva; no toca ninguna tabla ni dato existente.
         * Las columnas deben coincidir exactamente con [RutinaEntity] (Room lo comprueba al abrir).
         */
        val MIGRACION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `rutinas` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`nombre` TEXT NOT NULL, " +
                        "`frase` TEXT NOT NULL, " +
                        "`disparador` TEXT NOT NULL, " +
                        "`minutoDia` INTEGER, " +
                        "`diasMascara` INTEGER NOT NULL, " +
                        "`acciones` TEXT NOT NULL, " +
                        "`activa` INTEGER NOT NULL, " +
                        "`ultimaEjecucion` INTEGER, " +
                        "`creadaEn` INTEGER NOT NULL)",
                )
            }
        }

        @Volatile private var instancia: JulioDatabase? = null

        fun get(context: Context): JulioDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    JulioDatabase::class.java,
                    "julio.db",
                ).addMigrations(MIGRACION_1_2, MIGRACION_2_3, MIGRACION_3_4).build().also { instancia = it }
            }
    }
}
