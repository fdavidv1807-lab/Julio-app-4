package com.julio.asistente.escritorio

/** Lógica pura del modo escritorio (sin Android) para poder probarla con pruebas unitarias. */
object CalculoEscritorio {
    /** Brillo de pantalla (0 a 1) según la hora: muy bajo de noche, bajo de día. */
    const val BRILLO_DIA = 0.12f
    const val BRILLO_NOCHE = 0.02f

    fun brilloPorHora(hora: Int): Float = if (hora >= 22 || hora < 7) BRILLO_NOCHE else BRILLO_DIA

    /** Posiciones (en dp) por las que se desplaza la imagen para que ningún píxel quede fijo siempre. */
    private val POSICIONES = listOf(0 to 0, 18 to -12, -18 to 12, 12 to 18, -12 to -18)

    /** Cambia de posición cada [PERIODO_MIN] minutos. */
    const val PERIODO_MIN = 2L

    fun desplazamiento(minutosDesdeEpoch: Long): Pair<Int, Int> {
        val i = ((minutosDesdeEpoch / PERIODO_MIN) % POSICIONES.size).toInt()
        return POSICIONES[i]
    }

    /** Segundos de reposo antes de pasar al estado «dormido» (orbe casi apagado) en modo escritorio. */
    const val DORMIR_SEG = 30L
}
