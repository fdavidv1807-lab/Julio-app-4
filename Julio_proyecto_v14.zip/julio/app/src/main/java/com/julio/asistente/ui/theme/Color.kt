package com.julio.asistente.ui.theme

import androidx.compose.ui.graphics.Color

val AzulJulio = Color(0xFF1E88E5)
val AzulClaro = Color(0xFF63C7F9)
val AzulProfundo = Color(0xFF050C1C)
val SuperficieOscura = Color(0xFF081428)
val Cian = Color(0xFF4DD0E1)
val NeonCian = Color(0xFF38E8FF)
val NeonAzul = Color(0xFF2F6BFF)
