package com.julio.asistente.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.julio.asistente.ui.theme.Cian
import com.julio.asistente.ui.theme.NeonAzul
import com.julio.asistente.ui.theme.NeonCian
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Panel de la cabina: igual que una tarjeta, con borde de neón y esquinas cortadas (por el tema). */
@Composable
fun PanelJulio(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(listOf(NeonCian.copy(alpha = 0.6f), NeonAzul.copy(alpha = 0.25f))),
        ),
        content = content,
    )
}

/** Fondo de la app: degradado oscuro con un resplandor arriba y una cuadrícula muy sutil. */
@Composable
fun FondoHud(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val fondo = MaterialTheme.colorScheme.background
    Box(
        modifier
            .fillMaxSize()
            .background(fondo)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(NeonAzul.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(size.width / 2f, 0f),
                        radius = size.width * 0.95f,
                    ),
                )
                val paso = 36.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(Cian.copy(alpha = 0.045f), Offset(x, 0f), Offset(x, size.height), 1f)
                    x += paso
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(Cian.copy(alpha = 0.045f), Offset(0f, y), Offset(size.width, y), 1f)
                    y += paso
                }
            },
        content = content,
    )
}

/** Encabezado: nombre a la izquierda; hora y fecha a la derecha. */
@Composable
fun EncabezadoHud() {
    var ahora by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            ahora = LocalDateTime.now()
            delay(15_000)
        }
    }
    val formatoHora = remember { DateTimeFormatter.ofPattern("HH:mm") }
    val formatoFecha = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale("es")) }
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(NeonCian, CircleShape))
            Spacer(Modifier.size(8.dp))
            Text(
                "J U L I O",
                style = MaterialTheme.typography.titleMedium,
                color = NeonCian,
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(ahora.format(formatoHora), style = MaterialTheme.typography.titleMedium)
            Text(
                ahora.format(formatoFecha).uppercase(Locale("es")),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
