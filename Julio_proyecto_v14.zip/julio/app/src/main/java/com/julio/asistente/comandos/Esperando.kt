package com.julio.asistente.comandos

import com.julio.asistente.horario.Recurrencia
import java.time.LocalDate
import java.time.LocalTime

/** Lo que Julio le preguntó al usuario y está esperando que responda (conversación de varios turnos). */
sealed class Esperando {
    object TituloTarea : Esperando()
    object TituloMeta : Esperando()
    data class TipoEntrada(val texto: String) : Esperando()
    data class DatosActividad(
        val titulo: String?, val fecha: LocalDate?, val hora: LocalTime?, val recurrencia: Recurrencia,
    ) : Esperando()
    data class DatosAlarma(val hora: LocalTime?, val fecha: LocalDate?, val dias: Int) : Esperando()
    data class MetaParaProgreso(val porcentaje: Int?) : Esperando()
    data class PorcentajeMeta(val metaId: Long) : Esperando()
    data class ConfirmarEliminar(val elemento: Elemento, val id: Long, val nombre: String) : Esperando()
    data class ElementoParaEliminar(val elemento: Elemento) : Esperando()
    data class NuevoHorarioActividad(val id: Long) : Esperando()
    data class NuevoNombreTarea(val id: Long) : Esperando()
    data class NuevaHoraAlarma(val id: Long) : Esperando()
}
