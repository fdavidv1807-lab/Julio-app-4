package com.julio.asistente.comandos

import com.julio.asistente.horario.Recurrencia
import java.time.LocalDate
import java.time.LocalTime

/**
 * Convierte una frase en una [Intencion]. Es lógica pura: no toca la pantalla ni la base de datos.
 * Reglas locales (funcionan sin internet y no envían nada a ningún sitio).
 */
object Interprete {

    private fun tiene(n: String, patron: String): Boolean = Regex(patron).containsMatchIn(n)

    private val VERBO_AGREGAR = Regex(
        "\\b(agrega|agregar|agregame|anade|anadir|crea|crear|apunta|apuntar|anota|anotar|programa|" +
            "programar|agenda|agendar|pon|poner|registra|registrar|recuerdame|inscribe)\\b",
    )
    private val PALABRA_TAREA = Regex("\\b(tarea|tareas|pendiente|pendientes)\\b")
    private val CLAVE_HORARIO = Regex("\\b(clase|clases|laboratorio|laboratorios|cita|citas|reunion|actividad|actividades|examen|evento|junta|turno)\\b")
    private val RELLENO = setOf("a", "al", "de", "del", "en", "el", "la", "las", "los", "un", "una", "mi", "mis", "para", "que", "lista", "y", "por", "favor", "julio", "como")

    fun interpretar(texto: String, hoy: LocalDate, ahora: LocalTime): Intencion {
        val n = Texto.numeros(Texto.normalizar(texto))
        if (n.isBlank()) return Intencion.Desconocida
        return enfoque(n)
            ?: eliminar(n, hoy, ahora)
            ?: renombrarTarea(n, texto)
            ?: cambiarHoraAlarma(n, ahora)
            ?: moverActividad(n, hoy, ahora)
            ?: metas(n, texto)
            ?: alarma(n, hoy, ahora)
            ?: tareasOHorario(n, texto, hoy, ahora)
            ?: Intencion.Desconocida
    }

    // ---------- Eliminar, mover y renombrar ----------

    private val VERBO_ELIMINAR = Regex("\\b(elimina|eliminar|eliminame|borra|borrar|borrame|suprime|suprimir|remueve|remover|descarta|descartar)\\b")
    private const val VERBOS_SUELTOS = "\\b(quita|quitar|cancela|cancelar|anula|anular)\\b"
    private const val GENERICAS = "\\b(todas|todos|mi|mis|la|el|las|los|de|del|tarea|tareas|actividad|actividades|meta|metas|alarma|alarmas|horario|agenda|pendiente|pendientes|lista|julio|favor|por)\\b"
    private val PALABRA_ACTIVIDAD = Regex("\\b(actividad|actividades|horario|agenda|clase|clases|laboratorio|laboratorios|cita|citas|reunion|examen|evento|junta|turno)\\b")
    private const val VERBOS_MOVER = "\\b(mueve|mover|muevela|reprograma|reprogramar|cambia|cambiar|cambiala|pasa|pasar|pasala|pospone|posponer|aplaza|aplazar)\\b"

    /** «la alarma de las 6» -> «la alarma a las 6», que es la forma que sabe leer [Texto.extraerHora]. */
    private fun deAa(n: String): String =
        Regex("\\bde (la|las) (?=\\d)").replace(n) { "a ${it.groupValues[1]} " }

    private fun eliminar(n: String, hoy: LocalDate, ahora: LocalTime): Intencion? {
        val esAlarma = tiene(n, "\\balarmas?\\b")
        val candidatos = listOf(
            Elemento.META to Regex("\\bmetas?\\b"),
            Elemento.ALARMA to Regex("\\balarmas?\\b"),
            Elemento.TAREA to PALABRA_TAREA,
            Elemento.ACTIVIDAD to PALABRA_ACTIVIDAD,
        ).mapNotNull { (e, r) -> r.find(n)?.let { e to it.range.first } }
        val elemento = candidatos.minByOrNull { it.second }?.first
        val estricto = VERBO_ELIMINAR.containsMatchIn(n)
        // «quita» y «cancela» solo cuentan si nombran algo que borrar; «cancela la alarma» sigue siendo desactivarla.
        val suelto = !esAlarma && tiene(n, VERBOS_SUELTOS) && elemento != null
        if (!estricto && !suelto) return null

        val hora = if (elemento == Elemento.ALARMA) Texto.extraerHora(deAa(n), ahora, true).hora else null
        val dia = if (elemento == Elemento.ALARMA) diaDe(n) else null
        var base = n
        var fecha: LocalDate? = null
        if (elemento == Elemento.ACTIVIDAD) {
            val f = Texto.extraerFecha(n, hoy)
            fecha = f.fecha
            base = f.resto
        }
        val ref = limpiar(base, listOf(VERBO_ELIMINAR.pattern, VERBOS_SUELTOS, GENERICAS))
        return Intencion.Eliminar(elemento, ref.ifBlank { null }, hora, dia, fecha)
    }

    private fun renombrarTarea(n: String, original: String): Intencion? {
        if (!PALABRA_TAREA.containsMatchIn(n)) return null
        val verbo = tiene(n, "\\b(renombra|renombrar|renombrame)\\b") ||
            (tiene(n, "\\b(cambia|cambiar|modifica|modificar|edita|editar)\\b") && tiene(n, "\\b(nombre|titulo)\\b"))
        if (!verbo) return null
        val despues = Regex("\\btareas?\\b(.*)").find(n)?.groupValues?.get(1).orEmpty().trim()
        val partes = Regex("^(.*?) (?:por|como|a) (.+)$").find(despues)
        if (partes == null) {
            val ref = limpiar(despues, emptyList())
            return Intencion.RenombrarTarea(ref.ifBlank { null }, null)
        }
        val ref = limpiar(partes.groupValues[1], emptyList())
        val nuevo = limpiar(partes.groupValues[2], emptyList())
        return Intencion.RenombrarTarea(
            ref.ifBlank { null },
            if (nuevo.isBlank()) null else Texto.capitalizar(Texto.restaurar(nuevo, original)),
        )
    }

    private fun cambiarHoraAlarma(n: String, ahora: LocalTime): Intencion? {
        if (!tiene(n, "\\balarmas?\\b")) return null
        if (!tiene(n, "\\b(cambia|cambiar|cambiala|mueve|mover|muevela|pasa|pasar|pasala|modifica|modificar|reprograma|reprogramar)\\b")) return null
        val h1 = Texto.extraerHora(deAa(n), ahora, true)
        val h2 = Texto.extraerHora(h1.resto, ahora, true)
        return if (h1.hora != null && h2.hora != null) {
            Intencion.CambiarHoraAlarma(h1.hora, diaDe(n), h2.hora)
        } else {
            Intencion.CambiarHoraAlarma(null, diaDe(n), h1.hora)
        }
    }

    private fun moverActividad(n: String, hoy: LocalDate, ahora: LocalTime): Intencion? {
        if (!tiene(n, VERBOS_MOVER)) return null
        if (tiene(n, "\\b(alarma|alarmas|tarea|tareas|meta|metas|descanso|enfoque|sesion)\\b")) return null
        if (!PALABRA_ACTIVIDAD.containsMatchIn(n)) return null
        val h = Texto.extraerHora(n, ahora, false)
        val f = Texto.extraerFecha(h.resto, hoy)
        val ref = limpiar(f.resto, listOf(VERBOS_MOVER, "\\b(para|a)\\b"))
        return Intencion.MoverActividad(ref.ifBlank { null }, f.fecha, h.hora)
    }

    // ---------- Modo enfoque ----------

    private fun enfoque(n: String): Intencion? {
        val dur = Texto.extraerDuracionMin(n)
        val descanso = tiene(n, "\\b(descanso|descansar)\\b")
        val sesion = tiene(n, "\\b(enfoque|pomodoro|sesion|concentrar|concentracion)\\b")
        val estudiar = dur != null &&
            tiene(n, "\\b(estudiar|trabajar|concentrarme|leer)\\b") &&
            !tiene(n, "\\b(tarea|tareas|pendiente|pendientes|alarma|clase|meta|metas)\\b")
        if (!descanso && !sesion && !estudiar) return null

        if (descanso) {
            val configurar = tiene(n, "\\b(configura|configurar|establece|establecer|cambia|cambiar|ajusta|ajustar|define|definir)\\b")
            return if (configurar && dur != null) Intencion.ConfigurarDescanso(dur) else Intencion.IniciarDescanso(dur)
        }
        if (tiene(n, "\\b(como va|cuanto falta|cuanto tiempo|que tiempo|estado|queda|quedan)\\b")) return Intencion.EstadoEnfoque
        if (tiene(n, "\\b(pausa|pausar|pausala)\\b")) return Intencion.PausarEnfoque
        if (tiene(n, "\\b(reanuda|reanudar|continua|continuar|retoma)\\b")) return Intencion.ReanudarEnfoque
        if (tiene(n, "\\b(termina|terminar|finaliza|finalizar|detener|deten|cancela|cancelar)\\b")) return Intencion.FinalizarEnfoque
        return Intencion.IniciarEnfoque(dur)
    }

    // ---------- Mis metas ----------

    private fun metas(n: String, original: String): Intencion? {
        if (!tiene(n, "\\bmetas?\\b")) return null
        val agregar = tiene(n, "\\b(agrega|agregar|agregarme|anade|anadir|crea|crear|nueva|nuevo|apunta)\\b")
        val actualizar = tiene(n, "\\b(actualiza|actualizar|progreso|avance|avanza|sube|lleva|marca|completa|completar|termine|cumpli)\\b") ||
            tiene(n, "\\bva (al|en|a)\\b")
        if (actualizar && !agregar) {
            val pct = Regex("(\\d{1,3}) ?(?:por ciento|%)").find(n)?.groupValues?.get(1)?.toIntOrNull()
                ?: Regex("\\b(?:al|a) (\\d{1,3})\\b").find(n)?.groupValues?.get(1)?.toIntOrNull()
            val completada = tiene(n, "\\b(completada|completa|completar|terminada|cumplida|cumpli|termine)\\b")
            val porcentaje = if (completada && pct == null) 100 else pct
            return Intencion.ActualizarMeta(referenciaMeta(n, original), porcentaje)
        }
        if (agregar) {
            val despues = Regex("\\bmetas?\\b(.*)").find(n)?.groupValues?.get(1).orEmpty()
            val titulo = limpiar(despues, listOf("\\b(nueva|nuevo|llamada|que se llama)\\b"))
            return Intencion.CrearMeta(if (titulo.isBlank()) null else Texto.capitalizar(Texto.restaurar(titulo, original)))
        }
        return Intencion.ConsultarMetas
    }

    private fun referenciaMeta(n: String, original: String): String? {
        var despues = Regex("\\bmetas?\\b(.*)").find(n)?.groupValues?.get(1).orEmpty()
        val corte = Regex("\\b(va|al|a|en|con|lleva|esta|ya)\\b|\\d").find(despues)
        if (corte != null) despues = despues.substring(0, corte.range.first)
        val ref = limpiar(despues, listOf("\\b(llamada|que se llama)\\b"))
        return if (ref.isBlank()) null else Texto.restaurar(ref, original)
    }

    // ---------- Alarmas ----------

    private fun alarma(n: String, hoy: LocalDate, ahora: LocalTime): Intencion? {
        if (!tiene(n, "\\balarmas?\\b|\\bdespiertame\\b")) return null
        val desactivar = tiene(n, "\\b(desactiva|desactivar|apaga|apagar|deshabilita|cancela|cancelar|quita)\\b")
        val activar = tiene(n, "\\b(activa|activar|enciende|encender|habilita|reactiva)\\b")
        val crear = tiene(n, "\\b(pon|poner|crea|crear|programa|programar|configura|configurar|agrega|agregar|anade|anadir|despiertame|necesito|quiero)\\b")
        val consultar = tiene(n, "\\b(que|cuales|cuantas|muestrame|muestra|lista|mis)\\b.*\\balarmas?\\b|\\balarmas? (tengo|hay|programadas)\\b")

        val h = Texto.extraerHora(n, ahora, true)
        val hDA = Texto.extraerHora(deAa(n), ahora, true)
        if (desactivar) return Intencion.CambiarAlarma(false, hDA.hora, diaDe(n))
        if (activar && !tiene(n, "\\buna alarma\\b")) return Intencion.CambiarAlarma(true, hDA.hora, diaDe(n))
        if (consultar && !crear) return Intencion.ConsultarAlarmas

        val f = Texto.extraerFecha(h.resto, hoy)
        val dias = diasRepetidos(n)
        return Intencion.CrearAlarma(h.hora, f.fecha, dias, h.enMinutos)
    }

    private fun diaDe(n: String) = Regex("\\b(${Texto.DIAS.keys.joinToString("|")})\\b").find(n)
        ?.let { Texto.DIAS[it.groupValues[1]] }

    /** Máscara de días (lunes = bit 0 ... domingo = bit 6) para «todos los días», «los lunes y miércoles». */
    private fun diasRepetidos(n: String): Int {
        if (tiene(n, "\\b(todos los dias|cada dia|diariamente)\\b")) return 127
        if (!tiene(n, "\\b(los|cada|todos los) (${Texto.DIAS.keys.joinToString("|")})\\b")) return 0
        var mascara = 0
        for ((nombre, dia) in Texto.DIAS) {
            if (tiene(n, "\\b$nombre\\b")) mascara = mascara or (1 shl (dia.value - 1))
        }
        return mascara
    }

    // ---------- Tareas y Horario ----------

    private fun tareasOHorario(n: String, original: String, hoy: LocalDate, ahora: LocalTime): Intencion? {
        val tieneTarea = PALABRA_TAREA.containsMatchIn(n)
        val agrega = VERBO_AGREGAR.containsMatchIn(n)

        // Completar una tarea
        if (tieneTarea && tiene(n, "\\b(marca|marcar|completa|completar|termina|terminar|finaliza|finalizar|tacha|tachar|cumpli)\\b|\\bya (hice|termine)\\b")) {
            val despues = Regex("\\b(?:tarea|tareas)\\b(.*)").find(n)?.groupValues?.get(1).orEmpty()
            val ref = limpiar(despues, listOf("\\b(terminada|completada|hecha|lista)\\b"))
            return Intencion.CompletarTarea(if (ref.isBlank()) "" else Texto.restaurar(ref, original))
        }

        // Consultar tareas
        if (tieneTarea && !agrega) return Intencion.ConsultarTareas
        if (tiene(n, "\\bque me falta\\b|\\bque pendientes\\b")) return Intencion.ConsultarTareas

        // Agregar tarea
        if (tieneTarea && agrega) {
            val titulo = limpiar(
                n,
                listOf(
                    VERBO_AGREGAR.pattern,
                    "\\ba (mis|mi|las|la) (tareas?|pendientes?|lista de tareas|lista)\\b",
                    PALABRA_TAREA.pattern,
                ),
            )
            return Intencion.AgregarTarea(if (titulo.isBlank()) null else Texto.capitalizar(Texto.restaurar(titulo, original)))
        }

        // Consultar horario
        val palabraHorario = tiene(n, "\\b(programado|horario|agenda|clases?|actividades?|citas?|laboratorios?|eventos?|compromisos?)\\b")
        val preguntaDirecta = tiene(n, "^(que|cual|cuales) (tengo|hay)\\b")
        if (!agrega && (palabraHorario || preguntaDirecta) && tiene(n, "\\b(que|cuales|cual|tengo|hay|muestrame|muestra|mi|dime)\\b")) {
            val f = Texto.extraerFecha(n, hoy)
            return Intencion.ConsultarHorario(f.fecha ?: hoy)
        }

        // Agregar al horario
        if (agrega) {
            val h = Texto.extraerHora(n, ahora, false)
            // «todos los lunes» -> «lunes»: así la fecha toma el primer lunes y no queda «todos» en el título.
            val sinPlural = Regex("\\b(?:los|cada|todos los) (${Texto.DIAS.keys.joinToString("|")})\\b")
                .replace(h.resto, "\$1")
            val f = Texto.extraerFecha(sinPlural, hoy)
            val recurrencia = recurrenciaDe(n)
            val hayClave = CLAVE_HORARIO.containsMatchIn(n)
            if (h.hora == null && f.fecha == null && !hayClave && recurrencia == Recurrencia.NINGUNA) {
                return Intencion.Ambigua(original)
            }
            val titulo = limpiar(
                f.resto,
                listOf(
                    VERBO_AGREGAR.pattern,
                    "\\b(a|al) (mi |el |la )?(horario|agenda)\\b",
                    "\\b(todos los dias|cada dia|cada semana|todas las semanas|cada mes|semanalmente|mensualmente|diariamente)\\b",
                    "\\b(los|cada|todos los) (${Texto.DIAS.keys.joinToString("|")})\\b",
                ),
            )
            return Intencion.AgregarHorario(
                titulo = if (titulo.isBlank()) null else Texto.capitalizar(Texto.restaurar(titulo, original)),
                fecha = f.fecha,
                hora = h.hora,
                recurrencia = recurrencia,
            )
        }
        return null
    }

    fun recurrenciaDe(n: String): Recurrencia = when {
        tiene(n, "\\b(todos los dias|cada dia|diariamente)\\b") -> Recurrencia.DIARIA
        tiene(n, "\\b(cada semana|todas las semanas|semanalmente)\\b") ||
            tiene(n, "\\b(los|cada|todos los) (${Texto.DIAS.keys.joinToString("|")})\\b") -> Recurrencia.SEMANAL
        tiene(n, "\\b(cada mes|mensualmente|todos los meses)\\b") -> Recurrencia.MENSUAL
        else -> Recurrencia.NINGUNA
    }

    /** Quita las frases indicadas y las palabras de relleno al principio y al final. */
    fun limpiar(n: String, quitar: List<String>): String {
        var s = n
        for (p in quitar) s = Regex(p).replace(s, " ")
        val palabras = s.split(" ").filter { it.isNotEmpty() }.toMutableList()
        while (palabras.isNotEmpty() && palabras.first() in RELLENO) palabras.removeAt(0)
        while (palabras.isNotEmpty() && palabras.last() in RELLENO) palabras.removeAt(palabras.size - 1)
        return palabras.joinToString(" ")
    }
}
