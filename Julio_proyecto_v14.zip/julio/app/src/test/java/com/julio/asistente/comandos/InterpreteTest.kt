package com.julio.asistente.comandos

import com.julio.asistente.horario.Recurrencia
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

/** Pruebas de la lógica de comandos (sin Android). Ejecutar con: gradle testDebugUnitTest */
class InterpreteTest {
    private val hoy = LocalDate.of(2026, 10, 25) // domingo
    private val ahora = LocalTime.of(9, 11)

    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun consultaHorarioHoy() =
        assertEquals(Intencion.ConsultarHorario(hoy), i("¿Qué tengo programado hoy?"))

    @Test fun consultaClasesDelLunes() =
        assertEquals(Intencion.ConsultarHorario(LocalDate.of(2026, 10, 26)), i("¿Qué clases tengo el lunes?"))

    @Test fun agregaLaboratorioConFechaYHora() = assertEquals(
        Intencion.AgregarHorario("Laboratorio de química", LocalDate.of(2026, 10, 26), LocalTime.of(14, 0), Recurrencia.NINGUNA),
        i("Agrega laboratorio de química mañana a las dos de la tarde"),
    )

    @Test fun agregaTarea() =
        assertEquals(Intencion.AgregarTarea("Estudiar anatomía"), i("Agrega estudiar anatomía a mis tareas"))

    @Test fun consultaTareas() = assertEquals(Intencion.ConsultarTareas, i("¿Qué tareas tengo pendientes?"))

    @Test fun completaTarea() =
        assertEquals(Intencion.CompletarTarea("informe"), i("Marca como terminada la tarea del informe"))

    @Test fun creaAlarmaManana() = assertEquals(
        Intencion.CrearAlarma(LocalTime.of(6, 0), LocalDate.of(2026, 10, 26), 0, null),
        i("Pon una alarma para mañana a las seis de la mañana"),
    )

    @Test fun desactivaAlarmaDelDomingo() =
        assertEquals(Intencion.CambiarAlarma(false, null, DayOfWeek.SUNDAY), i("Desactiva la alarma del domingo"))

    @Test fun enfoque35() = assertEquals(Intencion.IniciarEnfoque(35), i("Inicia una sesión de enfoque de 35 minutos"))

    @Test fun estudiarUnaHoraVeinte() =
        assertEquals(Intencion.IniciarEnfoque(80), i("Quiero estudiar durante una hora y veinte minutos"))

    @Test fun configuraDescanso() =
        assertEquals(Intencion.ConfigurarDescanso(10), i("Configura un descanso de diez minutos"))

    @Test fun muestraMetas() = assertEquals(Intencion.ConsultarMetas, i("Muéstrame mis metas"))

    @Test fun creaMetaSinTitulo() = assertEquals(Intencion.CrearMeta(null), i("Quiero agregar una meta nueva"))

    @Test fun actualizaProgresoSinDatos() =
        assertEquals(Intencion.ActualizarMeta(null, null), i("Actualiza el progreso de mi meta"))

    @Test fun agregarSinFechaEsAmbiguo() = assertTrue(i("Agrega repasar química") is Intencion.Ambigua)

    @Test fun claseSemanalNoDejaTodosEnElTitulo() = assertEquals(
        Intencion.AgregarHorario("Clase de anatomía", LocalDate.of(2026, 10, 26), LocalTime.of(8, 0), Recurrencia.SEMANAL),
        i("Agrega clase de anatomía todos los lunes a las ocho"),
    )

    @Test fun fraseSinSentidoEsDesconocida() = assertEquals(Intencion.Desconocida, i("Hola Julio"))

    // ---------- Eliminar, mover y renombrar ----------

    @Test fun eliminaTarea() = assertEquals(
        Intencion.Eliminar(Elemento.TAREA, "informe", null, null, null), i("Elimina la tarea del informe"),
    )

    @Test fun eliminaAlarmaDeLasSeis() = assertEquals(
        Intencion.Eliminar(Elemento.ALARMA, "6", LocalTime.of(6, 0), null, null), i("Elimina la alarma de las seis"),
    )

    @Test fun eliminaClaseDeManana() = assertEquals(
        Intencion.Eliminar(Elemento.ACTIVIDAD, "clase", null, null, hoy.plusDays(1)), i("Elimina la clase de mañana"),
    )

    @Test fun cancelarLaAlarmaSigueSiendoDesactivar() =
        assertEquals(Intencion.CambiarAlarma(false, null, null), i("Cancela la alarma"))

    @Test fun mueveActividad() = assertEquals(
        Intencion.MoverActividad("laboratorio de quimica", LocalDate.of(2026, 10, 30), LocalTime.of(16, 0)),
        i("Mueve el laboratorio de química para el viernes a las cuatro de la tarde"),
    )

    @Test fun renombraTarea() = assertEquals(
        Intencion.RenombrarTarea("informe", "Informe final"), i("Cambia el nombre de la tarea informe por informe final"),
    )

    @Test fun cambiaHoraDeAlarma() = assertEquals(
        Intencion.CambiarHoraAlarma(LocalTime.of(6, 0), null, LocalTime.of(7, 0)), i("Cambia la alarma de las seis a las siete"),
    )

    @Test fun cambiarDescansoSigueSiendoEnfoque() =
        assertEquals(Intencion.ConfigurarDescanso(10), i("Cambia el descanso a diez minutos"))
}
