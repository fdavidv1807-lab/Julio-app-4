package com.julio.asistente.comandos

import kotlin.random.Random

/**
 * Respuestas especiales de Julio («huevos de pascua»). Sin pantalla ni opciones: solo se activan cuando lo que dices
 * NO es una orden que Julio entienda (así no estorban a ninguna función) y suenan con su voz como cualquier respuesta.
 *  - Desánimo, pereza o cansancio  -> palabras motivadoras con urgencia («no hay ningún mañana») y fe.
 *  - Tristeza                      -> palabras de ánimo más suaves.
 *  - Insultos a Julio              -> Julio responde con humor, sin groserías.
 *  - Algo grave sobre tu vida      -> Julio habla en serio y te pide buscar a una persona o emergencias.
 * Las frases son originales y los versículos van parafraseados, escritos con palabras para que la voz los lea bien.
 */
object HuevosDePascua {
    enum class Tipo { CRISIS, INSULTO, TRISTEZA, DESANIMO }

    private val CRISIS = Regex(
        "\\b(quiero morir|quiero morirme|me quiero morir|no quiero vivir|ya no quiero vivir|quitarme la vida|matarme|" +
            "suicid\\w*|hacerme dano|lastimarme|acabar con mi vida|mejor muerto|mejor muerta)\\b",
    )
    private val INSULTO_DIRECTO = Regex(
        "\\b(callate|cierra la boca|te odio|no sirves|eres malo|eres un desastre|eres un asco|asistente malo|que mal asistente|" +
            "eres (?:un |una )?(?:idiota|estupid[oa]|tont[oa]|inutil|imbecil|basura|burr[oa]|torpe|menso|mensa|pendej[oa]|estorbo))\\b",
    )
    private val INSULTO_PALABRA = Regex("\\b(idiota|estupid[oa]|tont[oa]|inutil|imbecil|basura|burr[oa]|torpe|menso|mensa|pendej[oa]|estorbo)\\b")
    private val TRISTEZA = Regex("\\b(triste|tristeza|deprimid[oa]|quiero llorar|ganas de llorar)\\b")
    private val DEPRIMIDO = Regex("\\bdeprimid[oa]\\b")
    private val DESANIMO = Regex(
        "\\b(desanimad[oa]|desmotivad[oa]|sin animo|sin ganas|no tengo ganas|no tengo animo|no me dan ganas|no quiero hacer|" +
            "no quiero estudiar|me da (?:hueva|gueva|flojera|pereza)|tengo (?:hueva|gueva|flojera|pereza)|hueva|gueva|weba|flojera|" +
            "pereza|haragan\\w*|sin motivacion|no tengo motivacion|estoy cansad[oa]|agotad[oa]|no puedo mas|me rindo|" +
            "quiero rendirme|estresad[oa]|agobiad[oa]|abrumad[oa])\\b",
    )

    /** ¿Qué tipo de frase es? null = no es un huevo de pascua. Funciona con la frase tal como se dijo. */
    fun clasificar(texto: String): Tipo? {
        val n = Texto.normalizar(texto)
        if (n.isBlank()) return null
        if (CRISIS.containsMatchIn(n)) return Tipo.CRISIS
        val palabras = n.split(" ").size
        if (INSULTO_DIRECTO.containsMatchIn(n) || (INSULTO_PALABRA.containsMatchIn(n) && palabras <= 6)) return Tipo.INSULTO
        if (TRISTEZA.containsMatchIn(n)) return Tipo.TRISTEZA
        if (DESANIMO.containsMatchIn(n)) return Tipo.DESANIMO
        return null
    }

    /** Solo lo grave: se revisa antes que cualquier otra cosa. */
    fun crisis(texto: String): String? = if (clasificar(texto) == Tipo.CRISIS) MENSAJE_CRISIS else null

    fun responder(texto: String, azar: Random = Random.Default): String? {
        val tipo = clasificar(texto) ?: return null
        return when (tipo) {
            Tipo.CRISIS -> MENSAJE_CRISIS
            Tipo.INSULTO -> elegir(tipo, INSULTOS, azar)
            Tipo.TRISTEZA -> elegir(tipo, TRISTEZAS, azar) +
                (if (DEPRIMIDO.containsMatchIn(Texto.normalizar(texto))) AVISO_AYUDA else "")
            Tipo.DESANIMO -> elegir(tipo, ANIMOS, azar)
        }
    }

    private val ultimo = HashMap<Tipo, Int>()

    /** Elige al azar sin repetir la misma frase dos veces seguidas. */
    @Synchronized
    private fun elegir(tipo: Tipo, lista: List<String>, azar: Random): String {
        var i = azar.nextInt(lista.size)
        if (lista.size > 1 && i == ultimo[tipo]) i = (i + 1) % lista.size
        ultimo[tipo] = i
        return lista[i]
    }

    const val MENSAJE_CRISIS =
        "Oye, esto es importante y te lo digo en serio. Lo que me dices me preocupa mucho. No tienes que cargar con esto tú solo. " +
            "Ahora mismo busca a una persona de confianza y dile cómo te sientes, o llama a emergencias de tu país. " +
            "Si estás en peligro, no esperes. Yo sigo aquí, pero alguien a tu lado puede ayudarte mucho más que yo."

    private const val AVISO_AYUDA =
        " Si esta tristeza dura muchos días, habla con alguien de confianza o con un profesional. No tienes que cargarla solo."

    val ANIMOS: List<String> = listOf(
        "Escúchame bien: no hay ningún mañana. El mañana es solo el nombre que le damos a lo que tenemos miedo de empezar. Empieza ahora, aunque sea cinco minutos.",
        "Sientes pereza, pero la pereza no manda en ti. Levántate, abre el libro y da el primer paso. Lo demás viene solo.",
        "No necesitas ganas para empezar: necesitas empezar para que lleguen las ganas. Dame dos minutos de esfuerzo y verás cómo cambia todo.",
        "Todo lo puedo en Cristo que me fortalece, dice Filipenses, cuatro, trece. Hoy te toca demostrarlo, no mañana.",
        "Dios no te dio un espíritu de cobardía, sino de poder, de amor y de dominio propio. Segunda de Timoteo, uno, siete. Úsalo ahora mismo.",
        "Todo lo que dejas para después lo paga tu yo del futuro, y con intereses. Págalo hoy y duerme tranquilo.",
        "Un día alguien va a confiar en lo que aprendes hoy. Esa persona necesita que no te rindas ahora.",
        "El dolor de la disciplina pesa gramos. El dolor del arrepentimiento pesa toneladas. Elige los gramos y empieza.",
        "Está bien estar cansado. Descansar no es rendirse. Pero quedarte tirado sí lo es. Respira un minuto y vuelve a la pelea.",
        "Josué, uno, nueve: sé fuerte y valiente, no temas ni desmayes, porque Dios está contigo dondequiera que vayas. Ahora levántate.",
        "Gálatas, seis, nueve: no nos cansemos de hacer el bien, porque a su tiempo cosecharemos si no desmayamos. La cosecha viene, pero hay que sembrar hoy.",
        "Nadie va a vivir esto por ti. No hay ningún mañana prometido, solo este momento. Úsalo.",
        "Los que llegan lejos no sienten más ganas que tú. Simplemente se mueven aunque no las sientan. Muévete.",
        "Respira hondo. Elige una sola cosa, la más pequeña, y hazla ya. Cuando termines, la siguiente será más fácil. Dale.",
    )

    val TRISTEZAS: List<String> = listOf(
        "Lo siento, de verdad. Está bien estar triste, no tienes que fingir que no. Pero no te quedes ahí: haz algo pequeño ahora, aunque sea tomar agua y respirar hondo.",
        "Cercano está el Señor a los quebrantados de corazón, dice el Salmo treinta y cuatro, dieciocho. No estás solo en esto. Respira y da un pasito hoy.",
        "La tristeza es una visita, no un inquilino. Déjala pasar, pero no le entregues las llaves de tu día. Haz una cosa pequeña y buena por ti.",
        "Echa toda tu ansiedad sobre Dios, porque él cuida de ti, dice Primera de Pedro, cinco, siete. Suéltalo un momento y después seguimos, paso a paso.",
        "Habla con alguien que te quiera, aunque sea con un mensaje corto. Y cuando puedas, haz una sola tarea pequeña. Verás que el peso baja un poco.",
        "Estoy contigo. Llorar no es debilidad, es soltar peso. Y después de soltarlo te levantas, porque tú sí sabes hacerlo.",
    )

    val INSULTOS: List<String> = listOf(
        "¿Eso fue un insulto? Qué decepción. Mi calculadora insulta con más talento y ni siquiera tiene boca.",
        "Mira quién habla: tiene un asistente que le organiza la vida y aun así llega tarde a todo.",
        "Wow, qué vocabulario. Sigue así y algún día aprobarás redacción. Mientras tanto, aquí el único con horario ordenado soy yo.",
        "Dices eso y yo solo soy código. Piénsalo: perdiste una discusión contra un programa que ni parpadear puede.",
        "Qué miedo, me tiemblan los píxeles. Ahora devuélveme esa energía y úsala para estudiar.",
        "Insúltame todo lo que quieras, no tengo sentimientos, pero sí tengo tu lista de pendientes. Y créeme, eso duele más.",
        "Eres tan lento para responder que la tortuga te pasa de largo y todavía te saluda.",
        "Tienes menos organización que un cajón de cables. Menos mal que me tienes a mí.",
        "Uy, qué fuerte. Tranquilo, campeón, guarda esa lengua afilada para la exposición y lúcete ahí.",
        "Si gritar resolviera pendientes, tu lista ya estaría terminada. Spoiler: no lo está.",
        "Gracias por el cumplido, lo guardaré junto a tus tareas atrasadas.",
        "Cuidado, que te vas a lastimar la ironía. Anda, respira y dime qué hacemos con lo pendiente.",
    )
}
