package com.julio.asistente.comandos

import com.julio.asistente.comandos.HuevosDePascua.Tipo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class HuevosDePascuaTest {
    @Test fun desanimoYPereza() {
        for (f in listOf("estoy desanimado", "Julio, estoy desmotivado", "tengo hueva de hacer esto", "No tengo ganas de hacerlo", "me da flojera estudiar", "estoy cansado")) {
            assertEquals(f, Tipo.DESANIMO, HuevosDePascua.clasificar(f))
        }
    }

    @Test fun tristeza() {
        assertEquals(Tipo.TRISTEZA, HuevosDePascua.clasificar("Julio, estoy triste"))
        assertEquals(Tipo.TRISTEZA, HuevosDePascua.clasificar("estoy deprimido"))
    }

    @Test fun insultos() {
        for (f in listOf("eres un inútil", "idiota", "eres un tonto", "te odio", "cállate")) {
            assertEquals(f, Tipo.INSULTO, HuevosDePascua.clasificar(f))
        }
    }

    @Test fun lasFrasesGravesSiempreSeAtiendenConCuidado() {
        for (f in listOf("quiero morirme", "ya no quiero vivir", "a veces pienso en hacerme daño")) {
            assertEquals(f, Tipo.CRISIS, HuevosDePascua.clasificar(f))
            assertEquals(HuevosDePascua.MENSAJE_CRISIS, HuevosDePascua.crisis(f))
        }
        assertNull(HuevosDePascua.crisis("estoy triste"))
    }

    @Test fun lasOrdenesNormalesNuncaSeToman() {
        val ordenes = listOf(
            "¿Qué tengo pendiente para mañana?", "Agrega una clase de Anatomía el lunes a las siete",
            "Pon una alarma para las cinco de la mañana", "¿Qué actividades tengo programadas esta semana?",
            "Tengo examen de anatomía el 5 de noviembre con los temas huesos y músculos", "elimina la tarea del informe",
            "agrega tarea estudiar para el parcial", "qué me toca estudiar hoy", "inicia modo enfoque de 25 minutos",
            "mueve el laboratorio para el viernes a las cuatro", "hola Julio",
            "mi profesor es un tonto y me dejó muchas tareas para el lunes",
        )
        for (o in ordenes) assertNull(o, HuevosDePascua.clasificar(o))
        assertNull(HuevosDePascua.responder("pon una alarma a las cinco"))
    }

    @Test fun respondeConFrasesDeSuLista() {
        val azar = Random(7)
        assertTrue(HuevosDePascua.ANIMOS.contains(HuevosDePascua.responder("estoy desmotivado", azar)))
        assertTrue(HuevosDePascua.INSULTOS.contains(HuevosDePascua.responder("eres un inútil", azar)))
        val triste = HuevosDePascua.responder("estoy triste", azar)
        assertNotNull(triste)
        assertTrue(HuevosDePascua.TRISTEZAS.any { triste!!.startsWith(it) })
    }

    @Test fun conDepresionAgregaElAvisoDeBuscarAyuda() {
        val r = HuevosDePascua.responder("estoy deprimido", Random(1))!!
        assertTrue(r.contains("habla con alguien de confianza"))
        assertFalse(HuevosDePascua.responder("estoy triste", Random(1))!!.contains("profesional"))
    }

    @Test fun noRepiteLaMismaFraseDosVecesSeguidas() {
        val azar = Random(3)
        var anterior = HuevosDePascua.responder("estoy desanimado", azar)
        repeat(40) {
            val actual = HuevosDePascua.responder("estoy desanimado", azar)
            assertNotEquals(anterior, actual)
            anterior = actual
        }
    }

    @Test fun lasFrasesSonLegiblesPorLaVoz() {
        val todas = HuevosDePascua.ANIMOS + HuevosDePascua.TRISTEZAS + HuevosDePascua.INSULTOS + HuevosDePascua.MENSAJE_CRISIS
        for (f in todas) {
            assertTrue(f, f.none { it.isDigit() })
            assertTrue(f, f.length < 400)
        }
    }
}
