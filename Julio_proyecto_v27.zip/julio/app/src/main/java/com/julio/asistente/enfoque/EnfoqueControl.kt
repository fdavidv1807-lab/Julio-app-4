package com.julio.asistente.enfoque

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.bloqueo.BloqueoConfig
import com.julio.asistente.bloqueo.BloqueoControl
import com.julio.asistente.core.Permisos
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Estado y control de la sesión de enfoque. El estado vive en SharedPreferences, así sobrevive
 * al cierre de la app; el fin de la sesión lo avisa AlarmManager, no un temporizador de la pantalla.
 * Esto mide tiempo y avisa; el bloqueo de apps lo hace BloqueoService (y el enfoque estricto añade reglas, ver Estricto).
 */
object EnfoqueControl {
    private const val ARCHIVO = "enfoque"
    private const val ID_PROGRESO = 5001
    private const val ID_FIN = 5002
    private const val ID_AVISO = 5003
    private const val ACCION_VIGILANTE = "com.julio.asistente.ENFOQUE_VIGILANTE"
    private const val ACCION_FIN = "com.julio.asistente.ENFOQUE_FIN"

    private val _sesion = MutableStateFlow(Sesion())
    val sesion: StateFlow<Sesion> = _sesion.asStateFlow()

    private val _preferencias = MutableStateFlow(Preferencias())
    val preferencias: StateFlow<Preferencias> = _preferencias.asStateFlow()

    private var cargado = false

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    @Synchronized
    fun cargar(c: Context) {
        if (cargado) return
        val p = sp(c)
        _preferencias.value = Preferencias(p.getInt("enfoqueMin", 25), p.getInt("descansoMin", 5))
        val estado = runCatching { EstadoSesion.valueOf(p.getString("estado", "INACTIVA") ?: "INACTIVA") }
            .getOrDefault(EstadoSesion.INACTIVA)
        val fase = runCatching { Fase.valueOf(p.getString("fase", "ENFOQUE") ?: "ENFOQUE") }
            .getOrDefault(Fase.ENFOQUE)
        _sesion.value = Sesion(
            estado, fase,
            p.getLong("duracionMs", 0L), p.getLong("finMs", 0L), p.getLong("restanteMs", 0L),
            p.getBoolean("estricto", false),
        )
        cargado = true
        reprogramar(c)
    }

    /** Tras reiniciar o actualizar la app el sistema olvida la alarma: se vuelve a armar o se cierra la sesión. */
    @Synchronized
    fun reprogramar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) {
            BloqueoControl.sincronizar(c)
            return
        }
        if (System.currentTimeMillis() >= s.finMs) {
            terminar(c)
        } else {
            programarAlarma(c, s.finMs)
            notificarProgreso(c, s)
            if (s.estricto) armarVigilante(c)
            BloqueoControl.sincronizar(c)
        }
    }

    private fun guardar(c: Context, s: Sesion) {
        _sesion.value = s
        sp(c).edit()
            .putString("estado", s.estado.name)
            .putString("fase", s.fase.name)
            .putLong("duracionMs", s.duracionMs)
            .putLong("finMs", s.finMs)
            .putLong("restanteMs", s.restanteMs)
            .putBoolean("estricto", s.estricto)
            .commit()
    }

    @Synchronized
    fun guardarPreferencias(c: Context, p: Preferencias) {
        cargar(c)
        _preferencias.value = p
        sp(c).edit().putInt("enfoqueMin", p.enfoqueMin).putInt("descansoMin", p.descansoMin).commit()
    }

    @Synchronized
    fun iniciar(c: Context, fase: Fase, duracionMs: Long) {
        cargar(c)
        if (duracionMs <= 0L) return
        // Una sesión nueva ya no es la de estudio que estuviera marcada (el plan la vuelve a marcar si hace falta).
        com.julio.asistente.estudio.EstudioRepo.limpiarEnCurso(c)
        cancelarAlarma(c)
        val fin = System.currentTimeMillis() + duracionMs
        val s = Sesion(EstadoSesion.CORRIENDO, fase, duracionMs, fin, 0L)
        guardar(c, s)
        programarAlarma(c, fin)
        NotificationManagerCompat.from(c).cancel(ID_FIN)
        notificarProgreso(c, s)
        BloqueoControl.sincronizar(c)
    }

    @Synchronized
    fun pausar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) return
        if (s.estricto) return // en modo estricto no hay pausa
        cancelarAlarma(c)
        NotificationManagerCompat.from(c).cancel(ID_PROGRESO)
        val restante = (s.finMs - System.currentTimeMillis()).coerceAtLeast(0L)
        guardar(c, s.copy(estado = EstadoSesion.PAUSADA, finMs = 0L, restanteMs = restante))
        BloqueoControl.sincronizar(c)
    }

    @Synchronized
    fun reanudar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.PAUSADA) return
        val fin = System.currentTimeMillis() + s.restanteMs
        val nueva = s.copy(estado = EstadoSesion.CORRIENDO, finMs = fin, restanteMs = 0L)
        guardar(c, nueva)
        programarAlarma(c, fin)
        notificarProgreso(c, nueva)
        BloqueoControl.sincronizar(c)
    }

    /** Cancela la sesión (o cierra el aviso de «terminada»): vuelve a INACTIVA. En modo estricto NO se puede mientras corre. */
    @Synchronized
    fun finalizar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estricto && (s.estado == EstadoSesion.CORRIENDO || s.estado == EstadoSesion.PAUSADA)) return
        cerrar(c)
    }

    private fun cerrar(c: Context) {
        cargar(c)
        val previo = _sesion.value.estado
        cancelarAlarma(c)
        cancelarVigilante(c)
        sp(c).edit().putLong("salidaDesdeMs", 0L).commit()
        val nm = NotificationManagerCompat.from(c)
        nm.cancel(ID_PROGRESO)
        nm.cancel(ID_FIN)
        guardar(c, Sesion())
        // Cancelar a mitad de una sesión de estudio no la da por hecha.
        if (previo == EstadoSesion.CORRIENDO || previo == EstadoSesion.PAUSADA) {
            com.julio.asistente.estudio.EstudioRepo.limpiarEnCurso(c)
        }
        BloqueoControl.sincronizar(c)
    }

    /** La hora de fin llegó (la llama el receptor de la alarma, o la pantalla si estaba abierta). */
    @Synchronized
    fun terminar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) return
        if (System.currentTimeMillis() < s.finMs - 2_000L) return
        cancelarAlarma(c)
        cancelarVigilante(c)
        NotificationManagerCompat.from(c).cancel(ID_PROGRESO)
        guardar(c, s.copy(estado = EstadoSesion.TERMINADA, finMs = 0L, restanteMs = 0L))
        notificarFin(c, s.fase, s.estricto)
        // Si era una sesión de estudio: se da por hecha (cuenta para la racha) y se pedirá «¿cómo te fue?».
        if (s.fase == Fase.ENFOQUE) com.julio.asistente.estudio.EstudioRepo.enfoqueTerminado(c)
        BloqueoControl.sincronizar(c)
    }

    // ---- Modo estricto ----

    /** Motivo por el que NO se puede empezar un enfoque estricto ahora, o null si se puede. */
    @Synchronized
    fun puedeEstricto(c: Context, minutos: Int): String? {
        cargar(c)
        if (!Estricto.duracionValida(minutos)) return "El modo estricto va de 1 minuto a 3 horas."
        val st = _sesion.value.estado
        if (st == EstadoSesion.CORRIENDO || st == EstadoSesion.PAUSADA) return "Ya hay una sesión en curso."
        BloqueoConfig.cargar(c)
        if (!BloqueoConfig.activo.value || BloqueoConfig.paquetes.value.isEmpty()) {
            return "Primero activa el bloqueo de apps y elige cuáles bloquear, en la pantalla Enfoque."
        }
        if (!BloqueoControl.permisos(c).ok) {
            return "Faltan los permisos del bloqueo (acceso de uso y superposición). Dalos en la pantalla Enfoque."
        }
        return null
    }

    /** Empieza un enfoque estricto. Devuelve el motivo si no se pudo, o null si ya está en marcha. */
    @Synchronized
    fun iniciarEstricto(c: Context, duracionMs: Long): String? {
        cargar(c)
        val motivo = puedeEstricto(c, (duracionMs / 60_000L).toInt())
        if (motivo != null) return motivo
        if (_sesion.value.estado == EstadoSesion.TERMINADA) cerrar(c)
        iniciar(c, Fase.ENFOQUE, duracionMs)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) return "No pude iniciar la sesión."
        sp(c).edit().putLong("salidaDesdeMs", 0L).commit()
        guardar(c, s.copy(estricto = true))
        armarVigilante(c)
        notificarProgreso(c, _sesion.value)
        BloqueoControl.sincronizar(c)
        return null
    }

    /** Empieza (o recuerda) la espera de 10 minutos para poder salir. Devuelve cuándo empezó. */
    @Synchronized
    fun solicitarSalida(c: Context): Long {
        cargar(c)
        val p = sp(c)
        val previa = p.getLong("salidaDesdeMs", 0L)
        if (previa > 0L) return previa
        val ahora = System.currentTimeMillis()
        p.edit().putLong("salidaDesdeMs", ahora).commit()
        return ahora
    }

    /** Termina un enfoque estricto antes de tiempo. Solo funciona si ya pasó la espera. Cuenta como sesión rota. */
    @Synchronized
    fun finalizarEstricto(c: Context): Boolean {
        cargar(c)
        val s = _sesion.value
        if (!s.estricto || (s.estado != EstadoSesion.CORRIENDO && s.estado != EstadoSesion.PAUSADA)) return false
        val p = sp(c)
        val desde = p.getLong("salidaDesdeMs", 0L)
        if (desde <= 0L || Estricto.esperaRestanteMs(desde, System.currentTimeMillis()) > 0L) return false
        p.edit().putInt("rotas", p.getInt("rotas", 0) + 1).commit()
        cerrar(c)
        avisar(c, "Sesión estricta rota", "Saliste antes de tiempo. Llevas ${rotas(c)} sesión(es) rota(s).")
        return true
    }

    fun rotas(c: Context): Int = sp(c).getInt("rotas", 0)

    private fun pendienteVigilante(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 33,
            Intent(c, VigilanteReceiver::class.java).setAction(ACCION_VIGILANTE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun armarVigilante(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60_000L, pendienteVigilante(c))
    }

    private fun cancelarVigilante(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendienteVigilante(c)
        am.cancel(pi)
        pi.cancel()
    }

    /** La llama el vigilante cada minuto: reactiva el bloqueo si el sistema lo cerró y vuelve a armarse. */
    @Synchronized
    fun vigilar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (!s.estricto || s.estado != EstadoSesion.CORRIENDO) return
        if (System.currentTimeMillis() >= s.finMs) {
            terminar(c)
        } else {
            BloqueoControl.sincronizar(c)
            armarVigilante(c)
        }
    }

    /** Aviso con sonido (por ejemplo: intentaste abrir una app bloqueada). */
    fun avisar(c: Context, titulo: String, texto: String) {
        val n = NotificationCompat.Builder(c, Canales.ENFOQUE_AVISO)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setStyle(NotificationCompat.BigTextStyle().bigText(texto))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(abrirApp(c))
            .build()
        enviar(c, ID_AVISO, n)
    }

    // ---- Alarma del sistema ----

    private fun pendienteFin(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 31,
            Intent(c, EnfoqueReceiver::class.java).setAction(ACCION_FIN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun programarAlarma(c: Context, finMs: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendienteFin(c)
        try {
            if (Permisos.alarmasExactas(c)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finMs, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finMs, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finMs, pi)
        }
    }

    private fun cancelarAlarma(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendienteFin(c)
        am.cancel(pi)
        pi.cancel()
    }

    // ---- Notificaciones ----

    private fun abrirApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 32, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun enviar(c: Context, id: Int, n: android.app.Notification) {
        try {
            NotificationManagerCompat.from(c).notify(id, n)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones: el temporizador sigue funcionando dentro de la app.
        }
    }

    private fun notificarProgreso(c: Context, s: Sesion) {
        val titulo = if (s.estricto) "Enfoque ESTRICTO en curso"
        else if (s.fase == Fase.ENFOQUE) "Enfoque en curso" else "Descanso en curso"
        val detalle = if (s.estricto) "No se puede terminar antes de tiempo" else "Tiempo restante"
        val n = NotificationCompat.Builder(c, Canales.ENFOQUE_PROGRESO)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle(titulo)
            .setContentText(detalle)
            .setWhen(s.finMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(abrirApp(c))
            .build()
        enviar(c, ID_PROGRESO, n)
    }

    private fun notificarFin(c: Context, fase: Fase, estricto: Boolean = false) {
        val titulo = if (estricto) "Modo estricto completado"
        else if (fase == Fase.ENFOQUE) "Hey, ya terminó tu enfoque" else "Hey, ya terminó tu descanso"
        val texto = if (estricto) "Lo lograste: aguantaste hasta el final. Ya puedes usar tus apps."
        else if (fase == Fase.ENFOQUE) "Buen trabajo. Es hora de un descanso." else "Listo para volver a enfocarte."
        val n = NotificationCompat.Builder(c, Canales.ENFOQUE_FIN)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(abrirApp(c))
            .build()
        enviar(c, ID_FIN, n)
    }
}
