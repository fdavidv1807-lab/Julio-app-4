package com.julio.asistente.recordatorios

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.avisos.AvisosAjustes
import com.julio.asistente.avisos.CalculoAvisos
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.data.local.TareaEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

/** Llega aquí el aviso de una actividad o tarea a su hora. */
class RecordatorioReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val tipo = intent.getStringExtra(RecordatorioProgramador.EXTRA_TIPO) ?: return
        val id = intent.getLongExtra(RecordatorioProgramador.EXTRA_ID, -1L)
        if (id < 0) return
        val app = context.applicationContext
        val pendiente = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = JulioDatabase.get(app)
                if (tipo == RecordatorioProgramador.TIPO_ACTIVIDAD) {
                    val a = db.actividadDao().porId(id)
                    if (a != null && CalculoAvisos.minutosAviso(a.recordatorioMin, AvisosAjustes.horarioPorDefecto(app)) != null) {
                        avisarActividad(app, a)
                        // Si se repite, dejar armado el siguiente aviso (margen de 1 min).
                        RecordatorioProgramador.programarActividad(app, a, ZonedDateTime.now().plusSeconds(60))
                    }
                } else {
                    val t = db.tareaDao().porId(id)
                    if (t != null && !t.completada) avisarTarea(app, t)
                }
            } finally {
                pendiente.finish()
            }
        }
    }

    private fun avisarActividad(c: Context, a: ActividadEntity) {
        val min = CalculoAvisos.minutosAviso(a.recordatorioMin, AvisosAjustes.horarioPorDefecto(c)) ?: 0
        val hora = Fechas.textoHora(Instant.ofEpochMilli(a.inicio).atZone(ZoneId.systemDefault()).toLocalTime())
        val texto = if (min == 0) "Empieza ahora · $hora" else "Empieza a las $hora (en ${textoAntelacion(min)})"
        enviar(c, 100_000 + a.id.toInt(), a.titulo, texto)
    }

    private fun avisarTarea(c: Context, t: TareaEntity) {
        enviar(c, 200_000 + t.id.toInt(), "Hey, tienes pendiente: ${t.titulo}", "Su fecha límite es hoy.")
    }

    private fun enviar(c: Context, id: Int, titulo: String, texto: String) {
        val abrir = PendingIntent.getActivity(
            c, 40, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(c, Canales.RECORDATORIOS)
            .setSmallIcon(R.drawable.ic_alarma)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(abrir)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(id, n)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones no se puede avisar; las pantallas lo advierten.
        }
    }
}
