# PLAN DE TRABAJO — Proyecto Julio

> Fuente principal de continuidad. Léelo primero; no releas todo el documento de requisitos.
> Última actualización: Tareas verificada; Horario y Alarmas compilan (alarmas: corregido permiso exacto en v07/v08, pendiente de confirmar); Enfoque y Metas escritos (sin compilar).

## 1. Decisiones técnicas
| Tema | Decisión | Motivo |
|---|---|---|
| Lenguaje / UI | **Kotlin nativo + Jetpack Compose (Material 3)** | Alarmas exactas, servicios en segundo plano, AccessibilityService/UsageStats y SpeechRecognizer/TextToSpeech son APIs nativas de Android; sin capa intermedia. |
| minSdk / target | 26 (Android 8.0) / 35 | Iconos adaptativos y canales de notificación sin parches. |
| Almacenamiento | **Room (SQLite)** 2.6.1 vía KSP; DataStore para preferencias (Etapa 5+) | Persistencia local, consultas por fecha, sin servidor. |
| Arquitectura | UI (Compose) → ViewModel → repositorio → DAO. Interpretación de comandos separada de UI y datos. | Requisito 3 y 11. |
| Build | Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01 | Combinación compatible conocida. |
| Paquete | `com.julio.asistente` | |

## 2. Estructura
```
app/src/main/java/com/julio/asistente/
  JulioApp.kt, MainActivity.kt
  ui/ (JulioRoot, navigation/, theme/, components/, screens/)
  data/local/ (Entidades, Daos, JulioDatabase)
  voz/ comandos/ horario/ tareas/ alarmas/ metas/ enfoque/ core/   <- reservados (LEEME.txt)
```

## 3. Limitaciones de Android a abordar
- **Voz**: `SpeechRecognizer` necesita permiso RECORD_AUDIO; el reconocimiento offline depende del paquete de idioma y del dispositivo. `TextToSpeech` usará la mejor voz masculina en español instalada (la disponibilidad varía por fabricante). Servicio externo de voz/IA: solo con aviso de datos enviados, coste y clave guardada fuera del repositorio.
- **Conversación real**: requiere un modelo de lenguaje externo (API con clave del usuario). Sin ella, solo comandos estructurados; no se simulará con respuestas fijas.
- **Alarmas**: `AlarmManager.setAlarmClock()` / exactas (`SCHEDULE_EXACT_ALARM` en Android 12+, `POST_NOTIFICATIONS` en 13+), reprogramar tras reinicio (`BOOT_COMPLETED`). Restricciones de batería por fabricante: se documentarán.
- **Bloqueo de apps**: solo viable con `PACKAGE_USAGE_STATS` + superposición o `AccessibilityService`, con consentimiento explícito. Se entrega primero el temporizador funcional.

## 3b. Referencia visual de la pantalla Voz (pedida por el usuario)
Imagen: `docs/referencia_voz_orbe.jpg`. Muestra a Julio dentro de un orbe azul neón con anillos y una onda de audio debajo, el título «JULIO» arriba y el estado «Escuchando...» abajo.
Decisiones para la Etapa 3b/8:
- El orbe se dibuja en Compose (anillos y barras de onda animados) alrededor del gorila original; la imagen de referencia tiene el texto «Escuchando...» fijo, así que no se usa tal cual.
- El texto de estado cambia según el estado real: Escuchando / Procesando / Respondiendo / En reposo.
- La animación solo se activa cuando el reconocimiento de voz esté realmente escuchando (nunca decorativa).
- El gorila debe seguir siendo la imagen original del usuario.

## 4. Estado de las etapas
| Etapa | Estado |
|---|---|
| 1 Planificación | ✅ Hecha (este documento) |
| 2 Base (proyecto, navegación, tema, Room) | ✅ Compila en GitHub Actions; abre en el teléfono, las 5 pestañas navegan |
| 3 Identidad visual | ✅ Icono real y mascota; pantalla Voz con orbe animado (sin probar en teléfono) |
| 4 Horario y Tareas | 🟡 Tareas ✅ (el usuario confirmó que funciona); Horario escrito, **sin compilar ni probar** |
| 5 Alarmas y recordatorios | 🟡 Escritas (AlarmManager.setAlarmClock + servicio + pantalla de alarma), **sin compilar ni probar**. Recordatorios de Horario/Tareas: pendientes (requieren migración de BD v1→v2) |
| 6 Modo enfoque | 🟡 Temporizador real + bloqueo de apps con consentimiento escritos (sin compilar/probar) |
| 7 Mis metas | 🟡 CRUD + progreso escrito dentro de Voz (sin compilar/probar) |
| 8 Voz e inteligencia | 🟡 Voz (SpeechRecognizer + TextToSpeech), orbe, guía e intérprete local escritos (sin compilar/probar). IA externa para conversación general: PENDIENTE |
| 9 Integración, pruebas, APK de producción | ⬜ |

## 5. Qué se verificó y qué NO
**Verificado en teléfono real (APK debug de la Etapa 2)**: la app abre, las 5 pestañas navegan, la mascota se ve completa en Voz.
**Sin confirmar**: que el icono aparezca en el lanzador (el usuario aún no lo reportó).
**Tareas**: compilada por Actions y probada por el usuario en su teléfono (funciona).
**Horario** y **Alarmas**: código escrito sin SDK; **no compilados ni probados**. Se verificarán con el siguiente build y en el teléfono. Las alarmas **solo pueden validarse en un dispositivo real**.
**No hay APK de producción** (solo debug).
Pruebas automatizadas: ninguna todavía.

## 6. Cómo compilar
- **Android Studio** (recomendado): abrir la carpeta, dejar sincronizar Gradle, `Build > Build APK(s)`. Ruta: `app/build/outputs/apk/debug/app-debug.apk`.
- **GitHub Actions**: `.github/workflows/build.yml` compila en cada push a `desarrollo-julio` y sube la APK como artefacto.
- El wrapper (`gradlew`) no está incluido; Android Studio lo genera, o `gradle wrapper --gradle-version 8.9`.
- APK de producción: requiere keystore propio (Etapa 9). Nunca subirlo al repositorio.

## 7. Errores conocidos / pendientes
- Enfoque es un aviso «Aún no implementado».
- Horario: repeticiones calculadas (diaria/semanal/mensual); editar/eliminar afecta a toda la serie; hora de fin opcional, mismo día.
- **Alarmas (Etapa 5, sin probar)**:
  - Mecanismo: `AlarmManager.setAlarmClock()` (atraviesa Doze). **Corrección**: en la v06 se creyó que no necesitaba permiso de alarmas exactas; en Android 12+ SÍ lo necesita (falló en el teléfono real: «No se pudo programar»). Desde la v07 se declaran USE_EXACT_ALARM (13+) y SCHEDULE_EXACT_ALARM (31-32), y la pantalla muestra el motivo técnico real si falla. `AlarmaReceiver` → `AlarmaService` (primer plano, mediaPlayback) → `AlarmaActivity` (sobre pantalla bloqueada). Respaldo: notificación con sonido si el sistema bloquea el servicio.
  - Permisos: USE_EXACT_ALARM, SCHEDULE_EXACT_ALARM (≤32), POST_NOTIFICATIONS (se pide en pantalla Alarmas), USE_FULL_SCREEN_INTENT (Android 14+ puede revocarlo; la pantalla lo avisa), FOREGROUND_SERVICE(+_MEDIA_PLAYBACK), RECEIVE_BOOT_COMPLETED, VIBRATE, WAKE_LOCK.
  - Una sola vez: se fija la fecha concreta al guardar; tras sonar se desactiva. Repetitivas: se reprograma la siguiente al sonar. Posponer = 10 min (constante `MINUTOS_POSPONER`, aún no configurable). Se detiene sola a los 5 min.
  - Se reprograman tras reinicio, actualización de la APK y cambio de hora/zona (`ArranqueReceiver`). Una alarma que vence con el teléfono apagado NO suena después.
  - Dudas a verificar en teléfono real: inicio del servicio desde el receptor (Android 12+), sonido con volumen de alarma, pantalla sobre bloqueo, restricciones de batería/autoarranque del fabricante (Xiaomi, Samsung, etc.: puede requerir permitir «inicio automático» y «sin restricciones de batería»).
  - Sonido: selector del sistema (TYPE_ALARM); si el sonido elegido falla, cae al predeterminado.
- **Enfoque (Etapa 6, sin probar)**: estado en SharedPreferences (`enfoque/EnfoqueControl.kt`), fin avisado por `AlarmManager.setExactAndAllowWhileIdle` (cae a inexacta si falta permiso) → `EnfoqueReceiver`. Notificación con cuenta regresiva (cronómetro) mientras corre; aviso con sonido al terminar. Duraciones personalizadas (1 min–12 h enfoque, 1 min–4 h descanso), presets 25/35/50/70/80 y 5/10/15/20. Pausar/reanudar/finalizar y encadenar descanso. Se reprograma tras reinicio/actualización (`ArranqueReceiver`).
- **Bloqueo de apps (sin probar; es lo más dependiente del fabricante)**: apagado por defecto. En Enfoque, tarjeta «Bloqueo de aplicaciones» con interruptor → diálogo de consentimiento (qué hace, qué permisos, qué nunca bloquea, cómo salir) → el usuario concede en Ajustes: **Acceso de uso** (`PACKAGE_USAGE_STATS`) y **Mostrar sobre otras apps** (`SYSTEM_ALERT_WINDOW`), y elige las apps (lista de apps con icono de lanzador vía `<queries>`). Solo bloquea durante un ENFOQUE en marcha (no pausa ni descanso). Mecanismo: `bloqueo/BloqueoService` (primer plano `specialUse`) consulta `UsageStatsManager.queryEvents` cada 600 ms y, si la app en primer plano está elegida, dibuja una ventana `TYPE_APPLICATION_OVERLAY` con «Ir al inicio» y «Finalizar sesión de enfoque» (2 toques). Nunca bloquea: Julio, marcador/llamadas (`TelecomManager.defaultDialerPackage` + lista fija), emergencias, Ajustes, SystemUI ni el launcher (`BloqueoControl.protegidas`). Se detiene si se apaga el interruptor, se revoca un permiso o termina/pausa el enfoque. No lee contenido de apps ni envía datos.
  - Limitaciones conocidas: el arranque tras reinicio/actualización puede ser bloqueado por Android al iniciar un servicio en primer plano desde segundo plano (se captura el error en `BloqueoControl.ultimoError`); Xiaomi/HyperOS, Samsung, etc. pueden exigir «inicio automático» y batería «sin restricciones»; un usuario puede salirse apagando permisos en Ajustes (por diseño: no se eludirá la protección del sistema).
- **Voz (Etapa 3b/8, sin probar)**:
  - Reconocimiento: `SpeechRecognizer` del teléfono (en muchos equipos necesita internet; el error de red se muestra claro). Permiso RECORD_AUDIO se pide al tocar «Hablar con Julio». Respuesta hablada: `TextToSpeech` en español, tono 0.85 / velocidad 0.95. **No se puede garantizar voz masculina**: depende de las voces instaladas; pendiente un selector de voz.
  - Orbe v13 (`ui/components/Orbe.kt`), pedido del usuario: sin caja, flota sobre el fondo de la app (disco con borde suave), anillos con halo, arcos giratorios, ondas hacia afuera, barras radiales (ecualizador circular) y el gorila (`drawable-nodpi/julio_orbe.png`, MISMO dibujo original sin el fondo azul de la baldosa; el icono de la app no cambia). Al responder, la quijada se estira (división en la línea de la boca, 52.8 % de la imagen, hasta +9 %) al ritmo de cada palabra (`Habla.palabras` ← `onRangeStart`) con un vaivén de respaldo; no es sincronía exacta de labios. En reposo respira muy despacio (animación mínima mientras la pestaña Voz está visible). Referencia original: `docs/referencia_voz_orbe.jpg`. El usuario recuerda un orbe de «las primeras versiones»: esa versión NO estaba disponible para el asistente; pedir captura si se quiere igualar.
  - Guía de comandos en pestañas (chips): Horario, Lista de tareas, Alarmas, Modo enfoque, Mis metas; al tocar una se despliega «Puedes decirle a Julio:» con ejemplos tocables; tocar de nuevo la cierra.
  - Intérprete local (`comandos/`): `Texto` (números, horas, fechas, duraciones) + `Interprete` (frases -> `Intencion`) + `Asistente` (ejecuta contra la BD y **verifica antes de confirmar**). Conversación de varios turnos con `Esperando`. Probado en lógica con un espejo en Python (todas las frases de la guía) y con `InterpreteTest.kt` (ejecutar `gradle testDebugUnitTest` en Android Studio; CI no corre tests).
  - Heurística de hora sin «mañana/tarde»: horario 1–6 = tarde, 7–11 = mañana; alarma 1–11 = mañana. Siempre se repite la hora resuelta al confirmar.
  - Historial de conversación: solo en memoria (no persiste), por diseño de esta versión.
  - Lo que NO hace aún: conversación general («¿cómo funciona X?»). Responde honestamente que no lo entendió como orden. Falta IA externa opcional (clave guardada cifrada, aviso de qué datos se envían y coste).
  - Limitaciones del intérprete: hora de fin («de 8 a 10») no soportada; no edita actividades por voz; eliminar por voz no soportado.
- **Metas (Etapa 7, sin probar)**: `ui/screens/MetasSection.kt` dentro de `VozScreen`: crear, editar (título/descripción/fecha objetivo), actualizar progreso (slider 0–100 %, 100 % = completada), marcar completada, eliminar con confirmación. Voz de metas («Muéstrame mis metas») llega con la etapa de voz.
- **Recordatorios (sin probar)**: Horario → aviso 0/5/10/15/30/60 min antes (columna `actividades.recordatorioMin`, se rearma tras cada aviso si es repetitiva); Tareas → aviso a una hora elegida el día de la fecha límite (`tareas.recordatorioMinutoDia`; se cancela al completar). Mecanismo: `recordatorios/` (AlarmManager exacta + `RecordatorioReceiver` + canal «Recordatorios»); se reprograman tras reinicio/actualización. **Base de datos v2**: migración 1→2 con `ALTER TABLE ... ADD COLUMN` (columnas anulables, no borra datos). Si la app se cierra al abrir tras actualizar, sospechar de esta migración.
- Fecha límite de tareas = medianoche UTC del día elegido (`core/Fechas.kt`).
- Flujo de subida del usuario (celular): sube `Julio_proyecto_vNN.zip` a la raíz del repo; el workflow descomprime el zip de nombre más alto (etapa2, etapa4, v05, v06...).

## 8. Siguiente tarea concreta
0. (v12) Probar Voz: permiso de micrófono, orbe, «Hablar con Julio», comandos de la guía, escribir comandos, respuesta hablada.
1. Compilar y probar en el teléfono: Alarmas (con permiso exacto), Enfoque y Metas.
2. Pantalla Voz con orbe (ver §3b), guía «¿Qué puedo decirle a Julio?» y luego Etapa 8 (voz + intérprete de comandos + IA externa opcional).
4. Etapa 9: pruebas finales y APK de producción firmada.

## 9. Prompt para continuar en otro chat
> Continúa el proyecto Julio (app Android, Kotlin + Compose). Lee primero `PLAN_DE_TRABAJO.md`. No reinicies ni reescribas lo hecho. Estado: Etapas 1-2 escritas (sin compilar), icono listo. Empieza por la «Siguiente tarea concreta». Archivos a revisar: `PLAN_DE_TRABAJO.md`, `app/build.gradle.kts`, `gradle/libs.versions.toml`, `data/local/*`, `ui/JulioRoot.kt`, `ui/screens/*`. Trabaja por etapas, sé honesto sobre lo verificado y actualiza el plan al final.


## v14 — Cabina futurista + saludo + editar/eliminar por voz + selector de voz (entrega combinada 1+2+3-parcial)

Confirmado por el usuario antes de v14: alarmas, recordatorios y diferenciación horario/tareas funcionan perfecto.

- **Diseño «cabina»** (todo el app): tema SIEMPRE oscuro (neón cian/azul, esquinas cortadas, tipografía con letra espaciada), fondo con cuadrícula y resplandor, encabezado con hora y fecha, barra inferior con línea de neón, `PanelJulio` (tarjeta con borde de neón) reemplaza a `Card` en todas las pantallas. Archivos: `ui/theme/*`, `ui/components/Hud.kt`, `ui/JulioRoot.kt`. Barras del sistema forzadas a iconos claros (MainActivity y AlarmaActivity).
- **Orbe holográfico** (`ui/components/Orbe.kt`): gorila protagonista (mismo dibujo recortado, `drawable-nodpi/julio_orbe.png` 568×665), bordes desvanecidos + líneas de holograma + barrido de luz, anillos 3D que giran (mitad detrás/mitad delante), partículas orbitando, plataforma de proyección con ecualizador. Estados: reposo (respira), escuchando (inclina la cabeza, reacciona al micrófono), procesando (anillos rápidos, ojos brillan), respondiendo (quijada se abre al ritmo de cada palabra vía `onRangeStart` + vaivén de respaldo). OJO: nunca compilado/visto en teléfono real al escribir esto; si se ve raro, ajustar proporciones en `Orbe.kt` (gw 0.58, gy 0.115, plataforma 0.87, vignette 0.74).
- **Saludo al abrir** (`Asistente.saludo()` + `VozViewModel`): resumen real de actividades que quedan hoy y tareas pendientes/vencidas; como máximo uno cada 30 min; se puede apagar (switch «Saludo al abrir la app»).
- **Eliminar, mover y renombrar por voz** (`Interprete` + `Asistente` + `Esperando`): eliminar tarea/actividad/alarma/meta SIEMPRE con confirmación sí/no (si hay varias coincidencias, lista y pide cuál); mover actividad («para el viernes a las cuatro»); renombrar tarea; cambiar hora de una alarma («de las seis a las siete»). Se arregló además que «de las seis» (en vez de «a las seis») no se leía como hora al desactivar/activar alarmas. Validado con espejo en Python (`/home/claude/test/nuevas.py`, 38 frases incl. regresiones) + 8 pruebas unitarias nuevas en `InterpreteTest.kt`.
- **Selector de voz** (`voz/Habla.kt`): lista las voces en español instaladas (primero las que no requieren internet), tono 0.5–1.4, velocidad 0.6–1.3, botón «Probar voz», acceso a Ajustes de Android > Texto a voz para instalar más voces. Se guarda en SharedPreferences `julio_voz`.
- **NO incluido todavía**: voz neuronal local tipo Piper (necesita descargar modelos/bibliotecas; el entorno del asistente no tiene red — habría que decidir cómo agregarlos al repo), plan de estudio diario (entrega 4), modo estudio con racha (5), extras: personalidad/clima/copias de seguridad (6), APK de producción firmado (7).
- **Siguiente tarea concreta**: confirmar con el usuario cómo se ve/siente v14 (orbe, estilo, saludo, borrar con confirmación). Luego entrega 4: plan de estudio diario (examen + temas → sesiones de enfoque repartidas por día, aviso diario, «¿cómo te fue?»).


## v15 — Legibilidad desde el origen + horarios de varios días (pedido del usuario)

Prioridad del usuario tras v14: (1) arreglar textos negros/ilegibles, (2) horarios para varios días de la semana. «Olvida lo de la voz» = olvidar la voz neuronal (Piper); los comandos de voz para horarios SÍ se hicieron. El prompt que pasó el usuario hablaba de Flutter/Dart, pero Julio es Kotlin + Compose: se aplicó a este código.

- **Causa del texto negro (error introducido en v14):** `Scaffold(containerColor = Transparent)` dejó el color de contenido por defecto (negro). Arreglo en el origen: `JulioTheme` ahora fija `LocalContentColor` claro para toda la app, y el Scaffold de `JulioRoot` usa `contentColor = onBackground`. Además `onSurfaceVariant` y `outline` más claros. Contrastes medidos (WCAG): texto principal 14–17:1, secundario 10–12:1, botón 13:1, chip 9:1, borde de campos 6:1 (mínimo AA = 4,5:1). Los textos deshabilitados de Material siguen siendo tenues a propósito.
- **Modelo:** `ActividadEntity` +3 columnas anulables (`diasMascara`, `intervaloSemanas`, `excluidas`); Room v3 con `MIGRACION_2_3` (solo ALTER TABLE ADD COLUMN: las actividades existentes no cambian). `Recurrencia.DIAS` nueva; DIARIA/SEMANAL/MENSUAL siguen como antes.
- **Lógica:** `horario/DiasSemana.kt` (máscaras, `primerDia`, `describir`), `Ocurrencias` entiende DIAS (máscara + cada N semanas) y días excluidos. Las repeticiones se calculan, no se duplican.
- **Formulario (HorarioScreen):** sección «Repetir» con: Una sola vez, Todos los días, Lunes a viernes, Fin de semana, Días elegidos (chips Lun..Dom), Cada varias semanas (2/3/4), Cada mes; resumen «Se repetirá de lunes a viernes». Hora de inicio y de fin ya existían. Al editar/eliminar una actividad que se repite se pregunta: solo ese día (se excluye de la serie y, al editar, se crea una actividad suelta) o toda la serie.
- **Voz:** `Interprete.extraerRepeticion` (de lunes a viernes; los lunes, miércoles y viernes; martes y jueves; todos los días; fines de semana; entre semana; cada dos semanas; cada semana/mes) + `RepetirActividad` («repite esta actividad todos los martes y jueves», usa la última actividad agregada). `Asistente.agregarHorario` pregunta lo que falta (nombre, hora, días), guarda, VUELVE A LEER de la base y comprueba tipo de repetición, hora y que el primer día realmente ocurra; solo entonces confirma («He programado «Clases» de lunes a viernes a las 7:00 a. m.»); si no cuadra, borra lo guardado y avisa. Mover una serie por días con una fecha nueva no se permite por voz (se explica cómo cambiar los días).
- **Pruebas:** espejo en Python (`/home/claude/test/rep.py`, 31 frases) + `InterpreteTest` (+9) y `OcurrenciasTest` (nuevo, 10 pruebas). NO se ejecutaron con Gradle (sin toolchain en el entorno del asistente); el CI no corre tests: `gradle testDebugUnitTest`.
- **Aparcado:** borrador del plan de estudio diario en `docs/pendiente_estudio/*.kt.txt` (no compila, no forma parte de la app).
- **Siguiente tarea concreta:** confirmar con el usuario (a) texto legible en todas las pantallas, (b) horarios de varios días por formulario y por voz. Luego retomar plan de estudio (entregas 4+5).


## v16 — Plan de estudio diario + modo estudio (entregas 4+5 juntas)

Estado previo: el usuario no confirmó aún v15 antes de pedir seguir («si sigue si puedes»); v15 (legibilidad + horarios de varios días) sigue SIN confirmación de uso real.

- **Pestaña nueva «Estudio»** (6.ª de la barra, icono School; `ui/screens/EstudioScreen.kt`): racha de días seguidos (y mejor racha), «Hoy toca» (sesiones del día con «Empezar» y «Ya la hice»), «Atrasadas» (con «Hacerla hoy»), «Mis exámenes» (fecha, días que faltan, sesiones hechas, temas, plan día por día, eliminar con confirmación), diálogo «Nuevo examen» (materia, fecha, temas por comas/líneas, bloque de 25/35/45/60 min, vista previa del número de sesiones), 3 tareas pendientes más urgentes, estado del bloqueo de apps, aviso diario con hora elegible.
- **Planificador** (`estudio/ModeloEstudio.kt`, lógica pura): un bloque por día desde hoy hasta el día ANTES del examen (máx. 30 días); con ≥4 días el último es «Repaso general» y con ≥7 los dos últimos; menos temas que días → días de repaso de lo visto; más temas que días → se agrupan (hasta 3 bloques por día).
- **Modo estudio = enfoque + bloqueo + tareas**: «Empezar» inicia una sesión de ENFOQUE con la duración planeada (`EnfoqueControl.iniciar`) y la marca como «en curso»; el bloqueo de apps (si el usuario lo activó) actúa solo. Ganchos pequeños en `EnfoqueControl`: iniciar otra sesión o cancelar a mitad limpia lo «en curso» (no se da por hecha); al terminar un ENFOQUE se da por hecha (cuenta para la racha) y la pantalla pregunta «¿Cómo te fue?» (Bien/Regular/Mal): con Regular o Mal se agrega un refuerzo para mañana si el examen aún no llega.
- **Guardado** (`estudio/EstudioRepo.kt`): SharedPreferences `julio_estudio` (JSON, sin tocar Room; no hay migración). Cada escritura se vuelve a leer y solo entonces se actualiza la pantalla / se confirma.
- **Aviso diario** (`EstudioAviso` + `EstudioReceiver`, receiver nuevo en el manifest): a la hora elegida (19:00 por defecto) dice qué toca y cuántas atrasadas; se rearma tras cada aviso, al abrir la app y tras reiniciar (ArranqueReceiver).
- **Voz**: «tengo examen de anatomía el 5 de noviembre con los temas huesos, músculos y nervios» (pregunta materia / fecha / temas si faltan), «¿qué me toca estudiar hoy?», «empieza mi sesión de estudio», «ya estudié», «¿cómo va mi racha?». Los temas se separan por comas y por «y» (hablando, sin comas, «huesos músculos y nervios» saldría como 2 temas: la confirmación los lista). Frases de otros comandos no cambian (verificado con espejo en Python `est.py` incl. negativos: «agrega examen de química mañana…» sigue siendo horario; «quiero estudiar durante una hora…» sigue siendo enfoque).
- **Pruebas** (NO ejecutadas con Gradle): `EstudioTest` (8), +7 en `InterpreteTest`.
- **Pendiente**: voz neuronal tipo Piper (descargar modelo al primer uso, sin internet después), extras (personalidad, color del orbe, clima, copias de seguridad), APK de producción firmado.
- **Siguiente tarea concreta**: confirmar con el usuario v15 y v16 en teléfono real (textos legibles, horarios de varios días, crear plan de estudio por formulario y por voz, empezar sesión, «¿cómo te fue?», aviso diario).


## v17 — Pulido: editar examen, hora de fin por voz, copia de seguridad, orbe con color

Confirmado por el usuario antes de v17: v15 y v16 compilaron y funcionan («todo salió bien»). Pidió seguir sin elegir ítems; se tomaron los de pulido de mayor valor y sin red.

- **Editar examen** (`EstudioRepo.editar`, icono lápiz en cada examen, mismo diálogo con datos cargados): cambia materia, fecha, temas o bloque; las sesiones YA HECHAS se conservan tal cual, las pendientes se reparten de nuevo desde hoy; si había una sesión de enfoque marcada para ese examen se desmarca.
- **Hora de fin por voz** (`Interprete.rangoHoras`, `AgregarHorario.horaFin`): «de 8 a 10», «de las 2 a las 4 de la tarde», «de 4:30 a 6», «de 11 a 1» (= 11 a. m. a 1 p. m.); mañana/tarde de un extremo vale para el otro; turnos que cruzan la medianoche no se interpretan como rango. Se guarda `fin` y la verificación posterior lo comprueba. Espejo Python: `/home/claude/test/fin.py`.
- **Copia de seguridad** (`respaldo/Respaldo.kt`, `RespaldoViewModel`, `ui/components/RespaldoPanel.kt`, botón «Copia de seguridad» en la pantalla Voz): exporta tareas, actividades (con repeticiones y días excluidos), alarmas, metas y planes de estudio a un JSON que el usuario guarda con el selector de archivos de Android (se vuelve a leer para comprobarlo). Restaurar: valida TODO el archivo antes de tocar nada, muestra qué trae y pide confirmación, guarda una copia automática de lo actual (`filesDir/respaldo_previo.json`), reemplaza en UNA transacción de Room, cancela y vuelve a armar alarmas/recordatorios/aviso de estudio y comprueba los conteos. Los DAOs ganaron `borrarTodo()` (solo se usa al restaurar). NO incluye ajustes de voz ni de enfoque ni la conversación. Nunca probado en teléfono real: probar primero guardar y restaurar en el mismo teléfono.
- **Orbe con color** (`Orbe.colorPorEstado`, switch en Voz): cian en reposo/escuchando, azul lavanda al procesar, dorado al responder, con transición suave.
- **Pruebas**: +4 en `InterpreteTest` (hora de fin). NO ejecutadas con Gradle.
- **Pendiente**: voz neuronal tipo Piper, personalidad serio/amigable, clima en el saludo (necesita internet + ubicación), widget, botones en notificaciones, resumen semanal, APK de producción firmado.
- **Siguiente tarea concreta**: confirmar v17 (sobre todo guardar/restaurar copia) y decidir el siguiente paquete.


## v18 — Rediseño VISUAL (sin cambiar el funcionamiento)

Pedido del usuario: solo estilo. Moderno, elegante, limpio, profesional; sin neón ni excesos futuristas. Distribución: panel izquierdo (secciones), centro (asistente), panel derecho (configuración). NO tocar voz, comandos, datos, permisos, notificaciones, enfoque ni lógica.

- **Paleta/tema** (`ui/theme/Color.kt`, `Theme.kt`, `Apariencia.kt`): grafito azulado + un acento azul suave; tema claro, oscuro o automático (nuevo selector en Configuración > Apariencia, se guarda en SharedPreferences `julio_ui`); formas redondeadas (adiós a las esquinas cortadas), tipografía con tamaños fijos y sin letra espaciada. Se conserva el arreglo de `LocalContentColor` (texto nunca negro sobre oscuro). Contrastes medidos WCAG: texto 14–17:1, secundario 7–8:1, acento 5–8:1 (mínimo AA 4,5:1); bordes de campos 3,6–4,3:1 (mínimo 3:1 para componentes). Barras del sistema con iconos claros/oscuros según el tema (MainActivity y AlarmaActivity); `values-night/colors.xml` para el color de ventana inicial.
- **Distribución** (`ui/JulioRoot.kt`): en teléfono, panel izquierdo = cajón lateral (botón de menú o deslizar desde el borde) con Inicio, Horario, Tareas, Estudio, Alarmas, Enfoque; panel derecho = Configuración que se desliza desde la derecha sobre un fondo atenuado (botón de engranaje; el botón Atrás lo cierra). En pantallas anchas (≥ 840 dp) los dos paneles quedan fijos. Se quitó la barra inferior y el encabezado con reloj/fecha (eran decorativos). «Inicio» = la antigua pantalla Voz (ruta `voz` sin cambios). Rutas y pantallas intactas.
- **«Recordatorios»**: NO existe como pantalla (los avisos viven dentro de Horario y Tareas); no se inventó una sección nueva para no añadir funciones. Si se quiere una vista que junte los avisos, es una función nueva.
- **Configuración** (`ui/screens/Configuracion.kt`): Apariencia (tema + «el orbe cambia de color», movido desde Inicio), Permisos (estado de solo lectura de micrófono, notificaciones, alarmas exactas, pantalla completa, acceso de uso y superposición; «Abrir» usa los mismos intents que ya existían), Voz (el mismo panel de selector de voz/tono/velocidad, movido tal cual), Guía de comandos (misma guía, tocar un ejemplo lo envía y vuelve a Inicio), Copia de seguridad (mismo panel). Secciones plegables.
- **Inicio** (`VozScreen`): conserva avatar, estado, Hablar/Detener, transcripción, errores, campo de texto, interruptores «Respuestas habladas» y «Saludo al abrir», conversación y metas; solo salieron los bloques que pasaron a Configuración.
- **Avatar** (`Orbe.kt`): mismo tamaño/geometría y mismos movimientos (respira, se inclina, quijada al ritmo de las palabras, ondas y barras con la voz); se quitaron brillos, partículas, haz de proyección, líneas de holograma y ojos luminosos; ahora disco liso + líneas finas del color del tema.
- **Un solo `VozViewModel`**: `JulioRoot` lo crea y se lo pasa a Inicio y a Configuración (así hay un solo motor de voz). Antes vivía en la entrada de navegación de Voz; ahora vive en la actividad. Es el único cambio estructural, necesario para compartirlo.
- **No cambia**: motor/voz/reconocimiento/comandos/respuestas, Room, SharedPreferences de datos, permisos, notificaciones, enfoque, bloqueo, copia de seguridad.
- **Pruebas**: no cambia ninguna lógica, así que las pruebas unitarias siguen igual. NO compilado ni visto en teléfono (sin SDK en el entorno del asistente); el APK sale de GitHub Actions.
- **Siguiente tarea concreta**: confirmar el aspecto en teléfono (menú izquierdo, configuración derecha, tema claro/oscuro, que el asistente funcione igual) y ajustar márgenes o tamaños según capturas.


## v19 — Ajuste visual: identidad futurista equilibrada sobre la estructura de v18 (solo estilo)

Pedido: conservar TODA la distribución/paneles/navegación/funciones de v18 y recuperar la identidad futurista de las versiones anteriores (v14–v17, recuperadas del zip v17): negro y azul marino, azul eléctrico y cian, bordes luminosos sutiles, brillos moderados, gorila integrado con luz azul, animaciones suaves; sin parecer videojuego ni estorbar la lectura.

- **Paleta** (`Color.kt`, `Theme.kt`): negro azulado `#04070F` y azul marino `#071226`; cian `#45D4FF` y azul eléctrico `#2F7BFF` como luz; azul hielo para «respondiendo» (se quitó el dorado: el pedido es azul/cian). Tema oscuro POR DEFECTO (`Apariencia`: el valor por defecto pasó de automático a oscuro; quien ya eligió otro lo conserva). Claro y automático siguen en Configuración > Apariencia. Contrastes medidos: texto 16–18:1, secundario 9,5–11:1, cian 10–12:1, botón 10,7:1, bordes de campos 5,2:1.
- **Componentes** (`ui/components/Hud.kt`): `PanelJulio` con borde de gradiente cian→azul, fondo marino algo translúcido y resplandor suave; `FondoHud` con degradado, resplandores azul/cian en esquinas y cuadrícula casi invisible (solo en oscuro); `BarraSuperior` con línea de luz inferior e indicador que late (misma disposición: menú, título, engranaje); helpers `brilloSuave` y `brilloRespirando` (la luz se redibuja, no recompone).
- **Estructura** (`JulioRoot.kt`): igual. Solo estilo: panel derecho con esquinas redondeadas y borde de luz, cajón izquierdo marino, elemento seleccionado con borde luminoso, aro de luz en el avatar del cajón.
- **Inicio** (`VozScreen`): botón «Hablar con Julio» con luz que respira; estado (LISTO/ESCUCHANDO…) en monoespaciada con color animado. Todo lo demás igual.
- **Avatar** (`Orbe.kt`): vuelve el gorila holográfico de v17 (anillos 3D, partículas, plataforma, ecualizador, boca animada, ojos que brillan al procesar), con efectos más discretos: 48 partículas (antes 64), haz, líneas de holograma, tinte y barrido con menos opacidad; colores por estado en la familia azul (cian, azul eléctrico al pensar, hielo al responder). Mismo tamaño y mismos movimientos.
- **Ventana** (`res/values*/`): fondo de ventana inicial oscuro en `colors.xml` y `values-night/themes.xml` (sin destello claro al abrir).
- **No cambia**: lógica, voz, comandos, datos, permisos, notificaciones, enfoque, rutas, orden de paneles. Sin pruebas nuevas (no hay lógica nueva). NO compilado ni visto en teléfono.
- **Versiones para volver atrás**: v18 (sobria) y v17 (neón original con barra inferior).
- **Siguiente tarea concreta**: confirmar el aspecto en teléfono; ajustar intensidad de brillos/cuadrícula si estorban (constantes en `Hud.kt` y `Orbe.kt`).


## v20 — Voz Piper «es_ES-davefx-medium» (vía motor del sistema)

El usuario eligió la voz Piper es_ES-davefx-medium. Julio NO carga archivos .onnx por sí mismo: la ruta que no requiere librerías es instalar un motor de texto a voz de Android que use Piper (SherpaTTS, o VoxSherpa TTS), descargar esa voz allí y ponerlo como motor predeterminado; Julio usa el motor predeterminado.
- `Habla.aplicar()`: con la opción «Automática» (sin voz elegida), si el motor ofrece una voz cuyo nombre contenga «davefx», se usa; si no, comportamiento de siempre. El selector muestra ahora el nombre técnico de cada voz para reconocerla.
- Texto de ayuda en Configuración > Voz con los pasos. Sin cambios de lógica de comandos ni de datos.
- NO probado con SherpaTTS (sin dispositivo ni red en el entorno del asistente). Posible: el motor no avise cada palabra → la boca usa el vaivén de respaldo.
- Si más adelante se quiere que Julio traiga el motor dentro de la app (sin instalar otra app): requiere integrar sherpa-onnx como librería y descargar el modelo (~60 MB) en el primer uso; GitHub desde el celular no admite subir el modelo al repo.


## v21 — Voz neuronal DENTRO de Julio (Piper «es_MX-claude-high» con sherpa-onnx)

Pedido: la voz dentro del código, sin instalar otra app. El usuario eligió es_MX-claude-high (ficha: es_MX, 22 050 Hz, 1 hablante, licencia Apache-2.0; el .onnx pesa 63 MB). Las muestras que subió como archivos y el código Flutter/Dart (otro proyecto) NO se usan: Julio es Kotlin.
- **Por qué se descarga y no va en el repo**: 63–67 MB no caben en el zip ni en la subida web de GitHub (25 MB por archivo). Se descarga UNA vez desde la app (Configuración > Voz > Descargar voz) y luego funciona sin internet. Paquete: `vits-piper-es_MX-claude-high.tar.bz2` de sherpa-onnx (trae modelo, `tokens.txt` y `espeak-ng-data`, que Piper necesita); respaldo en Hugging Face (streamkit/piper-models). Se descomprime al vuelo con commons-compress; carpeta `filesDir/piper/es_MX-claude-high`.
- **Motor**: `sherpa-onnx-1.13.7.aar` se baja al COMPILAR (build.gradle.kts, con try/catch: si no hay red la app compila igual sin voz neuronal y el panel lo avisa). ABIs arm64-v8a y armeabi-v7a. Se usa por REFLEXIÓN (`MotorPiper`): una API distinta no rompe la compilación, solo cae a la voz del teléfono. Reglas R8 añadidas. Permiso INTERNET añadido (solo para la descarga).
- **Archivos**: `voz/PiperModelo.kt` (estado, descarga, extracción segura), `voz/MotorPiper.kt` (genera por frases, reproduce con AudioTrack en streaming; tono = frecuencia de reproducción, velocidad compensada; pulsos de palabras estimados para la boca del gorila), `voz/Habla.kt` (elige neuronal o sistema; si la neuronal falla usa la del sistema y lo muestra), `VozViewModel` (estado, descargar/cancelar/eliminar, se activa sola al terminar la descarga), panel en `Configuracion.kt`.
- **Licencias** (por si algún día se publica la app): voz Apache-2.0 (según su ficha), sherpa-onnx Apache-2.0, `espeak-ng-data` GPL-3.0 (viene en el paquete de la voz). Uso personal: sin problema.
- **NO probado**: sin dispositivo ni compilador en el entorno del asistente. Riesgos: nombres de la API Kotlin de sherpa-onnx v1.13.7 (usados por reflexión), URL del paquete de la voz, APK ~+40 MB. Si «Probar voz» dice que usó la voz del teléfono, leer el motivo en el panel.
- **Siguiente tarea concreta**: compilar v21, descargar la voz con Wi‑Fi, probar «Probar voz»; reportar el mensaje exacto si falla.


## v22 — Arreglo de compilación: descarga del motor de voz en build.gradle.kts

Primer informe de compilación de v21 (capturas de GitHub Actions): FALLÓ el paso «Compilar APK debug» en 19 s, en `app/build.gradle.kts`, ANTES de compilar cualquier código de la app.
- **Error:** `line 16: Unresolved reference: net` (+ «Variable expected» líneas 19-20 y «Cannot infer a type» línea 21, que son consecuencia). **Causa:** en un script `.kts` de Gradle, `java` es la extensión `java { }` del plugin, no el paquete; por eso `java.net.URL(...)` no se resuelve.
- **Arreglo (solo ese bloque):** `import java.io.InputStream/OutputStream`, `java.net.HttpURLConnection` y `java.net.URI` arriba del archivo; se usa `URI(dirección).toURL().openConnection() as HttpURLConnection` y tipos explícitos en los `use { }`. Mismo comportamiento: si la descarga falla, la app compila sin voz neuronal. `.gitignore`: se añadió `/app/libs/` para no subir el .aar por accidente.
- **Pruebas unitarias en el CI:** CORRECCIÓN al plan anterior: `build.yml` SÍ ejecuta `gradle testDebugUnitTest` ANTES de `assembleDebug`; una prueba que falle detiene la compilación. Como el fallo fue en «Compilar APK debug» (paso posterior), se deduce que las pruebas pasaron en el CI (no vi su registro). Para no bloquear nunca la compilación hay que añadir `continue-on-error: true` a ese paso (pendiente del punto 4 de «Lo que sigue»).
- **Verificado aquí:** balance de llaves/paréntesis en todos los `.kt` y validez de todos los `.xml` (sin problemas). **NO verificado:** que el resto del código v17–v21 compile (el script falló antes de llegar al compilador de Kotlin: pueden salir errores nuevos en la siguiente corrida); que exista el archivo `sherpa-onnx-1.13.7.aar` en esa URL de GitHub (no pude comprobarlo; si no existe, el build pasa sin voz neuronal y el panel Voz lo avisa).
- **Siguiente tarea concreta:** subir v22, mirar el resultado de Actions; si sale otro error, pasar la captura de las líneas «e: file://…». Si compila: instalar, probar «Probar voz» y leer el motivo en rojo si usa la voz del teléfono.


## v23 — Voz «Dave» (Piper es_ES-davefx-medium) en lugar de «Claude» + limpieza de SherpaTTS

Pedido: sustituir la voz neuronal es_MX-claude-high por Dave con los archivos `es_ES-davefx-medium.onnx` y su `.json`; revisar «ShareParty TS»; no tocar nada más.

**Comprobado aquí (Python + onnxruntime 1.24, con los archivos reales):**
- El `.onnx` es el original de Hugging Face (SHA-256 `6658b03b…a917`, el mismo que muestra la página guardada en el .mht). Entradas `input`, `input_lengths`, `scales`; salida de audio. Sin metadatos de sherpa.
- Compatible con el `.json`: 22 050 Hz, 1 hablante, voz de pronunciación `es`, 152 fonemas con números 0–151 y `num_symbols` 256: el modelo acepta el número 255 y rechaza el 256 (su tabla es de 256 exactamente).
- Se ejecutó el modelo con una frase en fonemas escritos a mano (2,5 s): sin NaN, pico 0,98, F0 mediana 116 Hz (voz masculina), 12 % de silencios. Muestra: `muestra_dave_prueba.wav`. NO usa espeak (no hay en el entorno): es solo para oír el timbre.
- Los metadatos que sherpa-onnx exige (`model_type=vits`, `comment=piper`, `language`, `voice=es`, `has_espeak=1`, `n_speakers`, `sample_rate`) se AÑADEN al final del `.onnx` (campo protobuf `metadata_props`): onnxruntime los lee y el audio sale IDÉNTICO con y sin ellos. El archivo original no se modifica; Julio trabaja con una copia.

**Motor TTS:** sherpa-onnx (ONNX Runtime + espeak-ng para pasar texto a fonemas). Es el mismo que ya traía v21; Piper es el formato de la voz.

**Código (solo voz):**
- `voz/DaveArchivos.kt` (nuevo, lógica pura): revisa que el `.json` sea de Dave, genera `tokens.txt` (espacio incluido), arma los metadatos y busca las marcas `input_lengths`/`scales` dentro del `.onnx`.
- `voz/PiperModelo.kt`: ID `es_ES-davefx-medium`. Camino 1 «Instalar con mis archivos de Dave» (selector de archivos del sistema; elige el .onnx y el .json a la vez): revisa, copia el modelo con metadatos, crea tokens y baja UNA vez solo `espeak-ng-data` del paquete oficial de sherpa-onnx (~65 MB de descarga, se descarta lo demás). Camino 2 «Descargar Dave (sin archivos)»: baja el paquete oficial ya preparado. «Reintentar» recuerda los archivos elegidos. Al abrir la app se borra `piper/es_MX-claude-high` (ya nada lo usa).
- `voz/Habla.kt`: antes de hablar corta lo que suene (Dave o la voz del teléfono) para que nunca haya dos voces a la vez. Se quitó la preferencia por una voz del sistema llamada «davefx».
- `voz/VozViewModel.kt` y `ui/screens/Configuracion.kt`: solo textos del panel de voz y los botones nuevos (mismo diseño). Julio habla TODAS sus respuestas por `Habla.hablar`, así que Dave las lee igual que antes la voz neuronal.
- `app/build.gradle.kts`: ahora prueba 1.13.7, 1.13.8, 1.13.6 y 1.13.5 para el .aar de sherpa-onnx (no pude comprobar cuál tiene el archivo publicado); si ninguno baja, compila sin voz neuronal.
- Controles: tono y velocidad se conservan (funcionan con Dave). No existe control de volumen propio en Julio: se usa el volumen multimedia del teléfono.
- Dependencias que se conservan porque Dave las usa: sherpa-onnx, commons-compress (descomprimir el paquete), permiso INTERNET (solo para la descarga única), reglas R8.

**«ShareParty TS» = SherpaTTS (casi seguro):** buscado el nombre exacto («ShareParty», «Share Party») y variantes: NO existe en el código ni en las dependencias. «SherpaTTS» solo aparecía en un texto de ayuda de Configuración > Voz (v20) que mandaba a instalar OTRA app (un motor de voz de Android que usa sherpa-onnx) y en una regla que buscaba una voz del sistema con «davefx». Ninguna parte de Julio dependía de eso. Con Dave dentro de Julio no hace falta: se quitaron el texto y la regla. (No confundir con `sherpa-onnx`, la librería que SÍ usa Dave.)

**CI:** el paso de pruebas unitarias en `build.yml` ahora tiene `continue-on-error: true`: si una prueba falla se ve en rojo pero ya no impide generar el APK (punto 4 de «Lo que sigue», adelantado). Pruebas nuevas: `DaveArchivosTest` (10), con los bytes de metadatos comprobados contra onnxruntime. NO ejecutadas con Gradle.

**NO verificado (sin SDK, sin compilador y sin teléfono en el entorno del asistente):** que compile; que el .aar de sherpa-onnx exista con esos nombres; los nombres de la API Kotlin de sherpa-onnx (se usan por reflexión: si cambian, cae a la voz del teléfono y el panel muestra el motivo); que sherpa-onnx cargue Dave con estos metadatos; que la URL `…/tts-models/vits-piper-es_ES-davefx-medium.tar.bz2` exista; el selector de archivos en el teléfono; el audio real en el teléfono; que las demás funciones sigan igual (solo se tocaron los archivos de voz listados; validé llaves y XML).
- **Siguiente tarea concreta:** compilar v23. Instalar, Configuración > Voz > «Instalar con mis archivos de Dave» (elegir el .onnx y el .json juntos), esperar, «Probar voz». Si falla, copiar el mensaje rojo del panel o las líneas `e: file://…` de Actions.


## v24 — Reconocimiento de voz SIN internet (Vosk + modelo español)

Pedido: que Julio te escuche y convierta tu voz en texto 100 % en el teléfono, sin Google ni servidores, y que el texto entre al intérprete de comandos que ya existe, con Dave respondiendo. (El pedido hablaba de Flutter/Dart; Julio es Kotlin nativo y así se hizo.)

**Motor y modelo elegidos:** Vosk (Kaldi, Apache 2.0, `com.alphacephei:vosk-android:0.3.75`) con el modelo `vosk-model-small-es-0.42` (español, Apache 2.0). Por qué: es el único de los candidatos que reúne a la vez transmisión en tiempo real, dependencia normal de Maven (sin compilar C++ ni NDK), modelo pequeño y detección de fin de frase integrada. Descartados: whisper.cpp (hay que compilar código nativo con el NDK, no transcribe en tiempo real y sus modelos pesan 75 MB a 480 MB o más), sherpa-onnx para reconocer (lo pediste evitar; sigue solo para la voz Dave) y el modelo grande de Vosk (1,4 GB).
- Tamaño: modelo 39 MB comprimido (≈50 MB instalado, dato del sitio de Vosk). El APK crece por las librerías nativas de Vosk (no medido).
- Precisión publicada por Vosk para este modelo pequeño: errores de palabra 16,0 % (Common Voice), 16,7 % (mTEDx), 11,2 % (MLS). Es menos preciso que el reconocimiento de Google.
- RAM: NO medida. Vosk avisa que no se puede deducir del tamaño del modelo; el panel muestra la memoria nativa de la app tras cada prueba. Tras 2 minutos sin escuchar, el modelo se descarga de la memoria.

**Cómo funciona:** `voz/ReconocedorVosk.kt` lee el micrófono con AudioRecord (16 kHz, mono), manda 100 ms de audio por vez a Vosk, muestra el texto parcial mientras hablas, anima el orbe con el nivel del micrófono y entrega el texto final cuando Vosk detecta que terminaste (espera máx. 8 s a que empieces y 30 s en total). El audio no se guarda ni se envía. El texto final entra al mismo `procesar()` de siempre → intérprete → acción → respuesta con Dave. El intérprete ya normaliza mayúsculas, acentos y números dichos con palabras, así que acepta la salida de Vosk (minúsculas, sin puntuación).
- `voz/VoskModelo.kt`: instalar el modelo UNA vez, solo cuando tocas el botón: «Descargar modelo (39 MB)» de alphacephei.com/vosk/models (el panel muestra origen, tamaño y licencia antes) o «Elegir el .zip que ya tengo» (sin internet). Revisa que el .zip sea un modelo completo y no deja escribir fuera de su carpeta.
- Configuración > Voz > «Reconocimiento de voz sin internet»: botones, interruptor, y los datos de la última prueba (modelo cargado en X ms, texto listo Y ms después de dejar de hablar, memoria nativa).
- Al terminar de instalar el modelo, se activa solo. Con el interruptor activado, Julio NUNCA usa `SpeechRecognizer` (Google); si falta el modelo lo dice y no cae en silencio al reconocimiento de Google (verificado leyendo el código: `SpeechRecognizer` solo se crea en `obtenerReconocedor()`, y `escuchar()` sale antes cuando Vosk está activo). Sin modelo instalado, Julio sigue funcionando como antes (reconocimiento del sistema) hasta que lo instales.
- Permisos: ninguno nuevo (micrófono ya existía; INTERNET ya existía por la voz Dave y solo se usa en las descargas que tú pides).
- `build.gradle.kts` (+ Vosk y JNA 5.13.0 como en la guía de Vosk), `proguard-rules.pro` (reglas para Vosk/JNA). Pruebas nuevas: `ReconocimientoUtilTest` (6): lectura de la respuesta de Vosk, nivel del micrófono y protección de rutas del .zip; sus fórmulas se espejaron en Python.

**NO verificado (el entorno del asistente no tiene SDK, internet ni teléfono; no pude ejecutar Vosk):** que compile (dependencias nuevas de Maven; si no resuelven, el build falla en la descarga); que el modelo cargue y reconozca; precisión con tu voz; el modo avión; RAM y tiempos reales; que no se use Google (solo el análisis del código; la comprobación real es la prueba de abajo); que v17 a v23 compilen.

**Pruebas que debes hacer en el teléfono (la v24 es lo primero que te lo permite):**
1. Compilar. Si falla, pasar las líneas `e: file://…` o el error de Gradle.
2. Configuración > Voz > descargar el modelo (con Wi‑Fi) o elegir el .zip. Esperar «Entender mi voz sin internet» activado.
3. Activar modo avión (wifi y datos apagados). Tocar el micrófono y decir: «¿qué tengo pendiente para mañana?», «agrega una clase de anatomía el lunes a las siete», «pon una alarma para las cinco de la mañana», «¿qué actividades tengo esta semana?».
4. Comprobar que responde con voz (Dave, si está instalada) y que en la sección Voz aparecen la última prueba y los tiempos. Revisar que Alarmas/Horario/Tareas muestren lo creado.
5. Opcional, para descartar Google: en Ajustes del teléfono desactivar «Servicios de voz de Google»; si Julio sigue entendiéndote, no lo usa.
- **Siguiente tarea concreta:** con lo que salga del paso 1 a 5, corregir lo que falle. Posibles mejoras si la precisión se queda corta: restringir el vocabulario a los comandos y nombres de tus materias (Vosk lo permite) y ajustar los tiempos de espera.


## v25 — Huevos de pascua de Julio (palabras motivadoras, tristeza e insultos)

Pedido: que Julio responda, sin pantalla ni opción nueva, cuando le digas «tengo hueva de hacer esto», «estoy desmotivado», «estoy triste», «no tengo ganas», con palabras motivadoras como las de TikTok («no hay ningún mañana»); y que si lo insultas, te insulte igual o peor.
- `comandos/HuevosDePascua.kt` (nuevo, lógica pura): 14 frases de ánimo con urgencia y fe (incluye Filipenses 4:13, 2 Timoteo 1:7, Josué 1:9 y Gálatas 6:9, parafraseados), 6 de tristeza más suaves (Salmo 34:18, 1 Pedro 5:7), 12 respuestas con humor a insultos (sin groserías ni ofensas a personas o grupos). Frases ORIGINALES: no copié diálogos de películas (son de sus dueños). Cifras y versículos escritos con palabras para que Dave los lea bien. No repite la misma frase dos veces seguidas.
- Enganche en `Asistente.procesar()`: solo se usan cuando el intérprete devuelve «Desconocida» (no es una orden que Julio entienda). Así ninguna función existente cambia. No hay ningún cambio de interfaz.
- Insultos: solo si son directos («eres un inútil», «te odio», «cállate») o una frase corta de 6 palabras o menos con la palabra; una frase larga que mencione a otra persona no se toma como insulto.
- Seguridad que añadí por mi cuenta: si dices algo grave sobre tu vida («quiero morirme», «ya no quiero vivir», «hacerme daño»), Julio NO te lanza una frase motivadora de TikTok: te habla en serio, te pide buscar a una persona de confianza o emergencias de tu país y cancela cualquier pregunta pendiente. Con «deprimido» agrega que, si dura muchos días, hables con alguien de confianza o un profesional.
- Pruebas: `HuevosDePascuaTest` (9) y un espejo en Python con 29 frases (16 que deben activarse y 13 órdenes reales de Julio que NO deben activarse: todas pasaron). NO ejecutadas con Gradle; no probé el audio con Dave.
- Para añadir o cambiar frases: editar las listas ANIMOS, TRISTEZAS e INSULTOS en `HuevosDePascua.kt`; las palabras que lo activan están al inicio del mismo archivo.


## v26 — Enfoque ESTRICTO (bloqueo difícil de romper) + avisos, y limpieza de los huevos de pascua

**Huevos de pascua (cambio decidido antes):** se quitaron las frases motivadoras y los insultos de la v25. Queda «háblame de Dios» / «dame un versículo» (25 versículos parafraseados con su cita escrita en palabras; el texto textual de una versión queda pendiente de decidir) y la respuesta seria ante frases graves sobre la propia vida. Archivos: `comandos/HuevosDePascua.kt` y su prueba. NO usar la v25.

**Enfoque estricto (pedido: bloquear solo las apps elegidas, sin forma de desbloquearlas ni terminar antes; si quiere salir, que cueste «demasiado»; la IA para estudiar no se bloquea porque solo se bloquean las apps que él elige):**
- Se activa a propósito: interruptor «Modo estricto» en la pantalla Enfoque (con ventana de confirmación) o por voz «enfoque estricto de 45 minutos» (Julio pide confirmar con sí/no). Requiere el bloqueo ya activado, con permisos y al menos una app elegida; si no, lo dice. Máximo 3 horas, sin descansos.
- Mientras dura: no hay pausa ni terminar (ni por pantalla, voz, notificación ni la pantalla de bloqueo; `EnfoqueControl.pausar/finalizar` lo ignoran). No se puede apagar el bloqueo ni cambiar la lista de apps. Además se bloquean Ajustes, Play Store, instaladores de apps y el gestor de permisos (`Estricto.EXTRA_BLOQUEADAS`) para que no se puedan quitar permisos ni desinstalar desde el teléfono. Siguen libres: Julio, llamadas, emergencias, pantalla de inicio y alarmas.
- Resistencia: el servicio de bloqueo se reabre solo si el sistema lo cierra (START_STICKY) y un vigilante (`VigilanteReceiver`, alarma cada minuto) lo vuelve a encender; la sesión sobrevive a cerrar la app o reiniciar (ya se guardaba y se re-arma al arrancar).
- Salir antes (única salida): botón «Quiero salir (cuesta mucho)» en Enfoque. Paso 1: espera de 10 minutos (sigue corriendo aunque cierres la ventana). Paso 2: copiar a mano una frase de ~110 letras (pegar se bloquea). Paso 3: seis cuentas (multiplicaciones). Paso 4: escribir «ME RINDO». Al salir queda registrada como «sesión rota» (contador) y llega un aviso. La racha de estudio no se «reinicia» (no hay forma limpia en el modelo actual); lo que pasa es que esa sesión de estudio NO se da por hecha, igual que ya ocurría al cancelar.
- Notificaciones nuevas (canal «Modo estricto (avisos)», alta importancia): al intentar abrir una app bloqueada («Bloqueada: X. Faltan mm:ss», máx. una por minuto), al romper la sesión, al faltar un permiso, y al terminar con éxito («Modo estricto completado»). La notificación fija con cuenta regresiva dice «Enfoque ESTRICTO en curso».
- Código: `enfoque/Estricto.kt` (reglas puras), `Modelos.kt` (+`estricto`), `EnfoqueControl.kt`, `VigilanteReceiver.kt` (nuevo, registrado en el manifiesto), `bloqueo/BloqueoConfig.kt` y `BloqueoService.kt`, `alarmas/Canales.kt`, `comandos/` (Intencion, Interprete, Esperando, Asistente), `ui/screens/EnfoqueScreen.kt` y `BloqueoCard.kt`. Pruebas nuevas: `EstrictoTest` (8) y `EnfoqueEstrictoInterpreteTest` (2). Espejo en Python de las reglas de espera, frase y pegado: todo coincide.

**Límites (hay que decírselos, no se pueden arreglar con una app normal):** alguien decidido aún puede reiniciar en modo seguro, desinstalar con una computadora o forzar la detención por una ruta que el fabricante deje fuera de «Ajustes»; si Julio se detiene con «forzar detención» el sistema cancela sus alarmas hasta que se abra de nuevo. En Xiaomi/Samsung hay que dejar a Julio «sin restricciones» de batería e «inicio automático» (ya se avisa en la tarjeta de bloqueo). Esto frena el impulso de dos minutos, no a una persona que se lo proponga con herramientas.

**NO verificado (sin SDK ni teléfono):** que compile; que el bloqueo detecte Ajustes y Play Store en tu marca de teléfono (los nombres de paquete son los de Android estándar); que el vigilante reabra el servicio en tu teléfono; las notificaciones y su permiso en Android 13+; la ventana de salida difícil; que en el CI pasen las pruebas (no bloquean el APK).

**Prueba sugerida (5 min):** 1) Enfoque > activar el bloqueo, dar los dos permisos y elegir una app. 2) Poner «Modo estricto», 5 min, confirmar. 3) Abrir la app bloqueada (debe taparse y llegar la notificación), abrir Ajustes (debe taparse), decir «termina la sesión» (debe negarse). 4) En Julio > Enfoque ver que no hay Pausar ni Finalizar y probar «Quiero salir» (debe pedir esperar 10 min). 5) Dejar terminar y ver «Modo estricto completado».
- **Siguiente tarea concreta:** con lo que salga de esa prueba, corregir. Si «notificación» significaba otra cosa (avisos de tareas/horario/estudio), indicar cuál no llega para revisarla; las alarmas, recordatorios y avisos del plan de estudio ya existen y piden el permiso de notificaciones en Enfoque y Alarmas.


## v27 — Notificaciones que sí llegan (permiso, avisos automáticos, resumen de la mañana y pendientes de la tarde)

Queja: Julio no avisaba de las tareas, del horario ni de cuándo termina el modo enfoque; quiere «hey, ya terminó», «hey, tienes que hacer esto».
**Causas encontradas leyendo el código:**
1. El permiso de notificaciones (Android 13+) solo se pedía si entrabas a Enfoque o Alarmas y tocabas el botón del aviso. Sin permiso no sale NINGUNA notificación (fin del enfoque, recordatorios, estudio).
2. Los avisos eran opcionales por elemento: una actividad solo avisaba si tenía «recordatorioMin» y una tarea solo si tenía fecha límite Y hora de aviso. Por defecto no tenían, así que casi nada avisaba. No existía ningún resumen del día.
**Arreglo:**
- `MainActivity` pide el permiso al abrir la app (máximo 2 veces; si se rechaza, Configuración > Avisos explica y ofrece abrir los ajustes).
- Avisos por defecto, sin cambiar la base de datos: las actividades sin aviso propio avisan 10 minutos antes; las tareas con fecha límite y sin aviso propio avisan a las 8:00 del día del vencimiento. El aviso propio de cada elemento sigue mandando. (`CalculoRecordatorio` ahora recibe el valor por defecto; `RecordatorioProgramador` y `RecordatorioReceiver` lo usan; `reprogramarTodos` revisa todas las actividades y tareas.)
- Resumen de la mañana (7:00): «Buenos días, esto tienes hoy» con actividades, tareas de hoy y vencidas. Aviso de la tarde (19:00): «Hey, te faltan tareas por hacer» solo si queda algo pendiente. Si no hay nada, no avisa. Paquete nuevo `avisos/` (AvisosAjustes, CalculoAvisos, AvisosProgramador, AvisosReceiver), canal «Resumen y pendientes», receptor en el manifiesto; se arma al abrir la app y al reiniciar el teléfono (ArranqueReceiver).
- Configuración > Avisos (sección nueva): estado del permiso con botones, interruptores y horas del resumen de la mañana y de los pendientes de la tarde, aviso por defecto del horario (sin aviso / al empezar / 5 / 10 / 15 / 30 min) e interruptor de las tareas a las 8:00. Al cambiar algo se reprograman los avisos.
- Fin del enfoque: ahora «Hey, ya terminó tu enfoque» / «Hey, ya terminó tu descanso» (y «Modo estricto completado»). Las tareas avisan «Hey, tienes pendiente: …».
- Pruebas: `CalculoAvisosTest` (7: aviso propio vs. por defecto en actividades y tareas, textos del resumen y de la tarde, límite de 4 elementos). NO ejecutadas con Gradle.
**NO verificado (sin SDK ni teléfono):** que compile; que el permiso se pida en tu teléfono; que lleguen las notificaciones con la app cerrada (depende de la batería: Xiaomi/Samsung necesitan «sin restricciones» e «inicio automático»); que los avisos se vean bien.
**Notas:** los elementos que ya tenían «Sin aviso» elegido a propósito ahora usan el aviso por defecto; para no recibirlos, poner «Sin aviso» en Configuración > Avisos. La v25 (ya instalada por el usuario) trae las frases motivadoras e insultos; la v26 las quita: instalar la v27, que incluye todo lo de v26.
- **Siguiente tarea concreta:** instalar, aceptar el permiso, ver Configuración > Avisos y crear una actividad para dentro de 15 minutos para comprobar el aviso de 10 minutos antes; terminar un enfoque corto y ver «Hey, ya terminó tu enfoque».
