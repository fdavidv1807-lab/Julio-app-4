package com.julio.asistente.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.julio.asistente.R
import com.julio.asistente.voz.EstadoVoz
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

private val Azul = Color(0xFF2F6BFF)
private val Cian = Color(0xFF4DD0E1)

/**
 * Orbe de Julio. Solo se anima cuando Julio realmente escucha, procesa o responde;
 * en reposo queda quieto (y no gasta batería).
 */
@Composable
fun Orbe(estado: EstadoVoz, nivel: Float, modifier: Modifier = Modifier) {
    val activo = estado != EstadoVoz.REPOSO
    val fase: Float = if (activo) {
        val t = rememberInfiniteTransition(label = "orbe")
        t.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
            label = "fase",
        ).value
    } else 0f
    // Velocidades enteras para que el bucle sea continuo.
    val velocidad = when (estado) {
        EstadoVoz.ESCUCHANDO -> 1
        EstadoVoz.PROCESANDO -> 3
        EstadoVoz.RESPONDIENDO -> 2
        EstadoVoz.REPOSO -> 0
    }
    val energia = if (estado == EstadoVoz.ESCUCHANDO) 0.35f + 0.65f * nivel else 0.8f

    val textoEstado = when (estado) {
        EstadoVoz.REPOSO -> "Listo"
        EstadoVoz.ESCUCHANDO -> "Escuchando..."
        EstadoVoz.PROCESANDO -> "Procesando..."
        EstadoVoz.RESPONDIENDO -> "Respondiendo..."
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.radialGradient(listOf(Color(0xFF0A2A7A), Color(0xFF020A24)))),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val giro = fase * 360f * velocidad
            val intensidad = if (activo) 1f else 0.45f

            // Halo
            for (k in 3 downTo 1) {
                drawCircle(
                    color = Azul.copy(alpha = 0.07f * k * intensidad),
                    radius = r * 0.62f + k * 6.dp.toPx(),
                    center = c,
                    style = Stroke(width = (5 * k).dp.toPx()),
                )
            }
            drawCircle(color = Azul.copy(alpha = intensidad), radius = r * 0.62f, center = c, style = Stroke(width = 4.dp.toPx()))
            drawCircle(color = Cian.copy(alpha = 0.5f * intensidad), radius = r * 0.7f, center = c, style = Stroke(width = 2.dp.toPx()))

            // Arcos que giran
            val lado = r * 1.4f
            val esquina = Offset(c.x - lado / 2f, c.y - lado / 2f)
            drawArc(
                color = Cian.copy(alpha = intensidad), startAngle = giro, sweepAngle = 70f, useCenter = false,
                topLeft = esquina, size = Size(lado, lado), style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
                color = Cian.copy(alpha = intensidad), startAngle = 180f - giro, sweepAngle = 45f, useCenter = false,
                topLeft = esquina, size = Size(lado, lado), style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round),
            )

            // Onda de audio
            val barras = 29
            val ancho = size.width * 0.86f
            val x0 = c.x - ancho / 2f
            val yCentro = c.y + r * 0.5f
            for (i in 0 until barras) {
                val x = x0 + ancho * i / (barras - 1)
                val envolvente = 1f - abs(i - (barras - 1) / 2f) / ((barras - 1) / 2f)
                val oscila = if (activo) {
                    abs(sin(fase.toDouble() * velocidad * 2.0 * PI + i * 0.45)).toFloat()
                } else 0.15f
                val alto = size.height * 0.03f + size.height * 0.2f * envolvente * (0.25f + 0.75f * oscila * energia)
                drawLine(
                    color = Cian.copy(alpha = 0.9f * intensidad),
                    start = Offset(x, yCentro - alto / 2f),
                    end = Offset(x, yCentro + alto / 2f),
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
        }
        Image(
            painter = painterResource(R.drawable.julio_mascota),
            contentDescription = "Julio",
            modifier = Modifier.fillMaxSize(0.48f).clip(CircleShape),
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
        )
        Text(
            "J U L I O",
            color = Cian,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 16.dp),
        )
        Text(
            textoEstado,
            color = Cian,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp),
        )
    }
}
