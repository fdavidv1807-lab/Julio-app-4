package com.julio.asistente.cuerpo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MensajesTest {
    private val ahora = 1_000_000L
    private fun m(texto: String, t: Long, quien: String = "Ana") = MensajeCrudo(texto, t, quien)

    @Test fun losNumerosSonDesconocidos() {
        assertTrue(Remitentes.esNumero("+57 300 123 4567"))
        assertTrue(Remitentes.esNumero("3001234567"))
        assertFalse(Remitentes.esNumero("Ana"))
        assertFalse(Remitentes.esNumero("Oficina 12"))
        assertEquals("un número desconocido", Remitentes.nombreHablado("+57 300 123 4567"))
        assertEquals("Ana", Remitentes.nombreHablado("Ana"))
    }

    @Test fun elPrimerAvisoDiceLoReciente() {
        val s = SeguimientoChats(maxEdadMs = 300_000L)
        val r = s.nuevos("c", listOf(m("viejo", ahora - 900_000L), m("hola", ahora - 5_000L)), ahora)
        assertEquals(listOf("hola"), r.map { it.texto })
    }

    @Test fun noRepiteLoYaAvisadoYDiceSoloLoNuevo() {
        val s = SeguimientoChats()
        s.nuevos("c", listOf(m("uno", ahora - 3_000L)), ahora)
        val r = s.nuevos("c", listOf(m("uno", ahora - 3_000L), m("dos", ahora - 1_000L)), ahora)
        assertEquals(listOf("dos"), r.map { it.texto })
        assertTrue(s.nuevos("c", listOf(m("uno", ahora - 3_000L), m("dos", ahora - 1_000L)), ahora).isEmpty())
    }

    @Test fun dosMensajesIgualesSeguidosSonDos() {
        val s = SeguimientoChats()
        val r = s.nuevos("c", listOf(m("hola", ahora - 1_000L), m("hola", ahora - 1_000L)), ahora)
        assertEquals(2, r.size)
        val r2 = s.nuevos("c", listOf(m("hola", ahora - 1_000L), m("hola", ahora - 1_000L), m("hola", ahora - 1_000L)), ahora)
        assertEquals(1, r2.size)
    }

    @Test fun cadaConversacionLlevaSuPropiaCuenta() {
        val s = SeguimientoChats()
        s.nuevos("a", listOf(m("hola", ahora - 1_000L)), ahora)
        assertEquals(1, s.nuevos("b", listOf(m("hola", ahora - 1_000L)), ahora).size)
    }
}
