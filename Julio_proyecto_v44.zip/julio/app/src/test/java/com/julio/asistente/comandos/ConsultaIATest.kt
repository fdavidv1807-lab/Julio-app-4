package com.julio.asistente.comandos

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** «Pregúntale a la IA …» (v43). Sin Android. */
class ConsultaIATest {
    private val hoy = LocalDate.of(2026, 11, 10)
    private val ahora = LocalTime.of(9, 0)
    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun conservaLaPreguntaComoSeDijo() {
        assertEquals(
            Intencion.PreguntarIA("¿cuál es el mecanismo de acción de la metformina?"),
            i("Pregúntale a la IA ¿cuál es el mecanismo de acción de la metformina?"),
        )
        assertEquals(
            Intencion.PreguntarIA("qué es la hipertensión"),
            i("Julio, pregúntale a la inteligencia artificial qué es la hipertensión"),
        )
        assertEquals(
            Intencion.PreguntarIA("dosis de amoxicilina en niños"),
            i("Consulta a Gemini: dosis de amoxicilina en niños"),
        )
    }

    @Test fun sinPreguntaPideLaPregunta() {
        assertEquals(Intencion.PreguntarIA(""), i("Pregúntale a la IA"))
        assertEquals(Intencion.PreguntarIA(""), i("Julio, consulta a Gemini"))
    }

    @Test fun unaPreguntaMedicaNoSeConfundeConOtrasOrdenes() {
        // «examen», «horario» y «estudio» son palabras de otras órdenes, pero aquí manda la IA.
        assertEquals(
            Intencion.PreguntarIA("cuándo conviene estudiar para un examen de anatomía"),
            i("Pregúntale a la IA cuándo conviene estudiar para un examen de anatomía"),
        )
        assertEquals(
            Intencion.PreguntarIA("qué es un estudio de cohortes"),
            i("Pregúntale a la IA qué es un estudio de cohortes"),
        )
    }

    @Test fun sinNombrarALaIANoSeMandaNada() {
        assertNotEquals(Intencion.PreguntarIA("cuántas tareas tengo"), i("Pregunta cuántas tareas tengo"))
        assertEquals(Intencion.AbrirApp("gemini"), i("Abre Gemini"))
        assertNotEquals(Intencion.PreguntarIA(""), i("¿Qué notificaciones tengo?"))
    }
}
