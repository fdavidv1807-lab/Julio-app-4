package com.julio.asistente.cuerpo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistorialAvisosTest {
    private fun av(id: String, chat: String, texto: String = "hola", n: Int = 1) =
        Aviso(id, 0L, "WhatsApp", "com.whatsapp", "Ana", texto, chat = chat, remitente = "Ana", cantidad = n, mensajeria = true)

    @Test fun juntaLaMismaConversacionYMuestraLoNuevoPrimero() {
        val h = HistorialAvisos(capacidad = 5, vidaMs = 10_000L)
        h.registrar(av("1", "ana", "uno"), 0L)
        h.registrar(av("2", "pedro", "x"), 1L)
        h.registrar(av("3", "ana", "dos"), 2L)
        val l = h.lista(3L)
        assertEquals(listOf("ana", "pedro"), l.map { it.chat })
        assertEquals(2, l[0].cantidad)
        assertEquals("dos", l[0].texto)
    }

    @Test fun caducaYRespetaLaCapacidad() {
        val h = HistorialAvisos(capacidad = 2, vidaMs = 1_000L)
        h.registrar(av("1", "a"), 0L)
        h.registrar(av("2", "b"), 500L)
        h.registrar(av("3", "c"), 600L)
        assertEquals(listOf("c", "b"), h.lista(700L).map { it.chat })
        assertEquals(listOf("c"), h.lista(1_550L).map { it.chat })
        h.vaciar()
        assertTrue(h.lista(1_550L).isEmpty())
    }
}
