package com.julio.asistente.ia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PoliticaIATest {
    @Test fun noMandaDatosPersonales() {
        assertTrue(PoliticaIA.datosPersonales("mi correo es ana@mail.com"))
        assertTrue(PoliticaIA.datosPersonales("llámame al 300 123 4567"))
        assertTrue(PoliticaIA.datosPersonales("paciente con cédula 1234567890"))
        assertTrue(PoliticaIA.datosPersonales("+57 300 123 4567"))
    }

    @Test fun lasPreguntasMedicasNormalesPasan() {
        assertFalse(PoliticaIA.datosPersonales("¿cuál es la dosis de 500 mg cada 8 horas?"))
        assertFalse(PoliticaIA.datosPersonales("TA 120 80, FC 90, FR 18, temperatura 37.5"))
        assertFalse(PoliticaIA.datosPersonales("valores normales de glucosa 70 a 100 mg/dl"))
        assertFalse(PoliticaIA.datosPersonales("¿qué es la hipertensión arterial?"))
    }

    @Test fun limpiaElMarkdown() {
        val md = "**Metformina** reduce la glucosa.\n* Primera idea\n- Segunda idea\n# Título\nMira [la guía](http://x.com) y `código`."
        assertEquals("Metformina reduce la glucosa.\nPrimera idea\nSegunda idea\nTítulo\nMira la guía y código.", PoliticaIA.limpiarRespuesta(md))
    }

    @Test fun laRespuestaCortaSeDiceCompleta() {
        val t = "La metformina reduce la producción hepática de glucosa. También mejora la sensibilidad a la insulina."
        assertEquals(t, PoliticaIA.paraHablar(t))
    }

    @Test fun laRespuestaLargaSeCortaYAvisaQueElRestoEstaEnPantalla() {
        val largo = (1..30).joinToString(" ") { "Esta es la oración número $it de la respuesta." }
        val h = PoliticaIA.paraHablar(largo)
        assertTrue(h.endsWith("El resto está en la pantalla."))
        assertTrue(h.length < 500)
        assertTrue(h.startsWith("Esta es la oración número 1 de la respuesta."))
    }

    @Test fun conDosisRecuerdaVerificar() {
        val h = PoliticaIA.paraHablar("La dosis inicial suele ser 500 mg dos veces al día.")
        assertTrue(h.endsWith("Verifica dosis y cifras en tu libro o guía."))
        assertFalse(PoliticaIA.paraHablar("La insulina baja la glucosa.").contains("Verifica"))
    }

    @Test fun clasificaLosErrores() {
        assertEquals(ErrorIA.LIMITE, PoliticaIA.clasificar(429, ""))
        assertEquals(ErrorIA.MODELO, PoliticaIA.clasificar(404, ""))
        assertEquals(ErrorIA.SERVIDOR, PoliticaIA.clasificar(503, ""))
        assertEquals(ErrorIA.CLAVE, PoliticaIA.clasificar(403, ""))
        assertEquals(ErrorIA.CLAVE, PoliticaIA.clasificar(400, "API key not valid. Please pass a valid API key."))
        assertEquals(ErrorIA.SOLICITUD, PoliticaIA.clasificar(400, "INVALID_ARGUMENT: contenido mal formado"))
        assertEquals(ErrorIA.OTRO, PoliticaIA.clasificar(418, ""))
    }

    @Test fun soloSeProbaraOtroModeloSiVale() {
        assertTrue(PoliticaIA.sirveProbarOtroModelo(ErrorIA.LIMITE))
        assertTrue(PoliticaIA.sirveProbarOtroModelo(ErrorIA.MODELO))
        assertFalse(PoliticaIA.sirveProbarOtroModelo(ErrorIA.CLAVE))
        assertFalse(PoliticaIA.sirveProbarOtroModelo(ErrorIA.BLOQUEADA))
    }

    @Test fun laConversacionGuardaTresTurnosYCaduca() {
        val c = ConversacionIA(maxTurnos = 3, vidaMs = 1_000L)
        for (i in 1..4) c.agregar("p$i", "r$i", i * 100L)
        assertEquals(listOf("p2", "p3", "p4"), c.historial(500L).map { it.pregunta })
        assertEquals(listOf("p4"), c.historial(1_350L).map { it.pregunta })
        c.vaciar()
        assertTrue(c.historial(500L).isEmpty())
    }
}
