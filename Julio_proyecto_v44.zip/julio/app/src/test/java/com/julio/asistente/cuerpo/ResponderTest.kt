package com.julio.asistente.cuerpo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResponderTest {
    private val noHace: (String) -> Boolean = { true }
    private fun r(chat: String, nombre: String, t: Long, grupo: Boolean = false, f: (String) -> Boolean = noHace) =
        RespuestaPosible(chat, nombre, grupo, t, f)

    @Test fun elRegistroGuardaYEncuentraPorChatYNombre() {
        val g = RegistroRespuestas(vidaMs = 10_000L)
        g.registrar(r("a", "Ana María", 0L))
        g.registrar(r("p", "Pedro", 1L))
        assertEquals("Pedro", g.porChat("p", 2L)?.nombre)
        assertEquals("Ana María", g.porNombre("ana", 2L)?.nombre)
        assertEquals("Ana María", g.porNombre("Ana María", 2L)?.nombre)
        assertNull(g.porNombre("luis", 2L))
        assertNull(g.porNombre("  ", 2L))
    }

    @Test fun conDosParecidosGanaElMasReciente() {
        val g = RegistroRespuestas(vidaMs = 10_000L)
        g.registrar(r("1", "Ana López", 0L))
        g.registrar(r("2", "Ana Ruiz", 5L))
        assertEquals("2", g.porNombre("ana", 6L)?.chat)
    }

    @Test fun refrescarCambiaLaAccionSinCambiarCualEsLaMasReciente() {
        val g = RegistroRespuestas(vidaMs = 10_000L)
        var usada = ""
        g.registrar(r("a", "Ana", 0L) { usada = "vieja"; true })
        g.registrar(r("p", "Pedro", 1L))
        g.refrescar("a", { usada = "nueva"; true })
        g.porChat("a", 2L)!!.enviar("hola")
        assertEquals("nueva", usada)
    }

    @Test fun refrescarUnChatDesconocidoNoLoCrea() {
        val g = RegistroRespuestas()
        g.refrescar("x", noHace)
        assertNull(g.porChat("x", 0L))
    }

    @Test fun quitarCaducarYLimiteDeChats() {
        val g = RegistroRespuestas(vidaMs = 1_000L, maximo = 2)
        g.registrar(r("a", "Ana", 0L))
        g.registrar(r("b", "Beto", 100L))
        g.registrar(r("c", "Carla", 200L))
        assertNull(g.porChat("a", 300L))
        g.quitar("b")
        assertNull(g.porChat("b", 300L))
        assertEquals("Carla", g.porChat("c", 300L)?.nombre)
        assertNull(g.porChat("c", 5_000L))
    }

    @Test fun elDictadoSeLimpia() {
        assertEquals("Sí, a las 12", PoliticaRespuesta.limpiarDictado("  sí,   a las 12 \n"))
        assertEquals("", PoliticaRespuesta.limpiarDictado("   "))
        assertTrue(PoliticaRespuesta.limpiarDictado("palabra ".repeat(200)).length <= PoliticaRespuesta.MAX_CARACTERES)
    }

    @Test fun lasFrasesDicenAQuienVaYModoPrivadoNo() {
        val ana = r("a", "Ana", 0L)
        val grupo = r("g", "Familia", 0L, grupo = true)
        assertEquals("¿Qué le digo a Ana?", PoliticaRespuesta.preguntar(ana, false))
        assertEquals("¿Qué le digo al grupo Familia?", PoliticaRespuesta.preguntar(grupo, false))
        assertEquals("¿Qué le digo?", PoliticaRespuesta.preguntar(ana, true))
        assertEquals("Le diré a Ana: Sí, a las 12. ¿Lo envío?", PoliticaRespuesta.confirmar(ana, "Sí, a las 12", false))
        assertEquals("Lo mando al grupo Familia: Voy. ¿Lo envío?", PoliticaRespuesta.confirmar(grupo, "Voy", false))
        assertFalse(PoliticaRespuesta.confirmar(ana, "Sí", true).contains("Ana"))
    }

    @Test fun soloUnSiClaroEnvia() {
        val d = PoliticaRespuesta.Decision.values()
        assertEquals(PoliticaRespuesta.Decision.ENVIAR, PoliticaRespuesta.decidir("si"))
        assertEquals(PoliticaRespuesta.Decision.ENVIAR, PoliticaRespuesta.decidir("si envialo"))
        assertEquals(PoliticaRespuesta.Decision.CANCELAR, PoliticaRespuesta.decidir("no"))
        assertEquals(PoliticaRespuesta.Decision.CANCELAR, PoliticaRespuesta.decidir("no si mejor no"))
        assertEquals(PoliticaRespuesta.Decision.CAMBIAR, PoliticaRespuesta.decidir("cambialo"))
        assertEquals(PoliticaRespuesta.Decision.NO_ENTENDI, PoliticaRespuesta.decidir("tal vez manana"))
        assertEquals(PoliticaRespuesta.Decision.NO_ENTENDI, PoliticaRespuesta.decidir(""))
        assertEquals(4, d.size)
    }
}
