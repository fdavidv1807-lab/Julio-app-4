package com.julio.asistente.cuerpo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FiltroYColaTest {
    private fun n(paquete: String = "com.whatsapp", titulo: String = "Ana", texto: String = "Hola", cat: String? = "msg",
                  curso: Boolean = false, grupo: Boolean = false) = NotificacionCruda(paquete, titulo, texto, cat, curso, grupo)

    private val elegidas = setOf("com.whatsapp", "com.google.android.gm")

    private fun motivo(x: NotificacionCruda, permitidas: Set<String> = elegidas) =
        FiltroAvisos.motivoDescarte(x, "com.julio.asistente", permitidas)

    @Test fun leeUnMensajeNormalDeUnaAppElegida() = assertNull(motivo(n()))

    @Test fun porDefectoNoLeeNingunaApp() = assertNotNull(motivo(n(), emptySet()))

    @Test fun noLeeLasAppsQueNoSeEligieron() = assertNotNull(motivo(n(paquete = "com.instagram.android")))

    @Test fun descartaLoQueNoEsUnAviso() {
        assertNotNull(motivo(n(paquete = "com.julio.asistente")))
        assertNotNull(motivo(n(paquete = "android")))
        assertNotNull(motivo(n(curso = true)))
        assertNotNull(motivo(n(grupo = true)))
        assertNotNull(motivo(n(cat = "transport")))
        assertNotNull(motivo(n(cat = "progress")))
        assertNotNull(motivo(n(titulo = " ", texto = "")))
    }

    @Test fun deduplicaDentroDeLaVentana() {
        val d = Deduplicador(ventanaMs = 30_000L)
        assertFalse(d.repetido("a", "t", "x", 0L))
        assertTrue(d.repetido("a", "t", "x", 10_000L))
        assertFalse(d.repetido("a", "t", "otro", 10_000L))
        assertFalse(d.repetido("a", "t", "x", 40_000L)) // ya pasó la ventana
    }

    private fun av(id: String) = Aviso(id, 0L, "App", "p", "t", "x")

    @Test fun laColaEntregaEnOrdenYSeVacia() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 1000L)
        assertTrue(c.agregar(av("1"), 0L))
        assertTrue(c.agregar(av("2"), 0L))
        assertEquals("1", c.siguiente(0L)?.aviso?.id)
        assertEquals("2", c.siguiente(0L)?.aviso?.id)
        assertNull(c.siguiente(0L))
    }

    @Test fun laColaNoRepiteIds() {
        val c = ColaAvisos()
        assertTrue(c.agregar(av("1"), 0L))
        assertFalse(c.agregar(av("1"), 1L))
        assertEquals(1, c.tamano(1L))
    }

    @Test fun laColaTiraLoViejoCuandoSeLlenaYLoCuenta() {
        val c = ColaAvisos(capacidad = 3, vidaMs = 10_000L)
        for (i in 1..5) c.agregar(av("$i"), 0L)
        assertEquals(3, c.tamano(0L))
        assertEquals("3", c.siguiente(0L)?.aviso?.id)
        assertEquals(2, c.tomarPerdidos())
        assertEquals(0, c.tomarPerdidos())
    }

    @Test fun laColaCaducaLoViejo() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 1000L)
        c.agregar(av("1"), 0L)
        c.agregar(av("2"), 900L)
        assertEquals("2", c.siguiente(1500L)?.aviso?.id)
        assertNull(c.siguiente(1500L))
    }

    private fun chat(id: String, chat: String, texto: String = "x") = Aviso(id, 0L, "WhatsApp", "com.whatsapp", "Ana", texto, chat = chat, remitente = "Ana", mensajeria = true)

    @Test fun mensajesSeguidosDeLaMismaConversacionSeJuntan() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 10_000L, masNuevoPrimero = true)
        c.agregar(chat("1", "ana", "uno"), 0L)
        c.agregar(chat("2", "pedro", "hola"), 0L)
        c.agregar(chat("3", "ana", "dos"), 0L)
        assertEquals(2, c.tamano(0L))
        val e = c.siguiente(0L)!!.aviso
        assertEquals("ana", e.chat)
        assertEquals(2, e.cantidad)
        assertEquals("dos", e.texto)
    }

    @Test fun masNuevoPrimeroLeeLoUltimoQueLlego() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 10_000L, masNuevoPrimero = true)
        c.agregar(chat("1", "ana"), 0L)
        c.agregar(chat("2", "pedro"), 1L)
        assertEquals("pedro", c.siguiente(2L)?.aviso?.chat)
        assertEquals("ana", c.siguiente(2L)?.aviso?.chat)
    }

    @Test fun masNuevoPrimeroDevolverLoDejaPrimeroDeNuevo() {
        val c = ColaAvisos(capacidad = 5, vidaMs = 10_000L, masNuevoPrimero = true)
        c.agregar(chat("1", "ana"), 0L)
        c.agregar(chat("2", "pedro"), 1L)
        val e = c.siguiente(2L)!!
        c.devolver(e)
        assertEquals("pedro", c.siguiente(2L)?.aviso?.chat)
    }

    @Test fun lasFusionesNoPierdenLoSensible() {
        val a = chat("1", "ana", "hola")
        val b = a.copy(id = "2", tipo = TipoAviso.CODIGO, texto = "", remitente = "", titulo = "")
        val f = a.fusionarCon(b)
        assertEquals(TipoAviso.CODIGO, f.tipo)
        assertEquals("", f.texto)
        assertEquals(2, f.cantidad)
        assertEquals(TipoAviso.CODIGO, b.fusionarCon(a).tipo)
    }

    @Test fun devolverPoneElAvisoAlFrente() {
        val c = ColaAvisos()
        c.agregar(av("1"), 0L)
        c.agregar(av("2"), 0L)
        val e = c.siguiente(0L)!!
        c.devolver(e)
        assertEquals("1", c.siguiente(0L)?.aviso?.id)
    }
}
