package com.julio.asistente.cuerpo

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DedupeOrigenesTest {
    private fun av(texto: String, remitente: String = "Ana") =
        Aviso("x", 0L, "WhatsApp", "com.whatsapp", remitente, texto, remitente = remitente, mensajeria = true)

    @Test fun elMismoMensajePorLosDosCaminosSeLeeUnaVez() {
        val d = DedupeOrigenes(ventanaMs = 90_000L)
        assertFalse(d.repetido(av("hola"), Origen.LOCAL, 0L))
        assertTrue(d.repetido(av("hola"), Origen.DIARIO, 1_000L))
        assertTrue(d.repetido(av("hola"), Origen.DIARIO, 2_000L))
    }

    @Test fun elOrdenDeLlegadaNoImporta() {
        val d = DedupeOrigenes()
        assertFalse(d.repetido(av("hola"), Origen.DIARIO, 0L))
        assertTrue(d.repetido(av("hola"), Origen.LOCAL, 500L))
    }

    @Test fun dosMensajesIgualesPorElMismoCaminoSonDistintos() {
        val d = DedupeOrigenes()
        assertFalse(d.repetido(av("hola"), Origen.LOCAL, 0L))
        assertFalse(d.repetido(av("hola"), Origen.LOCAL, 5_000L))
    }

    @Test fun mensajesDistintosOPasadaLaVentanaNoSeDescartan() {
        val d = DedupeOrigenes(ventanaMs = 90_000L)
        assertFalse(d.repetido(av("hola"), Origen.LOCAL, 0L))
        assertFalse(d.repetido(av("otra cosa"), Origen.DIARIO, 1_000L))
        assertFalse(d.repetido(av("hola"), Origen.DIARIO, 200_000L))
        assertFalse(d.repetido(av("hola", "Pedro"), Origen.DIARIO, 201_000L))
    }
}
