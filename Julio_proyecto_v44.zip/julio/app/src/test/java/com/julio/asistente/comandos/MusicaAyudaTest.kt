package com.julio.asistente.comandos

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** Música por voz y «¿qué puedes hacer?» (v38). Sin Android. */
class MusicaAyudaTest {
    private val hoy = LocalDate.of(2026, 11, 7)
    private val ahora = LocalTime.of(9, 0)
    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun siguienteCancion() {
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Siguiente canción"))
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Cambia de música"))
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Julio, pon otra canción"))
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Salta esta canción"))
    }

    @Test fun cancionAnterior() {
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Canción anterior"))
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Retrocede la canción"))
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Retrocede"))
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Regresa a la canción anterior"))
    }

    @Test fun pausaYSigue() {
        assertEquals(Intencion.Musica(AccionMusica.PAUSAR), i("Pausa la música"))
        assertEquals(Intencion.Musica(AccionMusica.PAUSAR), i("Para la música"))
        assertEquals(Intencion.Musica(AccionMusica.SEGUIR), i("Sigue la música"))
        assertEquals(Intencion.Musica(AccionMusica.SEGUIR), i("Reanuda la canción"))
    }

    @Test fun ponMusica() {
        assertEquals(Intencion.Musica(AccionMusica.PONER), i("Pon música"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, "musica para estudiar"), i("Reproduce música para estudiar"))
    }

    @Test fun ponMusicaDeAlguienOUnaCancion() {
        assertEquals(Intencion.Musica(AccionMusica.PONER, "bad bunny"), i("Pon música de Bad Bunny"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, "despacito"), i("Pon la canción Despacito"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, "bad bunny"), i("Julio pon la música de Bad Bunny en Spotify"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, "salsa"), i("Pon música de salsa por favor"))
    }

    @Test fun ponMusicaSinPedirNadaEsAlAzar() {
        assertEquals(Intencion.Musica(AccionMusica.PONER, null), i("Pon música"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, null), i("Pon música aleatoria"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, null), i("Pon música en YouTube Music"))
        assertEquals(Intencion.Musica(AccionMusica.PONER, null), i("Pon una canción cualquiera"))
    }

    @Test fun laCancionAleatoriaSaleDeLaLista() {
        repeat(30) { assertTrue(ConsultasMusica.GENEROS.contains(ConsultasMusica.aleatoria())) }
    }

    @Test fun queNotificacionesTengo() {
        assertEquals(Intencion.ConsultarAvisos, i("¿Qué notificaciones tengo?"))
        assertEquals(Intencion.ConsultarAvisos, i("Julio, qué notificaciones me llegaron"))
        assertEquals(Intencion.ConsultarAvisos, i("Tengo notificaciones"))
        assertEquals(Intencion.ConsultarAvisos, i("Léeme mis notificaciones"))
        assertEquals(Intencion.ConsultarAvisos, i("¿Qué me escribieron?"))
        assertEquals(Intencion.ConsultarAvisos, i("¿Qué mensajes tengo?"))
        assertNotEquals(Intencion.ConsultarAvisos, i("Tengo un mensaje para mamá"))
        assertNotEquals(Intencion.ConsultarAvisos, i("Agrega la tarea revisar notificaciones"))
    }

    @Test fun responder() {
        assertEquals(Intencion.Responder(null), i("Responde"))
        assertEquals(Intencion.Responder(null), i("Julio, responde"))
        assertEquals(Intencion.Responder(null), i("Contéstale"))
        assertEquals(Intencion.Responder(null), i("Responde ese mensaje"))
        assertEquals(Intencion.Responder("ana"), i("Responde a Ana"))
        assertEquals(Intencion.Responder("pedro"), i("Respóndele a Pedro"))
        assertEquals(Intencion.Responder("maria jose"), i("Quiero responder a María José"))
        assertNotEquals(Intencion.Responder(null), i("Contesta el teléfono"))
        assertNotEquals(Intencion.Responder(null), i("Agrega la tarea responder correos"))
    }

    @Test fun noSeConfundeConOtrasOrdenes() {
        assertNotEquals(Intencion.Musica(AccionMusica.PAUSAR), i("Pausa el enfoque"))
        assertNotEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Cambia de tema"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.SUBIR), i("Sube el volumen de la música"))
        assertEquals(Intencion.AbrirApp("spotify"), i("Abre Spotify"))
    }

    @Test fun queSePuedeHacer() {
        assertEquals(Intencion.Ayuda, i("¿Qué puedes hacer?"))
        assertEquals(Intencion.Ayuda, i("Julio, qué sabes hacer"))
        assertEquals(Intencion.Ayuda, i("Ayuda"))
        assertEquals(Intencion.Ayuda, i("¿Qué puedo decirte?"))
    }
}
