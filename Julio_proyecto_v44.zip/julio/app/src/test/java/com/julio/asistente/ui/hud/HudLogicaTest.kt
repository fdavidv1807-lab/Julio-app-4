package com.julio.asistente.ui.hud

import com.julio.asistente.animacion.Capa
import com.julio.asistente.animacion.Principal
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HudLogicaTest {
    private fun datos(
        bateria: Int = 80, cargando: Boolean = false, wifi: Boolean = true, internet: Boolean = true, microfono: Boolean = true,
        escucha: Boolean = true, voz: EstadoVozHud = EstadoVozHud.LISTA, iaActiva: Boolean = true, iaClave: Boolean = true,
        avisosActivos: Boolean = true, pendientes: Int = 0, enlace: EstadoEnlaceHud = EstadoEnlaceHud.NO_APLICA,
    ) = DatosSistema(bateria, cargando, wifi, internet, microfono, escucha, voz, iaActiva, iaClave, avisosActivos, pendientes, enlace)

    @Test fun laVelocidadYElBrilloSubenConLaActividad() {
        val reposo = HudLogica.parametros(Principal.REPOSO)
        val dormido = HudLogica.parametros(Principal.DORMIDO)
        val escuchando = HudLogica.parametros(Principal.ESCUCHANDO)
        assertTrue(dormido.brillo < reposo.brillo && reposo.brillo < escuchando.brillo)
        assertTrue(dormido.velocidad < reposo.velocidad && reposo.velocidad < escuchando.velocidad)
    }

    @Test fun enReposoPocosCuadrosParaAhorrarBateria() {
        assertTrue(HudLogica.parametros(Principal.DORMIDO).intervaloMs > HudLogica.parametros(Principal.REPOSO).intervaloMs)
        assertTrue(HudLogica.parametros(Principal.REPOSO).intervaloMs > HudLogica.parametros(Principal.ESCUCHANDO).intervaloMs)
        assertTrue(Principal.values().all { HudLogica.parametros(it).intervaloMs in 1L..200L })
    }

    @Test fun soloEscuchandoYHablandoReaccionanAlSonidoYSoloPensandoEscanea() {
        assertTrue(HudLogica.parametros(Principal.ESCUCHANDO).reaccionaAlSonido)
        assertTrue(HudLogica.parametros(Principal.HABLANDO).reaccionaAlSonido)
        assertFalse(HudLogica.parametros(Principal.REPOSO).reaccionaAlSonido)
        assertTrue(HudLogica.parametros(Principal.PENSANDO).escaneo)
        assertFalse(HudLogica.parametros(Principal.HABLANDO).escaneo)
    }

    @Test fun elAvisoYElErrorMandanSobreElEstado() {
        assertEquals(TonoHud.CIAN, HudLogica.tono(Principal.REPOSO, Capa.NINGUNA))
        assertEquals(TonoHud.AMBAR, HudLogica.tono(Principal.HABLANDO, Capa.AVISO))
        assertEquals(TonoHud.ROJO, HudLogica.tono(Principal.ESCUCHANDO, Capa.ERROR))
        assertEquals(TonoHud.VERDE, HudLogica.tono(Principal.ENFOCADO, Capa.NINGUNA))
        assertEquals("ESCUCHANDO", HudLogica.etiqueta(Principal.ESCUCHANDO, Capa.NINGUNA))
        assertEquals("AVISO", HudLogica.etiqueta(Principal.ESCUCHANDO, Capa.AVISO))
        assertEquals("EN LÍNEA", HudLogica.etiqueta(Principal.REPOSO, Capa.NINGUNA))
    }

    @Test fun elNivelSubeRapidoYBajaDespacio() {
        val sube = HudLogica.suavizar(0f, 1f)
        val baja = HudLogica.suavizar(1f, 0f)
        assertEquals(0.5f, sube, 1e-6f)
        assertEquals(0.88f, baja, 1e-6f)
        assertEquals(1f, HudLogica.suavizar(0.9f, 5f, 1f, 1f), 1e-6f)
    }

    @Test fun elHistorialDeOndaGuardaLosUltimosEnOrden() {
        val h = HistorialOnda(4)
        assertArrayEquals(floatArrayOf(0f, 0f, 0f, 0f), h.valores(), 0f)
        h.agregar(0.1f); h.agregar(0.2f)
        assertArrayEquals(floatArrayOf(0f, 0f, 0.1f, 0.2f), h.valores(), 1e-6f)
        h.agregar(0.3f); h.agregar(0.4f); h.agregar(0.5f); h.agregar(2f)
        assertArrayEquals(floatArrayOf(0.3f, 0.4f, 0.5f, 1f), h.valores(), 1e-6f)
    }

    @Test fun todoEnOrdenDaOptimo() {
        val filas = HudSistema.filas(datos())
        assertEquals("ÓPTIMO" to NivelHud.OK, HudSistema.resumen(filas))
        assertEquals(7, filas.size) // sin fila de enlace
    }

    @Test fun laBateriaBajaDaAvisoYErrorSalvoSiCarga() {
        assertEquals(NivelHud.AVISO, HudSistema.filas(datos(bateria = 20)).first { it.nombre == "BATERÍA" }.nivel)
        assertEquals(NivelHud.ERROR, HudSistema.filas(datos(bateria = 10)).first { it.nombre == "BATERÍA" }.nivel)
        val cargando = HudSistema.filas(datos(bateria = 10, cargando = true)).first { it.nombre == "BATERÍA" }
        assertEquals(NivelHud.OK, cargando.nivel)
        assertEquals("10% ⚡", cargando.valor)
    }

    @Test fun laIAPasaPorSusCuatroEstados() {
        fun ia(d: DatosSistema) = HudSistema.filas(d).first { it.nombre == "IA" }
        assertEquals(NivelHud.APAGADO, ia(datos(iaActiva = false)).nivel)
        assertEquals("FALTA CLAVE", ia(datos(iaClave = false)).valor)
        assertEquals("SIN INTERNET", ia(datos(internet = false)).valor)
        assertEquals("LISTA", ia(datos()).valor)
    }

    @Test fun loApagadoAPropositoNoCuentaComoProblema() {
        val filas = HudSistema.filas(datos(iaActiva = false, avisosActivos = false))
        assertEquals("ÓPTIMO" to NivelHud.OK, HudSistema.resumen(filas))
    }

    @Test fun unProblemaCambiaElResumen() {
        assertEquals("ATENCIÓN", HudSistema.resumen(HudSistema.filas(datos(wifi = false))).first)
        assertEquals("FALLA", HudSistema.resumen(HudSistema.filas(datos(microfono = false))).first)
    }

    @Test fun elEnlaceSoloApareceEnElCuerpo() {
        assertTrue(HudSistema.filas(datos(enlace = EstadoEnlaceHud.ESCUCHANDO)).any { it.nombre == "ENLACE" && it.nivel == NivelHud.OK })
        assertEquals(NivelHud.AVISO, HudSistema.filas(datos(enlace = EstadoEnlaceHud.CERRADO)).first { it.nombre == "ENLACE" }.nivel)
    }

    @Test fun losAvisosPendientesSeCuentan() {
        assertEquals("3 POR LEER", HudSistema.filas(datos(pendientes = 3)).first { it.nombre == "AVISOS" }.valor)
    }

    @Test fun siNoCabenSeMuestranPrimeroLosProblemas() {
        val filas = HudSistema.filas(datos(microfono = false, wifi = false, enlace = EstadoEnlaceHud.ESCUCHANDO))
        val v = HudSistema.visibles(filas, 5)
        assertEquals(5, v.size)
        assertTrue(v.any { it.nombre == "MICRÓFONO" } && v.any { it.nombre == "WI-FI" })
        assertEquals(v.map { it.nombre }, filas.map { it.nombre }.filter { n -> v.any { it.nombre == n } }) // conserva el orden
        assertEquals(filas, HudSistema.visibles(filas, 20))
    }
}
