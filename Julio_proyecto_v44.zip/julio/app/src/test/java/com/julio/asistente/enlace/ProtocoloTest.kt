package com.julio.asistente.enlace

import com.julio.asistente.cuerpo.Aviso
import com.julio.asistente.cuerpo.TipoAviso
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.IOException

class ProtocoloTest {
    private val secreto = ByteArray(10) { (it * 7 + 1).toByte() }
    private val clave = Protocolo.claveDe(secreto)
    private val aviso = Aviso(
        "abc-123", 1_000_000L, "WhatsApp", "com.whatsapp", "Ana", "¿Vamos a comer? ñandú", TipoAviso.NORMAL,
        chat = "0|com.whatsapp|1|x|10123", remitente = "Ana", grupo = "Familia", cantidad = 3, mensajeria = true, aceptaOrdenes = true,
    )

    @Test fun idaYVueltaConservaTodo() {
        val trama = Protocolo.codificar(aviso, clave)
        assertEquals(aviso, Protocolo.decodificar(trama, clave))
    }

    @Test fun laTramaNoLlevaElTextoEnClaro() {
        val trama = Protocolo.codificar(aviso, clave)
        assertFalse(String(trama, Charsets.ISO_8859_1).contains("Vamos"))
    }

    @Test fun conOtraClaveSeRechaza() {
        val trama = Protocolo.codificar(aviso, clave)
        val otra = Protocolo.claveDe(ByteArray(10) { 9 })
        assertNull(Protocolo.decodificar(trama, otra))
    }

    @Test fun siSeAlteraUnByteSeRechaza() {
        val trama = Protocolo.codificar(aviso, clave)
        for (i in listOf(0, 2, 10, trama.size / 2, trama.size - 1)) {
            val mala = trama.copyOf()
            mala[i] = (mala[i].toInt() xor 1).toByte()
            assertNull("byte $i", Protocolo.decodificar(mala, clave))
        }
    }

    @Test fun dosEnviosDelMismoAvisoNoSonIguales() {
        assertFalse(Protocolo.codificar(aviso, clave).contentEquals(Protocolo.codificar(aviso, clave)))
    }

    @Test fun leerTramaLeeLaTramaCompletaYRechazaBasura() {
        val trama = Protocolo.codificar(aviso, clave)
        assertArrayEquals(trama, Protocolo.leerTrama(ByteArrayInputStream(trama + byteArrayOf(1, 2, 3))))
        try {
            Protocolo.leerTrama(ByteArrayInputStream("GET / HTTP/1.1\r\n\r\n".toByteArray()))
            throw AssertionError("debía fallar")
        } catch (e: IOException) { /* bien */ }
    }

    @Test fun elIdPublicoNoCambiaYTiene6Caracteres() {
        assertEquals(6, Protocolo.idPublico(secreto).length)
        assertEquals(Protocolo.idPublico(secreto), Protocolo.idPublico(secreto.copyOf()))
        assertNotEquals(Protocolo.idPublico(secreto), Protocolo.idPublico(ByteArray(10)))
    }

    @Test fun elVerificadorRechazaHoraYRepetidos() {
        val v = Verificador(ventanaMs = 600_000L)
        assertEquals(Protocolo.ACK_OK, v.revisar(aviso, aviso.tiempo + 1000L))
        assertEquals(Protocolo.ACK_REPETIDO, v.revisar(aviso, aviso.tiempo + 2000L))
        assertEquals(Protocolo.ACK_HORA, v.revisar(aviso.copy(id = "otro"), aviso.tiempo + 700_000L))
        assertEquals(Protocolo.ACK_HORA, v.revisar(aviso.copy(id = "otro2"), aviso.tiempo - 700_000L))
    }

    @Test fun elCodigoDeEmparejamientoIdaYVuelta() {
        val f = CodigoEmparejamiento.formatear(secreto)
        assertEquals(19, f.length) // 16 + 3 guiones
        assertArrayEquals(secreto, CodigoEmparejamiento.leer(f))
        assertArrayEquals(secreto, CodigoEmparejamiento.leer(f.lowercase().replace("-", " ")))
    }

    private val orden = Orden("o-1", 1_000_000L, "0|com.whatsapp|1|x|10123", "Sí, a las 12. ñandú")

    @Test fun laOrdenIdaYVuelta() {
        val trama = Protocolo.codificarOrden(orden, clave)
        val o = Protocolo.decodificarOrden(trama, clave)!!
        assertEquals(orden.id, o.id)
        assertEquals(orden.tiempo, o.tiempo)
        assertEquals(orden.chat, o.chat)
        assertEquals(orden.texto, o.texto)
        assertArrayEquals(trama, Protocolo.leerTramaOrden(ByteArrayInputStream(trama + byteArrayOf(9))))
    }

    @Test fun laOrdenNoLlevaElTextoEnClaro() {
        val trama = Protocolo.codificarOrden(orden, clave)
        assertFalse(String(trama, Charsets.ISO_8859_1).contains("12"))
    }

    @Test fun unAvisoNoSePuedeUsarComoOrdenNiAlReves() {
        val tramaAviso = Protocolo.codificar(aviso, clave)
        val tramaOrden = Protocolo.codificarOrden(orden, clave)
        assertNull(Protocolo.decodificarOrden(tramaAviso, clave))
        assertNull(Protocolo.decodificar(tramaOrden, clave))
        try {
            Protocolo.leerTramaOrden(ByteArrayInputStream(tramaAviso))
            throw AssertionError("debía fallar")
        } catch (e: IOException) { /* bien */ }
    }

    @Test fun laOrdenConOtraClaveOAlteradaSeRechaza() {
        val trama = Protocolo.codificarOrden(orden, clave)
        assertNull(Protocolo.decodificarOrden(trama, Protocolo.claveDe(ByteArray(10) { 9 })))
        for (i in listOf(0, 2, 10, trama.size / 2, trama.size - 1)) {
            val mala = trama.copyOf()
            mala[i] = (mala[i].toInt() xor 1).toByte()
            assertNull("byte $i", Protocolo.decodificarOrden(mala, clave))
        }
    }

    @Test fun elVerificadorDeOrdenesRechazaRepetidasYViejas() {
        val v = Verificador(ventanaMs = 600_000L)
        assertEquals(Protocolo.ACK_OK, v.revisarId("o-1", 1_000_000L, 1_001_000L))
        assertEquals(Protocolo.ACK_REPETIDO, v.revisarId("o-1", 1_000_000L, 1_002_000L))
        assertEquals(Protocolo.ACK_HORA, v.revisarId("o-2", 1_000_000L, 2_000_000L))
    }

    @Test fun elQrIdaYVuelta() {
        val q = Qr.contenido(secreto, "192.168.1.25", 48217)
        assertTrue(q.startsWith("JULIO1;"))
        val d = Qr.leer(q)!!
        assertArrayEquals(secreto, d.secreto)
        assertEquals("192.168.1.25", d.ip)
        assertEquals(48217, d.puerto)
    }

    @Test fun elQrSinIpSigueSiendoValido() {
        val d = Qr.leer(Qr.contenido(secreto, null, 48217))!!
        assertEquals("", d.ip)
        assertEquals(0, d.puerto)
    }

    @Test fun elQrRechazaLoQueNoEsDeJulio() {
        assertNull(Qr.leer("https://ejemplo.com"))
        assertNull(Qr.leer("JULIO1;1234;192.168.1.25;48217"))
        assertNull(Qr.leer(Qr.contenido(secreto, "192.168.1.25", 48217).replace("192.168.1.25", "999.1.1.1")))
        assertNull(Qr.leer(Qr.contenido(secreto, "192.168.1.25", 48217).replace(";48217", ";70000")))
    }

    @Test fun elCodigoToleraConfusionesYRechazaErrores() {
        val f = CodigoEmparejamiento.formatear(ByteArray(10)) // 0000-0000-0000-0000
        assertArrayEquals(ByteArray(10), CodigoEmparejamiento.leer(f.replace('0', 'O')))
        assertNull(CodigoEmparejamiento.leer("1234"))
        assertNull(CodigoEmparejamiento.leer("UUUU-UUUU-UUUU-UUUU")) // la U no existe en el alfabeto
    }

    @Test fun losSecretosNuevosSonDistintosYValidos() {
        val a = CodigoEmparejamiento.nuevoSecreto()
        val b = CodigoEmparejamiento.nuevoSecreto()
        assertEquals(10, a.size)
        assertFalse(a.contentEquals(b))
        assertNotNull(CodigoEmparejamiento.leer(CodigoEmparejamiento.formatear(a)))
        assertTrue(CodigoEmparejamiento.formatear(a).matches(Regex("[0-9A-Z]{4}(-[0-9A-Z]{4}){3}")))
    }
}
