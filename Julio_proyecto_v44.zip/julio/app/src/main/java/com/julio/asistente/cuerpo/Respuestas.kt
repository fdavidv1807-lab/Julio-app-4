package com.julio.asistente.cuerpo

/**
 * Un chat al que se puede responder: guarda CÓMO enviar (la acción «Responder» de su notificación, que vive solo en memoria).
 * [enviar] devuelve false si la notificación ya no sirve.
 */
class RespuestaPosible(
    val chat: String,
    /** A quién se le dice: el nombre, «un número desconocido» o el nombre del grupo. */
    val nombre: String,
    val esGrupo: Boolean,
    var tiempo: Long,
    var enviar: (String) -> Boolean,
)

/**
 * Chats a los que Julio puede responder: solo los mensajes que llegaron a ESTE teléfono (el WhatsApp complementario del Cuerpo),
 * nunca códigos ni bancos, y solo mientras su notificación exista. En memoria, máx. [maximo], caducan a los [vidaMs]. Lógica pura.
 */
class RegistroRespuestas(private val vidaMs: Long = 15 * 60_000L, private val maximo: Int = 10) {
    private val items = LinkedHashMap<String, RespuestaPosible>()

    @Synchronized
    private fun purgar(ahora: Long) {
        items.values.removeAll { ahora - it.tiempo > vidaMs }
    }

    /** Llegó un mensaje nuevo de este chat: se puede responder y pasa a ser el más reciente. */
    @Synchronized
    fun registrar(r: RespuestaPosible) {
        purgar(r.tiempo)
        items.remove(r.chat)
        items[r.chat] = r
        while (items.size > maximo) {
            val primero = items.entries.iterator()
            primero.next()
            primero.remove()
        }
    }

    /** La notificación se volvió a publicar (con una acción nueva): se actualiza SIN tocar cuál es la más reciente. */
    @Synchronized
    fun refrescar(chat: String, enviar: (String) -> Boolean) {
        items[chat]?.enviar = enviar
    }

    /** Ya no se puede responder a este chat (la notificación se borró, o era sensible). */
    @Synchronized
    fun quitar(chat: String) {
        items.remove(chat)
    }

    @Synchronized
    fun porChat(chat: String, ahora: Long): RespuestaPosible? {
        purgar(ahora)
        return items[chat]
    }

    /** «Responde a Ana»: el chat cuyo nombre coincide (el más reciente si hay varios). */
    @Synchronized
    fun porNombre(nombre: String, ahora: Long): RespuestaPosible? {
        purgar(ahora)
        val buscado = Sensibles.norm(nombre)
        if (buscado.isBlank()) return null
        return items.values.toList().asReversed().firstOrNull {
            val n = Sensibles.norm(it.nombre)
            n.contains(buscado) || buscado.contains(n)
        }
    }

    @Synchronized
    fun vaciar() {
        items.clear()
    }
}

/** El registro único de la app (el Cuerpo). */
object RespuestasDisponibles {
    val registro = RegistroRespuestas()
}

/** Frases del diálogo de «responde». El mensaje dictado se limpia y NUNCA se envía sin «sí». Lógica pura. */
object PoliticaRespuesta {
    const val MAX_CARACTERES = 500

    /** Deja el texto dictado listo: sin espacios de más, primera letra en mayúscula, tope de largo. */
    fun limpiarDictado(s: String): String {
        val t = s.replace(Regex("\\s+"), " ").trim()
        return PoliticaLectura.recortar(t.replaceFirstChar { it.uppercase() }, MAX_CARACTERES)
    }

    /** «¿Qué le digo a Ana?» (en modo privado no dice el nombre). */
    fun preguntar(r: RespuestaPosible, privado: Boolean): String = when {
        privado -> "¿Qué le digo?"
        r.esGrupo -> "¿Qué le digo al grupo ${r.nombre}?"
        else -> "¿Qué le digo a ${r.nombre}?"
    }

    /** Repite lo que va a enviar y a quién, para que la persona lo confirme. */
    fun confirmar(r: RespuestaPosible, texto: String, privado: Boolean): String = when {
        privado -> "Le diré: $texto. ¿Lo envío?"
        r.esGrupo -> "Lo mando al grupo ${r.nombre}: $texto. ¿Lo envío?"
        else -> "Le diré a ${r.nombre}: $texto. ¿Lo envío?"
    }

    private val SI = Regex("\\b(si|sip|claro|seguro|confirmo|confirma|dale|adelante|ok|okay|afirmativo|hazlo|envialo|enviar|mandalo|manda)\\b")
    private val NO = Regex("\\b(no|nunca|negativo|cancela|cancelar)\\b")
    private val CAMBIAR = Regex("\\b(cambialo|cambiar|corrige|corrigelo|otra vez|repitelo|de nuevo)\\b")

    enum class Decision { ENVIAR, CANCELAR, CAMBIAR, NO_ENTENDI }

    /** Qué quiso decir la persona (texto ya normalizado) ante «¿Lo envío?». «no» gana si dijo las dos cosas. */
    fun decidir(n: String): Decision = when {
        NO.containsMatchIn(n) -> Decision.CANCELAR
        CAMBIAR.containsMatchIn(n) -> Decision.CAMBIAR
        SI.containsMatchIn(n) -> Decision.ENVIAR
        else -> Decision.NO_ENTENDI
    }
}
