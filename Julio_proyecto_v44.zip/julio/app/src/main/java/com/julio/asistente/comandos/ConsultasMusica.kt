package com.julio.asistente.comandos

import kotlin.random.Random

/** Búsquedas de música para cuando se pide «pon música» sin decir qué. Lógica pura. */
object ConsultasMusica {
    val GENEROS = listOf(
        "éxitos en español", "pop latino", "rock en español", "baladas románticas", "reggaeton", "salsa", "bachata",
        "música para relajarse", "lo-fi para concentrarse", "éxitos del momento", "clásicos de los 2000", "cumbia",
    )

    fun aleatoria(azar: Random = Random.Default): String = GENEROS[azar.nextInt(GENEROS.size)]
}
