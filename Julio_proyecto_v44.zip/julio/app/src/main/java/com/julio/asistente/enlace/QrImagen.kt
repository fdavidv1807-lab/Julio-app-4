package com.julio.asistente.enlace

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter

/** Dibuja el QR de emparejamiento (negro sobre blanco, para que cualquier lector lo vea aunque la app esté en modo oscuro). */
object QrImagen {
    fun crear(contenido: String, tam: Int = 640): Bitmap {
        val matriz = QRCodeWriter().encode(contenido, BarcodeFormat.QR_CODE, tam, tam, mapOf(EncodeHintType.MARGIN to 2))
        val puntos = IntArray(tam * tam)
        for (y in 0 until tam) for (x in 0 until tam) puntos[y * tam + x] = if (matriz[x, y]) Color.BLACK else Color.WHITE
        val bmp = Bitmap.createBitmap(tam, tam, Bitmap.Config.ARGB_8888)
        bmp.setPixels(puntos, 0, tam, 0, 0, tam, tam)
        return bmp
    }
}
