package com.julio.asistente.acciones

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.KeyEvent
import android.net.Uri
import android.provider.Settings
import com.julio.asistente.comandos.AccionMusica
import com.julio.asistente.comandos.AccionNivel
import com.julio.asistente.comandos.AppInfo
import com.julio.asistente.comandos.ConsultasMusica
import com.julio.asistente.escritorio.CalculoEscritorio
import com.julio.asistente.escritorio.EscritorioControl
import java.util.Calendar
import kotlin.math.roundToInt

class BrilloEscritorio(val porcentaje: Int, val limitado: Boolean, val automatico: Boolean)
class BrilloSistema(val porcentaje: Int, val automatico: Boolean)

/**
 * Acciones seguras sobre el propio teléfono (Etapa 3 del Proyecto Cuerpo): abrir apps, volumen y brillo.
 * Todas devuelven lo que el sistema dice DESPUÉS de cambiar, para que Julio solo afirme lo que comprobó.
 * No compra, no paga y no borra nada.
 */
object AccionesLocales {
    private var volumenPrevio: Int? = null

    // ----- Apps -----

    fun apps(c: Context): List<AppInfo> {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.paquete != c.packageName }
            .distinctBy { it.paquete }
    }

    /** null = se pidió abrir sin error; si no, el motivo. Android puede ignorar el arranque si Julio no está visible. */
    fun abrir(c: Context, paquete: String): String? {
        val intent = c.packageManager.getLaunchIntentForPackage(paquete) ?: return "esa aplicación no tiene pantalla de inicio"
        return try {
            c.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }

    // ----- Música (teclas multimedia para la app que esté sonando) -----

    private fun tecla(c: Context, codigo: Int) {
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, codigo))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, codigo))
    }

    private val APPS_MUSICA = listOf("com.google.android.apps.youtube.music", "com.spotify.music")

    /**
     * Devuelve lo que se puede afirmar. Android no dice si la orden surtió efecto: solo se sabe si había música sonando
     * (antes de pausar, siguiente o anterior) y si se pudo abrir la app.
     */
    fun musica(c: Context, accion: AccionMusica, consulta: String? = null): String {
        val am = c.getSystemService(AudioManager::class.java)
        return when (accion) {
            AccionMusica.SIGUIENTE, AccionMusica.ANTERIOR, AccionMusica.PAUSAR -> {
                if (!am.isMusicActive) return "No hay música sonando ahora."
                tecla(
                    c,
                    when (accion) {
                        AccionMusica.SIGUIENTE -> KeyEvent.KEYCODE_MEDIA_NEXT
                        AccionMusica.ANTERIOR -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                        else -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    },
                )
                when (accion) {
                    AccionMusica.SIGUIENTE -> "Listo, siguiente canción."
                    AccionMusica.ANTERIOR -> "Listo, canción anterior."
                    else -> "Listo, pausé la música."
                }
            }
            AccionMusica.SEGUIR -> {
                tecla(c, KeyEvent.KEYCODE_MEDIA_PLAY)
                "Listo, le pedí a la música que siga."
            }
            AccionMusica.PONER -> ponerMusica(c, am, consulta)
        }
    }

    private fun nombreDeMusica(paquete: String) = if (paquete.contains("spotify")) "Spotify" else "YouTube Music"

    /**
     * «Pon música»: le pide a la app de música que reproduzca una búsqueda (lo que pediste o, si no pediste nada, un género al azar).
     * Android no confirma si empezó a sonar. Si la app no acepta la búsqueda, solo se abre y se le manda «play».
     */
    private fun ponerMusica(c: Context, am: AudioManager, consulta: String?): String {
        if (consulta == null && am.isMusicActive) return "Ya hay música sonando. Di «siguiente canción» para cambiarla."
        val paquete = APPS_MUSICA.firstOrNull { c.packageManager.getLaunchIntentForPackage(it) != null }
            ?: return "No encontré YouTube Music ni Spotify en este teléfono."
        val app = nombreDeMusica(paquete)
        val busqueda = consulta ?: ConsultasMusica.aleatoria()
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .setPackage(paquete)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            .putExtra(SearchManager.QUERY, busqueda)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            c.startActivity(intent)
            if (consulta != null) "Le pedí a $app que ponga $consulta. No puedo confirmar que haya empezado."
            else "Pongo algo al azar en $app: $busqueda. No puedo confirmar que haya empezado."
        } catch (e: Exception) {
            val error = abrir(c, paquete)
            if (error != null) return "No pude abrir $app: $error."
            Handler(Looper.getMainLooper()).postDelayed({ tecla(c, KeyEvent.KEYCODE_MEDIA_PLAY) }, 2500L)
            "Abrí $app, pero no acepta que le pida canciones. Le mando «play»; si no suena, ponla tú."
        }
    }

    // ----- Volumen (de medios: el de la voz de Julio, música y videos) -----

    /** Aplica la acción y devuelve el porcentaje real que quedó (leído del sistema). */
    fun volumen(c: Context, accion: AccionNivel, nivel: Int?): Int {
        val am = c.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val actual = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (accion != AccionNivel.CONSULTAR) {
            if (accion == AccionNivel.SILENCIAR && actual > 0) volumenPrevio = actual
            val nuevo = CalculoAjustes.nuevoVolumenPasos(actual, max, accion, nivel, volumenPrevio)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, nuevo, AudioManager.FLAG_SHOW_UI)
        }
        return CalculoAjustes.porcentajeDeVolumen(am.getStreamVolume(AudioManager.STREAM_MUSIC), max)
    }

    // ----- Brillo -----

    private fun horaActual() = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    /** En modo escritorio el brillo es el de la ventana (no hace falta ningún permiso) y tiene un tope para cuidar la pantalla AMOLED. */
    fun brilloEscritorio(accion: AccionNivel, nivel: Int?): BrilloEscritorio {
        val horario = CalculoEscritorio.brilloPorHora(horaActual())
        val actualPct = ((EscritorioControl.brilloManual.value ?: horario) * 100f).roundToInt()
        var pedido = actualPct
        when (accion) {
            AccionNivel.AUTOMATICO -> EscritorioControl.fijarBrilloManual(null)
            AccionNivel.CONSULTAR -> {}
            else -> {
                pedido = CalculoAjustes.nuevoPorcentaje(actualPct, accion, nivel, paso = 5)
                EscritorioControl.fijarBrilloManual(CalculoEscritorio.limitarBrilloEscritorio(pedido / 100f))
            }
        }
        val manual = EscritorioControl.brilloManual.value
        val pct = ((manual ?: horario) * 100f).roundToInt()
        val limitado = (accion == AccionNivel.SUBIR || accion == AccionNivel.FIJAR) && pedido > pct
        return BrilloEscritorio(pct, limitado, manual == null)
    }

    fun puedeCambiarBrilloSistema(c: Context): Boolean = Settings.System.canWrite(c)

    /** Abre la pantalla de Ajustes donde la persona concede «Modificar ajustes del sistema» a Julio. */
    fun abrirPermisoBrillo(c: Context) {
        try {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (e: Exception) {
            // Sin esa pantalla: la respuesta de Julio explica qué permiso falta.
        }
    }

    private fun leerBrilloSistema(c: Context): BrilloSistema {
        val cr = c.contentResolver
        val valor = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val auto = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL) ==
            Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
        return BrilloSistema(CalculoAjustes.brilloSistemaPorcentaje(valor), auto)
    }

    /** Fuera del modo escritorio. Hay que tener el permiso (salvo para consultar). Devuelve lo que quedó, leído del sistema. */
    fun brilloSistema(c: Context, accion: AccionNivel, nivel: Int?): BrilloSistema {
        val cr = c.contentResolver
        when (accion) {
            AccionNivel.CONSULTAR -> {}
            AccionNivel.AUTOMATICO ->
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
            else -> {
                val nuevo = CalculoAjustes.limitarBrilloSistema(
                    CalculoAjustes.nuevoPorcentaje(leerBrilloSistema(c).porcentaje, accion, nivel),
                )
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, CalculoAjustes.brilloSistemaValor(nuevo))
            }
        }
        return leerBrilloSistema(c)
    }
}
