package com.julio.asistente.enlace

import android.content.Context
import com.julio.asistente.cuerpo.Aviso
import com.julio.asistente.cuerpo.ColaAvisos
import com.julio.asistente.cuerpo.RespuestasDisponibles
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Lado «teléfono de diario»: manda cada aviso (ya filtrado y saneado) al Cuerpo por la Wi-Fi de casa.
 * Sin Wi-Fi, o si no encuentra al Cuerpo, los avisos esperan en memoria (máx. 20, 10 minutos) y se reintenta cada 20 s;
 * lo que caduca se tira sin ruido. Todo corre en un solo hilo propio.
 */
object EnlaceDiario {
    private val ejecutor = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "julio-enlace-diario").also { it.isDaemon = true } }
    private val esperando = ColaAvisos(capacidad = 20, vidaMs = 10 * 60_000L)
    private val reintentoPuesto = AtomicBoolean(false)

    // v42: tras enviar un aviso de un chat al que se puede responder, la conexión se queda abierta unos minutos esperando una orden
    // del Cuerpo («responde esto»). Solo si la persona lo permitió; nunca bloquea el envío de otros avisos (usa sus propios hilos).
    private val hilosOrdenes = Executors.newCachedThreadPool { r -> Thread(r, "julio-enlace-ordenes").also { it.isDaemon = true } }
    private val limiteOrdenes = Semaphore(5)
    private val verificadorOrdenes = Verificador()
    private const val ESPERA_ORDENES_MS = 190_000L
    private const val REINTENTO_SEG = 20L
    private val horaFmt get() = SimpleDateFormat("HH:mm", Locale.getDefault())

    private enum class Resultado { ENVIADO, SIN_CAMINO, DESCARTADO, SIN_AUTORIZACION }

    fun enviar(c: Context, aviso: Aviso) {
        val app = c.applicationContext
        ejecutor.execute {
            if (EnlaceAjustes.rol.value != RolEnlace.DIARIO || EnlaceAjustes.secreto() == null) return@execute
            esperando.agregar(aviso, System.currentTimeMillis())
            vaciar(app)
        }
    }

    /** «Probar conexión»: revisa paso por paso y dice dónde se corta (Wi-Fi, código, dirección, puerto, respuesta). */
    fun diagnosticar(c: Context) {
        val app = c.applicationContext
        EnlaceAjustes.ponerDiagnostico(listOf("Probando…"))
        ejecutor.execute {
            val lineas = mutableListOf<String>()
            fun publicar() = EnlaceAjustes.ponerDiagnostico(lineas.toList())
            val secreto = EnlaceAjustes.secreto()
            if (secreto == null) {
                lineas += "✗ Código: no hay emparejamiento. Escanea el QR del Cuerpo."
                publicar(); return@execute
            }
            lineas += "✓ Código: emparejado."
            if (!hayWifi(app)) {
                lineas += "✗ Wi-Fi: este teléfono no está en una Wi-Fi. Conéctalo a la misma que el Cuerpo."
                publicar(); return@execute
            }
            lineas += "✓ Wi-Fi: conectado."
            publicar()
            val clave = Protocolo.claveDe(secreto)
            val prueba = Aviso(UUID.randomUUID().toString(), System.currentTimeMillis(), "Julio", "com.julio.asistente", "Prueba", "El diario se conectó con el Cuerpo.")
            var respuesta = -1
            var donde = ""
            for ((host, puerto) in EnlaceAjustes.destinos()) {
                val ack = enviarA(host, puerto, prueba, clave)
                if (ack != -1) { respuesta = ack; donde = "$host:$puerto"; break }
                lineas += "✗ Dirección $host:$puerto: no responde (¿cambió la IP del Cuerpo, o el modo escritorio está cerrado?)."
                publicar()
            }
            if (respuesta == -1) {
                lineas += "… Buscando al Cuerpo en la red (hasta 8 s)."
                publicar()
                val hallado = Descubridor.buscar(app, Protocolo.idPublico(secreto), 8_000L)
                if (hallado == null) {
                    lineas += "✗ Búsqueda: no lo encuentro. Revisa que el Cuerpo tenga el modo escritorio abierto y que el router no aísle los equipos (a veces se llama «aislamiento de clientes» o «red de invitados»). Si no, escribe su IP a mano."
                    publicar(); return@execute
                }
                EnlaceAjustes.guardarDestino(app, hallado.first, hallado.second)
                donde = "${hallado.first}:${hallado.second}"
                lineas += "✓ Búsqueda: lo encontré en $donde."
                respuesta = enviarA(hallado.first, hallado.second, prueba, clave)
                if (respuesta == -1) {
                    lineas += "✗ Puerto: lo encontré pero no contesta. Reinicia el modo escritorio en el Cuerpo."
                    publicar(); return@execute
                }
            } else {
                lineas += "✓ Dirección $donde: responde."
            }
            lineas += when (respuesta) {
                Protocolo.ACK_OK, Protocolo.ACK_REPETIDO -> "✓ Aviso de prueba entregado. El Cuerpo debería leerlo (si la lectura de avisos está encendida allí)."
                Protocolo.ACK_NO_AUTORIZADO -> "✗ Código: el Cuerpo respondió pero no reconoce este código. Escanea de nuevo su QR."
                Protocolo.ACK_HORA -> "✗ Hora: la hora de los dos teléfonos difiere más de 10 minutos. Pon la hora automática en ambos."
                else -> "✗ Respuesta rara del Cuerpo (código $respuesta)."
            }
            publicar()
        }
    }

    /** Manda un aviso de prueba (para comprobar el enlace sin esperar una notificación real). */
    fun probar(c: Context) {
        enviar(c, Aviso(UUID.randomUUID().toString(), System.currentTimeMillis(), "Julio", "com.julio.asistente", "Prueba", "Este es un aviso de prueba."))
    }

    private fun vaciar(app: Context) {
        val secreto = EnlaceAjustes.secreto() ?: return
        val clave = Protocolo.claveDe(secreto)
        while (true) {
            val e = esperando.siguiente(System.currentTimeMillis()) ?: break
            when (intentar(app, e.aviso, clave, secreto)) {
                Resultado.ENVIADO, Resultado.DESCARTADO -> continue
                Resultado.SIN_AUTORIZACION -> {
                    esperando.vaciar()
                    EnlaceAjustes.ponerEstado("El Cuerpo no reconoce este código. Vuelve a emparejar los teléfonos.")
                    break
                }
                Resultado.SIN_CAMINO -> {
                    esperando.devolver(e)
                    programarReintento(app)
                    break
                }
            }
        }
    }

    private fun programarReintento(app: Context) {
        if (!reintentoPuesto.compareAndSet(false, true)) return
        ejecutor.schedule({
            reintentoPuesto.set(false)
            vaciar(app)
        }, REINTENTO_SEG, TimeUnit.SECONDS)
    }

    private fun intentar(app: Context, aviso: Aviso, clave: ByteArray, secreto: ByteArray): Resultado {
        if (!hayWifi(app)) {
            EnlaceAjustes.ponerEstado("Sin Wi-Fi: los avisos esperan hasta 10 minutos.")
            return Resultado.SIN_CAMINO
        }
        for ((host, puerto) in EnlaceAjustes.destinos()) {
            val r = resultadoDe(enviarA(host, puerto, aviso, clave))
            if (r != null) return r
        }
        val hallado = Descubridor.buscar(app, Protocolo.idPublico(secreto), 8_000L)
        if (hallado == null) {
            EnlaceAjustes.ponerEstado("No encuentro al Cuerpo. Debe estar en modo escritorio y en la misma Wi-Fi (si el router aísla los equipos, no se verán).")
            return Resultado.SIN_CAMINO
        }
        EnlaceAjustes.guardarDestino(app, hallado.first, hallado.second)
        return resultadoDe(enviarA(hallado.first, hallado.second, aviso, clave)) ?: Resultado.SIN_CAMINO
    }

    /** null = no hubo respuesta (probar otra dirección). */
    private fun resultadoDe(ack: Int): Resultado? = when (ack) {
        Protocolo.ACK_OK, Protocolo.ACK_REPETIDO -> {
            EnlaceAjustes.ponerEstado("Enviado al Cuerpo a las ${horaFmt.format(Date())}.")
            Resultado.ENVIADO
        }
        Protocolo.ACK_NO_AUTORIZADO -> Resultado.SIN_AUTORIZACION
        Protocolo.ACK_HORA -> {
            EnlaceAjustes.ponerEstado("La hora de los dos teléfonos difiere más de 10 minutos; el Cuerpo rechazó el aviso.")
            Resultado.DESCARTADO
        }
        Protocolo.ACK_MALFORMADO -> Resultado.DESCARTADO
        else -> null
    }

    /** Devuelve el byte de respuesta del Cuerpo, o -1 si no se pudo conectar o no contestó. */
    private fun enviarA(host: String, puerto: Int, aviso: Aviso, clave: ByteArray): Int {
        val s = Socket()
        var conservar = false
        try {
            s.connect(InetSocketAddress(host, puerto), 2_500)
            s.soTimeout = 4_000
            s.getOutputStream().write(Protocolo.codificar(aviso, clave))
            s.getOutputStream().flush()
            val ack = s.getInputStream().read()
            if (ack == Protocolo.ACK_OK && aviso.aceptaOrdenes && limiteOrdenes.tryAcquire()) {
                conservar = true
                hilosOrdenes.execute { escucharOrdenes(s, clave) }
            }
            return ack
        } catch (e: IOException) {
            return -1
        } finally {
            if (!conservar) {
                try { s.close() } catch (e: IOException) { }
            }
        }
    }

    /** Espera órdenes del Cuerpo por esta conexión hasta ~3 min. Cada orden se valida y contesta con un byte. */
    private fun escucharOrdenes(s: Socket, clave: ByteArray) {
        val limite = System.currentTimeMillis() + ESPERA_ORDENES_MS
        try {
            while (true) {
                val resto = limite - System.currentTimeMillis()
                if (resto <= 0) break
                s.soTimeout = resto.toInt().coerceAtLeast(1)
                val trama = try {
                    Protocolo.leerTramaOrden(s.getInputStream())
                } catch (e: SocketTimeoutException) {
                    break
                }
                val resultado = ejecutarOrden(Protocolo.decodificarOrden(trama, clave))
                s.getOutputStream().write(resultado)
                s.getOutputStream().flush()
            }
        } catch (e: IOException) {
            // el Cuerpo cerró o la red se cortó
        } finally {
            try { s.close() } catch (e: IOException) { }
            limiteOrdenes.release()
        }
    }

    /**
     * Ejecuta una orden de respuesta: solo si el código es el correcto, la hora y el id son válidos, la persona activó
     * «Permitir que el Cuerpo responda» y ese chat sigue teniendo su notificación. Responde solo a chats que ya se avisaron.
     */
    private fun ejecutarOrden(orden: Orden?): Int {
        if (orden == null) return Protocolo.ACK_NO_AUTORIZADO
        val r = verificadorOrdenes.revisarId(orden.id, orden.tiempo, System.currentTimeMillis())
        if (r != Protocolo.ACK_OK) return r
        if (!EnlaceAjustes.permitirRespuestas.value) return Protocolo.ACK_SIN_PERMISO
        val texto = orden.texto.trim()
        if (texto.isEmpty() || texto.length > 600) return Protocolo.ACK_MALFORMADO
        val posible = RespuestasDisponibles.registro.porChat(orden.chat, System.currentTimeMillis()) ?: return Protocolo.ACK_NO_DISPONIBLE
        return if (posible.enviar(texto)) Protocolo.ACK_OK else Protocolo.ACK_NO_DISPONIBLE
    }

    private fun hayWifi(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    /** Busca «Julio-<id>» por NSD/mDNS (la IP del Cuerpo cambia). Bloquea hasta [esperaMs]; se llama desde el hilo propio. */
    internal object Descubridor {
        fun buscar(app: Context, id: String, esperaMs: Long): Pair<String, Int>? {
            val m = app.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return null
            val resultado = AtomicReference<Pair<String, Int>?>(null)
            val listo = CountDownLatch(1)
            val resolviendo = AtomicBoolean(false)
            val oyente = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(tipo: String) {}
                override fun onServiceFound(s: NsdServiceInfo) {
                    if (!s.serviceName.startsWith("Julio-$id")) return
                    if (!resolviendo.compareAndSet(false, true)) return
                    @Suppress("DEPRECATION")
                    m.resolveService(s, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(i: NsdServiceInfo, codigo: Int) { resolviendo.set(false) }
                        override fun onServiceResolved(i: NsdServiceInfo) {
                            @Suppress("DEPRECATION")
                            val direccion = i.host?.hostAddress
                            if (direccion != null) {
                                resultado.set(direccion to i.port)
                                listo.countDown()
                            }
                        }
                    })
                }
                override fun onServiceLost(s: NsdServiceInfo) {}
                override fun onDiscoveryStopped(tipo: String) {}
                override fun onStartDiscoveryFailed(tipo: String, codigo: Int) { listo.countDown() }
                override fun onStopDiscoveryFailed(tipo: String, codigo: Int) {}
            }
            try {
                m.discoverServices(Protocolo.TIPO_SERVICIO, NsdManager.PROTOCOL_DNS_SD, oyente)
                listo.await(esperaMs, TimeUnit.MILLISECONDS)
            } catch (e: Exception) {
                // sin descubrimiento: se queda sin resultado
            } finally {
                try { m.stopServiceDiscovery(oyente) } catch (e: Exception) { }
            }
            return resultado.get()
        }
    }
}
