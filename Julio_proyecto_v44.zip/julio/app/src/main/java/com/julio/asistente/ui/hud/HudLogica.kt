package com.julio.asistente.ui.hud

import com.julio.asistente.animacion.Capa
import com.julio.asistente.animacion.Principal

/** Cómo se mueve el HUD según el estado de Julio. Lógica pura (sin Compose): se prueba sin Android. */
data class HudParametros(
    /** Vueltas por segundo del anillo principal (los demás son múltiplos). */
    val velocidad: Float,
    /** 0..1: cuánto brillan los anillos. */
    val brillo: Float,
    /** Milisegundos entre cuadros: pocos cuadros en reposo (ahorra batería en la pantalla siempre encendida). */
    val intervaloMs: Long,
    /** El nivel de voz o micrófono ensancha el anillo de pulso. */
    val reaccionaAlSonido: Boolean,
    /** Arco de escaneo rápido (Julio está procesando). */
    val escaneo: Boolean,
)

/** Colores del HUD, sin depender de Compose. */
enum class TonoHud { CIAN, TURQUESA, AMBAR, ROJO, VERDE }

enum class NivelHud { OK, AVISO, ERROR, APAGADO }

data class FilaSistema(val nombre: String, val valor: String, val nivel: NivelHud)

enum class EstadoVozHud { LISTA, DESCARGANDO, SISTEMA }

enum class EstadoEnlaceHud { NO_APLICA, ESCUCHANDO, CERRADO }

/** Todo lo que el panel «SISTEMA» muestra: datos REALES del teléfono y de Julio, nada inventado. */
data class DatosSistema(
    val bateria: Int,
    val cargando: Boolean,
    val wifi: Boolean,
    val internet: Boolean,
    val microfono: Boolean,
    val escuchaJulio: Boolean,
    val voz: EstadoVozHud,
    val iaActiva: Boolean,
    val iaClave: Boolean,
    val avisosActivos: Boolean,
    val avisosPendientes: Int,
    val enlace: EstadoEnlaceHud,
)

object HudLogica {
    fun parametros(p: Principal): HudParametros = when (p) {
        Principal.REPOSO -> HudParametros(0.04f, 0.40f, 66L, reaccionaAlSonido = false, escaneo = false)
        Principal.DORMIDO -> HudParametros(0.015f, 0.18f, 125L, reaccionaAlSonido = false, escaneo = false)
        Principal.ESCUCHANDO -> HudParametros(0.20f, 0.90f, 33L, reaccionaAlSonido = true, escaneo = false)
        Principal.PENSANDO -> HudParametros(0.35f, 0.85f, 33L, reaccionaAlSonido = false, escaneo = true)
        Principal.HABLANDO -> HudParametros(0.12f, 0.90f, 33L, reaccionaAlSonido = true, escaneo = false)
        Principal.ENFOCADO -> HudParametros(0.05f, 0.50f, 66L, reaccionaAlSonido = false, escaneo = false)
    }

    /** Un aviso o un error mandan sobre el estado; luego manda el estado. */
    fun tono(p: Principal, alerta: Capa): TonoHud = when {
        alerta == Capa.ERROR -> TonoHud.ROJO
        alerta == Capa.AVISO -> TonoHud.AMBAR
        p == Principal.ENFOCADO -> TonoHud.VERDE
        p == Principal.PENSANDO -> TonoHud.TURQUESA
        else -> TonoHud.CIAN
    }

    /** Texto bajo el título. */
    fun etiqueta(p: Principal, alerta: Capa): String = when {
        alerta == Capa.ERROR -> "ERROR"
        alerta == Capa.AVISO -> "AVISO"
        else -> when (p) {
            Principal.REPOSO -> "EN LÍNEA"
            Principal.DORMIDO -> "EN REPOSO"
            Principal.ESCUCHANDO -> "ESCUCHANDO"
            Principal.PENSANDO -> "PROCESANDO"
            Principal.HABLANDO -> "HABLANDO"
            Principal.ENFOCADO -> "MODO ENFOQUE"
        }
    }

    /** Suaviza el nivel de sonido: sube rápido y baja despacio, para que el anillo no parpadee. */
    fun suavizar(actual: Float, objetivo: Float, subida: Float = 0.5f, bajada: Float = 0.12f): Float {
        val o = objetivo.coerceIn(0f, 1f)
        val k = if (o > actual) subida else bajada
        return (actual + (o - actual) * k).coerceIn(0f, 1f)
    }
}

/** Los últimos niveles de sonido para dibujar la onda (el más viejo primero). */
class HistorialOnda(private val capacidad: Int = 48) {
    private val datos = FloatArray(capacidad)
    private var siguiente = 0
    private var cuantos = 0

    @Synchronized
    fun agregar(v: Float) {
        datos[siguiente] = v.coerceIn(0f, 1f)
        siguiente = (siguiente + 1) % capacidad
        if (cuantos < capacidad) cuantos++
    }

    /** Siempre devuelve [capacidad] valores (los que faltan, 0). */
    @Synchronized
    fun valores(): FloatArray {
        val salida = FloatArray(capacidad)
        val inicio = if (cuantos < capacidad) 0 else siguiente
        val falta = capacidad - cuantos
        for (i in 0 until cuantos) salida[falta + i] = datos[(inicio + i) % capacidad]
        return salida
    }
}

object HudSistema {
    fun filas(d: DatosSistema): List<FilaSistema> {
        val l = ArrayList<FilaSistema>()
        l += FilaSistema(
            "BATERÍA", "${d.bateria}%" + if (d.cargando) " ⚡" else "",
            when {
                d.cargando || d.bateria >= 30 -> NivelHud.OK
                d.bateria >= 15 -> NivelHud.AVISO
                else -> NivelHud.ERROR
            },
        )
        l += FilaSistema("WI-FI", if (d.wifi) "CONECTADO" else "SIN WI-FI", if (d.wifi) NivelHud.OK else NivelHud.AVISO)
        l += FilaSistema("ESCUCHA", if (d.escuchaJulio) "ACTIVA" else "APAGADA", if (d.escuchaJulio) NivelHud.OK else NivelHud.AVISO)
        l += when (d.voz) {
            EstadoVozHud.LISTA -> FilaSistema("VOZ", "DE JULIO", NivelHud.OK)
            EstadoVozHud.DESCARGANDO -> FilaSistema("VOZ", "DESCARGANDO", NivelHud.AVISO)
            EstadoVozHud.SISTEMA -> FilaSistema("VOZ", "DEL TELÉFONO", NivelHud.AVISO)
        }
        l += when {
            !d.iaActiva -> FilaSistema("IA", "APAGADA", NivelHud.APAGADO)
            !d.iaClave -> FilaSistema("IA", "FALTA CLAVE", NivelHud.AVISO)
            !d.internet -> FilaSistema("IA", "SIN INTERNET", NivelHud.AVISO)
            else -> FilaSistema("IA", "LISTA", NivelHud.OK)
        }
        l += when {
            !d.avisosActivos -> FilaSistema("AVISOS", "APAGADOS", NivelHud.APAGADO)
            d.avisosPendientes > 0 -> FilaSistema("AVISOS", "${d.avisosPendientes} POR LEER", NivelHud.OK)
            else -> FilaSistema("AVISOS", "ACTIVOS", NivelHud.OK)
        }
        when (d.enlace) {
            EstadoEnlaceHud.ESCUCHANDO -> l += FilaSistema("ENLACE", "ESCUCHANDO", NivelHud.OK)
            EstadoEnlaceHud.CERRADO -> l += FilaSistema("ENLACE", "CERRADO", NivelHud.AVISO)
            EstadoEnlaceHud.NO_APLICA -> Unit
        }
        l += FilaSistema("MICRÓFONO", if (d.microfono) "PERMITIDO" else "SIN PERMISO", if (d.microfono) NivelHud.OK else NivelHud.ERROR)
        return l
    }

    /** «ÓPTIMO», «ATENCIÓN» o «FALLA»; lo apagado a propósito no cuenta. */
    fun resumen(filas: List<FilaSistema>): Pair<String, NivelHud> = when {
        filas.any { it.nivel == NivelHud.ERROR } -> "FALLA" to NivelHud.ERROR
        filas.any { it.nivel == NivelHud.AVISO } -> "ATENCIÓN" to NivelHud.AVISO
        else -> "ÓPTIMO" to NivelHud.OK
    }

    /** Si no caben todas (pantalla vertical), se muestran primero las que tienen problemas, en su orden original. */
    fun visibles(filas: List<FilaSistema>, maximo: Int): List<FilaSistema> {
        if (filas.size <= maximo) return filas
        val prioridad = filas.withIndex().sortedWith(
            compareBy({ if (it.value.nivel == NivelHud.ERROR || it.value.nivel == NivelHud.AVISO) 0 else 1 }, { it.index }),
        )
        return prioridad.take(maximo).sortedBy { it.index }.map { it.value }
    }
}
