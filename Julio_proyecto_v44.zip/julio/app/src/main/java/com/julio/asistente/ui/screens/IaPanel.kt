package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.ia.Gemini
import com.julio.asistente.ia.IaAjustes
import com.julio.asistente.ia.PoliticaIA
import com.julio.asistente.ia.ResultadoIA
import com.julio.asistente.ui.components.PanelJulio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Configuración > IA de consulta (v43). Apagada por defecto. Julio manda a Gemini SOLO la pregunta que dices después de
 * «Julio, pregúntale a la IA …», con tu propia clave; nunca notificaciones, contactos ni códigos.
 */
@Composable
fun IaPanel() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val activo by IaAjustes.activo.collectAsStateWithLifecycle()
    val clave by IaAjustes.clave.collectAsStateWithLifecycle()
    val modelos by IaAjustes.modelos.collectAsStateWithLifecycle()
    var nueva by rememberSaveable { mutableStateOf("") }
    var modelosTxt by rememberSaveable(modelos) { mutableStateOf(modelos) }
    var resultado by remember { mutableStateOf<String?>(null) }
    var probando by remember { mutableStateOf(false) }
    var mas by remember { mutableStateOf(false) }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Activar la IA de consulta", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = activo, onCheckedChange = { IaAjustes.fijarActivo(ctx, it) })
            }
            Text(
                "Se usa solo al decir «Julio, pregúntale a la IA …» y necesita internet. Julio dice un resumen corto y deja la respuesta completa en pantalla.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                if (clave.isBlank()) "Clave de Gemini: falta." else "Clave de Gemini: guardada ✓",
                style = MaterialTheme.typography.bodySmall,
                color = if (clave.isBlank()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            )
            OutlinedTextField(
                value = nueva,
                onValueChange = { nueva = it.take(120) },
                label = { Text("Pega aquí tu clave de Gemini") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        IaAjustes.fijarClave(ctx, nueva)
                        nueva = ""
                        resultado = "Clave guardada."
                    },
                    enabled = nueva.isNotBlank(),
                    shape = MaterialTheme.shapes.small,
                ) { Text("Guardar clave") }
                if (clave.isNotBlank()) TextButton(onClick = { IaAjustes.fijarClave(ctx, ""); resultado = "Clave borrada." }) { Text("Borrar clave") }
            }
            OutlinedButton(
                enabled = clave.isNotBlank() && !probando,
                onClick = {
                    probando = true
                    resultado = "Probando…"
                    scope.launch {
                        val r = withContext(Dispatchers.IO) {
                            Gemini.preguntar(IaAjustes.clave.value, IaAjustes.listaDeModelos(), emptyList(), "Responde solo con la palabra: listo")
                        }
                        resultado = when (r) {
                            is ResultadoIA.Texto -> "✓ Funciona (modelo ${r.modelo})."
                            is ResultadoIA.Falla -> "✗ " + PoliticaIA.mensajeDeError(r.error)
                        }
                        probando = false
                    }
                },
            ) { Text("Probar la IA") }
            resultado?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            Text(
                "Cómo sacar la clave (gratis, con tu cuenta de Google): entra a aistudio.google.com y busca «Get API key» " +
                    "(los nombres pueden cambiar). Copia la clave y pégala aquí.",
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                "Importante: no dictes datos de pacientes ni datos personales. En el nivel gratis, Google puede usar lo que envíes para mejorar sus productos. " +
                    "Solo se manda tu pregunta (y hasta 3 anteriores para dar contexto), nunca notificaciones, contactos ni códigos. " +
                    "La IA puede equivocarse, sobre todo en dosis y cifras: verifícalas en tu libro o guía.",
                style = MaterialTheme.typography.bodySmall,
            )
            TextButton(onClick = { mas = !mas }) { Text(if (mas) "Menos" else "Más") }
            if (mas) {
                OutlinedTextField(
                    value = modelosTxt,
                    onValueChange = { modelosTxt = it.take(200) },
                    label = { Text("Modelos, en orden de prueba") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { IaAjustes.fijarModelos(ctx, modelosTxt); resultado = "Modelos guardados." }, shape = MaterialTheme.shapes.small) { Text("Guardar") }
                    TextButton(onClick = { IaAjustes.fijarModelos(ctx, ""); resultado = "Modelos restablecidos." }) { Text("Restablecer") }
                }
                Text(
                    "Si uno llega a su límite gratis o ya no existe, Julio prueba el siguiente. Cada modelo tiene su propio cupo.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
