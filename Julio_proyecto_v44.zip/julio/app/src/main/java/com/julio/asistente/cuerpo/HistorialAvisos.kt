package com.julio.asistente.cuerpo

/**
 * Los avisos de los últimos minutos (ya leídos o no), para poder contestar «¿qué notificaciones tengo?». Solo en memoria,
 * máximo [capacidad] conversaciones y [vidaMs] de vida. Los códigos y avisos del banco entran SIN contenido. Lógica pura.
 */
class HistorialAvisos(private val capacidad: Int = 15, private val vidaMs: Long = 30 * 60_000L) {
    private val items = ArrayList<Entrada>()

    @Synchronized
    private fun purgar(ahora: Long) {
        items.removeAll { ahora - it.recibido > vidaMs }
    }

    @Synchronized
    fun registrar(a: Aviso, ahora: Long) {
        purgar(ahora)
        if (a.chat.isNotEmpty()) {
            val i = items.indexOfFirst { it.aviso.chat == a.chat }
            if (i >= 0) {
                val viejo = items.removeAt(i)
                items.add(Entrada(viejo.aviso.fusionarCon(a), ahora))
                return
            }
        }
        items.add(Entrada(a, ahora))
        while (items.size > capacidad) items.removeAt(0)
    }

    /** Del más nuevo al más viejo. */
    @Synchronized
    fun lista(ahora: Long): List<Aviso> {
        purgar(ahora)
        return items.map { it.aviso }.reversed()
    }

    @Synchronized
    fun vaciar() {
        items.clear()
    }
}
