package com.julio.asistente.cuerpo

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Ajustes de la lectura de avisos del Cuerpo (SharedPreferences «julio_cuerpo_avisos»; no toca la base de datos Room).
 * Todo apagado por defecto: nada se lee hasta que la persona lo enciende y elige las apps una por una.
 */
object CuerpoAjustes {
    private const val ARCHIVO = "julio_cuerpo_avisos"

    private val _activo = MutableStateFlow(false)
    val activo: StateFlow<Boolean> = _activo.asStateFlow()

    private val _privado = MutableStateFlow(false)
    val privado: StateFlow<Boolean> = _privado.asStateFlow()

    /** Paquetes de las apps cuyos avisos se leen. Vacío = ninguna. */
    private val _permitidas = MutableStateFlow<Set<String>>(emptySet())
    val permitidas: StateFlow<Set<String>> = _permitidas.asStateFlow()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun cargar(c: Context) {
        val p = sp(c)
        _activo.value = p.getBoolean("activo", false)
        _privado.value = p.getBoolean("privado", false)
        _permitidas.value = p.getStringSet("permitidas", emptySet())?.toSet() ?: emptySet()
    }

    /** ¿Tiene Julio el permiso «Acceso a notificaciones»? */
    fun accesoANotificaciones(c: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

    fun yaPreparado(c: Context): Boolean = sp(c).getBoolean("preparado", false)

    /**
     * Se llama al terminar de preparar el modo escritorio por primera vez: enciende la lectura de avisos y elige WhatsApp
     * si está instalado (y no hay otras apps elegidas). Después respeta lo que la persona cambie en Configuración.
     */
    fun prepararPorDefecto(c: Context) {
        val p = sp(c)
        if (p.getBoolean("preparado", false)) return
        val ed = p.edit().putBoolean("preparado", true).putBoolean("activo", true)
        var elegidas = _permitidas.value
        if (elegidas.isEmpty() && c.packageManager.getLaunchIntentForPackage("com.whatsapp") != null) {
            elegidas = setOf("com.whatsapp")
            ed.putStringSet("permitidas", elegidas)
        }
        ed.apply()
        _activo.value = true
        _permitidas.value = elegidas
    }

    fun fijarActivo(c: Context, valor: Boolean) {
        sp(c).edit().putBoolean("activo", valor).apply()
        _activo.value = valor
        if (!valor) CuerpoAvisos.vaciar()
    }

    fun alternarPrivado(c: Context) {
        val nuevo = !_privado.value
        sp(c).edit().putBoolean("privado", nuevo).apply()
        _privado.value = nuevo
    }

    fun permitir(c: Context, paquete: String, permitir: Boolean) {
        val nuevo = if (permitir) _permitidas.value + paquete else _permitidas.value - paquete
        sp(c).edit().putStringSet("permitidas", nuevo).apply()
        _permitidas.value = nuevo
    }
}
