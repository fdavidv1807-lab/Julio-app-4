package com.julio.asistente.ia

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Ajustes de la IA de consulta (SharedPreferences «julio_ia»; no toca la base de datos Room). Apagada por defecto.
 * La clave de Gemini queda en el almacenamiento privado de la app (allowBackup = false), sin cifrar aparte; no se muestra ni se registra.
 */
object IaAjustes {
    private const val ARCHIVO = "julio_ia"

    /** Se prueban en orden: si el primero llega a su límite (cada modelo tiene el suyo), se pasa al siguiente. */
    const val MODELOS_POR_DEFECTO = "gemini-flash-latest, gemini-flash-lite-latest"

    private val _activo = MutableStateFlow(false)
    val activo: StateFlow<Boolean> = _activo.asStateFlow()

    private val _clave = MutableStateFlow("")
    val clave: StateFlow<String> = _clave.asStateFlow()

    private val _modelos = MutableStateFlow(MODELOS_POR_DEFECTO)
    val modelos: StateFlow<String> = _modelos.asStateFlow()

    /** Todas las consultas pasan por la misma conversación (preguntas seguidas = contexto). */
    val conversacion = ConversacionIA()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun cargar(c: Context) {
        val p = sp(c)
        _activo.value = p.getBoolean("activo", false)
        _clave.value = p.getString("clave", "") ?: ""
        _modelos.value = (p.getString("modelos", MODELOS_POR_DEFECTO) ?: MODELOS_POR_DEFECTO).ifBlank { MODELOS_POR_DEFECTO }
    }

    fun fijarActivo(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("activo", v).apply()
        _activo.value = v
        if (!v) conversacion.vaciar()
    }

    fun fijarClave(c: Context, texto: String) {
        val limpia = texto.trim()
        sp(c).edit().putString("clave", limpia).apply()
        _clave.value = limpia
    }

    fun fijarModelos(c: Context, texto: String) {
        val limpio = texto.trim().ifBlank { MODELOS_POR_DEFECTO }
        sp(c).edit().putString("modelos", limpio).apply()
        _modelos.value = limpio
    }

    /** Lista de modelos a probar, en orden; solo nombres válidos (letras, números, punto y guion). */
    fun listaDeModelos(): List<String> =
        _modelos.value.split(",", ";", " ").map { it.trim().removePrefix("models/") }.filter { it.matches(Regex("[A-Za-z0-9._-]{3,60}")) }
}
