package com.julio.asistente.escritorio

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.EnlaceCuerpo
import com.julio.asistente.enlace.RolEnlace

/**
 * Mantiene a Julio vivo mientras el teléfono hace de cuerpo fijo (Etapa 1 del Proyecto Cuerpo).
 * Servicio en primer plano con notificación fija y wake lock parcial. NO usa el micrófono (eso es la Etapa 2).
 */
class JulioServicio : Service() {
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACCION_SALIR) {
            EscritorioControl.salir(this)
            stopSelf()
            return START_NOT_STICKY
        }
        crearCanal()
        val especial = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        val quiereMicrofono = intent?.getBooleanExtra(EXTRA_MICROFONO, false) == true &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        try {
            try {
                val tipo = if (quiereMicrofono) especial or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else especial
                ServiceCompat.startForeground(this, ID, notificacion(), tipo)
            } catch (e: Exception) {
                if (!quiereMicrofono) throw e
                // Android no dejó usar el tipo micrófono (p. ej. app no visible): se sigue solo con «special use».
                EscritorioControl.ultimoError = "Sin tipo micrófono: " + (e.message ?: e.javaClass.simpleName)
                ServiceCompat.startForeground(this, ID, notificacion(), especial)
            }
        } catch (e: Exception) {
            EscritorioControl.ultimoError = e.message ?: e.javaClass.simpleName
            stopSelf()
            return START_NOT_STICKY
        }
        if (wake == null) {
            val pm = getSystemService(PowerManager::class.java)
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "julio:escritorio").apply { acquire() }
        }
        // v40: si este teléfono es el Cuerpo, recibe los avisos del teléfono de diario (y mantiene la Wi-Fi despierta).
        EnlaceAjustes.cargar(this)
        if (EnlaceAjustes.rol.value == RolEnlace.CUERPO) {
            tomarWifi()
            EnlaceCuerpo.iniciar(this)
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun tomarWifi() {
        if (wifi != null) return
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val modo = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifi = wm.createWifiLock(modo, "julio:enlace").apply { acquire() }
        } catch (e: Exception) {
            EnlaceAjustes.ponerEstado("Wi-Fi: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    override fun onDestroy() {
        EnlaceCuerpo.detener()
        wifi?.let { if (it.isHeld) it.release() }
        wifi = null
        wake?.let { if (it.isHeld) it.release() }
        wake = null
        super.onDestroy()
    }

    private fun crearCanal() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CANAL, "Julio en el escritorio", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Mantiene a Julio activo mientras el teléfono está fijo en el escritorio"
            },
        )
    }

    private fun notificacion(): Notification {
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val salir = PendingIntent.getService(
            this, 1, Intent(this, JulioServicio::class.java).setAction(ACCION_SALIR),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CANAL)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle("Julio está activo")
            .setContentText("Modo escritorio")
            .setContentIntent(abrir)
            .addAction(0, "Salir", salir)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    companion object {
        const val EXTRA_MICROFONO = "microfono"
        private const val ID = 4201
        private const val CANAL = "julio_escritorio"
        private const val ACCION_SALIR = "com.julio.asistente.escritorio.SALIR"
    }
}
