package com.julio.asistente.enlace

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Qué hace este teléfono en el enlace. */
enum class RolEnlace { NINGUNO, DIARIO, CUERPO }

/**
 * Ajustes del enlace entre los dos teléfonos (SharedPreferences «julio_enlace»; no toca la base de datos Room).
 * El código de emparejamiento queda en el almacenamiento privado de la app (allowBackup = false); no está cifrado aparte.
 * En el teléfono de diario SOLO se reenvían las apps elegidas (ninguna por defecto; al emparejar se elige WhatsApp si está instalado).
 */
object EnlaceAjustes {
    private const val ARCHIVO = "julio_enlace"

    private val IPV4 = Regex("^[0-9]{1,3}(\\.[0-9]{1,3}){3}(:[0-9]{1,5})?$")

    private val _rol = MutableStateFlow(RolEnlace.NINGUNO)
    val rol: StateFlow<RolEnlace> = _rol.asStateFlow()

    /** Código con formato (XXXX-XXXX-XXXX-XXXX) o null si aún no hay. */
    private val _codigo = MutableStateFlow<String?>(null)
    val codigo: StateFlow<String?> = _codigo.asStateFlow()

    /** Apps del teléfono de diario cuyos avisos se reenvían al Cuerpo. */
    private val _permitidas = MutableStateFlow<Set<String>>(emptySet())
    val permitidas: StateFlow<Set<String>> = _permitidas.asStateFlow()

    /** ¿Deja este teléfono (diario) que el Cuerpo responda mensajes por él? Apagado por defecto. Cada respuesta exige un «sí» en el Cuerpo. */
    private val _permitirRespuestas = MutableStateFlow(false)
    val permitirRespuestas: StateFlow<Boolean> = _permitirRespuestas.asStateFlow()

    private val _ipManual = MutableStateFlow("")
    val ipManual: StateFlow<String> = _ipManual.asStateFlow()

    /** Línea de estado (nunca contiene texto de avisos). */
    private val _estado = MutableStateFlow("")
    val estado: StateFlow<String> = _estado.asStateFlow()
    fun ponerEstado(texto: String) { _estado.value = texto }

    /** Resultado de «Probar conexión», paso por paso. */
    private val _diagnostico = MutableStateFlow<List<String>>(emptyList())
    val diagnostico: StateFlow<List<String>> = _diagnostico.asStateFlow()
    fun ponerDiagnostico(lineas: List<String>) { _diagnostico.value = lineas }

    /** Puerto en el que escucha el Cuerpo (0 = no está escuchando). */
    private val _puertoLocal = MutableStateFlow(0)
    val puertoLocal: StateFlow<Int> = _puertoLocal.asStateFlow()
    fun ponerPuertoLocal(p: Int) { _puertoLocal.value = p }

    @Volatile private var ipCache: String = ""

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun cargar(c: Context) {
        val p = sp(c)
        _rol.value = runCatching { RolEnlace.valueOf(p.getString("rol", "NINGUNO") ?: "NINGUNO") }.getOrDefault(RolEnlace.NINGUNO)
        val cod = p.getString("codigo", null)
        _codigo.value = if (cod != null && CodigoEmparejamiento.leer(cod) != null) cod else null
        _permitidas.value = p.getStringSet("permitidas", emptySet())?.toSet() ?: emptySet()
        _permitirRespuestas.value = p.getBoolean("permitirRespuestas", false)
        _ipManual.value = p.getString("ipManual", "") ?: ""
        ipCache = p.getString("ipCache", "") ?: ""
    }

    fun fijarRol(c: Context, rol: RolEnlace) {
        sp(c).edit().putString("rol", rol.name).apply()
        _rol.value = rol
    }

    /** Crea un código nuevo (el teléfono de diario tendrá que volver a emparejarse). */
    fun nuevoCodigo(c: Context): String {
        val f = CodigoEmparejamiento.formatear(CodigoEmparejamiento.nuevoSecreto())
        sp(c).edit().putString("codigo", f).putString("ipCache", "").apply()
        ipCache = ""
        _codigo.value = f
        return f
    }

    private fun guardarCodigo(c: Context, secreto: ByteArray, pista: String) {
        val f = CodigoEmparejamiento.formatear(secreto)
        sp(c).edit().putString("codigo", f).putString("ipCache", pista).apply()
        ipCache = pista
        _codigo.value = f
        elegirWhatsAppSiPrimeraVez(c)
    }

    /** Empareja con el código escrito a mano. false si no es válido. */
    fun usarCodigo(c: Context, texto: String): Boolean {
        val secreto = CodigoEmparejamiento.leer(texto) ?: return false
        guardarCodigo(c, secreto, "")
        return true
    }

    /** Empareja con el contenido del QR (o con un código suelto, si se pegó solo eso). false si no es válido. */
    fun usarQr(c: Context, contenido: String): Boolean {
        val datos = Qr.leer(contenido) ?: return usarCodigo(c, contenido)
        guardarCodigo(c, datos.secreto, if (datos.ip.isEmpty()) "" else "${datos.ip}:${datos.puerto}")
        return true
    }

    /** Al emparejar el diario por primera vez, si no hay apps elegidas y WhatsApp está instalado, se elige. */
    private fun elegirWhatsAppSiPrimeraVez(c: Context) {
        if (_permitidas.value.isNotEmpty()) return
        if (c.applicationContext.packageManager.getLaunchIntentForPackage("com.whatsapp") == null) return
        permitir(c, "com.whatsapp", true)
    }

    fun borrarCodigo(c: Context) {
        sp(c).edit().remove("codigo").putString("ipCache", "").apply()
        ipCache = ""
        _codigo.value = null
    }

    fun secreto(): ByteArray? = _codigo.value?.let { CodigoEmparejamiento.leer(it) }

    fun fijarPermitirRespuestas(c: Context, valor: Boolean) {
        sp(c).edit().putBoolean("permitirRespuestas", valor).apply()
        _permitirRespuestas.value = valor
    }

    fun permitir(c: Context, paquete: String, permitir: Boolean) {
        val nuevo = if (permitir) _permitidas.value + paquete else _permitidas.value - paquete
        sp(c).edit().putStringSet("permitidas", nuevo).apply()
        _permitidas.value = nuevo
    }

    /** IP del Cuerpo escrita a mano (por si la red no deja que se encuentren solos). Vacía = automático. */
    fun fijarIpManual(c: Context, texto: String): Boolean {
        val t = texto.trim()
        if (t.isNotEmpty() && !IPV4.matches(t)) return false
        sp(c).edit().putString("ipManual", t).apply()
        _ipManual.value = t
        return true
    }

    fun guardarDestino(c: Context, host: String, puerto: Int) {
        ipCache = "$host:$puerto"
        sp(c).edit().putString("ipCache", ipCache).apply()
    }

    /** Direcciones a probar antes de buscar en la red: la escrita a mano y la última que funcionó (o la del QR). */
    fun destinos(): List<Pair<String, Int>> {
        val lista = mutableListOf<Pair<String, Int>>()
        for (t in listOf(_ipManual.value, ipCache)) {
            if (t.isBlank()) continue
            val partes = t.split(":")
            val puerto = partes.getOrNull(1)?.toIntOrNull() ?: Protocolo.PUERTO
            val par = partes[0] to puerto
            if (par !in lista) lista += par
        }
        return lista
    }
}
