package com.julio.asistente.cuerpo

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Avisos esperando turno para ser leídos en voz alta. Solo en memoria (nunca en disco); caducan a los 3 minutos. */
object CuerpoAvisos {
    // Lo viejo ya no sirve: caduca a los 3 minutos y se lee primero lo más nuevo.
    private val cola = ColaAvisos(capacidad = 20, vidaMs = 3 * 60_000L, masNuevoPrimero = true)
    private val historial = HistorialAvisos()
    private val _pendientes = MutableStateFlow(0)
    val pendientes: StateFlow<Int> = _pendientes.asStateFlow()

    private fun ahora() = System.currentTimeMillis()
    private fun actualizar() { _pendientes.value = cola.tamano(ahora()) }

    private val origenes = DedupeOrigenes()

    /**
     * [origen]: LOCAL = notificación de este teléfono; DIARIO = enviada por el teléfono de diario. Si el mismo mensaje llega por
     * los dos caminos (WhatsApp complementario en el Cuerpo y reenvío del diario), solo se lee una vez.
     */
    fun recibir(a: Aviso, origen: Origen = Origen.LOCAL) {
        if (origenes.repetido(a, origen, ahora())) return
        val aviso = a.copy(origen = origen)
        if (cola.agregar(aviso, ahora())) {
            historial.registrar(aviso, ahora())
            actualizar()
        }
    }

    /** Lo que llegó en los últimos 30 minutos (para «¿qué notificaciones tengo?»). */
    fun recientes(): List<Aviso> = historial.lista(ahora())
    /** El último aviso que Julio empezó a leer (para «responde»). */
    @Volatile var ultimoLeido: Aviso? = null
        private set
    @Volatile private var ultimoLeidoEn = 0L

    /** El último aviso leído si fue hace menos de 10 minutos; si no, null. */
    fun ultimoReciente(): Aviso? = if (ahora() - ultimoLeidoEn <= 10 * 60_000L) ultimoLeido else null

    fun siguiente(): Entrada? = cola.siguiente(ahora()).also {
        if (it != null) {
            ultimoLeido = it.aviso
            ultimoLeidoEn = ahora()
        }
        actualizar()
    }
    fun devolver(e: Entrada) { cola.devolver(e); actualizar() }
    fun perdidos(): Int = cola.tomarPerdidos()
    fun vaciar() { cola.vaciar(); historial.vaciar(); ultimoLeido = null; RespuestasDisponibles.registro.vaciar(); actualizar() }
}
