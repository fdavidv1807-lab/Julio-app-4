package com.julio.asistente.enlace

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.julio.asistente.cuerpo.ConversorAvisos
import com.julio.asistente.cuerpo.RespuestasDisponibles
import com.julio.asistente.cuerpo.TipoAviso

/**
 * Teléfono de diario: ve las notificaciones nuevas (permiso «Acceso a notificaciones», que se concede en Ajustes), deja solo las
 * de las apps elegidas, quita el contenido de códigos y bancos ANTES de enviar y las manda cifradas al Cuerpo por la Wi-Fi.
 * Si el teléfono no está en el rol «diario», no hace nada.
 */
class DiarioListener : NotificationListenerService() {
    private lateinit var conversor: ConversorAvisos

    override fun onCreate() {
        super.onCreate()
        EnlaceAjustes.cargar(applicationContext)
        // Guarda (solo en memoria) la acción «Responder» de cada chat: se usa solo si la persona activó «Permitir que el Cuerpo responda».
        conversor = ConversorAvisos(applicationContext, registrarRespuestas = true)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (EnlaceAjustes.rol.value != RolEnlace.DIARIO) return
            val aviso = conversor.convertir(sbn, EnlaceAjustes.permitidas.value) ?: return
            val acepta = EnlaceAjustes.permitirRespuestas.value && aviso.mensajeria && aviso.tipo == TipoAviso.NORMAL &&
                RespuestasDisponibles.registro.porChat(aviso.chat, System.currentTimeMillis()) != null
            EnlaceDiario.enviar(applicationContext, aviso.copy(aceptaOrdenes = acepta))
        } catch (e: Exception) {
            // Un aviso raro nunca debe tumbar el servicio.
        }
    }

    /** Si la notificación se borra ya no hay a dónde responder. */
    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        try {
            RespuestasDisponibles.registro.quitar(sbn.key.orEmpty())
        } catch (e: Exception) { }
    }

    /** Samsung y otros matan estos servicios: se pide al sistema que lo vuelva a conectar. */
    override fun onListenerDisconnected() {
        try {
            NotificationListenerService.requestRebind(ComponentName(this, DiarioListener::class.java))
        } catch (e: Exception) { }
    }
}
