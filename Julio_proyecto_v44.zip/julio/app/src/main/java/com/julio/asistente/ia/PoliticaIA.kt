package com.julio.asistente.ia

import com.julio.asistente.cuerpo.PoliticaLectura

/** Por qué falló una consulta a la IA. */
enum class ErrorIA { LIMITE, CLAVE, MODELO, SERVIDOR, SOLICITUD, BLOQUEADA, SIN_RED, OTRO }

/** Una pregunta con su respuesta, para que la IA entienda «¿y la dosis?» como continuación. */
data class Turno(val pregunta: String, val respuesta: String, val tiempo: Long)

/** Lógica pura de la IA de consulta (v43): qué se manda, qué se dice en voz alta y cómo se explican los errores. */
object PoliticaIA {
    /** Instrucción fija para la IA: estudiante de medicina, texto plano para poder leerlo en voz alta, sin inventar. */
    const val INSTRUCCION =
        "Eres Julio, un asistente de voz para un estudiante de medicina. Responde siempre en español, claro y preciso, " +
            "en un máximo de 8 oraciones (si te piden más detalle, puedes extenderte). Si no estás seguro de un dato, dilo; " +
            "no inventes cifras, dosis, estudios ni referencias. Para dosis y valores de referencia, recuerda que deben " +
            "verificarse en fuentes oficiales. No des diagnósticos ni indicaciones para un paciente concreto. " +
            "Escribe en texto plano: sin markdown, sin tablas, sin símbolos de lista ni asteriscos, porque tu respuesta se leerá en voz alta."

    // ----- Datos personales: no se mandan a internet -----

    private val CORREO = Regex("[\\w.+-]+@[\\w-]+\\.[\\w.]+")
    private val NUMERO_LARGO = Regex("(?<![0-9])[0-9]{9,}(?![0-9])")
    private val TELEFONO = Regex("(?<![0-9])\\+?[0-9]{2,3}[\\s.-][0-9]{3}[\\s.-][0-9]{3,4}(?![0-9])")

    /** ¿La pregunta parece llevar datos personales (correo, teléfono, cédula, historia clínica)? Entonces NO se envía. */
    fun datosPersonales(pregunta: String): Boolean =
        CORREO.containsMatchIn(pregunta) || NUMERO_LARGO.containsMatchIn(pregunta) || TELEFONO.containsMatchIn(pregunta)

    // ----- Texto de la respuesta -----

    /** Quita el formato de markdown (la pantalla de chat no lo dibuja y la voz lo leería). */
    fun limpiarRespuesta(t: String): String {
        var s = t.replace("\r", "")
        s = s.replace(Regex("```[\\s\\S]*?```"), " ")
        s = s.replace(Regex("(?m)^\\s{0,3}#{1,6}\\s*"), "")
        s = s.replace(Regex("(?m)^\\s*[*\\-•]\\s+"), "")
        s = s.replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        s = s.replace(Regex("\\*\\*|__|\\*|`"), "")
        s = s.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n{3,}"), "\n\n")
        return s.trim()
    }

    private val CIFRAS = Regex(
        "[0-9]+([.,][0-9]+)?\\s?(%|(mg|mcg|ug|µg|g|ml|ui|mmhg|mmol|meq|kg|l)\\b)|\\bdosis\\b",
        RegexOption.IGNORE_CASE,
    )

    /** ¿Trae dosis o cifras con unidades? Entonces Julio recuerda verificarlas. */
    fun llevaCifras(t: String): Boolean = CIFRAS.containsMatchIn(t)

    /**
     * Lo que Julio dice en voz alta: las primeras oraciones (hasta ~[maxChars] caracteres); el texto completo queda en pantalla.
     * Si hay dosis o cifras, recuerda verificarlas.
     */
    fun paraHablar(respuesta: String, maxChars: Int = 380): String {
        val plano = respuesta.replace(Regex("\\s+"), " ").trim()
        if (plano.isEmpty()) return plano
        val oraciones = plano.split(Regex("(?<=[.!?])\\s+"))
        val sb = StringBuilder()
        var recortado = false
        for (o in oraciones) {
            if (sb.isNotEmpty() && sb.length + o.length + 1 > maxChars) {
                recortado = true
                break
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(o)
        }
        var hablado = sb.toString()
        if (hablado.length > maxChars) {
            hablado = PoliticaLectura.recortar(hablado, maxChars)
            recortado = true
        }
        if (recortado) hablado += " El resto está en la pantalla."
        if (llevaCifras(plano)) hablado += " Verifica dosis y cifras en tu libro o guía."
        return hablado
    }

    // ----- Errores -----

    fun clasificar(codigo: Int, cuerpo: String): ErrorIA = when {
        codigo == 429 -> ErrorIA.LIMITE
        codigo == 404 -> ErrorIA.MODELO
        codigo in 500..599 -> ErrorIA.SERVIDOR
        codigo == 401 || codigo == 403 -> ErrorIA.CLAVE
        codigo == 400 && (cuerpo.contains("API_KEY_INVALID") || cuerpo.contains("API key not valid", ignoreCase = true)) -> ErrorIA.CLAVE
        codigo == 400 -> ErrorIA.SOLICITUD
        else -> ErrorIA.OTRO
    }

    /** ¿Vale la pena intentar con el siguiente modelo de la lista? (límite, modelo que ya no existe, servidor caído). */
    fun sirveProbarOtroModelo(e: ErrorIA): Boolean = e == ErrorIA.LIMITE || e == ErrorIA.MODELO || e == ErrorIA.SERVIDOR

    fun mensajeDeError(e: ErrorIA): String = when (e) {
        ErrorIA.LIMITE -> "La IA llegó a su límite gratuito por ahora. Inténtalo en unos minutos o mañana."
        ErrorIA.CLAVE -> "La clave de Gemini no sirve. Revísala en Configuración, en IA de consulta."
        ErrorIA.MODELO -> "El modelo de la IA ya no existe. Cámbialo en Configuración, en IA de consulta."
        ErrorIA.SERVIDOR -> "El servicio de la IA no está respondiendo. Inténtalo de nuevo en un momento."
        ErrorIA.SOLICITUD -> "La IA no aceptó esa pregunta."
        ErrorIA.BLOQUEADA -> "La IA no quiso responder esa pregunta."
        ErrorIA.SIN_RED -> "No pude conectarme a la IA. Revisa tu internet."
        ErrorIA.OTRO -> "La consulta a la IA falló. Inténtalo de nuevo."
    }
}

/** Las últimas preguntas y respuestas (máx. 3, 10 minutos, solo en memoria) para poder seguir la conversación. */
class ConversacionIA(private val maxTurnos: Int = 3, private val vidaMs: Long = 10 * 60_000L) {
    private val turnos = ArrayList<Turno>()

    @Synchronized
    private fun purgar(ahora: Long) {
        turnos.removeAll { ahora - it.tiempo > vidaMs }
    }

    @Synchronized
    fun agregar(pregunta: String, respuesta: String, ahora: Long) {
        purgar(ahora)
        turnos.add(Turno(pregunta.take(600), respuesta.take(1500), ahora))
        while (turnos.size > maxTurnos) turnos.removeAt(0)
    }

    @Synchronized
    fun historial(ahora: Long): List<Turno> {
        purgar(ahora)
        return turnos.toList()
    }

    @Synchronized
    fun vaciar() {
        turnos.clear()
    }
}
