package com.julio.asistente.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.core.Permisos
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.voz.EstadoPiper
import com.julio.asistente.voz.PiperModelo

/** Lo que hay que tener listo para usar el modo escritorio con avisos. */
object PrepararEscritorio {
    fun microfono(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun bateria(c: Context): Boolean =
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    /** Obligatorio: micrófono, notificaciones de Julio y acceso a las notificaciones del teléfono. */
    fun obligatoriosListos(c: Context): Boolean =
        microfono(c) && Permisos.notificaciones(c) && CuerpoAjustes.accesoANotificaciones(c)
}

/**
 * «Preparar el modo escritorio»: lista de lo necesario con un botón por cada cosa. El modo escritorio no se abre hasta tener
 * los tres obligatorios (micrófono, notificaciones de Julio, acceso a notificaciones). La voz y la batería son recomendadas.
 * Al entrar por primera vez se enciende la lectura de avisos y se elige WhatsApp si está instalado.
 */
@Composable
fun PrepararEscritorioDialog(alCerrar: () -> Unit) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    val refrescar = { version++ }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refrescar() }
    LaunchedEffect(Unit) { PiperModelo.iniciar(ctx) }
    val voz by PiperModelo.estado.collectAsStateWithLifecycle()

    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refrescar() }
    val pedirNotificaciones = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refrescar() }

    // «version» solo sirve para volver a leer los permisos cuando cambian.
    val microfono = version >= 0 && PrepararEscritorio.microfono(ctx)
    val notificaciones = version >= 0 && Permisos.notificaciones(ctx)
    val acceso = version >= 0 && CuerpoAjustes.accesoANotificaciones(ctx)
    val bateria = version >= 0 && PrepararEscritorio.bateria(ctx)
    val todoListo = microfono && notificaciones && acceso

    AlertDialog(
        onDismissRequest = alCerrar,
        title = { Text("Preparar el modo escritorio") },
        text = {
            Column(
                Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Hay que dejar esto listo una sola vez. Lo marcado con * es obligatorio.", style = MaterialTheme.typography.bodySmall)
                Paso("* Micrófono", "Para oír «Julio».", microfono, "Permitir") {
                    pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO)
                }
                Paso("* Notificaciones de Julio", "Para mostrar que el modo escritorio está activo.", notificaciones, "Permitir") {
                    if (Build.VERSION.SDK_INT >= 33) pedirNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else ctx.startActivity(Permisos.ajustesNotificaciones(ctx))
                }
                Paso(
                    "* Acceso a notificaciones",
                    "Para que Julio lea tus avisos. Si sale en gris: Ajustes > Aplicaciones > Julio > ⋮ > «Permitir ajustes restringidos».",
                    acceso,
                    "Abrir ajustes",
                ) { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                val vozLista = voz is EstadoPiper.Lista
                val descargando = voz as? EstadoPiper.Descargando
                Paso(
                    "Voz de Julio (recomendada)",
                    if (descargando != null) "Descargando… ${(descargando.progreso * 100).toInt()} %"
                    else "Descarga única de unos ${PiperModelo.TAMANO_APROX_MB} MB, con internet. Sin ella usa la voz del teléfono.",
                    vozLista,
                    "Descargar",
                ) { if (descargando == null) PiperModelo.descargar(ctx) }
                Paso("Batería sin restricciones (recomendada)", "Para que Samsung no cierre a Julio. Busca Julio y elige «Sin restricciones».", bateria, "Abrir ajustes") {
                    ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                Text(
                    "Al entrar, Julio empieza a leer en voz alta las notificaciones de WhatsApp (si lo tienes). Puedes cambiar las apps en Configuración > Avisos del Cuerpo. Los códigos y avisos del banco nunca se leen.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            Button(
                enabled = todoListo,
                onClick = {
                    CuerpoAjustes.prepararPorDefecto(ctx)
                    // Entrar al modo escritorio es ser el Cuerpo: si no tenía rol, se lo da (y crea su código de emparejamiento).
                    if (EnlaceAjustes.rol.value == RolEnlace.NINGUNO) {
                        EnlaceAjustes.fijarRol(ctx, RolEnlace.CUERPO)
                        if (EnlaceAjustes.codigo.value == null) EnlaceAjustes.nuevoCodigo(ctx)
                    }
                    EscritorioControl.entrar(ctx)
                    alCerrar()
                },
            ) { Text(if (todoListo) "Entrar al modo escritorio" else "Faltan los marcados con *") }
        },
        dismissButton = { TextButton(onClick = alCerrar) { Text("Cancelar") } },
    )
}

@Composable
private fun Paso(titulo: String, detalle: String, listo: Boolean, boton: String, alPulsar: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (listo) "✓" else "○", style = MaterialTheme.typography.titleMedium)
            Text(titulo, style = MaterialTheme.typography.titleSmall)
        }
        Text(detalle, style = MaterialTheme.typography.bodySmall)
        if (!listo) OutlinedButton(onClick = alPulsar, modifier = Modifier.fillMaxWidth()) { Text(boton) }
    }
}
