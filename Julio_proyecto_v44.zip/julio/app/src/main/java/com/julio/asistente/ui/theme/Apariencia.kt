package com.julio.asistente.ui.theme

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tema elegido por el usuario: 0 = automático (como el teléfono), 1 = claro, 2 = oscuro (por defecto). Solo afecta al aspecto. */
object Apariencia {
    private const val ARCHIVO = "julio_ui"
    private val _modo = MutableStateFlow(2)
    val modo: StateFlow<Int> = _modo.asStateFlow()

    /** Tema Cyber (HUD) del modo escritorio y de Inicio (v44). Encendido por defecto; apagado = interfaz clásica. */
    private val _cyber = MutableStateFlow(true)
    val cyber: StateFlow<Boolean> = _cyber.asStateFlow()

    fun cargar(c: Context) {
        val p = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)
        _modo.value = p.getInt("tema", 2)
        _cyber.value = p.getBoolean("cyber", true)
    }

    fun cambiarCyber(c: Context, valor: Boolean) {
        _cyber.value = valor
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("cyber", valor).apply()
    }

    fun cambiar(c: Context, valor: Int) {
        _modo.value = valor
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putInt("tema", valor).apply()
    }
}
