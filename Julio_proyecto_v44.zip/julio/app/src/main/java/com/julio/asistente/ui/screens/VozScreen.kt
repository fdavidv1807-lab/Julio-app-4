package com.julio.asistente.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.animacion.JulioAnimado
import com.julio.asistente.animacion.JulioEstado
import com.julio.asistente.ui.hud.HudOrbe
import com.julio.asistente.ui.theme.Apariencia
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.julio.asistente.ui.components.brilloRespirando
import com.julio.asistente.voz.EstadoVoz
import com.julio.asistente.voz.VozViewModel

@Composable
fun VozScreen(vm: VozViewModel = viewModel()) {
    val ctx = LocalContext.current
    val estado by vm.estado.collectAsStateWithLifecycle()
    val llamada by vm.llamada.collectAsStateWithLifecycle()
    val transcripcion by vm.transcripcion.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val historial by vm.historial.collectAsStateWithLifecycle()
    val hablar by vm.hablarRespuestas.collectAsStateWithLifecycle()
    val saludo by vm.saludoActivo.collectAsStateWithLifecycle()
    val orbeColor by vm.orbeColor.collectAsStateWithLifecycle()
    val cyber by Apariencia.cyber.collectAsStateWithLifecycle()
    val principal by JulioEstado.principal.collectAsStateWithLifecycle()
    val capa by JulioEstado.capa.collectAsStateWithLifecycle()
    var texto by remember { mutableStateOf("") }

    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        if (concedido) vm.iniciarLlamada() else vm.reportarPermisoDenegado()
    }

    // Modo escritorio: antes de entrar hay que tener listos micrófono, notificaciones y acceso a notificaciones (v39).
    var preparandoEscritorio by remember { mutableStateOf(false) }
    if (preparandoEscritorio) PrepararEscritorioDialog(alCerrar = { preparandoEscritorio = false })

    // La llamada se cuelga si la app pasa al fondo o si sales de esta pantalla: el micrófono no queda abierto.
    val dueno = LocalLifecycleOwner.current
    DisposableEffect(dueno) {
        val observador = LifecycleEventObserver { _, evento ->
            if (evento == Lifecycle.Event.ON_STOP) vm.salirDeLlamada()
        }
        dueno.lifecycle.addObserver(observador)
        onDispose {
            dueno.lifecycle.removeObserver(observador)
            vm.salirDeLlamada()
        }
    }

    fun enviar() {
        vm.enviarTexto(texto)
        texto = ""
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (cyber) {
            HudOrbe(
                vm = vm,
                principal = principal,
                capa = capa,
                orbeColor = orbeColor,
                alToque = { vm.interrumpir() },
                modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp).align(Alignment.CenterHorizontally),
            )
        } else {
            JulioAnimado(
                principal = principal,
                capa = capa,
                nivelMic = { vm.nivel.value },
                nivelHabla = { vm.nivelHabla() },
                palabras = { vm.palabras.value },
                alToque = { vm.interrumpir() },
                colorPorEstado = orbeColor,
                modifier = Modifier.fillMaxWidth().widthIn(max = 380.dp).align(Alignment.CenterHorizontally),
            )
        }
        val colorEstado by animateColorAsState(
            when (estado) {
                EstadoVoz.REPOSO -> MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                EstadoVoz.ESCUCHANDO -> MaterialTheme.colorScheme.primary
                EstadoVoz.PROCESANDO -> MaterialTheme.colorScheme.secondary
                EstadoVoz.RESPONDIENDO -> MaterialTheme.colorScheme.tertiary
            },
            tween(400), label = "colorEstado",
        )
        Text(
            when (estado) {
                EstadoVoz.REPOSO -> "LISTO"
                EstadoVoz.ESCUCHANDO -> "ESCUCHANDO..."
                EstadoVoz.PROCESANDO -> "PROCESANDO..."
                EstadoVoz.RESPONDIENDO -> "RESPONDIENDO..."
            },
            style = MaterialTheme.typography.titleMedium,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.5.sp,
            color = colorEstado,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )

        OutlinedButton(
            onClick = {
                if (PrepararEscritorio.obligatoriosListos(ctx) && com.julio.asistente.cuerpo.CuerpoAjustes.yaPreparado(ctx)) {
                    com.julio.asistente.escritorio.EscritorioControl.entrar(ctx)
                } else {
                    preparandoEscritorio = true
                }
            },
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        ) { Text("Modo escritorio") }

        // Controles principales
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val ocupado = estado == EstadoVoz.PROCESANDO
            Button(
                enabled = !ocupado && estado != EstadoVoz.ESCUCHANDO,
                onClick = {
                    if (vm.permisoMicrofono()) vm.iniciarLlamada() else pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO)
                },
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.height(56.dp).brilloRespirando(MaterialTheme.colorScheme.primary, 14.dp),
            ) {
                Icon(Icons.Filled.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Hablar con Julio")
            }
            if (llamada || estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.RESPONDIENDO) {
                OutlinedButton(
                    onClick = { vm.detener() },
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.height(56.dp),
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (llamada) "Colgar" else "Detener")
                }
            }
        }

        // Transcripción en vivo
        if (transcripcion.isNotBlank() && (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.PROCESANDO)) {
            Text("Dijiste: $transcripcion", style = MaterialTheme.typography.bodyMedium)
        }

        // Errores claros
        error?.let { mensaje ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(mensaje, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    Row {
                        if (!vm.permisoMicrofono()) {
                            TextButton(onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")),
                                )
                            }) { Text("Abrir ajustes de la app") }
                        }
                        TextButton(onClick = { vm.limpiarError() }) { Text("Cerrar") }
                    }
                }
            }
        }

        // Escribir en vez de hablar
        OutlinedTextField(
            value = texto,
            onValueChange = { texto = it },
            label = { Text("O escríbele a Julio") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { enviar() }),
            trailingIcon = {
                IconButton(enabled = texto.isNotBlank(), onClick = { enviar() }) {
                    Icon(Icons.Filled.Send, contentDescription = "Enviar")
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Respuestas habladas", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = hablar, onCheckedChange = { vm.alternarHablar() })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Saludo al abrir la app", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = saludo, onCheckedChange = { vm.alternarSaludo() })
        }

        // Conversación (solo de esta sesión)
        if (historial.isNotEmpty()) {
            Text("Conversación", style = MaterialTheme.typography.titleMedium)
            historial.takeLast(8).forEach { m ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (m.deUsuario) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            if (m.deUsuario) "TÚ" else "JULIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(m.texto, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Text(
                "La conversación no se guarda: se borra al cerrar la app. Tus tareas, horario y alarmas sí se guardan.",
                style = MaterialTheme.typography.labelSmall,
            )
        }

    }
}
