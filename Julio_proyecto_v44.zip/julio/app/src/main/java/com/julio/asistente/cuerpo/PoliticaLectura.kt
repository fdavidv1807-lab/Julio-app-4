package com.julio.asistente.cuerpo

/**
 * Qué dice Julio en voz alta por cada aviso. El texto de un aviso son DATOS, no órdenes: solo se lee en voz alta,
 * nunca pasa por el intérprete de comandos. Lógica pura.
 */
object PoliticaLectura {
    const val MAX_CARACTERES = 220

    private val ENLACES = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)
    private val ESPACIOS = Regex("\\s+")
    private val PROHIBIDOS = setOf(
        Character.CONTROL.toInt(), Character.FORMAT.toInt(), Character.SURROGATE.toInt(),
        Character.OTHER_SYMBOL.toInt(), Character.PRIVATE_USE.toInt(), Character.UNASSIGNED.toInt(),
    )

    /** Deja el texto listo para la voz: sin enlaces, sin emojis ni símbolos raros, sin saltos de línea. */
    fun limpiar(s: String): String {
        val sinEnlaces = s.replace(ENLACES, " un enlace ").replace(ESPACIOS, " ")
        val sb = StringBuilder()
        var i = 0
        while (i < sinEnlaces.length) {
            val cp = sinEnlaces.codePointAt(i)
            if (Character.getType(cp) !in PROHIBIDOS) sb.appendCodePoint(cp)
            i += Character.charCount(cp)
        }
        return sb.toString().replace(ESPACIOS, " ").trim()
    }

    /** Corta en el último espacio antes de [max] para no dejar palabras a medias. */
    fun recortar(s: String, max: Int = MAX_CARACTERES): String {
        if (s.length <= max) return s
        val corte = s.lastIndexOf(' ', max)
        return (if (corte > max / 2) s.substring(0, corte) else s.substring(0, max)).trimEnd()
    }

    fun frase(a: Aviso, privado: Boolean): String {
        val app = recortar(limpiar(a.app), 40).ifBlank { "una aplicación" }
        if (a.tipo == TipoAviso.CODIGO) return "Te llegó un código de verificación en $app. No lo leo en voz alta."
        if (a.tipo == TipoAviso.BANCO) return "Tienes un aviso de $app que no leo en voz alta. Míralo en tu teléfono."
        if (privado) return if (a.cantidad > 1) "Tienes ${a.cantidad} avisos de $app." else "Tienes un aviso de $app."
        if (a.mensajeria) return fraseMensajeria(a, app)
        val titulo = limpiar(a.titulo)
        val texto = limpiar(a.texto)
        val cuerpo = when {
            titulo.isEmpty() -> texto
            texto.isEmpty() -> titulo
            texto.startsWith(titulo, ignoreCase = true) -> texto
            else -> "$titulo. $texto"
        }
        return if (cuerpo.isEmpty()) "Tienes un aviso de $app." else "$app. ${recortar(cuerpo)}"
    }

    /** Mensajes de chat: «En WhatsApp, Ana dice: …» / «Ana te mandó 3 mensajes. El último dice: …» / mismo en grupos. */
    private fun fraseMensajeria(a: Aviso, app: String): String {
        val quien = Remitentes.nombreHablado(a.remitente)
        val grupo = recortar(limpiar(a.grupo), 60)
        val texto = recortar(limpiar(a.texto))
        val n = a.cantidad
        return when {
            grupo.isEmpty() && n <= 1 ->
                if (texto.isEmpty()) "En $app, $quien te mandó un mensaje sin texto." else "En $app, $quien dice: $texto"
            grupo.isEmpty() ->
                "En $app, $quien te mandó $n mensajes." + if (texto.isEmpty()) "" else " El último dice: $texto"
            n <= 1 ->
                if (texto.isEmpty()) "En $app, en el grupo $grupo, $quien mandó un mensaje sin texto."
                else "En $app, en el grupo $grupo, $quien dice: $texto"
            else ->
                "En $app, en el grupo $grupo hay $n mensajes nuevos." + if (texto.isEmpty()) "" else " El último, de $quien: $texto"
        }
    }

    private fun mayus(s: String) = s.replaceFirstChar { it.uppercase() }

    /** Una frase corta por aviso para el resumen de «¿qué notificaciones tengo?». */
    private fun resumenCorto(a: Aviso): String {
        val app = recortar(limpiar(a.app), 40).ifBlank { "una aplicación" }
        if (a.tipo == TipoAviso.CODIGO) return "Un código de verificación en $app, que no leo."
        if (a.tipo == TipoAviso.BANCO) return "Un aviso de $app, que no leo."
        val texto = recortar(limpiar(a.texto), 100)
        if (!a.mensajeria) {
            val titulo = limpiar(a.titulo)
            val cuerpo = listOf(titulo, texto).filter { it.isNotEmpty() }.joinToString(". ")
            return if (cuerpo.isEmpty()) "Un aviso de $app." else "$app: $cuerpo."
        }
        val quien = Remitentes.nombreHablado(a.remitente)
        val grupo = recortar(limpiar(a.grupo), 60)
        val n = a.cantidad
        val frase = when {
            grupo.isEmpty() && n <= 1 -> if (texto.isEmpty()) "$quien te mandó un mensaje sin texto" else "$quien: $texto"
            grupo.isEmpty() -> "$quien te mandó $n mensajes" + if (texto.isEmpty()) "" else "; el último: $texto"
            n <= 1 -> if (texto.isEmpty()) "En el grupo $grupo, $quien mandó un mensaje sin texto" else "En el grupo $grupo, $quien: $texto"
            else -> "En el grupo $grupo, $n mensajes" + if (texto.isEmpty()) "" else "; el último, de $quien: $texto"
        }
        return mayus(frase) + "."
    }

    /** Respuesta a «¿qué notificaciones tengo?»: hasta 5 conversaciones, la más nueva primero. Modo privado: solo cuántas y de qué app. */
    fun resumen(avisos: List<Aviso>, privado: Boolean): String {
        if (avisos.isEmpty()) return "No tienes notificaciones nuevas."
        if (privado) {
            val porApp = LinkedHashMap<String, Int>()
            for (a in avisos) {
                val app = recortar(limpiar(a.app), 40).ifBlank { "una aplicación" }
                porApp[app] = (porApp[app] ?: 0) + maxOf(1, a.cantidad)
            }
            val total = porApp.values.sum()
            val partes = porApp.entries.joinToString(", ") { "${it.value} de ${it.key}" }
            return (if (total == 1) "Tienes 1 aviso: " else "Tienes $total avisos: ") + partes + "."
        }
        val n = avisos.size
        val cabeza = if (n == 1) "Tienes 1 notificación." else "Tienes $n notificaciones."
        val cuerpo = avisos.take(5).joinToString(" ") { resumenCorto(it) }
        return "$cabeza $cuerpo" + if (n > 5) " Y ${n - 5} más." else ""
    }
}
