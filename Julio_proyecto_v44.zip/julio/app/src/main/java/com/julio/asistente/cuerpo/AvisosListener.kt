package com.julio.asistente.cuerpo

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.julio.asistente.escritorio.EscritorioControl

/**
 * Corre en el Cuerpo de Julio (el teléfono del escritorio). Ve las notificaciones que llegan a ESTE teléfono (WhatsApp vinculado
 * como dispositivo complementario, Gmail, etc.) y deja en cola las de las apps que la persona eligió, para que Julio las lea.
 * No usa la red. Requiere el permiso «Acceso a notificaciones» (Ajustes). Solo trabaja con el modo escritorio abierto y la lectura
 * encendida; si no, no hace nada.
 */
class AvisosListener : NotificationListenerService() {
    private lateinit var conversor: ConversorAvisos

    override fun onCreate() {
        super.onCreate()
        CuerpoAjustes.cargar(applicationContext)
        conversor = ConversorAvisos(applicationContext, registrarRespuestas = true)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (!CuerpoAjustes.activo.value || !EscritorioControl.activo.value) return
            val aviso = conversor.convertir(sbn, CuerpoAjustes.permitidas.value) ?: return
            CuerpoAvisos.recibir(aviso, Origen.LOCAL)
        } catch (e: Exception) {
            // Un aviso raro nunca debe tumbar el servicio.
        }
    }

    /** Si la notificación se borra ya no hay a dónde responder. */
    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        try {
            RespuestasDisponibles.registro.quitar(sbn.key.orEmpty())
        } catch (e: Exception) { }
    }

    /** Samsung y otros matan estos servicios: se pide al sistema que lo vuelva a conectar. */
    override fun onListenerDisconnected() {
        try {
            NotificationListenerService.requestRebind(ComponentName(this, AvisosListener::class.java))
        } catch (e: Exception) { }
    }
}
