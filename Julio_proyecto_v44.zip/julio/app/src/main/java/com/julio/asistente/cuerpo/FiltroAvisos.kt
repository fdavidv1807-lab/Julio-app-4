package com.julio.asistente.cuerpo

/** Lo que se sabe de una notificación recién publicada en este teléfono. */
data class NotificacionCruda(
    val paquete: String,
    val titulo: String,
    val texto: String,
    val categoria: String?,
    val enCurso: Boolean,
    val resumenGrupo: Boolean,
)

/** Decide qué notificaciones se leen en voz alta: solo las de las apps que la persona eligió. Lógica pura. */
object FiltroAvisos {
    /** Categorías que no son «avisos» para leer: descargas, música, servicios, sistema, navegación. */
    private val CATEGORIAS_IGNORADAS = setOf("progress", "transport", "service", "sys", "status", "navigation")
    private val PAQUETES_IGNORADOS = setOf("android", "com.android.systemui")

    /** null = se lee; si no, el motivo por el que se descarta. */
    fun motivoDescarte(n: NotificacionCruda, paquetePropio: String, permitidas: Set<String>): String? = when {
        n.paquete.isBlank() -> "sin paquete"
        n.paquete == paquetePropio -> "es de Julio"
        n.paquete in PAQUETES_IGNORADOS -> "del sistema"
        n.paquete !in permitidas -> "app no elegida"
        n.enCurso -> "notificación en curso"
        n.resumenGrupo -> "resumen de grupo"
        n.categoria != null && n.categoria in CATEGORIAS_IGNORADAS -> "categoría ${n.categoria}"
        n.titulo.isBlank() && n.texto.isBlank() -> "vacía"
        else -> null
    }
}

/** Evita reenviar la misma notificación dos veces seguidas (muchas apps la republican al actualizarla). Guarda solo números, no texto. */
class Deduplicador(private val ventanaMs: Long = 30_000L, private val maximo: Int = 50) {
    private val vistos = LinkedHashMap<Int, Long>()

    @Synchronized
    fun repetido(paquete: String, titulo: String, texto: String, ahora: Long): Boolean {
        val it = vistos.entries.iterator()
        while (it.hasNext()) if (ahora - it.next().value > ventanaMs) it.remove()
        val clave = listOf(paquete, titulo, texto).hashCode()
        if (vistos.containsKey(clave)) return true
        vistos[clave] = ahora
        while (vistos.size > maximo) {
            val primero = vistos.entries.iterator()
            primero.next()
            primero.remove()
        }
        return false
    }
}
