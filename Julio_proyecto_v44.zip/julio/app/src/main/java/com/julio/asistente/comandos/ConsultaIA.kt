package com.julio.asistente.comandos

/**
 * «Pregúntale a la IA …»: la ÚNICA forma de mandar una pregunta a internet. Se reconoce antes que cualquier otra orden
 * (una pregunta médica puede decir «examen», «horario» o «estudio» sin que sea una orden). Lógica pura.
 */
object ConsultaIA {
    private val DISPARADOR = Regex(
        "^(?:julio )?(?:preguntale|preguntar|pregunta|consulta|consultale|consultar|averigua|investiga)(?: le)? " +
            "(?:a |con |en |sobre )?(?:la |el )?(?:ia|inteligencia artificial|gemini|google|chat gpt|chatgpt|asistente)\\b ?(.*)$",
    )

    /** [n] = frase normalizada; [original] = lo que se dijo (para conservar acentos y signos en la pregunta). */
    fun interpretar(n: String, original: String): Intencion? {
        val limpia = n.trim()
        val m = DISPARADOR.find(limpia) ?: return null
        val cruda = m.groupValues[1]
        val normalizada = cruda.trim().trimStart(':', ',', ';', ' ')
        val disparador = limpia.removeSuffix(cruda).trim().split(" ").filter { it.isNotEmpty() }
        val delOriginal = preguntaDelOriginal(original, disparador).trim().trimStart(':', ',', ';', ' ')
        return Intencion.PreguntarIA((delOriginal.ifBlank { normalizada }).trim())
    }

    /** Quita del texto original las palabras del disparador (comparándolas ya normalizadas) y deja la pregunta tal como se dijo. */
    internal fun preguntaDelOriginal(original: String, disparador: List<String>): String {
        val tokens = original.trim().split(Regex("\\s+"))
        var i = 0
        var j = 0
        while (i < tokens.size && j < disparador.size) {
            // «Gemini:» y «IA,» llevan su signo pegado: se compara sin él.
            val t = Texto.normalizar(tokens[i]).trimEnd(':', ',', ';')
            if (t.isEmpty()) {
                i++
                continue
            }
            if (t == disparador[j]) {
                i++
                j++
            } else {
                return ""
            }
        }
        return if (j < disparador.size) "" else tokens.drop(i).joinToString(" ")
    }
}
