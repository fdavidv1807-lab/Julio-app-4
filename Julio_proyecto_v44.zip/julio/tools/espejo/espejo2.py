# Espejo en Python de la lógica nueva de v38 (mismas reglas y mismos casos que las pruebas Kotlin).
import re, unicodedata
from collections import deque
exec(open('espejo.py', encoding='utf-8').read().split('# --- Pruebas de Sensibles ---')[0])  # norm, norm_texto, clasificar
ENL = re.compile(r'(https?://|www\.)\S+', re.I)
exec('def limpiar' + open('espejo.py', encoding='utf-8').read().split('def limpiar',1)[1].split('def frase',1)[0])  # limpiar, recortar

# ---------- Remitentes y SeguimientoChats ----------
def es_numero(s): return re.fullmatch(r'[+()\-\s0-9.]+', s.strip()) is not None and sum(c.isdigit() for c in s) >= 6
def nombre_hablado(s):
    t = limpiar(s); return "un número desconocido" if (not t.strip() or es_numero(t)) else t

class Seguimiento:
    def __init__(s, max_edad=300000): s.v={}; s.max=max_edad
    def nuevos(s, chat, msgs, ahora):
        previo = s.v.get(chat, {}); usados={}; res=[]
        for m in sorted(msgs, key=lambda m:m[1]):          # m = (texto, tiempo, remitente)
            k=(m[1],m[0],m[2]); usados[k]=usados.get(k,0)+1
            if usados[k] > previo.get(k,0) and ahora-m[1] <= s.max: res.append(m)
        s.v[chat]=usados; return res
A=1_000_000
assert es_numero("+57 300 123 4567") and es_numero("3001234567") and not es_numero("Ana") and not es_numero("Oficina 12")
assert nombre_hablado("+57 300 123 4567")=="un número desconocido" and nombre_hablado("Ana")=="Ana" and nombre_hablado("")=="un número desconocido"
s=Seguimiento(); assert [m[0] for m in s.nuevos("c",[("viejo",A-900000,"Ana"),("hola",A-5000,"Ana")],A)]==["hola"]
s=Seguimiento(); s.nuevos("c",[("uno",A-3000,"Ana")],A)
assert [m[0] for m in s.nuevos("c",[("uno",A-3000,"Ana"),("dos",A-1000,"Ana")],A)]==["dos"]
assert s.nuevos("c",[("uno",A-3000,"Ana"),("dos",A-1000,"Ana")],A)==[]
s=Seguimiento(); assert len(s.nuevos("c",[("hola",A-1000,"Ana")]*2,A))==2; assert len(s.nuevos("c",[("hola",A-1000,"Ana")]*3,A))==1
s=Seguimiento(); s.nuevos("a",[("hola",A-1000,"Ana")],A); assert len(s.nuevos("b",[("hola",A-1000,"Ana")],A))==1
print("Remitentes y SeguimientoChats: OK")

# ---------- Cola con fusión y 'más nuevo primero' ----------
class Av:
    def __init__(s,id,chat="",texto="x",tipo="NORMAL",cant=1): s.id=id; s.chat=chat; s.texto=texto; s.tipo=tipo; s.cant=cant
    def fusionar(s,n):
        t = s.tipo if s.tipo!="NORMAL" else n.tipo
        r = Av(n.id,n.chat,n.texto,t,s.cant+n.cant)
        if t!="NORMAL": r.texto=""
        return r
class Cola2:
    def __init__(s,cap=20,vida=600000,nuevo_primero=False): s.items=[]; s.ids=deque(); s.perd=0; s.cap=cap; s.vida=vida; s.np=nuevo_primero
    def cad(s,ahora): s.items=[e for e in s.items if ahora-e[1]<=s.vida]
    def agregar(s,a,ahora):
        s.cad(ahora)
        if a.id in s.ids: return False
        s.ids.append(a.id)
        if a.chat:
            for i,e in enumerate(s.items):
                if e[0].chat==a.chat: s.items.pop(i); s.items.append((e[0].fusionar(a),ahora)); return True
        s.items.append((a,ahora))
        while len(s.items)>s.cap: s.items.pop(0); s.perd+=1
        return True
    def siguiente(s,ahora):
        s.cad(ahora)
        if not s.items: return None
        return s.items.pop() if s.np else s.items.pop(0)
    def devolver(s,e): s.items.append(e) if s.np else s.items.insert(0,e)
    def tam(s,ahora): s.cad(ahora); return len(s.items)
c=Cola2(5,10000,True); c.agregar(Av("1","ana","uno"),0); c.agregar(Av("2","pedro","hola"),0); c.agregar(Av("3","ana","dos"),0)
assert c.tam(0)==2; e=c.siguiente(0)[0]; assert e.chat=="ana" and e.cant==2 and e.texto=="dos"
c=Cola2(5,10000,True); c.agregar(Av("1","ana"),0); c.agregar(Av("2","pedro"),1)
assert c.siguiente(2)[0].chat=="pedro" and c.siguiente(2)[0].chat=="ana"
c=Cola2(5,10000,True); c.agregar(Av("1","ana"),0); c.agregar(Av("2","pedro"),1); e=c.siguiente(2); c.devolver(e); assert c.siguiente(2)[0].chat=="pedro"
a=Av("1","ana","hola"); b=Av("2","ana","",tipo="CODIGO"); f=a.fusionar(b)
assert f.tipo=="CODIGO" and f.texto=="" and f.cant==2 and b.fusionar(a).tipo=="CODIGO"
c=Cola2(5,1000); c.agregar(Av("1"),0); c.agregar(Av("2"),900); assert c.siguiente(1500)[0].id=="2" and c.siguiente(1500) is None
print("Cola con fusión y orden: OK")

# ---------- Frases de mensajería ----------
def frase_msg(app, rem, texto, n=1, grupo="", privado=False):
    if privado: return f"Tienes {n} avisos de {app}." if n>1 else f"Tienes un aviso de {app}."
    quien=nombre_hablado(rem); g=recortar(limpiar(grupo),60); t=recortar(limpiar(texto))
    if not g and n<=1: return f"En {app}, {quien} te mandó un mensaje sin texto." if not t else f"En {app}, {quien} dice: {t}"
    if not g: return f"En {app}, {quien} te mandó {n} mensajes." + ("" if not t else f" El último dice: {t}")
    if n<=1: return f"En {app}, en el grupo {g}, {quien} mandó un mensaje sin texto." if not t else f"En {app}, en el grupo {g}, {quien} dice: {t}"
    return f"En {app}, en el grupo {g} hay {n} mensajes nuevos." + ("" if not t else f" El último, de {quien}: {t}")
assert frase_msg("WhatsApp","Ana","¿vamos a comer?")=="En WhatsApp, Ana dice: ¿vamos a comer?"
assert frase_msg("WhatsApp","Ana","hola",3)=="En WhatsApp, Ana te mandó 3 mensajes. El último dice: hola"
assert frase_msg("WhatsApp","+57 300 123 4567","hola")=="En WhatsApp, un número desconocido dice: hola"
assert frase_msg("WhatsApp","","hola")=="En WhatsApp, un número desconocido dice: hola"
assert frase_msg("WhatsApp","Pedro","llego tarde",grupo="Familia")=="En WhatsApp, en el grupo Familia, Pedro dice: llego tarde"
assert frase_msg("WhatsApp","Pedro","llego tarde",4,"Familia")=="En WhatsApp, en el grupo Familia hay 4 mensajes nuevos. El último, de Pedro: llego tarde"
assert frase_msg("WhatsApp","Ana","")=="En WhatsApp, Ana te mandó un mensaje sin texto."
assert frase_msg("WhatsApp","Ana","secreto",3,privado=True)=="Tienes 3 avisos de WhatsApp." and "secreto" not in frase_msg("WhatsApp","Ana","secreto",privado=True)
print("Frases de mensajería: OK")

# ---------- Música y ayuda (mismas expresiones que Dispositivo.kt) ----------
def tiene(n,p): return re.search(p,n) is not None
INTERNAS=r"\b(alarma|alarmas|tarea|tareas|pendiente|pendientes|horario|agenda|meta|metas|enfoque|estudio|examen|clase|clases|actividad|actividades|descanso)\b"
AYUDA=r"\b(que (puedes|sabes|podes) (hacer|decir)|que haces|para que sirves|que puedo (decirte|decirle|pedirte|pedirle)|que comandos|que ordenes|como te uso|como se usa julio)\b|^(julio )?ayuda$"
NOMBRE=r"\b(cancion|canciones|musica|pista|rola)\b"
PON=r"\b(pon|poner|ponme|reproduce|reproducir|toca|tocar|play|inicia|iniciar|empieza|empezar)\b"
def musica(n):
    if tiene(n,r"^(julio )?(retrocede|retroceder)$"): return "ANTERIOR"
    if not tiene(n,NOMBRE): return None
    if tiene(n,r"\b(siguiente|proxima|otra|cambia|cambiar|cambiala|salta|saltar|avanza|avanzar|pasa|pasar|adelanta)\b"): return "SIGUIENTE"
    if tiene(n,r"\b(anterior|previa|retrocede|retroceder|regresa|regresar|devuelve|devolver|atras)\b"): return "ANTERIOR"
    if tiene(n,r"\b(pausa|pausar|pausala|deten|detener|detenla)\b") or (not tiene(n,PON) and tiene(n,r"\b(para|parar)\b")): return "PAUSAR"
    if tiene(n,r"\b(reanuda|reanudar|continua|continuar|sigue|seguir|resume)\b"): return "SEGUIR"
    if tiene(n,PON): return "PONER"
    return None
def interpretar(t):
    n=norm_texto(t)
    if tiene(n,INTERNAS): return None
    if tiene(n,AYUDA): return "AYUDA"
    if tiene(n,r"\b(volumen|sonido|audio)\b") and tiene(n,r"\b(sube|subir|aumenta|mas|alto)\b"): return "VOLUMEN_SUBE"
    m=musica(n)
    if m: return m
    if tiene(n,r"\b(abre|abrir|lanza)\b"): return "ABRIR"
    return None
casos = {"Siguiente canción":"SIGUIENTE","Cambia de música":"SIGUIENTE","Julio, pon otra canción":"SIGUIENTE","Salta esta canción":"SIGUIENTE",
 "Canción anterior":"ANTERIOR","Retrocede la canción":"ANTERIOR","Retrocede":"ANTERIOR","Regresa a la canción anterior":"ANTERIOR",
 "Pausa la música":"PAUSAR","Para la música":"PAUSAR","Sigue la música":"SEGUIR","Reanuda la canción":"SEGUIR",
 "Pon música":"PONER","Reproduce música para estudiar":"PONER",
 "Sube el volumen de la música":"VOLUMEN_SUBE","Abre Spotify":"ABRIR",
 "Pausa el enfoque":None,"Cambia de tema":None,
 "¿Qué puedes hacer?":"AYUDA","Julio, qué sabes hacer":"AYUDA","Ayuda":"AYUDA","¿Qué puedo decirte?":"AYUDA"}
for t,esp in casos.items(): assert interpretar(t)==esp, (t, interpretar(t), esp)
print("Música y ayuda:", len(casos), "frases OK")
