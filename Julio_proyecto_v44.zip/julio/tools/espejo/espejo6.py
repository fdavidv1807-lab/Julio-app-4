# Espejo de lo nuevo de v43: IA de consulta (reconocimiento de la orden, datos personales, limpieza y resumen hablado, errores).
import re, json, unicodedata
exec(open('espejo5.py', encoding='utf-8').read().split('# ---------- Registro ----------')[0])   # norm_texto, limpiar, recortar, etc.

# ---------- Reconocimiento de «pregúntale a la IA» ----------
DISP=re.compile(r"^(?:julio )?(?:preguntale|preguntar|pregunta|consulta|consultale|consultar|averigua|investiga)(?: le)? (?:a |con |en |sobre )?(?:la |el )?(?:ia|inteligencia artificial|gemini|google|chat gpt|chatgpt|asistente)\b ?(.*)$")
def pregunta_del_original(original, disparador):
    toks=original.strip().split(); i=j=0
    while i<len(toks) and j<len(disparador):
        t=norm_texto(toks[i]).rstrip(":,;")
        if t=="": i+=1; continue
        if t==disparador[j]: i+=1; j+=1
        else: return ""
    return "" if j<len(disparador) else " ".join(toks[i:])
def consulta_ia(original):
    n=norm_texto(original).strip()
    m=DISP.search(n)
    if not m: return None
    cruda=m.group(1); norm_q=cruda.strip().lstrip(":,; ")
    disp=n[:len(n)-len(cruda)].strip().split(); disp=[d for d in disp if d]
    orig=pregunta_del_original(original,disp).strip().lstrip(":,; ")
    return (orig or norm_q).strip()
casos={
 "Pregúntale a la IA ¿cuál es el mecanismo de acción de la metformina?":"¿cuál es el mecanismo de acción de la metformina?",
 "Julio, pregúntale a la inteligencia artificial qué es la hipertensión":"qué es la hipertensión",
 "Consulta a Gemini: dosis de amoxicilina en niños":"dosis de amoxicilina en niños",
 "Pregúntale a la IA":"", "Julio, consulta a Gemini":"",
 "Pregúntale a la IA cuándo conviene estudiar para un examen de anatomía":"cuándo conviene estudiar para un examen de anatomía",
 "Pregúntale a la IA qué es un estudio de cohortes":"qué es un estudio de cohortes",
 "Pregunta cuántas tareas tengo":None,"Abre Gemini":None,"¿Qué notificaciones tengo?":None}
for t,esp in casos.items(): assert consulta_ia(t)==esp,(t,consulta_ia(t),esp)
print("Reconocimiento de «pregúntale a la IA»:",len(casos),"frases OK")

# ---------- PoliticaIA ----------
CORREO=re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"); LARGO=re.compile(r"(?<![0-9])[0-9]{9,}(?![0-9])"); TEL=re.compile(r"(?<![0-9])\+?[0-9]{2,3}[\s.-][0-9]{3}[\s.-][0-9]{3,4}(?![0-9])")
def datos_personales(s): return bool(CORREO.search(s) or LARGO.search(s) or TEL.search(s))
for t in ["mi correo es ana@mail.com","llámame al 300 123 4567","paciente con cédula 1234567890","+57 300 123 4567"]: assert datos_personales(t),t
for t in ["¿cuál es la dosis de 500 mg cada 8 horas?","TA 120 80, FC 90, FR 18, temperatura 37.5","valores normales de glucosa 70 a 100 mg/dl","¿qué es la hipertensión arterial?"]: assert not datos_personales(t),t
def limpiar_resp(t):
    s=t.replace("\r","")
    s=re.sub(r"```[\s\S]*?```"," ",s); s=re.sub(r"(?m)^\s{0,3}#{1,6}\s*","",s); s=re.sub(r"(?m)^\s*[*\-•]\s+","",s)
    s=re.sub(r"\[([^\]]+)\]\([^)]*\)",r"\1",s); s=re.sub(r"\*\*|__|\*|`","",s)
    s=re.sub(r"[ \t]+"," ",s); s=re.sub(r"\n{3,}","\n\n",s); return s.strip()
md="**Metformina** reduce la glucosa.\n* Primera idea\n- Segunda idea\n# Título\nMira [la guía](http://x.com) y `código`."
assert limpiar_resp(md)=="Metformina reduce la glucosa.\nPrimera idea\nSegunda idea\nTítulo\nMira la guía y código.", limpiar_resp(md)
CIF=re.compile(r"[0-9]+([.,][0-9]+)?\s?(%|(mg|mcg|ug|µg|g|ml|ui|mmhg|mmol|meq|kg|l)\b)|\bdosis\b",re.I)
def para_hablar(resp,mx=380):
    plano=re.sub(r"\s+"," ",resp).strip()
    if not plano: return plano
    sb=""; rec=False
    for o in re.split(r"(?<=[.!?])\s+",plano):
        if sb and len(sb)+len(o)+1>mx: rec=True; break
        sb=(sb+" " if sb else "")+o
    if len(sb)>mx: sb=recortar(sb,mx); rec=True
    if rec: sb+=" El resto está en la pantalla."
    if CIF.search(plano): sb+=" Verifica dosis y cifras en tu libro o guía."
    return sb
t="La metformina reduce la producción hepática de glucosa. También mejora la sensibilidad a la insulina."; assert para_hablar(t)==t
largo=" ".join(f"Esta es la oración número {i} de la respuesta." for i in range(1,31)); h=para_hablar(largo)
assert h.endswith("El resto está en la pantalla.") and len(h)<500 and h.startswith("Esta es la oración número 1 de la respuesta.") and "Verifica" not in h
assert para_hablar("La dosis inicial suele ser 500 mg dos veces al día.").endswith("Verifica dosis y cifras en tu libro o guía.") and "Verifica" not in para_hablar("La insulina baja la glucosa.")
def clasificar(c,cuerpo):
    if c==429: return "LIMITE"
    if c==404: return "MODELO"
    if 500<=c<=599: return "SERVIDOR"
    if c in (401,403): return "CLAVE"
    if c==400 and ("API_KEY_INVALID" in cuerpo or "api key not valid" in cuerpo.lower()): return "CLAVE"
    if c==400: return "SOLICITUD"
    return "OTRO"
assert [clasificar(*a) for a in [(429,""),(404,""),(503,""),(403,""),(400,"API key not valid. Please pass a valid API key."),(400,"INVALID_ARGUMENT: contenido mal formado"),(418,"")]]==["LIMITE","MODELO","SERVIDOR","CLAVE","CLAVE","SOLICITUD","OTRO"]
class Conv:
    def __init__(s,mx=3,vida=600000): s.t=[]; s.mx=mx; s.vida=vida
    def agregar(s,p,r,a): s.t=[x for x in s.t if a-x[2]<=s.vida]; s.t.append((p[:600],r[:1500],a)); s.t=s.t[-s.mx:]
    def hist(s,a): s.t=[x for x in s.t if a-x[2]<=s.vida]; return [x[0] for x in s.t]
c=Conv(3,1000)
for i in range(1,5): c.agregar(f"p{i}",f"r{i}",i*100)
assert c.hist(500)==["p2","p3","p4"] and c.hist(1350)==["p4"]
print("PoliticaIA (datos personales, markdown, resumen hablado, errores, conversación): OK")

# ---------- Forma de la respuesta de Gemini (la que lee Gemini.extraer) ----------
def extraer(j):
    raiz=json.loads(j); cand=raiz.get("candidates")
    if not cand: return "BLOQUEADA"
    partes=(cand[0].get("content") or {}).get("parts") or []
    t="".join(p.get("text","") for p in partes).strip()
    return t or "BLOQUEADA"
ok='{"candidates":[{"content":{"parts":[{"text":"La metformina "},{"text":"baja la glucosa."}],"role":"model"},"finishReason":"STOP","index":0}],"usageMetadata":{"totalTokenCount":42}}'
assert extraer(ok)=="La metformina baja la glucosa."
assert extraer('{"promptFeedback":{"blockReason":"SAFETY"}}')=="BLOQUEADA" and extraer('{"candidates":[{"finishReason":"SAFETY"}]}')=="BLOQUEADA"
print("Lectura de la respuesta de Gemini (formato supuesto): OK")
