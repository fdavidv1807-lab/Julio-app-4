# Espejo de DedupeOrigenes (v40): mismo mensaje por los dos caminos = una sola lectura.
class DO:
    def __init__(s, ventana=90000, maximo=100): s.v={}; s.w=ventana; s.m=maximo
    def repetido(s, clave, origen, ahora):
        s.v={k:e for k,e in s.v.items() if ahora-e[1]<=s.w}
        e=s.v.get(clave)
        if e is not None and e[0]!=origen: return True
        s.v.pop(clave,None); s.v[clave]=(origen,ahora)
        while len(s.v)>s.m: s.v.pop(next(iter(s.v)))
        return False
k=lambda texto,rem="Ana":("com.whatsapp","NORMAL","Ana".lower() if rem=="Ana" else rem.lower(),"",rem.lower(),texto.lower())
d=DO(); assert not d.repetido(k("hola"),"LOCAL",0) and d.repetido(k("hola"),"DIARIO",1000) and d.repetido(k("hola"),"DIARIO",2000)
d=DO(); assert not d.repetido(k("hola"),"DIARIO",0) and d.repetido(k("hola"),"LOCAL",500)
d=DO(); assert not d.repetido(k("hola"),"LOCAL",0) and not d.repetido(k("hola"),"LOCAL",5000)
d=DO(90000); assert not d.repetido(k("hola"),"LOCAL",0) and not d.repetido(k("otra cosa"),"DIARIO",1000) and not d.repetido(k("hola"),"DIARIO",200000) and not d.repetido(k("hola","Pedro"),"DIARIO",201000)
print("DedupeOrigenes: OK")
