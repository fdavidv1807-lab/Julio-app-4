# Espejo en Python de la lógica pura de enlace/ (mismas reglas, mismos casos que las pruebas Kotlin).
import re, unicodedata, itertools

def strip_acc(s):
    return re.sub(r'\p{M}+' if False else r'[\u0300-\u036f]+', '', unicodedata.normalize('NFD', s.lower()))

def norm(s):
    s = strip_acc(s)
    s = re.sub(r'[^a-z0-9 ]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()

def norm_texto(s):  # Texto.normalizar (conserva : / %)
    s = strip_acc(s)
    s = re.sub(r'[^a-z0-9:/% ]', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()

SENS_APPS = ["banco","bank","bancolombia","davivienda","daviplata","nequi","paypal","wallet","billetera",
             "pagos","pago","pay","paisa","transfer","cartera","nubank","tarjeta"]
def app_es_banco(app, paquete):
    n = norm_texto(app); p = paquete.lower()
    return any(k in n or k in p for k in SENS_APPS)

FRASES = ["codigo de verificacion","verification code","one time password","one time passcode","no compartas","do not share",
          "dont share","clave temporal","clave dinamica","contrasena temporal","codigo de seguridad","codigo de acceso",
          "codigo de confirmacion","codigo de un solo uso"]
PCOD = {"codigo","code","otp","clave","contrasena","password","pin","token","verificacion","verification","passcode","2fa","autenticacion"}
PBANCO = {"banco","bancos","bank","bancario","bancaria","bancolombia","davivienda","daviplata","nequi","bbva","itau","scotiabank",
          "colpatria","avvillas","tarjeta","saldo","transferencia","transferencias","pse","cvv","paypal"}

def es_codigo(t, x):
    s = " " + re.sub(r'([0-9]{3}) ([0-9]{3})', r'\1\2', norm(t + " " + x)) + " "
    if any(" " + f + " " in s for f in FRASES): return True
    pal = set(s.strip().split(" "))
    return bool(pal & PCOD) and re.search(r'(?<![0-9])[0-9]{4,8}(?![0-9])', s) is not None

def es_banco(t, x): return any(w in PBANCO for w in norm(t + " " + x).split(" "))

def clasificar(app, paq, t, x):
    if app_es_banco(app, paq): return "BANCO"
    if es_codigo(t, x): return "CODIGO"
    if es_banco(t, x): return "BANCO"
    return "NORMAL"

# --- Pruebas de Sensibles ---
c = clasificar
assert c("Mensajes","com.google.android.apps.messaging","Google","G-123456 es tu código de verificación de Google")=="CODIGO"
assert c("WhatsApp","com.whatsapp","WhatsApp","Tu código de WhatsApp: 123-456. No compartas este código")=="CODIGO"
assert c("Mensajes","x.y","Uber","Your Uber code is 4821")=="CODIGO"
assert c("Mensajes","x.y","","Tu clave temporal es 884211")=="CODIGO"
assert c("Mensajes","x.y","Tu codigo de verificacion","")=="CODIGO"
assert c("Bancolombia","com.todo1.mobile","Compra","Compra por 25.000")=="BANCO"
assert c("Mensajes","com.google.android.apps.messaging","Davivienda","Compra aprobada")=="BANCO"
assert c("Mensajes","x.y","Aviso","Tu saldo disponible es bajo")=="BANCO"
assert c("Nequi","com.nequi.MobileApp","Nequi","Te llegó plata")=="BANCO"
assert c("WhatsApp","com.whatsapp","Ana","¿Vamos a comer a las 12?")=="NORMAL"
assert c("WhatsApp","com.whatsapp","Mamá","Llámame cuando salgas")=="NORMAL"
assert c("Gmail","com.google.android.gm","Reunión","Mañana a las 3 en la oficina 4521")=="NORMAL"
assert not es_codigo("Hola","Hola")
print("Sensibles: OK")

# paquetes comunes que NO deben marcarse como banco por el nombre del paquete
for app,p in [("WhatsApp","com.whatsapp"),("Mensajes","com.samsung.android.messaging"),("Mensajes","com.google.android.apps.messaging"),
              ("Gmail","com.google.android.gm"),("Instagram","com.instagram.android"),("Telegram","org.telegram.messenger"),
              ("Teléfono","com.samsung.android.dialer"),("Calendario","com.google.android.calendar"),("Outlook","com.microsoft.office.outlook"),
              ("Messenger","com.facebook.orca"),("Chrome","com.android.chrome"),("Spotify","com.spotify.music")]:
    assert not app_es_banco(app,p), (app,p)
print("Apps comunes no se marcan como banco: OK")

# --- Filtro / Dedupe / Cola ---
def motivo(n, propio="com.julio.asistente", perm=("com.whatsapp","com.google.android.gm")):
    p,t,x,cat,curso,grupo = n
    if not p.strip(): return "sin paquete"
    if p==propio: return "propio"
    if p in ("android","com.android.systemui"): return "sistema"
    if p not in perm: return "no elegida"
    if curso: return "curso"
    if grupo: return "grupo"
    if cat in ("progress","transport","service","sys","status","navigation"): return "cat"
    if not t.strip() and not x.strip(): return "vacia"
    return None
base=("com.whatsapp","Ana","Hola","msg",False,False)
assert motivo(base) is None
for mod in [("com.julio.asistente","Ana","Hola","msg",False,False),("android","Ana","Hola","msg",False,False),
            ("com.whatsapp","Ana","Hola","msg",True,False),("com.whatsapp","Ana","Hola","msg",False,True),
            ("com.whatsapp","Ana","Hola","transport",False,False),("com.whatsapp","Ana","Hola","progress",False,False),
            ("com.whatsapp"," ","","msg",False,False)]:
    assert motivo(mod) is not None, mod
assert motivo(base, perm=()) is not None  # por defecto ninguna app
assert motivo(("com.instagram.android","Ana","Hola","msg",False,False)) is not None  # app no elegida
print("Filtro: OK")

class Dedup:
    def __init__(s, ventana=30000, maximo=50): s.v={}; s.w=ventana; s.m=maximo
    def repetido(s,p,t,x,ahora):
        s.v={k:v for k,v in s.v.items() if ahora-v<=s.w}
        k=hash((p,t,x))
        if k in s.v: return True
        s.v[k]=ahora
        while len(s.v)>s.m: s.v.pop(next(iter(s.v)))
        return False
d=Dedup()
assert not d.repetido("a","t","x",0); assert d.repetido("a","t","x",10000)
assert not d.repetido("a","t","otro",10000); assert not d.repetido("a","t","x",40000)
print("Dedupe: OK")

from collections import deque
class Cola:
    def __init__(s,cap=20,vida=600000): s.items=deque(); s.ids=deque(); s.perd=0; s.cap=cap; s.vida=vida
    def cad(s,ahora):
        while s.items and ahora-s.items[0][1]>s.vida: s.items.popleft()
    def agregar(s,i,ahora):
        s.cad(ahora)
        if i in s.ids: return False
        s.ids.append(i)
        while len(s.ids)>200: s.ids.popleft()
        s.items.append((i,ahora))
        while len(s.items)>s.cap: s.items.popleft(); s.perd+=1
        return True
    def siguiente(s,ahora):
        s.cad(ahora); return s.items.popleft() if s.items else None
    def devolver(s,e): s.items.appendleft(e)
    def tam(s,ahora): s.cad(ahora); return len(s.items)
    def perdidos(s): p=s.perd; s.perd=0; return p
c=Cola(5,1000); assert c.agregar("1",0) and c.agregar("2",0)
assert c.siguiente(0)[0]=="1" and c.siguiente(0)[0]=="2" and c.siguiente(0) is None
c=Cola(); assert c.agregar("1",0) and not c.agregar("1",1) and c.tam(1)==1
c=Cola(3,10000)
for i in range(1,6): c.agregar(str(i),0)
assert c.tam(0)==3 and c.siguiente(0)[0]=="3" and c.perdidos()==2 and c.perdidos()==0
c=Cola(5,1000); c.agregar("1",0); c.agregar("2",900); assert c.siguiente(1500)[0]=="2" and c.siguiente(1500) is None
c=Cola(); c.agregar("1",0); c.agregar("2",0); e=c.siguiente(0); c.devolver(e); assert c.siguiente(0)[0]=="1"
print("Cola: OK")

# --- Política de lectura ---
ENL = re.compile(r'(https?://|www\.)\S+', re.I)
def limpiar(s):
    s = re.sub(r'\s+',' ', ENL.sub(' un enlace ', s))
    out=[]
    for ch in s:
        cat = unicodedata.category(ch)
        if cat in ('Cc','Cf','Cs','So','Co','Cn'): continue
        out.append(ch)
    return re.sub(r'\s+',' ', ''.join(out)).strip()
def recortar(s, mx=220):
    if len(s)<=mx: return s
    corte = s.rfind(' ', 0, mx+1)
    return (s[:corte] if corte>mx//2 else s[:mx]).rstrip()
def frase(app,t,x,tipo,privado):
    app = recortar(limpiar(app),40) or "una aplicación"
    if tipo=="CODIGO": return f"Te llegó un código de verificación en {app}. No lo leo en voz alta."
    if tipo=="BANCO": return f"Tienes un aviso de {app} que no leo en voz alta. Míralo en tu teléfono."
    if privado: return f"Tienes un aviso de {app}."
    t=limpiar(t); x=limpiar(x)
    if not t: cuerpo=x
    elif not x: cuerpo=t
    elif x.lower().startswith(t.lower()): cuerpo=x
    else: cuerpo=f"{t}. {x}"
    return f"Tienes un aviso de {app}." if not cuerpo else f"{app}. {recortar(cuerpo)}"
assert frase("WhatsApp","Ana","¿Vamos a comer?","NORMAL",False)=="WhatsApp. Ana. ¿Vamos a comer?"
assert frase("WhatsApp","Ana","Ana: hola","NORMAL",False)=="WhatsApp. Ana: hola"
assert frase("WhatsApp","Ana","secreto","NORMAL",True)=="Tienes un aviso de WhatsApp."
f=frase("Mensajes","123456","123456","CODIGO",False); assert "123456" not in f and "código de verificación" in f
f=frase("Bancolombia","Compra","Compra por 25.000","BANCO",False); assert "25.000" not in f and "Bancolombia" in f
assert limpiar("Mira esto https://ejemplo.com/x?y=1 \U0001F600\U0001F600\nlinda\tfoto")=="Mira esto un enlace linda foto"
r=recortar("palabra "*100, 50); assert len(r)<=50 and r.endswith("palabra")
print("Política de lectura: OK")
