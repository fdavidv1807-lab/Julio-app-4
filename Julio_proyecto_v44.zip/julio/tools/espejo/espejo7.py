# Espejo de la lógica pura del HUD (v44): parámetros por estado, tono, suavizado, historial de onda y panel SISTEMA.
P=dict(REPOSO=(0.04,0.40,66,False,False),DORMIDO=(0.015,0.18,125,False,False),ESCUCHANDO=(0.20,0.90,33,True,False),
       PENSANDO=(0.35,0.85,33,False,True),HABLANDO=(0.12,0.90,33,True,False),ENFOCADO=(0.05,0.50,66,False,False))
assert P["DORMIDO"][1]<P["REPOSO"][1]<P["ESCUCHANDO"][1] and P["DORMIDO"][0]<P["REPOSO"][0]<P["ESCUCHANDO"][0]
assert P["DORMIDO"][2]>P["REPOSO"][2]>P["ESCUCHANDO"][2] and all(1<=v[2]<=200 for v in P.values())
assert P["ESCUCHANDO"][3] and P["HABLANDO"][3] and not P["REPOSO"][3] and P["PENSANDO"][4] and not P["HABLANDO"][4]
def tono(p,alerta):
    return "ROJO" if alerta=="ERROR" else "AMBAR" if alerta=="AVISO" else "VERDE" if p=="ENFOCADO" else "TURQUESA" if p=="PENSANDO" else "CIAN"
assert tono("REPOSO","NINGUNA")=="CIAN" and tono("HABLANDO","AVISO")=="AMBAR" and tono("ESCUCHANDO","ERROR")=="ROJO" and tono("ENFOCADO","NINGUNA")=="VERDE"
def suavizar(a,o,s=0.5,b=0.12):
    o=min(max(o,0.0),1.0); k=s if o>a else b; return min(max(a+(o-a)*k,0.0),1.0)
assert abs(suavizar(0,1)-0.5)<1e-6 and abs(suavizar(1,0)-0.88)<1e-6 and abs(suavizar(0.9,5,1,1)-1)<1e-6
class Hist:
    def __init__(s,n=48): s.d=[0.0]*n; s.sig=0; s.c=0; s.n=n
    def agregar(s,v): s.d[s.sig]=min(max(v,0.0),1.0); s.sig=(s.sig+1)%s.n; s.c=min(s.c+1,s.n)
    def valores(s):
        out=[0.0]*s.n; ini=0 if s.c<s.n else s.sig; falta=s.n-s.c
        for i in range(s.c): out[falta+i]=s.d[(ini+i)%s.n]
        return out
h=Hist(4); assert h.valores()==[0,0,0,0]; h.agregar(.1); h.agregar(.2); assert h.valores()==[0,0,.1,.2]
for v in (.3,.4,.5,2): h.agregar(v)
assert h.valores()==[.3,.4,.5,1.0]
def filas(bateria=80,cargando=False,wifi=True,internet=True,mic=True,escucha=True,voz="LISTA",ia=True,clave=True,avisos=True,pend=0,enlace="NO"):
    l=[("BATERÍA",f"{bateria}%"+(" ⚡" if cargando else ""),"OK" if cargando or bateria>=30 else "AVISO" if bateria>=15 else "ERROR"),
       ("WI-FI","CONECTADO" if wifi else "SIN WI-FI","OK" if wifi else "AVISO"),
       ("ESCUCHA","ACTIVA" if escucha else "APAGADA","OK" if escucha else "AVISO"),
       {"LISTA":("VOZ","DE JULIO","OK"),"DESCARGANDO":("VOZ","DESCARGANDO","AVISO"),"SISTEMA":("VOZ","DEL TELÉFONO","AVISO")}[voz]]
    l.append(("IA","APAGADA","APAGADO") if not ia else ("IA","FALTA CLAVE","AVISO") if not clave else ("IA","SIN INTERNET","AVISO") if not internet else ("IA","LISTA","OK"))
    l.append(("AVISOS","APAGADOS","APAGADO") if not avisos else ("AVISOS",f"{pend} POR LEER","OK") if pend>0 else ("AVISOS","ACTIVOS","OK"))
    if enlace=="ESCUCHANDO": l.append(("ENLACE","ESCUCHANDO","OK"))
    if enlace=="CERRADO": l.append(("ENLACE","CERRADO","AVISO"))
    l.append(("MICRÓFONO","PERMITIDO" if mic else "SIN PERMISO","OK" if mic else "ERROR")); return l
def resumen(f): return ("FALLA","ERROR") if any(x[2]=="ERROR" for x in f) else ("ATENCIÓN","AVISO") if any(x[2]=="AVISO" for x in f) else ("ÓPTIMO","OK")
def visibles(f,mx):
    if len(f)<=mx: return f
    pr=sorted(enumerate(f),key=lambda t:(0 if t[1][2] in("ERROR","AVISO") else 1,t[0]))
    return [x[1] for x in sorted(pr[:mx],key=lambda t:t[0])]
f=filas(); assert resumen(f)==("ÓPTIMO","OK") and len(f)==7
b=lambda **k:[x for x in filas(**k) if x[0]=="BATERÍA"][0]
assert b(bateria=20)[2]=="AVISO" and b(bateria=10)[2]=="ERROR" and b(bateria=10,cargando=True)[2]=="OK" and b(bateria=10,cargando=True)[1]=="10% ⚡"
ia=lambda **k:[x for x in filas(**k) if x[0]=="IA"][0]
assert ia(ia=False)[2]=="APAGADO" and ia(clave=False)[1]=="FALTA CLAVE" and ia(internet=False)[1]=="SIN INTERNET" and ia()[1]=="LISTA"
assert resumen(filas(ia=False,avisos=False))==("ÓPTIMO","OK") and resumen(filas(wifi=False))[0]=="ATENCIÓN" and resumen(filas(mic=False))[0]=="FALLA"
assert any(x[0]=="ENLACE" and x[2]=="OK" for x in filas(enlace="ESCUCHANDO")) and [x for x in filas(enlace="CERRADO") if x[0]=="ENLACE"][0][2]=="AVISO"
assert [x for x in filas(pend=3) if x[0]=="AVISOS"][0][1]=="3 POR LEER"
f=filas(mic=False,wifi=False,enlace="ESCUCHANDO"); v=visibles(f,5)
assert len(v)==5 and any(x[0]=="MICRÓFONO" for x in v) and any(x[0]=="WI-FI" for x in v) and [x[0] for x in v]==[n for n in [y[0] for y in f] if n in [z[0] for z in v]] and visibles(f,20)==f
print("HUD (parámetros, tono, suavizado, onda, panel SISTEMA): OK")
