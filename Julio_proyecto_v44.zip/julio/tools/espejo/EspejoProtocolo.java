import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/** Espejo en Java de enlace/Protocolo.kt (mismas llamadas a javax.crypto y mismo formato). */
public class EspejoProtocolo {
    static final int VERSION = 3, TAM_NONCE = 12, TAG_BITS = 128, TAM_ENC = 7, MAX = 8192;
    static final byte[] MAGIA = {'J', 'U'};
    static final byte[] MAGIA_ORDEN = {'J', 'O'};
    record Aviso(String id, long tiempo, String app, String paquete, String titulo, String texto, int tipo, String chat, String remitente, String grupo, int cantidad, boolean mensajeria, boolean acepta) {}

    static byte[] claveDe(byte[] secreto) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secreto, "HmacSHA256"));
        return mac.doFinal("julio-enlace-v1".getBytes(StandardCharsets.UTF_8));
    }
    static String idPublico(byte[] s) throws Exception {
        byte[] pre = "julio-id-v1".getBytes(StandardCharsets.UTF_8);
        byte[] in = new byte[pre.length + s.length];
        System.arraycopy(pre, 0, in, 0, pre.length); System.arraycopy(s, 0, in, pre.length, s.length);
        byte[] h = MessageDigest.getInstance("SHA-256").digest(in);
        return String.format("%02x%02x%02x", h[0] & 0xff, h[1] & 0xff, h[2] & 0xff);
    }
    static String cortar(String s, int m) { return s.length() <= m ? s : s.substring(0, m); }
    static byte[] aad(byte[] m) { return new byte[]{m[0], m[1], (byte) VERSION}; }

    static byte[] armar(byte[] clave, byte[] datos, byte[] magia) throws Exception {
        byte[] nonce = new byte[TAM_NONCE]; new SecureRandom().nextBytes(nonce);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(clave, "AES"), new GCMParameterSpec(TAG_BITS, nonce));
        c.updateAAD(aad(magia));
        byte[] cif = c.doFinal(datos);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (DataOutputStream d = new DataOutputStream(out)) { d.write(magia); d.writeByte(VERSION); d.writeInt(nonce.length + cif.length); d.write(nonce); d.write(cif); }
        return out.toByteArray();
    }
    static byte[] codificarOrden(String id, long t, String chat, String texto, byte[] clave) throws Exception {
        ByteArrayOutputStream cuerpo = new ByteArrayOutputStream();
        try (DataOutputStream d = new DataOutputStream(cuerpo)) { d.writeLong(t); d.writeUTF(cortar(id, 40)); d.writeUTF(cortar(chat, 200)); d.writeUTF(cortar(texto, 600)); }
        return armar(clave, cuerpo.toByteArray(), MAGIA_ORDEN);
    }
    static Object[] decodificarOrden(byte[] t, byte[] clave) {
        byte[] claro = abrir(t, clave, MAGIA_ORDEN); if (claro == null) return null;
        try (DataInputStream d = new DataInputStream(new ByteArrayInputStream(claro))) { long tt = d.readLong(); String id = d.readUTF(), ch = d.readUTF(), tx = d.readUTF(); return new Object[]{id, tt, ch, tx}; } catch (IOException e) { return null; }
    }
    static byte[] abrir(byte[] t, byte[] clave, byte[] magia) {
        if (t.length < TAM_ENC + TAM_NONCE + 16) return null;
        if (t[0] != magia[0] || t[1] != magia[1] || t[2] != VERSION) return null;
        byte[] nonce = Arrays.copyOfRange(t, TAM_ENC, TAM_ENC + TAM_NONCE);
        byte[] cif = Arrays.copyOfRange(t, TAM_ENC + TAM_NONCE, t.length);
        try { Cipher c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(clave, "AES"), new GCMParameterSpec(TAG_BITS, nonce)); c.updateAAD(aad(magia)); return c.doFinal(cif); } catch (GeneralSecurityException e) { return null; }
    }
    static byte[] codificar(Aviso a, byte[] clave) throws Exception {
        ByteArrayOutputStream cuerpo = new ByteArrayOutputStream();
        try (DataOutputStream d = new DataOutputStream(cuerpo)) {
            d.writeLong(a.tiempo()); d.writeByte(a.tipo());
            d.writeUTF(cortar(a.id(), 40)); d.writeUTF(cortar(a.app(), 80)); d.writeUTF(cortar(a.paquete(), 200));
            d.writeUTF(cortar(a.titulo(), 200)); d.writeUTF(cortar(a.texto(), 600));
            d.writeUTF(cortar(a.chat(), 200)); d.writeUTF(cortar(a.remitente(), 100)); d.writeUTF(cortar(a.grupo(), 100));
            d.writeShort(Math.max(1, Math.min(9999, a.cantidad()))); d.writeBoolean(a.mensajeria()); d.writeBoolean(a.acepta());
        }
        byte[] nonce = new byte[TAM_NONCE]; new SecureRandom().nextBytes(nonce);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(clave, "AES"), new GCMParameterSpec(TAG_BITS, nonce));
        c.updateAAD(aad(MAGIA));
        byte[] cif = c.doFinal(cuerpo.toByteArray());
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (DataOutputStream d = new DataOutputStream(out)) {
            d.write(MAGIA); d.writeByte(VERSION); d.writeInt(nonce.length + cif.length); d.write(nonce); d.write(cif);
        }
        return out.toByteArray();
    }
    static byte[] leerTrama(InputStream in) throws IOException {
        DataInputStream d = new DataInputStream(in);
        byte[] enc = new byte[TAM_ENC]; d.readFully(enc);
        if (enc[0] != MAGIA[0] || enc[1] != MAGIA[1] || enc[2] != VERSION) throw new IOException("encabezado");
        int largo = new DataInputStream(new ByteArrayInputStream(enc, 3, 4)).readInt();
        if (largo < TAM_NONCE + 16 || largo > MAX) throw new IOException("largo");
        byte[] resto = new byte[largo]; d.readFully(resto);
        byte[] t = new byte[enc.length + resto.length];
        System.arraycopy(enc, 0, t, 0, enc.length); System.arraycopy(resto, 0, t, enc.length, resto.length);
        return t;
    }
    static Aviso decodificar(byte[] t, byte[] clave) {
        if (t.length < TAM_ENC + TAM_NONCE + 16) return null;
        if (t[0] != MAGIA[0] || t[1] != MAGIA[1] || t[2] != VERSION) return null;
        byte[] nonce = Arrays.copyOfRange(t, TAM_ENC, TAM_ENC + TAM_NONCE);
        byte[] cif = Arrays.copyOfRange(t, TAM_ENC + TAM_NONCE, t.length);
        byte[] claro;
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(clave, "AES"), new GCMParameterSpec(TAG_BITS, nonce));
            c.updateAAD(aad(MAGIA));
            claro = c.doFinal(cif);
        } catch (GeneralSecurityException e) { return null; }
        try (DataInputStream d = new DataInputStream(new ByteArrayInputStream(claro))) {
            long tiempo = d.readLong(); int tipo = d.readUnsignedByte();
            String id = d.readUTF(), app = d.readUTF(), paq = d.readUTF(), ti = d.readUTF(), tx = d.readUTF();
            String chat = d.readUTF(), rem = d.readUTF(), grp = d.readUTF(); int cant = Math.max(1, d.readUnsignedShort()); boolean mens = d.readBoolean(); boolean acp = d.readBoolean();
            return new Aviso(id, tiempo, app, paq, ti, tx, tipo, chat, rem, grp, cant, mens, acp);
        } catch (IOException e) { return null; }
    }

    static final String ALF = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    static String formatear(byte[] s) {
        StringBuilder sb = new StringBuilder(); int acu = 0, bits = 0;
        for (byte b : s) {
            acu = (acu << 8) | (b & 0xff); bits += 8;
            while (bits >= 5) { sb.append(ALF.charAt((acu >> (bits - 5)) & 31)); bits -= 5; }
            acu &= (1 << bits) - 1;
        }
        String r = sb.toString(); StringBuilder o = new StringBuilder();
        for (int i = 0; i < r.length(); i += 4) { if (i > 0) o.append('-'); o.append(r, i, Math.min(i + 4, r.length())); }
        return o.toString();
    }
    static byte[] leer(String texto) {
        StringBuilder l = new StringBuilder();
        for (char ch : texto.toUpperCase().toCharArray()) if (ch != '-' && !Character.isWhitespace(ch)) l.append(ch);
        String x = l.toString().replace('O', '0').replace('I', '1').replace('L', '1');
        if (x.length() != 16) return null;
        byte[] out = new byte[10]; int acu = 0, bits = 0, n = 0;
        for (char ch : x.toCharArray()) {
            int v = ALF.indexOf(ch); if (v < 0) return null;
            acu = (acu << 5) | v; bits += 5;
            if (bits >= 8) { out[n++] = (byte) ((acu >> (bits - 8)) & 0xff); bits -= 8; acu &= (1 << bits) - 1; }
        }
        return out;
    }
    static final java.util.regex.Pattern IPV4 = java.util.regex.Pattern.compile("^(25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})(\\.(25[0-5]|2[0-4][0-9]|1?[0-9]{1,2})){3}$");
    static String qr(byte[] s, String ip, int puerto) { return "JULIO1;" + formatear(s) + ";" + (ip == null ? "" : ip) + ";" + ((ip == null || ip.isEmpty()) ? 0 : puerto); }
    /** devuelve {secreto, ip, puerto} o null */
    static Object[] qrLeer(String t) {
        String[] p = t.trim().split(";", -1);
        if (p.length != 4 || !p[0].equals("JULIO1")) return null;
        byte[] s = leer(p[1]); if (s == null) return null;
        if (p[2].isEmpty()) return new Object[]{s, "", 0};
        if (!IPV4.matcher(p[2]).matches()) return null;
        try { int pu = Integer.parseInt(p[3]); if (pu < 1 || pu > 65535) return null; return new Object[]{s, p[2], pu}; } catch (NumberFormatException e) { return null; }
    }
    static void ok(boolean c, String m) { if (!c) throw new AssertionError(m); }

    public static void main(String[] a) throws Exception {
        byte[] sec = new byte[10]; for (int i = 0; i < 10; i++) sec[i] = (byte) (i * 7 + 1);
        byte[] clave = claveDe(sec);
        Aviso av = new Aviso("abc-123", 1_000_000L, "WhatsApp", "com.whatsapp", "Ana", "¿Vamos a comer? ñandú", 0, "0|com.whatsapp|1|x|10123", "Ana", "Familia", 3, true, true);
        byte[] tr = codificar(av, clave);
        ok(av.equals(decodificar(tr, clave)), "ida y vuelta");
        ok(!new String(tr, StandardCharsets.ISO_8859_1).contains("Vamos"), "texto en claro");
        ok(decodificar(tr, claveDe(new byte[10])) == null, "otra clave");
        for (int i : new int[]{0, 2, 10, tr.length / 2, tr.length - 1}) {
            byte[] m = tr.clone(); m[i] ^= 1; ok(decodificar(m, clave) == null, "byte " + i);
        }
        ok(!Arrays.equals(codificar(av, clave), codificar(av, clave)), "nonce distinto");
        byte[] con = Arrays.copyOf(tr, tr.length + 3);
        ok(Arrays.equals(tr, leerTrama(new ByteArrayInputStream(con))), "leerTrama");
        try { leerTrama(new ByteArrayInputStream("GET / HTTP/1.1\r\n\r\n".getBytes())); ok(false, "debía fallar"); } catch (IOException e) {}
        ok(idPublico(sec).length() == 6 && !idPublico(sec).equals(idPublico(new byte[10])), "id publico");
        String f = formatear(sec);
        ok(f.length() == 19, "largo " + f);
        ok(Arrays.equals(sec, leer(f)) && Arrays.equals(sec, leer(f.toLowerCase().replace("-", " "))), "codigo ida y vuelta " + f);
        ok(Arrays.equals(new byte[10], leer(formatear(new byte[10]).replace('0', 'O'))), "O->0");
        ok(leer("1234") == null && leer("UUUU-UUUU-UUUU-UUUU") == null, "invalidos");
        // 2000 códigos aleatorios: ida y vuelta y formato
        SecureRandom r = new SecureRandom();
        for (int i = 0; i < 2000; i++) {
            byte[] s = new byte[10]; r.nextBytes(s);
            String c = formatear(s);
            ok(c.matches("[0-9A-Z]{4}(-[0-9A-Z]{4}){3}"), c); ok(Arrays.equals(s, leer(c)), "rt " + c);
        }
        // v42: órdenes (Cuerpo -> diario)
        byte[] to = codificarOrden("o-1", 1_000_000L, "0|com.whatsapp|1|x|10123", "Sí, a las 12. ñandú", clave);
        Object[] oo = decodificarOrden(to, clave);
        ok(oo != null && "o-1".equals(oo[0]) && "0|com.whatsapp|1|x|10123".equals(oo[2]) && "Sí, a las 12. ñandú".equals(oo[3]), "orden ida y vuelta");
        ok(!new String(to, StandardCharsets.ISO_8859_1).contains("12"), "orden cifrada");
        ok(decodificarOrden(tr, clave) == null && decodificar(to, clave) == null, "aviso/orden no se confunden");
        ok(decodificarOrden(to, claveDe(new byte[10])) == null, "orden otra clave");
        for (int i : new int[]{0, 2, 10, to.length / 2, to.length - 1}) { byte[] m = to.clone(); m[i] ^= 1; ok(decodificarOrden(m, clave) == null, "orden byte " + i); }
        // QR
        String q = qr(sec, "192.168.1.25", 48217);
        Object[] d = qrLeer(q);
        ok(d != null && Arrays.equals(sec, (byte[]) d[0]) && "192.168.1.25".equals(d[1]) && (int) d[2] == 48217, "qr ida y vuelta");
        Object[] d2 = qrLeer(qr(sec, null, 48217)); ok(d2 != null && "".equals(d2[1]) && (int) d2[2] == 0, "qr sin ip");
        ok(qrLeer("https://ejemplo.com") == null && qrLeer("JULIO1;1234;192.168.1.25;48217") == null, "qr ajeno");
        ok(qrLeer(q.replace("192.168.1.25", "999.1.1.1")) == null && qrLeer(q.replace(";48217", ";70000")) == null, "qr ip/puerto malos");
        // aviso grande: se corta y sigue cabiendo
        String largo = "ñ".repeat(5000);
        byte[] g = codificar(new Aviso("i", 5, "A", "p", largo, largo, 0, "", "", "", 1, false, false), clave);
        ok(g.length < MAX, "cabe en MAX_TRAMA: " + g.length);
        Aviso gd = decodificar(g, clave);
        ok(gd != null && gd.titulo().length() == 200 && gd.texto().length() == 600, "truncado");
        System.out.println("Java v3 (crypto, trama con campos de chat y acepta-órdenes, órdenes, código y QR): OK  trama típica = " + tr.length + " bytes");
    }
}
