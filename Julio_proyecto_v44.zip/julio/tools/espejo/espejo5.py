# Espejo de lo nuevo de v41: responder por voz (registro de chats, decisión sí/no, dictado, reconocimiento de «responde»).
import re
exec(open('espejo4.py', encoding='utf-8').read().split('class DO')[0])   # nada
exec(open('espejo3.py', encoding='utf-8').read())

# ---------- Registro ----------
class R:
    def __init__(s,chat,nombre,t,grupo=False,f=lambda x:True): s.chat=chat; s.nombre=nombre; s.esGrupo=grupo; s.tiempo=t; s.enviar=f
class Reg:
    def __init__(s,vida=900000,maximo=10): s.d={}; s.vida=vida; s.max=maximo
    def purgar(s,ahora): s.d={k:v for k,v in s.d.items() if ahora-v.tiempo<=s.vida}
    def registrar(s,r):
        s.purgar(r.tiempo); s.d.pop(r.chat,None); s.d[r.chat]=r
        while len(s.d)>s.max: s.d.pop(next(iter(s.d)))
    def refrescar(s,chat,f):
        if chat in s.d: s.d[chat].enviar=f
    def quitar(s,chat): s.d.pop(chat,None)
    def porChat(s,chat,ahora): s.purgar(ahora); return s.d.get(chat)
    def porNombre(s,nombre,ahora):
        s.purgar(ahora); b=norm(nombre)
        if not b.strip(): return None
        for r in reversed(list(s.d.values())):
            n=norm(r.nombre)
            if b in n or n in b: return r
        return None
g=Reg(10000); g.registrar(R("a","Ana María",0)); g.registrar(R("p","Pedro",1))
assert g.porChat("p",2).nombre=="Pedro" and g.porNombre("ana",2).nombre=="Ana María" and g.porNombre("Ana María",2).nombre=="Ana María"
assert g.porNombre("luis",2) is None and g.porNombre("  ",2) is None
g=Reg(10000); g.registrar(R("1","Ana López",0)); g.registrar(R("2","Ana Ruiz",5)); assert g.porNombre("ana",6).chat=="2"
g=Reg(10000); usada=[]; g.registrar(R("a","Ana",0,f=lambda x:usada.append("vieja") or True)); g.registrar(R("p","Pedro",1))
g.refrescar("a",lambda x:usada.append("nueva") or True); g.porChat("a",2).enviar("hola"); assert usada==["nueva"]
g=Reg(); g.refrescar("x",lambda x:True); assert g.porChat("x",0) is None
g=Reg(1000,2); g.registrar(R("a","Ana",0)); g.registrar(R("b","Beto",100)); g.registrar(R("c","Carla",200))
assert g.porChat("a",300) is None; g.quitar("b"); assert g.porChat("b",300) is None and g.porChat("c",300).nombre=="Carla" and g.porChat("c",5000) is None
print("Registro de respuestas: OK")

# ---------- Dictado y frases ----------
def limpiar_dictado(s):
    t=re.sub(r"\s+"," ",s).strip(); t=t[:1].upper()+t[1:]; return recortar(t,500)
assert limpiar_dictado("  sí,   a las 12 \n")=="Sí, a las 12" and limpiar_dictado("   ")=="" and len(limpiar_dictado("palabra "*200))<=500
def preguntar(r,priv): return "¿Qué le digo?" if priv else (f"¿Qué le digo al grupo {r.nombre}?" if r.esGrupo else f"¿Qué le digo a {r.nombre}?")
def confirmar(r,t,priv): return f"Le diré: {t}. ¿Lo envío?" if priv else (f"Lo mando al grupo {r.nombre}: {t}. ¿Lo envío?" if r.esGrupo else f"Le diré a {r.nombre}: {t}. ¿Lo envío?")
ana=R("a","Ana",0); fam=R("g","Familia",0,True)
assert preguntar(ana,False)=="¿Qué le digo a Ana?" and preguntar(fam,False)=="¿Qué le digo al grupo Familia?" and preguntar(ana,True)=="¿Qué le digo?"
assert confirmar(ana,"Sí, a las 12",False)=="Le diré a Ana: Sí, a las 12. ¿Lo envío?" and confirmar(fam,"Voy",False)=="Lo mando al grupo Familia: Voy. ¿Lo envío?" and "Ana" not in confirmar(ana,"Sí",True)
SI=r"\b(si|sip|claro|seguro|confirmo|confirma|dale|adelante|ok|okay|afirmativo|hazlo|envialo|enviar|mandalo|manda)\b"
NO=r"\b(no|nunca|negativo|cancela|cancelar)\b"; CAM=r"\b(cambialo|cambiar|corrige|corrigelo|otra vez|repitelo|de nuevo)\b"
def decidir(n): return "CANCELAR" if re.search(NO,n) else "CAMBIAR" if re.search(CAM,n) else "ENVIAR" if re.search(SI,n) else "NO_ENTENDI"
assert decidir("si")=="ENVIAR" and decidir("si envialo")=="ENVIAR" and decidir("no")=="CANCELAR" and decidir("no si mejor no")=="CANCELAR"
assert decidir("cambialo")=="CAMBIAR" and decidir("tal vez manana")=="NO_ENTENDI" and decidir("")=="NO_ENTENDI"
print("Dictado, frases y decisión: OK")

# ---------- Reconocimiento de «responde» ----------
RESP=r"^(?:julio )?(?:quiero |puedes |podrias |vamos a )?(?:responde|responder|contesta|contestar|respondele|contestale|respondeme)(?: (?:el|ese|este|al) (?:mensaje|chat|whatsapp))?(?: a (.+))?$"
def responder(t):
    n=norm_texto(t)
    if tiene(n,INTERNAS): return "NO"
    m=re.match(RESP,n.strip())
    return ("R", (m.group(1) or "").strip() or None) if m else None
casos={"Responde":("R",None),"Julio, responde":("R",None),"Contéstale":("R",None),"Responde ese mensaje":("R",None),
 "Responde a Ana":("R","ana"),"Respóndele a Pedro":("R","pedro"),"Quiero responder a María José":("R","maria jose"),
 "Contesta el teléfono":None,"Agrega la tarea responder correos":"NO"}
for t,esp in casos.items(): assert responder(t)==esp,(t,responder(t),esp)
print("Reconocimiento de «responde»:",len(casos),"frases OK")
