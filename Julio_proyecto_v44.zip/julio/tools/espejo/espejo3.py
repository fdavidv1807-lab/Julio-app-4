# Espejo en Python de lo nuevo de v39 (mismas reglas y casos que las pruebas Kotlin).
exec(open('espejo2.py', encoding='utf-8').read())

# ---------- Resumen y historial ----------
def mayus(s): return s[:1].upper()+s[1:]
def resumen_corto(app, tipo, rem, texto, n, grupo, mens, titulo=""):
    app = recortar(limpiar(app),40) or "una aplicación"
    if tipo=="CODIGO": return f"Un código de verificación en {app}, que no leo."
    if tipo=="BANCO": return f"Un aviso de {app}, que no leo."
    t = recortar(limpiar(texto),100)
    if not mens:
        c = ". ".join(x for x in [limpiar(titulo), t] if x)
        return f"Un aviso de {app}." if not c else f"{app}: {c}."
    quien = nombre_hablado(rem); g = recortar(limpiar(grupo),60)
    if not g and n<=1: f = f"{quien} te mandó un mensaje sin texto" if not t else f"{quien}: {t}"
    elif not g: f = f"{quien} te mandó {n} mensajes" + ("" if not t else f"; el último: {t}")
    elif n<=1: f = f"En el grupo {g}, {quien} mandó un mensaje sin texto" if not t else f"En el grupo {g}, {quien}: {t}"
    else: f = f"En el grupo {g}, {n} mensajes" + ("" if not t else f"; el último, de {quien}: {t}")
    return mayus(f)+"."
def resumen(avs, privado):   # avs = lista de dict
    if not avs: return "No tienes notificaciones nuevas."
    if privado:
        por={}
        for a in avs:
            k = recortar(limpiar(a["app"]),40) or "una aplicación"; por[k]=por.get(k,0)+max(1,a.get("n",1))
        tot=sum(por.values()); partes=", ".join(f"{v} de {k}" for k,v in por.items())
        return ("Tienes 1 aviso: " if tot==1 else f"Tienes {tot} avisos: ")+partes+"."
    n=len(avs); cab = "Tienes 1 notificación." if n==1 else f"Tienes {n} notificaciones."
    cuerpo=" ".join(resumen_corto(a["app"],a.get("tipo","NORMAL"),a.get("rem",""),a.get("texto",""),a.get("n",1),a.get("grupo",""),a.get("mens",True)) for a in avs[:5])
    return f"{cab} {cuerpo}" + (f" Y {n-5} más." if n>5 else "")
W=lambda rem,texto,n=1,grupo="":dict(app="WhatsApp",rem=rem,texto=texto,n=n,grupo=grupo,mens=True)
assert resumen([],False)=="No tienes notificaciones nuevas."
assert resumen([W("Ana","hola",3),W("Pedro","llego tarde",grupo="Familia")],False)=="Tienes 2 notificaciones. Ana te mandó 3 mensajes; el último: hola. En el grupo Familia, Pedro: llego tarde."
r=resumen([W("+57 300 123 4567","hola"),dict(app="Mensajes",tipo="CODIGO",mens=False)],False)
assert "Un número desconocido: hola." in r and "Un código de verificación en Mensajes, que no leo." in r and "123456" not in r
r=resumen([W("Ana","secreto",3),W("Pedro","x")],True); assert r=="Tienes 4 avisos: 4 de WhatsApp." and "secreto" not in r
r=resumen([W(f"Persona{i}","hola") for i in range(1,8)],False); assert r.startswith("Tienes 7 notificaciones.") and r.endswith("Y 2 más.")
class Hist:
    def __init__(s,cap=15,vida=1800000): s.items=[]; s.cap=cap; s.vida=vida
    def reg(s,chat,texto,ahora,n=1):
        s.items=[e for e in s.items if ahora-e[3]<=s.vida]
        for i,e in enumerate(s.items):
            if e[0]==chat: s.items.pop(i); s.items.append((chat,texto,e[2]+n,ahora)); return
        s.items.append((chat,texto,n,ahora))
        while len(s.items)>s.cap: s.items.pop(0)
    def lista(s,ahora): s.items=[e for e in s.items if ahora-e[3]<=s.vida]; return [e[0] for e in reversed(s.items)]
h=Hist(5,10000); h.reg("ana","uno",0); h.reg("pedro","x",1); h.reg("ana","dos",2)
assert h.lista(3)==["ana","pedro"] and h.items[-1][2]==2 and h.items[-1][1]=="dos"
h=Hist(2,1000); h.reg("a","x",0); h.reg("b","x",500); h.reg("c","x",600)
assert h.lista(700)==["c","b"] and h.lista(1550)==["c"]
print("Resumen e historial: OK")

# ---------- ¿Qué notificaciones tengo? ----------
AV=(r"\b(que|cuales|cuantas|cuantos) (notificaciones|notificacion|mensajes|mensaje)( nuevas| nuevos)? (tengo|hay|me llegaron|llegaron|me escribieron|me mandaron)\b|"
    r"\b(tengo|hay) (alguna |algun )?(notificacion|notificaciones|mensajes)( nuevas| nuevos)?\b|"
    r"\b(lee|leeme|leer|dime|resume|resumeme) (mis |las |los )?(notificaciones|mensajes)\b|"
    r"\bque me (llego|escribieron|mandaron)\b")
for t in ["¿Qué notificaciones tengo?","Julio, qué notificaciones me llegaron","Tengo notificaciones","Léeme mis notificaciones","¿Qué me escribieron?","¿Qué mensajes tengo?"]:
    n=norm_texto(t); assert not tiene(n,INTERNAS) and tiene(n,AV), t
for t in ["Tengo un mensaje para mamá","Agrega la tarea revisar notificaciones"]:
    n=norm_texto(t); assert tiene(n,INTERNAS) or not tiene(n,AV), t
print("Consulta de notificaciones: OK")

# ---------- Música: qué se quiere escuchar ----------
SIN=r"^(aleatoria|aleatorio|cualquiera|al azar|lo que sea|alguna|algo|una|otra|buena|bonita)( .*)?$"
def consulta(n):
    m=re.search(r"\b(?:cancion|canciones|musica|rola|pista)\s+(.+)$",n)
    if not m: return None
    r=re.sub(r"\s+"," ",re.sub(r"\b(por favor|julio|ahora|ya)\b"," ",m.group(1))).strip()
    r=re.sub(r"(^|\s)(en|con|por) (youtube music|youtube|spotify)$","",r).strip()
    if r.startswith("para "): return "musica "+r
    while True:
        s=re.sub(r"^(de|del|la|el|los|las|un|una|unos|unas|estilo|tipo)\s+","",r)
        if s==r: break
        r=s
    return None if (not r.strip() or re.match(SIN,r)) else r
def poner(t):
    n=norm_texto(t); assert tiene(n,PON) and tiene(n,NOMBRE) and musica(n)=="PONER", (t,musica(n)); return consulta(n)
assert poner("Pon música de Bad Bunny")=="bad bunny"
assert poner("Pon la canción Despacito")=="despacito"
assert poner("Julio pon la música de Bad Bunny en Spotify")=="bad bunny"
assert poner("Pon música de salsa por favor")=="salsa"
assert poner("Reproduce música para estudiar")=="musica para estudiar"
assert poner("Pon música") is None and poner("Pon música aleatoria") is None
assert poner("Pon música en YouTube Music") is None and poner("Pon una canción cualquiera") is None
print("Música por búsqueda: OK")
