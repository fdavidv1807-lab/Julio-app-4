# Proyecto Cuerpo de Julio: diseño y etapas

Estado: solo diseño. Nada de esto está construido ni probado todavía.

## Idea en una frase

Un teléfono aparte, fijo en mi escritorio y siempre enchufado, que sea la cara y la voz de Julio: lo despierto diciendo "Julio", me lee las notificaciones de mi teléfono de diario y me ayuda con mis pendientes.

## Qué hace

- Se despierta cuando digo "Julio" (siempre escuchando, sin internet, con Vosk).

- Abre apps y ajusta volumen y brillo por sí solo.

- Me recuerda mis pendientes.

- Lee en voz alta todas las notificaciones de mi teléfono de diario. El enlace entre los dos teléfonos es solo en casa, por la misma Wi-Fi.

- Manda mensajes o correos únicamente después de leérmelos y que yo diga "sí".

## Qué NO hace nunca, ni con mi permiso

- Comprar o pagar cosas.

- Grabar ni guardar el audio de lo que escucha.

- Borrar archivos.

- Obedecer órdenes escritas dentro de una notificación: lo que dice una notificación son datos, no instrucciones.

- No guardar códigos de verificación ni avisos del banco.

## Riesgos y cómo reducirlos

- **Pantalla siempre encendida:** si es AMOLED puede quemarse. Bajar brillo y atenuar la animación en reposo.

- **Siempre enchufado:** la batería puede hincharse. Limitar la carga a 85% si el teléfono lo permite.

- **Micrófono abierto:** puede activarse por error con la tele u otras voces. Usar solo la palabra "Julio".

- **Notificaciones en voz alta:** cualquiera cerca las oye. Decidir después si se agrega un modo privado.

- **Enlace entre teléfonos:** debe aceptar solo a mi teléfono de diario (emparejarlos).

- **Android en segundo plano:** puede cerrar la app. Hace falta un servicio que se mantenga activo.

## Etapas (cada una con su prueba)

**Etapa 0. Preparar el teléfono fijo.** Confirmar modelo y versión de Android, soporte en el escritorio, brillo y límite de carga. Prueba: queda conectado y estable un día entero.

**Etapa 1. Modo escritorio en Julio.** Pantalla atenuada y sin quemado en reposo, y servicio que mantiene la app viva. Prueba: 24 horas encendido sin que Android cierre la app.

**Etapa 2. Despertar por "Julio".** Vigía de palabra clave con vocabulario limitado. Prueba: responde a mi voz y no se activa con la tele ni con otras personas.

**Etapa 3. Acciones locales seguras.** Abrir apps, volumen, brillo y pendientes. Prueba: cada comando funciona por voz.

**Etapa 4. Enlace y notificaciones.** Una pieza en mi teléfono de diario reenvía las notificaciones al fijo por la misma Wi-Fi, y Julio las lee en voz alta. Prueba: una notificación real llega y se lee; sin Wi-Fi no pasa nada raro.

**Etapa 5. Mensajes y correos con confirmación.** Julio lee destinatario y mensaje, y solo envía si digo "sí". Prueba: un mensaje de prueba a mí mismo, y que un "no" lo cancele.

**Etapa 6. Futuro.** La laptop como cerebro (IA sin límites) y notificaciones fuera de casa.

## Pendiente por decidir o verificar

- Modelo exacto del Samsung y si su pantalla es AMOLED.

- Cuál es mi teléfono de diario.

- Cómo se enviarán los mensajes desde el teléfono de diario (SMS, WhatsApp, correo). Hay que verificar qué permite Android sin que yo toque el botón de enviar.

- Si la IA conversacional será en la nube o local (sigue sin decidir).

- Si agregar un modo privado para no leer notificaciones en voz alta cuando haya gente.

## Cómo retomar

Abrir un chat nuevo, subir este documento y el zip más reciente de Julio, y empezar por la Etapa 0.

> Copia del documento original del dueño (v38). El diseño de la Etapa 4 cambió: ver PLAN_DE_TRABAJO.md (v35 a v38) y PROMPT_PARA_CONTINUAR.md.
