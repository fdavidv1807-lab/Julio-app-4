# Reglas R8 específicas del proyecto.
# Voz neuronal: sherpa-onnx se usa por reflexión y con JNI; no debe renombrarse ni recortarse.
-keep class com.k2fsa.sherpa.onnx.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-dontwarn org.apache.commons.compress.**
-dontwarn org.tukaani.xz.**
-dontwarn com.github.luben.zstd.**
-dontwarn org.brotli.dec.**
-dontwarn org.objectweb.asm.**
-dontwarn javax.annotation.**

# Vosk (reconocimiento sin internet): usa JNA, que busca clases y métodos por nombre.
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keepclassmembers class * extends com.sun.jna.** { public *; }
-dontwarn java.awt.*
