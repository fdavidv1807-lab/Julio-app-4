package com.julio.asistente.voz

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ReconocimientoUtilTest {
    @Test
    fun sacaElTextoFinalDeVosk() {
        val json = "{\n  \"text\" : \"agrega una clase de anatomia el lunes a las siete\"\n}"
        assertEquals("agrega una clase de anatomia el lunes a las siete", ReconocimientoUtil.extraer(json, "text"))
    }

    @Test
    fun sacaElTextoParcial() {
        val json = "{\n  \"partial\" : \"que tengo pendiente\"\n}"
        assertEquals("que tengo pendiente", ReconocimientoUtil.extraer(json, "partial"))
        assertEquals("", ReconocimientoUtil.extraer(json, "text"))
    }

    @Test
    fun respuestasVaciasDanTextoVacio() {
        assertEquals("", ReconocimientoUtil.extraer("{\"text\" : \"\"}", "text"))
        assertEquals("", ReconocimientoUtil.extraer("{\"partial\" : \"\"}", "partial"))
        assertEquals("", ReconocimientoUtil.extraer("", "text"))
        assertEquals("", ReconocimientoUtil.extraer("no es json", "text"))
    }

    @Test
    fun entiendeAcentosYEscapes() {
        assertEquals("qué día es", ReconocimientoUtil.extraer("{\"text\" : \"qué día es\"}", "text"))
        assertEquals("mañana", ReconocimientoUtil.extraer("{\"text\" : \"ma\\u00f1ana\"}", "text"))
        assertEquals("di \"hola\"", ReconocimientoUtil.extraer("{\"text\" : \"di \\\"hola\\\"\"}", "text"))
    }

    @Test
    fun elNivelDelSilencioEsCeroYElDeUnaVozFuerteEsAlto() {
        val silencio = ShortArray(1600)
        assertEquals(0f, ReconocimientoUtil.nivel(silencio, silencio.size), 0.0001f)
        val fuerte = ShortArray(1600) { if (it % 2 == 0) 20000 else -20000 }
        assertTrue(ReconocimientoUtil.nivel(fuerte, fuerte.size) > 0.9f)
        assertEquals(0f, ReconocimientoUtil.nivel(silencio, 0), 0.0001f)
    }

    @Test
    fun noDejaDescomprimirFueraDeLaCarpeta() {
        val raiz = File("/tmp/julio_prueba_raiz")
        assertTrue(ReconocimientoUtil.esRutaSegura(raiz, File(raiz, "modelo/am/final.mdl")))
        assertFalse(ReconocimientoUtil.esRutaSegura(raiz, File(raiz, "../fuera.txt")))
        assertFalse(ReconocimientoUtil.esRutaSegura(raiz, File("/tmp/julio_prueba_raiz_otro/x")))
    }
}
