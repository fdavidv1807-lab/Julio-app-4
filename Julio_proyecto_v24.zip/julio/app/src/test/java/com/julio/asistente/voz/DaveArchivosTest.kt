package com.julio.asistente.voz

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DaveArchivosTest {
    private fun mapaDave() = linkedMapOf("_" to 0, "^" to 1, "\$" to 2, " " to 3, "a" to 14)

    @Test
    fun aceptaLosDatosDeDave() {
        assertNull(DaveArchivos.revisar(22050, "es", 256, 1, mapaDave()))
    }

    @Test
    fun rechazaOtraFrecuencia() {
        assertNotNull(DaveArchivos.revisar(16000, "es", 256, 1, mapaDave()))
    }

    @Test
    fun rechazaOtraPronunciacion() {
        assertNotNull(DaveArchivos.revisar(22050, "en-us", 256, 1, mapaDave()))
    }

    @Test
    fun rechazaOtroNumeroDeSimbolosOHablantes() {
        assertNotNull(DaveArchivos.revisar(22050, "es", 130, 1, mapaDave()))
        assertNotNull(DaveArchivos.revisar(22050, "es", 256, 2, mapaDave()))
    }

    @Test
    fun rechazaFonemasFueraDeRangoOTablaIncompleta() {
        assertNotNull(DaveArchivos.revisar(22050, "es", 256, 1, mapaDave() + ("x" to 300)))
        assertNotNull(DaveArchivos.revisar(22050, "es", 256, 1, mapaDave() - "^"))
        assertNotNull(DaveArchivos.revisar(22050, "es", 256, 1, emptyMap()))
    }

    @Test
    fun tokensLlevanSimboloYNumeroTambienParaElEspacio() {
        assertEquals("_ 0\n^ 1\n\$ 2\n  3\na 14\n", DaveArchivos.generarTokens(mapaDave()))
    }

    @Test
    fun metadatosSonIgualesALosQueSeProbaronConOnnxruntime() {
        // Estos bytes se comprobaron en Python: onnxruntime los leyó y el audio salió idéntico.
        val bytes = DaveArchivos.metadatos(22050, "es", 1, "Spanish")
        val hex = bytes.joinToString("") { "%02x".format(it) }
        assertEquals("72120a0a6d6f64656c5f7479706512047669747372100a07636f6d6d656e741205706970657272130a086c616e677561676512075370616e697368720b0a05766f69636512026573720f0a0a6861735f65737065616b120131720f0a0a6e5f737065616b65727312013172140a0b73616d706c655f7261746512053232303530", hex)
        assertEquals(128, bytes.size)
    }

    @Test
    fun buscaMarcasDentroDeUnTrozo() {
        val datos = "xxinput_lengthsyy".toByteArray()
        assertTrue(DaveArchivos.contiene(datos, datos.size, "input_lengths".toByteArray()))
        assertFalse(DaveArchivos.contiene(datos, datos.size, "scales".toByteArray()))
        // Solo se mira hasta «largo»: la marca queda fuera.
        assertFalse(DaveArchivos.contiene(datos, 8, "input_lengths".toByteArray()))
    }

    @Test
    fun elRastreoEncuentraMarcasPartidasEntreDosTrozos() {
        val r = DaveArchivos.Rastreo(DaveArchivos.MARCAS_PIPER)
        val a = "....input_len".toByteArray()
        val b = "gths....sca".toByteArray()
        val c = "les....".toByteArray()
        r.alimentar(a, a.size)
        assertFalse(r.todasVistas())
        r.alimentar(b, b.size)
        r.alimentar(c, c.size)
        assertTrue(r.todasVistas())
    }

    @Test
    fun unModeloSinLasMarcasNoPasa() {
        val r = DaveArchivos.Rastreo(DaveArchivos.MARCAS_PIPER)
        val a = "solo input_lengths aqui".toByteArray()
        r.alimentar(a, a.size)
        assertFalse(r.todasVistas())
    }
}
