package com.julio.asistente.estudio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** Pruebas del plan de estudio y la racha (sin Android). Ejecutar con: gradle testDebugUnitTest */
class EstudioTest {
    private val hoy = LocalDate.of(2026, 10, 28)

    @Test fun seisDiasTresTemas() {
        val s = Planificador.generar("Anatomía", listOf("A", "B", "C"), LocalDate.of(2026, 11, 3), hoy, 45)
        assertEquals(6, s.size)
        assertEquals(listOf("A", "B", "C"), s.take(3).map { it.titulo })
        assertEquals("Repaso general", s.last().titulo)
        assertEquals(LocalDate.of(2026, 11, 2).toEpochDay(), s.last().fecha) // el día ANTES del examen
        assertEquals(hoy.toEpochDay(), s.first().fecha)
    }

    @Test fun examenManana() {
        val s = Planificador.generar("Química", listOf("A", "B"), hoy.plusDays(1), hoy, 45)
        assertEquals(1, s.size)
        assertEquals("A, B", s[0].titulo)
    }

    @Test fun examenHoyNoTieneDiasParaEstudiar() =
        assertTrue(Planificador.generar("X", listOf("A"), hoy, hoy, 45).isEmpty())

    @Test fun examenLejanoSoloPlaneaLosUltimosTreintaDias() {
        val examen = hoy.plusDays(60)
        val s = Planificador.generar("X", listOf("A"), examen, hoy, 45)
        assertEquals(Planificador.MAX_DIAS, s.size)
        assertEquals(examen.minusDays(30).toEpochDay(), s.first().fecha)
    }

    @Test fun masTemasQueDiasSeAgrupan() {
        val s = Planificador.generar("X", listOf("A", "B", "C", "D", "E", "F"), hoy.plusDays(3), hoy, 45)
        assertEquals(listOf("A, B", "C, D", "E, F"), s.map { it.titulo })
    }

    @Test fun sobranDiasSeUsanParaRepasar() {
        val s = Planificador.generar("X", listOf("A", "B", "C", "D"), LocalDate.of(2026, 11, 7), hoy, 45)
        assertEquals(10, s.size)
        assertEquals("Repaso de lo visto", s[5].titulo)
        assertEquals(90, s.last().minutos)
    }

    @Test fun rachaCuentaDiasSeguidos() {
        assertEquals(3, Rachas.actual(setOf(10L, 11L, 12L), 12L))
        assertEquals(3, Rachas.actual(setOf(10L, 11L, 12L), 13L)) // hoy todavía no estudias: sigue viva
        assertEquals(0, Rachas.actual(setOf(10L, 11L, 12L), 14L)) // se rompió
        assertEquals(3, Rachas.mejor(setOf(1L, 2L, 3L, 7L, 8L)))
    }

    @Test fun agendaSeparaHoyYAtrasadas() {
        val ses = Planificador.generar("X", listOf("A", "B", "C"), hoy.plusDays(6), hoy.minusDays(1), 45)
        val ex = Examen(1, "X", hoy.plusDays(6).toEpochDay(), listOf("A", "B", "C"), 45, ses, 0L)
        assertEquals(1, Agenda.deHoy(listOf(ex), hoy).size)
        assertEquals(1, Agenda.atrasadas(listOf(ex), hoy).size)
    }
}
