package com.julio.asistente.horario

import com.julio.asistente.data.local.ActividadEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

/** Pruebas de la lógica de repetición del horario (sin Android). Ejecutar con: gradle testDebugUnitTest */
class OcurrenciasTest {
    private val zona = ZoneId.of("America/Mexico_City")
    private val lunes = LocalDate.of(2026, 11, 2)

    private fun actividad(
        inicio: LocalDate, rec: Recurrencia, mascara: Int? = null, cada: Int? = null, excluidas: String? = null,
    ) = ActividadEntity(
        titulo = "X",
        inicio = inicio.atTime(7, 0).atZone(zona).toInstant().toEpochMilli(),
        recurrencia = rec.name, diasMascara = mascara, intervaloSemanas = cada, excluidas = excluidas,
    )

    private fun semana(a: ActividadEntity) = (0..6).map { Ocurrencias.ocurreEn(a, lunes.plusDays(it.toLong()), zona) }

    @Test fun lunesAViernes() = assertEquals(
        listOf(true, true, true, true, true, false, false),
        semana(actividad(lunes, Recurrencia.DIAS, DiasSemana.LUNES_A_VIERNES)),
    )

    @Test fun finDeSemana() = assertEquals(
        listOf(false, false, false, false, false, true, true),
        semana(actividad(lunes, Recurrencia.DIAS, DiasSemana.FIN_DE_SEMANA)),
    )

    @Test fun lunesMiercolesViernes() = assertEquals(
        listOf(true, false, true, false, true, false, false),
        semana(actividad(lunes, Recurrencia.DIAS, 21)),
    )

    @Test fun todosLosDias() = assertTrue(semana(actividad(lunes, Recurrencia.DIARIA)).all { it })

    @Test fun nadaAntesDelInicio() =
        assertFalse(Ocurrencias.ocurreEn(actividad(lunes, Recurrencia.DIAS, 31), lunes.minusDays(7), zona))

    @Test fun cadaDosSemanas() {
        val a = actividad(lunes, Recurrencia.DIAS, DiasSemana.bit(java.time.DayOfWeek.MONDAY), cada = 2)
        assertTrue(Ocurrencias.ocurreEn(a, lunes, zona))
        assertFalse(Ocurrencias.ocurreEn(a, lunes.plusWeeks(1), zona))
        assertTrue(Ocurrencias.ocurreEn(a, lunes.plusWeeks(2), zona))
    }

    @Test fun sinDuplicadosAlConsultar() {
        val a = actividad(lunes, Recurrencia.DIAS, DiasSemana.LUNES_A_VIERNES)
        assertEquals(5, Ocurrencias.entre(listOf(a), lunes, lunes.plusDays(6), zona).size)
    }

    @Test fun unaOcurrenciaExcluidaNoAparece() {
        val a = Ocurrencias.conExcluida(actividad(lunes, Recurrencia.DIAS, DiasSemana.LUNES_A_VIERNES), lunes.plusDays(2))
        assertEquals(
            listOf(true, true, false, true, true, false, false),
            semana(a),
        )
    }

    @Test fun primerDiaCaeEnUnDiaElegido() =
        assertEquals(lunes, DiasSemana.primerDia(lunes.minusDays(2), DiasSemana.LUNES_A_VIERNES)) // sábado -> lunes

    @Test fun descripciones() {
        assertEquals("de lunes a viernes", DiasSemana.describir(31))
        assertEquals("todos los días", DiasSemana.describir(127))
        assertEquals("los fines de semana", DiasSemana.describir(96))
        assertEquals("los lunes, miércoles y viernes", DiasSemana.describir(21))
        assertEquals("los martes y jueves", DiasSemana.describir(10))
        assertEquals("cada 2 semanas, los lunes", DiasSemana.describir(1, 2))
    }
}
