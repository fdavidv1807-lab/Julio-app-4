package com.julio.asistente.comandos

import com.julio.asistente.horario.Recurrencia
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

/** Qué tipo de cosa se quiere eliminar. */
enum class Elemento { TAREA, ACTIVIDAD, ALARMA, META }

/** Lo que el usuario quiere hacer, ya separado del texto, de la pantalla y de la base de datos. */
sealed class Intencion {
    data class AgregarHorario(
        val titulo: String?, val fecha: LocalDate?, val hora: LocalTime?, val recurrencia: Recurrencia,
        /** Con recurrencia DIAS: días elegidos (bit 0 = lunes ... bit 6 = domingo). 0 = el día de la fecha. */
        val diasMascara: Int = 0,
        /** Con recurrencia DIAS: cada cuántas semanas. */
        val intervaloSemanas: Int = 1,
        /** «de 8 a 10»: hora en que termina (null = sin hora de fin). */
        val horaFin: LocalTime? = null,
    ) : Intencion()
    /** «Tengo examen de anatomía el 5 de noviembre con los temas huesos y músculos». */
    data class CrearExamen(val materia: String?, val fecha: LocalDate?, val temas: List<String>) : Intencion()
    object ConsultarEstudio : Intencion()
    object IniciarSesionEstudio : Intencion()
    object EstudioHecho : Intencion()
    object ConsultarRacha : Intencion()
    /** «Repite esta actividad todos los martes y jueves». [referencia] null = la última actividad que se agregó. */
    data class RepetirActividad(
        val referencia: String?, val recurrencia: Recurrencia, val diasMascara: Int, val intervaloSemanas: Int,
    ) : Intencion()
    data class ConsultarHorario(val fecha: LocalDate) : Intencion()
    data class AgregarTarea(val titulo: String?) : Intencion()
    object ConsultarTareas : Intencion()
    data class CompletarTarea(val referencia: String) : Intencion()
    data class CrearAlarma(val hora: LocalTime?, val fecha: LocalDate?, val dias: Int, val enMinutos: Long?) : Intencion()
    data class CambiarAlarma(val activar: Boolean, val hora: LocalTime?, val dia: DayOfWeek?) : Intencion()
    object ConsultarAlarmas : Intencion()
    data class IniciarEnfoque(val minutos: Int?) : Intencion()
    data class IniciarDescanso(val minutos: Int?) : Intencion()
    data class ConfigurarDescanso(val minutos: Int) : Intencion()
    object PausarEnfoque : Intencion()
    object ReanudarEnfoque : Intencion()
    object FinalizarEnfoque : Intencion()
    object EstadoEnfoque : Intencion()
    object ConsultarMetas : Intencion()
    data class CrearMeta(val titulo: String?) : Intencion()
    data class ActualizarMeta(val referencia: String?, val porcentaje: Int?) : Intencion()
    /** «Elimina la tarea del informe»: siempre se confirma antes de borrar. */
    data class Eliminar(
        val elemento: Elemento?, val referencia: String?, val hora: LocalTime?, val dia: DayOfWeek?, val fecha: LocalDate?,
    ) : Intencion()
    /** «Mueve el laboratorio para el viernes a las cuatro». */
    data class MoverActividad(val referencia: String?, val fecha: LocalDate?, val hora: LocalTime?) : Intencion()
    /** «Cambia el nombre de la tarea informe por informe final». */
    data class RenombrarTarea(val referencia: String?, val nuevoTitulo: String?) : Intencion()
    /** «Cambia la alarma de las seis a las siete». */
    data class CambiarHoraAlarma(val horaActual: LocalTime?, val dia: DayOfWeek?, val horaNueva: LocalTime?) : Intencion()
    /** «Agrega X» sin fecha ni hora: ¿actividad del horario o tarea pendiente? */
    data class Ambigua(val texto: String) : Intencion()
    object Desconocida : Intencion()
}
