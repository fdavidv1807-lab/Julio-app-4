package com.julio.asistente.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.respaldo.RespaldoViewModel
import java.time.LocalDate

/** Guardar y restaurar una copia de seguridad de todos los datos. */
@Composable
fun RespaldoPanel(vm: RespaldoViewModel = viewModel()) {
    val mensaje by vm.mensaje.collectAsStateWithLifecycle()
    val pendiente by vm.pendiente.collectAsStateWithLifecycle()

    val crear = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.guardarEn(uri)
    }
    val abrir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.leerDe(uri)
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Copia de seguridad", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Guarda tus tareas, horario, alarmas, metas y planes de estudio en un archivo que tú eliges dónde dejar " +
                    "(por ejemplo en Drive o en tu memoria). Sirve para no perder nada si cambias de teléfono.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { crear.launch("julio_copia_${LocalDate.now()}.json") }, shape = MaterialTheme.shapes.small) {
                    Text("Guardar copia")
                }
                OutlinedButton(onClick = { abrir.launch(arrayOf("*/*")) }, shape = MaterialTheme.shapes.small) {
                    Text("Restaurar")
                }
            }
            mensaje?.let {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.cerrarMensaje() }) { Text("Cerrar") }
                }
            }
        }
    }

    pendiente?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.cancelarRestaurar() },
            title = { Text("Restaurar copia") },
            text = {
                Text(
                    "La copia trae ${p.resumen.texto()}.\n\nRestaurar REEMPLAZA todo lo que tienes ahora por lo de la copia. " +
                        "Antes, Julio guarda una copia automática de lo actual. ¿Continuar?",
                )
            },
            confirmButton = { TextButton(onClick = { vm.confirmarRestaurar() }) { Text("Restaurar") } },
            dismissButton = { TextButton(onClick = { vm.cancelarRestaurar() }) { Text("Cancelar") } },
        )
    }
}
