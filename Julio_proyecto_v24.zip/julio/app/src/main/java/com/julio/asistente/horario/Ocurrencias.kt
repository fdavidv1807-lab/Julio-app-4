package com.julio.asistente.horario

import com.julio.asistente.data.local.ActividadEntity
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.time.DayOfWeek

/** Una aparición concreta de una actividad en un día (las recurrentes tienen muchas). */
data class Ocurrencia(
    val actividad: ActividadEntity,
    val fecha: LocalDate,
    val horaInicio: LocalTime,
    val horaFin: LocalTime?,
)

/**
 * Lógica pura (sin Android ni base de datos) para saber qué actividades caen en qué día.
 * Una actividad se guarda una sola vez; sus repeticiones se calculan, no se duplican.
 */
object Ocurrencias {

    /** Días (epoch day) en que la serie NO ocurre. */
    fun excluidasDe(a: ActividadEntity): Set<Long> =
        a.excluidas?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()

    /** La misma actividad, sin ocurrir el día [dia] (para modificar o eliminar solo esa ocurrencia). */
    fun conExcluida(a: ActividadEntity, dia: LocalDate): ActividadEntity =
        a.copy(excluidas = (excluidasDe(a) + dia.toEpochDay()).sorted().joinToString(","))

    fun ocurreEn(a: ActividadEntity, dia: LocalDate, zona: ZoneId): Boolean {
        val primero = Instant.ofEpochMilli(a.inicio).atZone(zona).toLocalDate()
        if (dia.isBefore(primero)) return false
        if (a.excluidas != null && dia.toEpochDay() in excluidasDe(a)) return false
        return when (Recurrencia.de(a.recurrencia)) {
            Recurrencia.NINGUNA -> dia == primero
            Recurrencia.DIARIA -> true
            Recurrencia.SEMANAL -> dia.dayOfWeek == primero.dayOfWeek
            Recurrencia.DIAS -> {
                val mascara = a.diasMascara ?: 0
                if (mascara == 0) {
                    dia.dayOfWeek == primero.dayOfWeek
                } else if (!DiasSemana.contiene(mascara, dia.dayOfWeek)) {
                    false
                } else {
                    val cada = (a.intervaloSemanas ?: 1).coerceAtLeast(1)
                    val semanas = ChronoUnit.WEEKS.between(primero.with(DayOfWeek.MONDAY), dia.with(DayOfWeek.MONDAY))
                    semanas % cada == 0L
                }
            }
            // Si el mes no tiene ese día (p. ej. 31), cae en el último día del mes.
            Recurrencia.MENSUAL -> dia.dayOfMonth == minOf(primero.dayOfMonth, dia.lengthOfMonth())
        }
    }

    fun entre(
        actividades: List<ActividadEntity>,
        desde: LocalDate,
        hasta: LocalDate,
        zona: ZoneId = ZoneId.systemDefault(),
    ): List<Ocurrencia> {
        val resultado = mutableListOf<Ocurrencia>()
        var dia = desde
        while (!dia.isAfter(hasta)) {
            for (a in actividades) {
                if (ocurreEn(a, dia, zona)) {
                    val inicio = Instant.ofEpochMilli(a.inicio).atZone(zona).toLocalTime().withSecond(0).withNano(0)
                    val fin = a.fin?.let {
                        Instant.ofEpochMilli(it).atZone(zona).toLocalTime().withSecond(0).withNano(0)
                    }
                    resultado.add(Ocurrencia(a, dia, inicio, fin))
                }
            }
            dia = dia.plusDays(1)
        }
        return resultado.sortedWith(compareBy({ it.fecha }, { it.horaInicio }))
    }

    /** Lo que sigue: desde ahora hasta [dias] días; lo que ya terminó hoy no aparece. */
    fun proximas(
        actividades: List<ActividadEntity>,
        ahora: LocalDateTime = LocalDateTime.now(),
        dias: Int = 14,
        zona: ZoneId = ZoneId.systemDefault(),
    ): List<Ocurrencia> {
        val hoy = ahora.toLocalDate()
        return entre(actividades, hoy, hoy.plusDays((dias - 1).toLong()), zona).filter {
            !LocalDateTime.of(it.fecha, it.horaFin ?: it.horaInicio).isBefore(ahora)
        }
    }
}
