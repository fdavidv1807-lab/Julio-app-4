package com.julio.asistente.comandos

import java.text.Normalizer
import java.time.DateTimeException
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime

/** Utilidades puras (sin Android) para entender español hablado: números, horas, fechas, duraciones. */
object Texto {
    private val acentos = Regex("\\p{M}+")
    private val noAlfanum = Regex("[^a-z0-9:/% ]")
    private val espacios = Regex("\\s+")

    val DIAS: Map<String, DayOfWeek> = mapOf(
        "lunes" to DayOfWeek.MONDAY, "martes" to DayOfWeek.TUESDAY, "miercoles" to DayOfWeek.WEDNESDAY,
        "jueves" to DayOfWeek.THURSDAY, "viernes" to DayOfWeek.FRIDAY, "sabado" to DayOfWeek.SATURDAY,
        "domingo" to DayOfWeek.SUNDAY,
    )
    private val MESES = listOf(
        "enero", "febrero", "marzo", "abril", "mayo", "junio",
        "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
    )

    private val unidades: Map<String, Int> = mapOf(
        "cero" to 0, "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4,
        "cinco" to 5, "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11,
        "doce" to 12, "trece" to 13, "catorce" to 14, "quince" to 15, "dieciseis" to 16,
        "diecisiete" to 17, "dieciocho" to 18, "diecinueve" to 19, "veinte" to 20, "veintiuno" to 21,
        "veintiun" to 21, "veintidos" to 22, "veintitres" to 23, "veinticuatro" to 24,
        "veinticinco" to 25, "veintiseis" to 26, "veintisiete" to 27, "veintiocho" to 28,
        "veintinueve" to 29,
    )
    private val decenas: Map<String, Int> = mapOf(
        "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60,
        "setenta" to 70, "ochenta" to 80, "noventa" to 90,
    )

    /** Minúsculas, sin acentos ni signos: «¿Qué tengo mañana?» -> «que tengo manana». */
    fun normalizar(s: String): String {
        val sinAcentos = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(acentos, "")
        return sinAcentos.replace(noAlfanum, " ").replace(espacios, " ").trim()
    }

    /** Pasa números escritos con palabras a cifras: «treinta y cinco» -> «35», «las ocho» -> «las 8». */
    fun numeros(n: String): String {
        val t = n.split(" ")
        val salida = mutableListOf<String>()
        var i = 0
        while (i < t.size) {
            val w = t[i]
            val dec = decenas[w]
            val uni = unidades[w]
            if (dec != null) {
                val unidadSiguiente = if (i + 2 < t.size && t[i + 1] == "y") unidades[t[i + 2]] else null
                if (unidadSiguiente != null && unidadSiguiente in 1..9) {
                    salida.add((dec + unidadSiguiente).toString())
                    i += 3
                } else {
                    salida.add(dec.toString())
                    i += 1
                }
            } else if (uni != null) {
                val esUno = w == "un" || w == "uno" || w == "una"
                if (esUno) {
                    val sig = if (i + 1 < t.size) t[i + 1] else ""
                    val tras = sig == "hora" || sig == "horas" || sig == "minuto" || sig == "minutos"
                    val aLa = i >= 2 && t[i - 1] == "la" && t[i - 2] == "a"
                    salida.add(if (tras || aLa) uni.toString() else w)
                } else {
                    salida.add(uni.toString())
                }
                i += 1
            } else {
                salida.add(w)
                i += 1
            }
        }
        return salida.joinToString(" ")
    }

    /** Devuelve la cadena en minúsculas con tildes restauradas usando las palabras del texto original. */
    fun restaurar(normalizado: String, original: String): String {
        val mapa = HashMap<String, String>()
        for (palabra in original.lowercase().split(Regex("\\s+"))) {
            val limpia = palabra.trim { !it.isLetterOrDigit() }
            if (limpia.isNotEmpty()) mapa[normalizar(limpia)] = limpia
        }
        return normalizado.split(" ").filter { it.isNotEmpty() }.joinToString(" ") { mapa[it] ?: it }
    }

    fun capitalizar(s: String): String = s.replaceFirstChar { it.uppercase() }

    class ResultadoHora(val hora: LocalTime?, val resto: String, val enMinutos: Long? = null)

    /**
     * Busca una hora en el texto ya pasado por [numeros]. Sin indicación de mañana/tarde:
     * 7-11 = mañana, 12 = mediodía, y de 1 a 6 = tarde (horario) o madrugada (alarma).
     * Quien confirma siempre repite la hora resuelta para que el usuario pueda corregirla.
     */
    fun extraerHora(n: String, ahora: LocalTime, alarma: Boolean): ResultadoHora {
        val rel = Regex("\\ben (\\d+) (minutos?|horas?)\\b").find(n)
        if (rel != null) {
            val v = rel.groupValues[1].toLong()
            val minutos = if (rel.groupValues[2].startsWith("hora")) v * 60 else v
            return ResultadoHora(ahora.plusMinutes(minutos), n.removeRange(rel.range), minutos)
        }
        val mediodia = Regex("\\bmediodia\\b").find(n)
        if (mediodia != null) return ResultadoHora(LocalTime.NOON, n.removeRange(mediodia.range))
        val medianoche = Regex("\\bmedianoche\\b").find(n)
        if (medianoche != null) return ResultadoHora(LocalTime.MIDNIGHT, n.removeRange(medianoche.range))

        val reDosPuntos = Regex("\\b(\\d{1,2}):(\\d{2})\\b(?: (am|pm)\\b)?(?: (?:de|por|en) la (manana|tarde|noche|madrugada)\\b)?")
        val m1 = reDosPuntos.find(n)
        if (m1 != null) {
            val periodo = m1.groupValues[3].ifEmpty { m1.groupValues[4] }
            val t = resolver(m1.groupValues[1].toInt(), m1.groupValues[2].toInt(), periodo, alarma)
            if (t != null) return ResultadoHora(t, n.removeRange(m1.range))
        }

        val m2 = Regex("\\ba la(?:s)? (\\d{1,2})\\b").find(n)
        if (m2 != null) {
            var hora = m2.groupValues[1].toInt()
            var minuto = 0
            var fin = m2.range.last + 1
            val mm = Regex("^ (y media|y cuarto|menos cuarto|y (\\d{1,2})|menos (\\d{1,2}))\\b").find(n.substring(fin))
            if (mm != null) {
                val g = mm.groupValues[1]
                when {
                    g == "y media" -> minuto = 30
                    g == "y cuarto" -> minuto = 15
                    g == "menos cuarto" -> { hora -= 1; minuto = 45 }
                    mm.groupValues[2].isNotEmpty() -> minuto = mm.groupValues[2].toInt()
                    mm.groupValues[3].isNotEmpty() -> { hora -= 1; minuto = 60 - mm.groupValues[3].toInt() }
                }
                fin += mm.value.length
            }
            var periodo = ""
            val mp = Regex("^ (?:(am|pm)\\b|(?:de|por|en) la (manana|tarde|noche|madrugada)\\b)").find(n.substring(fin))
            if (mp != null) {
                periodo = mp.groupValues[1].ifEmpty { mp.groupValues[2] }
                fin += mp.value.length
            }
            val t = resolver(hora, minuto, periodo, alarma)
            if (t != null) return ResultadoHora(t, n.removeRange(m2.range.first, fin))
        }
        return ResultadoHora(null, n)
    }

    private fun resolver(h: Int, min: Int, periodo: String, alarma: Boolean): LocalTime? {
        if (h !in 0..23 || min !in 0..59) return null
        var hora = h
        when (periodo) {
            "pm", "tarde" -> if (hora in 1..11) hora += 12
            "noche" -> if (hora == 12) hora = 0 else if (hora in 1..11) hora += 12
            "am", "manana", "madrugada" -> if (hora == 12) hora = 0
            else -> if (hora in 1..6 && !alarma) hora += 12
        }
        return LocalTime.of(hora, min)
    }

    class ResultadoFecha(val fecha: LocalDate?, val resto: String)

    fun extraerFecha(n: String, hoy: LocalDate): ResultadoFecha {
        var resto = n
        var fecha: LocalDate? = null

        val pasado = Regex("\\bpasado manana\\b").find(resto)
        if (pasado != null) { resto = resto.removeRange(pasado.range); fecha = hoy.plusDays(2) }

        if (fecha == null) {
            val m = Regex("\\bmanana\\b").find(resto)
            if (m != null) { resto = resto.removeRange(m.range); fecha = hoy.plusDays(1) }
        }
        if (fecha == null) {
            val m = Regex("\\bhoy\\b").find(resto)
            if (m != null) { resto = resto.removeRange(m.range); fecha = hoy }
        }
        if (fecha == null) {
            val m = Regex("\\ben (\\d+) dias?\\b").find(resto)
            if (m != null) { resto = resto.removeRange(m.range); fecha = hoy.plusDays(m.groupValues[1].toLong()) }
        }
        if (fecha == null) {
            val m = Regex("\\b(?:el )?(\\d{1,2}) de (${MESES.joinToString("|")})(?: de (\\d{4}))?\\b").find(resto)
            if (m != null) {
                val f = construirFecha(m.groupValues[1].toInt(), MESES.indexOf(m.groupValues[2]) + 1, m.groupValues[3].toIntOrNull(), hoy)
                if (f != null) { resto = resto.removeRange(m.range); fecha = f }
            }
        }
        if (fecha == null) {
            val m = Regex("\\b(\\d{1,2})/(\\d{1,2})(?:/(\\d{4}))?\\b").find(resto)
            if (m != null) {
                val f = construirFecha(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toIntOrNull(), hoy)
                if (f != null) { resto = resto.removeRange(m.range); fecha = f }
            }
        }
        if (fecha == null) {
            val m = Regex("\\b(?:(?:el proximo|el|este|proximo) )?(${DIAS.keys.joinToString("|")})\\b").find(resto)
            if (m != null) {
                val objetivo = DIAS.getValue(m.groupValues[1])
                var d = hoy.plusDays(1)
                while (d.dayOfWeek != objetivo) d = d.plusDays(1)
                resto = resto.removeRange(m.range)
                fecha = d
            }
        }
        return ResultadoFecha(fecha, resto)
    }

    private fun construirFecha(dia: Int, mes: Int, anio: Int?, hoy: LocalDate): LocalDate? {
        return try {
            val f = LocalDate.of(anio ?: hoy.year, mes, dia)
            if (anio == null && f.isBefore(hoy)) f.plusYears(1) else f
        } catch (e: DateTimeException) {
            null
        }
    }

    /** «1 hora y 20 minutos» -> 80; «una hora y media» -> 90; «media hora» -> 30. */
    fun extraerDuracionMin(n: String): Int? {
        var total = 0
        var hallado = false
        val horaYMedia = Regex("(\\d+) horas? y media").find(n)
        if (horaYMedia != null) {
            total += horaYMedia.groupValues[1].toInt() * 60 + 30
            hallado = true
        } else {
            val h = Regex("(\\d+) horas?").find(n)
            if (h != null) { total += h.groupValues[1].toInt() * 60; hallado = true }
            if (Regex("\\bmedia hora\\b").containsMatchIn(n)) { total += 30; hallado = true }
        }
        val m = Regex("(\\d+) (?:minutos?|min)\\b").find(n)
        if (m != null) { total += m.groupValues[1].toInt(); hallado = true }
        return if (hallado && total > 0) total else null
    }
}
