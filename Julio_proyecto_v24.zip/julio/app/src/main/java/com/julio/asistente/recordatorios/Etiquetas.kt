package com.julio.asistente.recordatorios

/** «10 min», «1 h», «1 h 30 min». */
fun textoAntelacion(min: Int): String = when {
    min < 60 -> "$min min"
    min % 60 == 0 -> "${min / 60} h"
    else -> "${min / 60} h ${min % 60} min"
}

/** Etiqueta del aviso de una actividad: null = sin aviso, 0 = al empezar. */
fun etiquetaAviso(min: Int?): String = when (min) {
    null -> "Sin aviso"
    0 -> "Al empezar"
    else -> "${textoAntelacion(min)} antes"
}
