package com.julio.asistente.voz

import java.io.ByteArrayOutputStream

/**
 * Lo que Julio necesita saber de los dos archivos de la voz Dave (es_ES-davefx-medium):
 * el modelo `.onnx` y su `.json`. Todo aquí es lógica pura (sin Android) para poder probarla.
 *
 * sherpa-onnx no lee el `.onnx` de Piper tal cual sale de Hugging Face: pide (1) unos datos extra dentro del
 * modelo («metadatos») y (2) un `tokens.txt` con la tabla de fonemas. Ambos se derivan del `.json`.
 * Los metadatos se AÑADEN al final del archivo (formato protobuf); los pesos del modelo no se tocan.
 */
object DaveArchivos {
    const val MUESTREO = 22050
    const val SIMBOLOS = 256
    const val VOZ_ESPEAK = "es"

    /** Nombres que tiene que tener el modelo por dentro para ser un Piper (VITS) con esta forma de entrada. */
    val MARCAS_PIPER: List<ByteArray> = listOf("input_lengths", "scales").map { it.toByteArray(Charsets.UTF_8) }

    /** Devuelve un mensaje con el motivo si el `.json` NO corresponde a Dave, o null si todo cuadra. */
    fun revisar(muestreo: Int, vozEspeak: String, simbolos: Int, hablantes: Int, mapa: Map<String, Int>): String? {
        if (mapa.isEmpty()) return "El archivo .json no trae la tabla de fonemas (phoneme_id_map)."
        if (muestreo != MUESTREO) return "El .json dice $muestreo Hz y Dave usa $MUESTREO Hz."
        if (vozEspeak != VOZ_ESPEAK) return "El .json usa la pronunciación «$vozEspeak», y Dave usa «$VOZ_ESPEAK» (español de España)."
        if (simbolos != SIMBOLOS) return "El .json declara $simbolos símbolos y Dave usa $SIMBOLOS."
        if (hablantes != 1) return "Dave es de un solo hablante y el .json declara $hablantes."
        if (mapa.values.any { it < 0 || it >= simbolos }) return "Hay fonemas con un número fuera del rango del modelo."
        for (s in listOf("^", "\$", "_", " ")) {
            if (s !in mapa) return "Falta el símbolo «$s» en la tabla de fonemas."
        }
        return null
    }

    /** El `tokens.txt` que pide sherpa-onnx: una línea «símbolo número» por cada fonema (el espacio también). */
    fun generarTokens(mapa: Map<String, Int>): String {
        val sb = StringBuilder()
        for ((simbolo, numero) in mapa) sb.append(simbolo).append(' ').append(numero).append('\n')
        return sb.toString()
    }

    private fun escribirNumero(salida: ByteArrayOutputStream, valor: Int) {
        var n = valor
        while (n >= 0x80) {
            salida.write((n and 0x7F) or 0x80)
            n = n ushr 7
        }
        salida.write(n)
    }

    /**
     * Los metadatos que sherpa-onnx lee en un modelo Piper, ya codificados como campo `metadata_props`
     * (número 14) de un modelo ONNX. Se pueden pegar al final de un `.onnx` válido: en protobuf, repetir un
     * campo al final del archivo lo agrega sin cambiar nada de lo anterior.
     */
    fun metadatos(muestreo: Int, vozEspeak: String, hablantes: Int, idioma: String): ByteArray {
        val pares = listOf(
            "model_type" to "vits",
            "comment" to "piper",
            "language" to idioma,
            "voice" to vozEspeak,
            "has_espeak" to "1",
            "n_speakers" to hablantes.toString(),
            "sample_rate" to muestreo.toString(),
        )
        val todo = ByteArrayOutputStream()
        for ((clave, valor) in pares) {
            val k = clave.toByteArray(Charsets.UTF_8)
            val v = valor.toByteArray(Charsets.UTF_8)
            val entrada = ByteArrayOutputStream()
            entrada.write(0x0A)
            escribirNumero(entrada, k.size)
            entrada.write(k, 0, k.size)
            entrada.write(0x12)
            escribirNumero(entrada, v.size)
            entrada.write(v, 0, v.size)
            todo.write(0x72)
            escribirNumero(todo, entrada.size())
            todo.write(entrada.toByteArray(), 0, entrada.size())
        }
        return todo.toByteArray()
    }

    /** ¿Está [patron] dentro de los primeros [largo] bytes de [datos]? */
    fun contiene(datos: ByteArray, largo: Int, patron: ByteArray): Boolean {
        if (patron.isEmpty() || largo < patron.size) return false
        val limite = largo - patron.size
        var i = 0
        while (i <= limite) {
            if (datos[i] == patron[0]) {
                var j = 1
                while (j < patron.size && datos[i + j] == patron[j]) j++
                if (j == patron.size) return true
            }
            i++
        }
        return false
    }

    /** Busca varias marcas mientras el archivo se copia por trozos (también si una marca cae entre dos trozos). */
    class Rastreo(private val patrones: List<ByteArray>) {
        private val vistos = BooleanArray(patrones.size)
        private var cola = ByteArray(0)
        private val margen = (patrones.maxOfOrNull { it.size } ?: 1) - 1

        fun alimentar(trozo: ByteArray, n: Int) {
            val ventana = cola + trozo.copyOfRange(0, n)
            for (i in patrones.indices) {
                if (!vistos[i] && contiene(ventana, ventana.size, patrones[i])) vistos[i] = true
            }
            cola = ventana.copyOfRange(maxOf(0, ventana.size - margen), ventana.size)
        }

        fun todasVistas(): Boolean = vistos.all { it }
    }
}
