package com.julio.asistente.horario

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.JulioApp
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.recordatorios.RecordatorioProgramador
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HorarioViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as JulioApp).database.actividadDao()

    /** null = cargando. La lista siempre refleja lo realmente guardado en la base de datos. */
    val actividades: StateFlow<List<ActividadEntity>?> = dao.observarTodas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun guardar(a: ActividadEntity) {
        viewModelScope.launch {
            val id = if (a.id == 0L) dao.insertar(a) else {
                dao.actualizar(a)
                a.id
            }
            RecordatorioProgramador.programarActividad(getApplication(), a.copy(id = id))
        }
    }

    /** Modifica solo el día [dia] de una serie: ese día deja de ocurrir en la serie y se crea una actividad suelta. */
    fun guardarSoloEsta(original: ActividadEntity, dia: java.time.LocalDate, nueva: ActividadEntity) {
        viewModelScope.launch {
            val serie = Ocurrencias.conExcluida(original, dia)
            dao.actualizar(serie)
            val suelta = nueva.copy(
                id = 0, recurrencia = Recurrencia.NINGUNA.name,
                diasMascara = null, intervaloSemanas = null, excluidas = null,
            )
            val id = dao.insertar(suelta)
            RecordatorioProgramador.programarActividad(getApplication(), serie)
            RecordatorioProgramador.programarActividad(getApplication(), suelta.copy(id = id))
        }
    }

    /** Elimina solo el día [dia] de una serie; el resto de los días sigue igual. */
    fun eliminarSoloEsta(original: ActividadEntity, dia: java.time.LocalDate) {
        viewModelScope.launch {
            val serie = Ocurrencias.conExcluida(original, dia)
            dao.actualizar(serie)
            RecordatorioProgramador.programarActividad(getApplication(), serie)
        }
    }

    fun eliminar(a: ActividadEntity) {
        viewModelScope.launch {
            RecordatorioProgramador.cancelar(getApplication(), RecordatorioProgramador.TIPO_ACTIVIDAD, a.id)
            dao.eliminar(a)
        }
    }
}
