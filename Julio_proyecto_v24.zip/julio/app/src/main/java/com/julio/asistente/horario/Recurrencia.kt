package com.julio.asistente.horario

enum class Recurrencia(val etiqueta: String) {
    NINGUNA("No se repite"),
    DIARIA("Cada día"),
    SEMANAL("Cada semana"),
    MENSUAL("Cada mes"),
    /** Días de la semana elegidos (lunes a viernes, fin de semana, lunes y jueves...). */
    DIAS("Días de la semana");

    companion object {
        fun de(valor: String): Recurrencia = entries.firstOrNull { it.name == valor } ?: NINGUNA
    }
}
