package com.julio.asistente.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val EsquemaOscuro = darkColorScheme(
    primary = CianElectrico,
    onPrimary = Color(0xFF031521),
    primaryContainer = Color(0xFF0E3A66),
    onPrimaryContainer = Color(0xFFD3EEFF),
    secondary = Color(0xFF6EA2FF),
    onSecondary = Color(0xFF031024),
    secondaryContainer = Color(0xFF10305C),
    onSecondaryContainer = Color(0xFFD6E6FF),
    tertiary = AzulHielo,
    onTertiary = Color(0xFF03203A),
    background = NegroAzulado,
    onBackground = TextoPrincipal,
    surface = AzulMarino,
    onSurface = TextoPrincipal,
    surfaceVariant = Color(0xFF0F2038),
    onSurfaceVariant = TextoSecundario,
    surfaceContainerLowest = Color(0xFF030812),
    surfaceContainerLow = Color(0xFF08122A),
    surfaceContainer = Color(0xFF0B1A35),
    surfaceContainerHigh = Color(0xFF0F2242),
    surfaceContainerHighest = Color(0xFF142B52),
    outline = Color(0xFF4F86B5),
    outlineVariant = Color(0xFF1B3A5E),
    error = Color(0xFFFF7A8A),
    onError = Color(0xFF3B0A0A),
    errorContainer = Color(0xFF5A1A24),
    onErrorContainer = Color(0xFFFFD9DD),
)

private val EsquemaClaro = lightColorScheme(
    primary = ClaAcento,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE7FF),
    onPrimaryContainer = Color(0xFF0B2A66),
    secondary = Color(0xFF475569),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE2E8F0),
    onSecondaryContainer = Color(0xFF1E293B),
    tertiary = Color(0xFF9A6A12),
    onTertiary = Color.White,
    background = ClaFondo,
    onBackground = ClaTexto,
    surface = ClaSuperficie,
    onSurface = ClaTexto,
    surfaceVariant = Color(0xFFE9EDF3),
    onSurfaceVariant = ClaTextoSecundario,
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainer = Color(0xFFF3F5F9),
    surfaceContainerHigh = Color(0xFFEDF0F5),
    surfaceContainerHighest = Color(0xFFE6EAF0),
    outline = Color(0xFF7C8798),
    outlineVariant = Color(0xFFD5DCE6),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

private val Formas = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

private val TipografiaBase = Typography()
private val Tipografia = TipografiaBase.copy(
    titleLarge = TipografiaBase.titleLarge.copy(fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp),
    titleMedium = TipografiaBase.titleMedium.copy(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TipografiaBase.titleSmall.copy(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TipografiaBase.bodyLarge.copy(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TipografiaBase.bodyMedium.copy(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TipografiaBase.bodySmall.copy(fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TipografiaBase.labelLarge.copy(fontSize = 14.sp, fontWeight = FontWeight.Medium),
    labelMedium = TipografiaBase.labelMedium.copy(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TipografiaBase.labelSmall.copy(fontSize = 11.sp),
)

/** ¿Se está usando el tema oscuro? [modo]: 0 = como el teléfono, 1 = claro, 2 = oscuro. */
@Composable
fun esOscuro(modo: Int): Boolean = when (modo) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun JulioTheme(modo: Int = 0, content: @Composable () -> Unit) {
    val esquema = if (esOscuro(modo)) EsquemaOscuro else EsquemaClaro
    MaterialTheme(colorScheme = esquema, shapes = Formas, typography = Tipografia) {
        // Fuera de una Surface, el color de texto por defecto es negro: aquí se fija el del tema para toda la app.
        CompositionLocalProvider(LocalContentColor provides esquema.onBackground) {
            content()
        }
    }
}
