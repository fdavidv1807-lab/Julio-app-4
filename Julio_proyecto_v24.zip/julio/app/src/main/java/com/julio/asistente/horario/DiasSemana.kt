package com.julio.asistente.horario

import java.time.DayOfWeek
import java.time.LocalDate

/** Máscaras de días de la semana: bit 0 = lunes ... bit 6 = domingo. Lógica pura. */
object DiasSemana {
    const val LUNES_A_VIERNES = 31
    const val FIN_DE_SEMANA = 96
    const val TODOS = 127

    private val NOMBRES = listOf("lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo")
    private val CORTOS = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")

    fun bit(d: DayOfWeek): Int = 1 shl (d.value - 1)
    fun bit(indice: Int): Int = 1 shl indice
    fun contiene(mascara: Int, d: DayOfWeek): Boolean = (mascara and bit(d)) != 0
    fun corto(indice: Int): String = CORTOS[indice]

    /** Primer día desde [desde] (incluido) cuyo día de la semana está en la máscara. */
    fun primerDia(desde: LocalDate, mascara: Int): LocalDate {
        if (mascara == 0) return desde
        var d = desde
        repeat(7) {
            if (contiene(mascara, d.dayOfWeek)) return d
            d = d.plusDays(1)
        }
        return desde
    }

    private fun plural(indice: Int): String = NOMBRES[indice].let { if (it.endsWith("s")) it else it + "s" }

    /** «de lunes a viernes», «los lunes, miércoles y viernes», «todos los días»... */
    fun describir(mascara: Int, intervalo: Int = 1): String {
        val dias = when {
            mascara == TODOS -> "todos los días"
            mascara == LUNES_A_VIERNES -> "de lunes a viernes"
            mascara == FIN_DE_SEMANA -> "los fines de semana"
            mascara == 0 -> "el mismo día de la semana"
            else -> {
                val lista = (0..6).filter { (mascara and bit(it)) != 0 }.map { plural(it) }
                "los " + if (lista.size == 1) lista[0] else lista.dropLast(1).joinToString(", ") + " y " + lista.last()
            }
        }
        return if (intervalo > 1) "cada $intervalo semanas, $dias" else dias
    }
}
