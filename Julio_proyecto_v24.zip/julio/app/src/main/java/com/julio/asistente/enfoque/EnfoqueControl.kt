package com.julio.asistente.enfoque

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.bloqueo.BloqueoControl
import com.julio.asistente.core.Permisos
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Estado y control de la sesión de enfoque. El estado vive en SharedPreferences, así sobrevive
 * al cierre de la app; el fin de la sesión lo avisa AlarmManager, no un temporizador de la pantalla.
 * Importante: esto mide tiempo y avisa. NO bloquea aplicaciones.
 */
object EnfoqueControl {
    private const val ARCHIVO = "enfoque"
    private const val ID_PROGRESO = 5001
    private const val ID_FIN = 5002
    private const val ACCION_FIN = "com.julio.asistente.ENFOQUE_FIN"

    private val _sesion = MutableStateFlow(Sesion())
    val sesion: StateFlow<Sesion> = _sesion.asStateFlow()

    private val _preferencias = MutableStateFlow(Preferencias())
    val preferencias: StateFlow<Preferencias> = _preferencias.asStateFlow()

    private var cargado = false

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    @Synchronized
    fun cargar(c: Context) {
        if (cargado) return
        val p = sp(c)
        _preferencias.value = Preferencias(p.getInt("enfoqueMin", 25), p.getInt("descansoMin", 5))
        val estado = runCatching { EstadoSesion.valueOf(p.getString("estado", "INACTIVA") ?: "INACTIVA") }
            .getOrDefault(EstadoSesion.INACTIVA)
        val fase = runCatching { Fase.valueOf(p.getString("fase", "ENFOQUE") ?: "ENFOQUE") }
            .getOrDefault(Fase.ENFOQUE)
        _sesion.value = Sesion(
            estado, fase,
            p.getLong("duracionMs", 0L), p.getLong("finMs", 0L), p.getLong("restanteMs", 0L),
        )
        cargado = true
        reprogramar(c)
    }

    /** Tras reiniciar o actualizar la app el sistema olvida la alarma: se vuelve a armar o se cierra la sesión. */
    @Synchronized
    fun reprogramar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) {
            BloqueoControl.sincronizar(c)
            return
        }
        if (System.currentTimeMillis() >= s.finMs) {
            terminar(c)
        } else {
            programarAlarma(c, s.finMs)
            notificarProgreso(c, s)
            BloqueoControl.sincronizar(c)
        }
    }

    private fun guardar(c: Context, s: Sesion) {
        _sesion.value = s
        sp(c).edit()
            .putString("estado", s.estado.name)
            .putString("fase", s.fase.name)
            .putLong("duracionMs", s.duracionMs)
            .putLong("finMs", s.finMs)
            .putLong("restanteMs", s.restanteMs)
            .commit()
    }

    @Synchronized
    fun guardarPreferencias(c: Context, p: Preferencias) {
        cargar(c)
        _preferencias.value = p
        sp(c).edit().putInt("enfoqueMin", p.enfoqueMin).putInt("descansoMin", p.descansoMin).commit()
    }

    @Synchronized
    fun iniciar(c: Context, fase: Fase, duracionMs: Long) {
        cargar(c)
        if (duracionMs <= 0L) return
        // Una sesión nueva ya no es la de estudio que estuviera marcada (el plan la vuelve a marcar si hace falta).
        com.julio.asistente.estudio.EstudioRepo.limpiarEnCurso(c)
        cancelarAlarma(c)
        val fin = System.currentTimeMillis() + duracionMs
        val s = Sesion(EstadoSesion.CORRIENDO, fase, duracionMs, fin, 0L)
        guardar(c, s)
        programarAlarma(c, fin)
        NotificationManagerCompat.from(c).cancel(ID_FIN)
        notificarProgreso(c, s)
        BloqueoControl.sincronizar(c)
    }

    @Synchronized
    fun pausar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) return
        cancelarAlarma(c)
        NotificationManagerCompat.from(c).cancel(ID_PROGRESO)
        val restante = (s.finMs - System.currentTimeMillis()).coerceAtLeast(0L)
        guardar(c, s.copy(estado = EstadoSesion.PAUSADA, finMs = 0L, restanteMs = restante))
        BloqueoControl.sincronizar(c)
    }

    @Synchronized
    fun reanudar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.PAUSADA) return
        val fin = System.currentTimeMillis() + s.restanteMs
        val nueva = s.copy(estado = EstadoSesion.CORRIENDO, finMs = fin, restanteMs = 0L)
        guardar(c, nueva)
        programarAlarma(c, fin)
        notificarProgreso(c, nueva)
        BloqueoControl.sincronizar(c)
    }

    /** Cancela la sesión (o cierra el aviso de «terminada»): vuelve a INACTIVA. */
    @Synchronized
    fun finalizar(c: Context) {
        cargar(c)
        val previo = _sesion.value.estado
        cancelarAlarma(c)
        val nm = NotificationManagerCompat.from(c)
        nm.cancel(ID_PROGRESO)
        nm.cancel(ID_FIN)
        guardar(c, Sesion())
        // Cancelar a mitad de una sesión de estudio no la da por hecha.
        if (previo == EstadoSesion.CORRIENDO || previo == EstadoSesion.PAUSADA) {
            com.julio.asistente.estudio.EstudioRepo.limpiarEnCurso(c)
        }
        BloqueoControl.sincronizar(c)
    }

    /** La hora de fin llegó (la llama el receptor de la alarma, o la pantalla si estaba abierta). */
    @Synchronized
    fun terminar(c: Context) {
        cargar(c)
        val s = _sesion.value
        if (s.estado != EstadoSesion.CORRIENDO) return
        if (System.currentTimeMillis() < s.finMs - 2_000L) return
        cancelarAlarma(c)
        NotificationManagerCompat.from(c).cancel(ID_PROGRESO)
        guardar(c, s.copy(estado = EstadoSesion.TERMINADA, finMs = 0L, restanteMs = 0L))
        notificarFin(c, s.fase)
        // Si era una sesión de estudio: se da por hecha (cuenta para la racha) y se pedirá «¿cómo te fue?».
        if (s.fase == Fase.ENFOQUE) com.julio.asistente.estudio.EstudioRepo.enfoqueTerminado(c)
        BloqueoControl.sincronizar(c)
    }

    // ---- Alarma del sistema ----

    private fun pendienteFin(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 31,
            Intent(c, EnfoqueReceiver::class.java).setAction(ACCION_FIN),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun programarAlarma(c: Context, finMs: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendienteFin(c)
        try {
            if (Permisos.alarmasExactas(c)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finMs, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finMs, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, finMs, pi)
        }
    }

    private fun cancelarAlarma(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendienteFin(c)
        am.cancel(pi)
        pi.cancel()
    }

    // ---- Notificaciones ----

    private fun abrirApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 32, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun enviar(c: Context, id: Int, n: android.app.Notification) {
        try {
            NotificationManagerCompat.from(c).notify(id, n)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones: el temporizador sigue funcionando dentro de la app.
        }
    }

    private fun notificarProgreso(c: Context, s: Sesion) {
        val titulo = if (s.fase == Fase.ENFOQUE) "Enfoque en curso" else "Descanso en curso"
        val n = NotificationCompat.Builder(c, Canales.ENFOQUE_PROGRESO)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle(titulo)
            .setContentText("Tiempo restante")
            .setWhen(s.finMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(abrirApp(c))
            .build()
        enviar(c, ID_PROGRESO, n)
    }

    private fun notificarFin(c: Context, fase: Fase) {
        val titulo = if (fase == Fase.ENFOQUE) "Enfoque terminado" else "Descanso terminado"
        val texto = if (fase == Fase.ENFOQUE) "Buen trabajo. Es hora de un descanso." else "Listo para volver a enfocarte."
        val n = NotificationCompat.Builder(c, Canales.ENFOQUE_FIN)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(abrirApp(c))
            .build()
        enviar(c, ID_FIN, n)
    }
}
