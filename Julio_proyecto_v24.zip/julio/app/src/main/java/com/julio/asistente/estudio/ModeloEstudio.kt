package com.julio.asistente.estudio

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Una sesión de estudio planeada para un día. [nota]: 0 = sin calificar, 1 = mal, 2 = regular, 3 = bien. */
data class SesionEstudio(
    val id: Int,
    /** Día planeado (epoch day). */
    val fecha: Long,
    val titulo: String,
    val temas: List<String>,
    val minutos: Int,
    val hecha: Boolean = false,
    /** Día en que realmente se hizo (epoch day); cuenta para la racha. 0 = no hecha. */
    val hechaEn: Long = 0L,
    val nota: Int = 0,
    val refuerzo: Boolean = false,
)

data class Examen(
    val id: Long,
    val materia: String,
    /** Día del examen (epoch day). */
    val fecha: Long,
    val temas: List<String>,
    val minutos: Int,
    val sesiones: List<SesionEstudio>,
    val creadoEn: Long,
)

/** Reparte los temas en los días que faltan para el examen. Lógica pura (sin Android). */
object Planificador {
    const val MAX_DIAS = 30

    /**
     * Un bloque por día, desde hoy hasta el día ANTES del examen (como máximo [MAX_DIAS] días).
     *  - Con 4 días o más, el último día es «Repaso general»; con 7 o más, los dos últimos.
     *  - Si hay menos temas que días, sobran días de repaso de lo ya visto.
     *  - Si hay más temas que días, se agrupan; los días con más temas duran más (hasta 3 bloques).
     */
    fun generar(materia: String, temas: List<String>, fechaExamen: LocalDate, hoy: LocalDate, minutos: Int): List<SesionEstudio> {
        val disponibles = ChronoUnit.DAYS.between(hoy, fechaExamen).toInt()
        if (disponibles <= 0) return emptyList()
        val dias = minOf(disponibles, MAX_DIAS)
        val inicio = fechaExamen.minusDays(dias.toLong())
        val lista = temas.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(materia) }
        val repaso = when {
            dias >= 7 -> 2
            dias >= 4 -> 1
            else -> 0
        }
        val diasTemas = dias - repaso
        val n = lista.size
        val porDia: List<List<String>> =
            if (n <= diasTemas) List(diasTemas) { i -> if (i < n) listOf(lista[i]) else emptyList() }
            else List(diasTemas) { i -> lista.subList(i * n / diasTemas, (i + 1) * n / diasTemas) }

        val sesiones = mutableListOf<SesionEstudio>()
        var id = 1
        for (i in 0 until diasTemas) {
            val fecha = inicio.plusDays(i.toLong()).toEpochDay()
            val delDia = porDia[i]
            if (delDia.isEmpty()) {
                val titulo = if (lista.size <= 3) "Repaso: " + lista.joinToString(", ") else "Repaso de lo visto"
                sesiones += SesionEstudio(id++, fecha, titulo, lista, minutos)
            } else {
                val bloques = ((delDia.size + 1) / 2).coerceIn(1, 3)
                sesiones += SesionEstudio(id++, fecha, delDia.joinToString(", "), delDia, minutos * bloques)
            }
        }
        for (j in 0 until repaso) {
            val fecha = inicio.plusDays((diasTemas + j).toLong()).toEpochDay()
            sesiones += SesionEstudio(id++, fecha, "Repaso general", lista, minutos * 2)
        }
        return sesiones
    }
}

/** Consultas sobre el conjunto de exámenes. */
object Agenda {
    /** Sesiones de hoy sin hacer, de exámenes que aún no han pasado. */
    fun deHoy(examenes: List<Examen>, hoy: LocalDate): List<Pair<Examen, SesionEstudio>> {
        val d = hoy.toEpochDay()
        return examenes.filter { it.fecha > d }
            .flatMap { e -> e.sesiones.filter { it.fecha == d && !it.hecha }.map { e to it } }
    }

    /** Sesiones de días anteriores que no se hicieron (solo si el examen todavía no llega). */
    fun atrasadas(examenes: List<Examen>, hoy: LocalDate): List<Pair<Examen, SesionEstudio>> {
        val d = hoy.toEpochDay()
        return examenes.filter { it.fecha > d }
            .flatMap { e -> e.sesiones.filter { it.fecha < d && !it.hecha }.map { e to it } }
            .sortedBy { it.second.fecha }
    }

    /** Próxima sesión sin hacer después de hoy. */
    fun proxima(examenes: List<Examen>, hoy: LocalDate): Pair<Examen, SesionEstudio>? {
        val d = hoy.toEpochDay()
        return examenes.filter { it.fecha > d }
            .flatMap { e -> e.sesiones.filter { it.fecha > d && !it.hecha }.map { e to it } }
            .minByOrNull { it.second.fecha }
    }

    fun diasHechos(examenes: List<Examen>): Set<Long> =
        examenes.flatMap { it.sesiones }.filter { it.hecha && it.hechaEn > 0L }.map { it.hechaEn }.toSet()
}

/** Días seguidos estudiando. */
object Rachas {
    /** Racha vigente: si hoy todavía no estudias, la racha de ayer sigue viva hasta que termine el día. */
    fun actual(hechos: Set<Long>, hoy: Long): Int {
        var d = if (hoy in hechos) hoy else hoy - 1
        var n = 0
        while (d in hechos) {
            n++
            d--
        }
        return n
    }

    fun mejor(hechos: Set<Long>): Int {
        var mejor = 0
        var actual = 0
        var previo = Long.MIN_VALUE
        for (d in hechos.sorted()) {
            actual = if (previo != Long.MIN_VALUE && d == previo + 1) actual + 1 else 1
            if (actual > mejor) mejor = actual
            previo = d
        }
        return mejor
    }
}
