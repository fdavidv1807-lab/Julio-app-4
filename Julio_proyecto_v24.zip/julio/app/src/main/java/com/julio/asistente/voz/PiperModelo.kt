package com.julio.asistente.voz

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

sealed class EstadoPiper {
    object NoDescargada : EstadoPiper()
    data class Descargando(val progreso: Float, val mb: Long, val etapa: String = "Descargando") : EstadoPiper()
    object Lista : EstadoPiper()
    data class Error(val mensaje: String) : EstadoPiper()
}

/**
 * La voz neuronal «Dave» (Piper `es_ES-davefx-medium`, español de España, 22 050 Hz, un hablante, dataset CC0).
 * Pesa unos 63 MB, así que no va dentro del APK. Se instala UNA vez y después funciona sin internet.
 *
 * Dos caminos:
 *  1. [instalarDesdeArchivos]: con los DOS archivos originales de Dave (`.onnx` y `.json`) que la persona ya tiene.
 *     Julio los revisa, prepara el modelo para sherpa-onnx (sin cambiar sus pesos) y genera `tokens.txt`.
 *     Solo necesita internet para bajar una vez los datos de pronunciación (`espeak-ng-data`).
 *  2. [descargar]: baja el paquete ya preparado de sherpa-onnx (modelo + tokens + espeak-ng-data).
 */
object PiperModelo {
    const val ID = "es_ES-davefx-medium"
    const val TAMANO_APROX_MB = 65
    private val URLS = listOf(
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-es_ES-davefx-medium.tar.bz2",
    )

    /** Carpetas de voces que Julio instaló en versiones anteriores y que ya nadie usa. */
    private val VOCES_ANTERIORES = listOf("es_MX-claude-high")

    class Rutas(val modelo: String, val tokens: String, val datos: String)

    private val _estado = MutableStateFlow<EstadoPiper>(EstadoPiper.NoDescargada)
    val estado: StateFlow<EstadoPiper> = _estado.asStateFlow()

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var cancelado = false

    /** Los archivos que la persona eligió la última vez (para reintentar sin volver a elegirlos). */
    @Volatile private var ultimaSeleccion: List<Uri> = emptyList()

    private fun carpeta(c: Context) = File(c.applicationContext.filesDir, "piper/$ID")

    /** Busca los tres archivos que necesita el motor dentro de una carpeta. null = faltan. */
    private fun localizar(raiz: File): Rutas? {
        if (!raiz.isDirectory) return null
        val onnx = raiz.walkTopDown().firstOrNull { it.isFile && it.name.endsWith(".onnx") } ?: return null
        val base = onnx.parentFile ?: return null
        val tokens = File(base, "tokens.txt")
        val datos = File(base, "espeak-ng-data")
        if (!tokens.isFile || !datos.isDirectory || datos.listFiles().isNullOrEmpty()) return null
        return Rutas(onnx.absolutePath, tokens.absolutePath, datos.absolutePath)
    }

    fun rutas(c: Context): Rutas? = localizar(carpeta(c))

    /** Al abrir la app: ¿ya está instalada? Además borra restos de voces anteriores que ya no se usan. */
    fun iniciar(c: Context) {
        if (_estado.value is EstadoPiper.Descargando) return
        val base = File(c.applicationContext.filesDir, "piper")
        for (vieja in VOCES_ANTERIORES) {
            File(base, vieja).deleteRecursively()
            File(base, ".descarga_$vieja").deleteRecursively()
        }
        _estado.value = if (rutas(c) != null) EstadoPiper.Lista else EstadoPiper.NoDescargada
    }

    private fun marcar(etapa: String, progreso: Float, mb: Long) {
        _estado.value = EstadoPiper.Descargando(progreso, mb, etapa)
    }

    /** Termina una instalación: comprueba que está todo y lo mueve a su sitio definitivo. */
    private fun publicar(app: Context, temporal: File) {
        if (localizar(temporal) == null) throw IOException("Faltan archivos de la voz (modelo, tokens o datos de pronunciación).")
        val destino = carpeta(app)
        destino.deleteRecursively()
        destino.parentFile?.mkdirs()
        if (!temporal.renameTo(destino)) throw IOException("No pude guardar la voz en la memoria de Julio.")
        _estado.value = if (localizar(destino) != null) EstadoPiper.Lista else EstadoPiper.Error("La voz no quedó completa.")
    }

    private fun fallo(e: Exception, queHacia: String) {
        _estado.value = if (cancelado) EstadoPiper.NoDescargada
        else EstadoPiper.Error("$queHacia: ${e.message ?: e.javaClass.simpleName}")
    }

    /** Camino 2: baja el paquete ya preparado de sherpa-onnx. */
    fun descargar(c: Context) {
        if (_estado.value is EstadoPiper.Descargando) return
        val app = c.applicationContext
        ultimaSeleccion = emptyList()
        cancelado = false
        marcar("Descargando", 0f, 0)
        alcance.launch {
            val temporal = File(app.filesDir, "piper/.descarga_$ID")
            try {
                bajarPrimeraUrl(temporal, soloDatos = false)
                publicar(app, temporal)
            } catch (e: Exception) {
                temporal.deleteRecursively()
                fallo(e, "No pude descargar la voz. Revisa tu conexión e inténtalo otra vez")
            }
        }
    }

    /** Camino 1: instala Dave a partir de sus dos archivos originales. */
    fun instalarDesdeArchivos(c: Context, uris: List<Uri>) {
        if (_estado.value is EstadoPiper.Descargando) return
        val app = c.applicationContext
        ultimaSeleccion = uris
        cancelado = false
        marcar("Revisando los archivos", -1f, 0)
        alcance.launch {
            val temporal = File(app.filesDir, "piper/.descarga_$ID")
            try {
                val jsonUri = uris.firstOrNull { nombreDe(app, it).lowercase().endsWith(".json") }
                    ?: throw IOException("Falta el archivo .json de Dave. Elige los dos archivos: el .onnx y el .json.")
                val onnxUri = uris.firstOrNull { nombreDe(app, it).lowercase().endsWith(".onnx") }
                    ?: throw IOException("Falta el archivo .onnx de Dave. Elige los dos archivos: el .onnx y el .json.")

                // 1) El .json: ¿corresponde a Dave?
                val texto = app.contentResolver.openInputStream(jsonUri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                    ?: throw IOException("No pude abrir el archivo .json.")
                if (texto.length > 2_000_000) throw IOException("El .json es demasiado grande para ser de una voz Piper.")
                val obj = JSONObject(texto)
                val muestreo = obj.optJSONObject("audio")?.optInt("sample_rate", -1) ?: -1
                val vozEspeak = obj.optJSONObject("espeak")?.optString("voice", "") ?: ""
                val simbolos = obj.optInt("num_symbols", -1)
                val hablantes = obj.optInt("num_speakers", -1)
                val idioma = obj.optJSONObject("language")?.optString("name_english", "Spanish") ?: "Spanish"
                val mapaJson = obj.optJSONObject("phoneme_id_map")
                    ?: throw IOException("El .json no trae la tabla de fonemas (phoneme_id_map).")
                val mapa = LinkedHashMap<String, Int>()
                val claves = mapaJson.keys()
                while (claves.hasNext()) {
                    val k = claves.next()
                    val lista = mapaJson.optJSONArray(k)
                    if (lista != null && lista.length() > 0) mapa[k] = lista.getInt(0)
                }
                DaveArchivos.revisar(muestreo, vozEspeak, simbolos, hablantes, mapa)?.let { throw IOException(it) }

                // 2) El .onnx: se copia con los metadatos añadidos al final (los pesos no cambian).
                temporal.deleteRecursively()
                temporal.mkdirs()
                val rastreo = DaveArchivos.Rastreo(DaveArchivos.MARCAS_PIPER)
                val metadatos = DaveArchivos.metadatos(muestreo, vozEspeak, hablantes, idioma)
                var total = 0L
                var ultimoMb = -1L
                val destinoOnnx = File(temporal, "$ID.onnx")
                app.contentResolver.openInputStream(onnxUri)?.use { entrada ->
                    destinoOnnx.outputStream().use { salida ->
                        val trozo = ByteArray(64 * 1024)
                        while (true) {
                            if (cancelado) throw IOException("Instalación cancelada")
                            val n = entrada.read(trozo)
                            if (n < 0) break
                            if (total == 0L && trozo[0] != 0x08.toByte()) {
                                throw IOException("El archivo .onnx no tiene el formato de un modelo ONNX.")
                            }
                            rastreo.alimentar(trozo, n)
                            salida.write(trozo, 0, n)
                            total += n
                            val mb = total / 1_000_000
                            if (mb != ultimoMb) {
                                ultimoMb = mb
                                marcar("Preparando el modelo", -1f, mb)
                            }
                        }
                        if (total < 5_000_000L) throw IOException("El .onnx es demasiado pequeño para ser el modelo de Dave.")
                        if (!rastreo.todasVistas()) throw IOException("El .onnx no parece un modelo Piper (no tiene las entradas input_lengths y scales).")
                        salida.write(metadatos)
                    }
                } ?: throw IOException("No pude abrir el archivo .onnx.")

                // 3) La tabla de fonemas que pide sherpa-onnx.
                File(temporal, "tokens.txt").writeText(DaveArchivos.generarTokens(mapa), Charsets.UTF_8)

                // 4) Datos de pronunciación (espeak-ng-data): se bajan una sola vez.
                marcar("Descargando datos de pronunciación", 0f, 0)
                bajarPrimeraUrl(temporal, soloDatos = true)

                publicar(app, temporal)
            } catch (e: Exception) {
                temporal.deleteRecursively()
                fallo(e, "No pude instalar la voz")
            }
        }
    }

    /** Vuelve a intentar con lo mismo que se eligió antes (archivos propios o paquete). */
    fun reintentar(c: Context) {
        val previa = ultimaSeleccion
        if (previa.isNotEmpty()) instalarDesdeArchivos(c, previa) else descargar(c)
    }

    fun cancelar() { cancelado = true }

    fun eliminar(c: Context) {
        cancelado = true
        ultimaSeleccion = emptyList()
        carpeta(c).deleteRecursively()
        _estado.value = EstadoPiper.NoDescargada
    }

    private fun nombreDe(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) return cursor.getString(0) ?: ""
            }
        } catch (e: Exception) {
            // Si no se puede leer el nombre se prueba con el final de la ruta.
        }
        return uri.lastPathSegment ?: ""
    }

    private class Contador(entrada: InputStream, private val alLeer: (Long) -> Unit) : FilterInputStream(entrada) {
        private var total = 0L
        override fun read(): Int {
            val b = super.read()
            if (b >= 0) { total++; alLeer(total) }
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { total += n; alLeer(total) }
            return n
        }
    }

    private fun bajarPrimeraUrl(destino: File, soloDatos: Boolean) {
        var ultimo: Exception? = null
        for (url in URLS) {
            if (!soloDatos) destino.deleteRecursively()
            destino.mkdirs()
            try {
                bajarYExtraer(url, destino, soloDatos)
                return
            } catch (e: Exception) {
                if (cancelado) throw e
                ultimo = e
            }
        }
        throw ultimo ?: IOException("No se pudo descargar")
    }

    /**
     * Baja el .tar.bz2 y lo va descomprimiendo al vuelo (no hace falta espacio extra para el comprimido).
     * Con [soloDatos] solo se guarda la carpeta `espeak-ng-data`; el resto del paquete se descarta.
     */
    private fun bajarYExtraer(url: String, destino: File, soloDatos: Boolean) {
        val conexion = URL(url).openConnection() as HttpURLConnection
        conexion.connectTimeout = 20_000
        conexion.readTimeout = 30_000
        conexion.instanceFollowRedirects = true
        try {
            if (conexion.responseCode !in 200..299) throw IOException("el servidor respondió ${conexion.responseCode}")
            val total = conexion.contentLengthLong
            var porcentajePublicado = -1
            val etapa = if (soloDatos) "Descargando datos de pronunciación" else "Descargando"
            val contado = Contador(conexion.inputStream) { leidos ->
                if (cancelado) throw IOException("Descarga cancelada")
                val p = if (total > 0) (leidos * 100 / total).toInt() else -1
                if (p != porcentajePublicado) {
                    porcentajePublicado = p
                    marcar(etapa, if (total > 0) leidos.toFloat() / total else -1f, leidos / 1_000_000)
                }
            }
            val raiz = destino.canonicalFile
            TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(contado))).use { tar ->
                var entrada = tar.nextEntry
                while (entrada != null) {
                    val nombre = entrada.name
                    val relativo = if (soloDatos) {
                        val i = nombre.indexOf("espeak-ng-data")
                        if (i >= 0) nombre.substring(i) else null
                    } else {
                        nombre
                    }
                    if (relativo != null) {
                        val salida = File(raiz, relativo).canonicalFile
                        if (!salida.path.startsWith(raiz.path + File.separator)) throw IOException("Archivo con ruta no válida")
                        if (entrada.isDirectory) {
                            salida.mkdirs()
                        } else {
                            salida.parentFile?.mkdirs()
                            salida.outputStream().use { fuera -> tar.copyTo(fuera) }
                        }
                    }
                    entrada = tar.nextEntry
                }
            }
        } finally {
            conexion.disconnect()
        }
    }
}
