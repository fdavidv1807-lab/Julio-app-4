package com.julio.asistente.bloqueo

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.enfoque.Fase

data class PermisosBloqueo(val acceso: Boolean, val superposicion: Boolean) {
    val ok: Boolean get() = acceso && superposicion
}

object BloqueoControl {

    /** Motivo técnico del último fallo al iniciar el bloqueo (para diagnóstico). */
    @Volatile
    var ultimoError: String? = null

    fun permisos(c: Context): PermisosBloqueo {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val modo = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        }
        return PermisosBloqueo(
            acceso = modo == AppOpsManager.MODE_ALLOWED,
            superposicion = Settings.canDrawOverlays(c),
        )
    }

    fun ajustesAcceso(c: Context): Intent =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:${c.packageName}"))

    fun ajustesAccesoGeneral(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    fun ajustesSuperposicion(c: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${c.packageName}"))

    /** El bloqueo solo corre durante un ENFOQUE en marcha (no en pausa ni en descansos). */
    fun debeEstarActivo(c: Context): Boolean {
        BloqueoConfig.cargar(c)
        val s = EnfoqueControl.sesion.value
        return BloqueoConfig.activo.value &&
            BloqueoConfig.paquetes.value.isNotEmpty() &&
            s.estado == EstadoSesion.CORRIENDO &&
            s.fase == Fase.ENFOQUE &&
            permisos(c).ok
    }

    /** Arranca o detiene el servicio de bloqueo según el estado real. Es seguro llamarla muchas veces. */
    fun sincronizar(c: Context) {
        val app = c.applicationContext
        val intent = Intent(app, BloqueoService::class.java)
        if (debeEstarActivo(app)) {
            try {
                ContextCompat.startForegroundService(app, intent)
                ultimoError = null
            } catch (e: Exception) {
                ultimoError = "${e.javaClass.simpleName}: ${e.message}"
            }
        } else {
            app.stopService(intent)
        }
    }

    /**
     * Apps que NUNCA se pueden bloquear: Julio, llamadas y emergencias, ajustes del sistema
     * y la pantalla de inicio. Así siempre hay forma de salir y de llamar.
     */
    fun protegidas(c: Context): Set<String> {
        val s = mutableSetOf(
            c.packageName,
            "android",
            "com.android.systemui",
            "com.android.settings",
            "com.android.emergency",
            "com.android.phone",
            "com.android.server.telecom",
            "com.android.dialer",
            "com.google.android.dialer",
            "com.samsung.android.dialer",
            "com.android.incallui",
            "com.samsung.android.incallui",
        )
        try {
            c.getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) }
        } catch (e: Exception) {
            // Sin acceso al marcador por defecto: queda la lista fija.
        }
        val inicio = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        @Suppress("DEPRECATION")
        c.packageManager.queryIntentActivities(inicio, 0).forEach { s.add(it.activityInfo.packageName) }
        return s
    }
}
