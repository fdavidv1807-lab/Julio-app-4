package com.julio.asistente.estudio

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.julio.asistente.core.Permisos
import java.time.ZonedDateTime

/** Programa con AlarmManager el aviso diario «hoy toca estudiar» (un solo aviso a la hora elegida). */
object EstudioAviso {
    const val ACCION = "com.julio.asistente.ESTUDIO_AVISO"
    private const val CODIGO = 7001

    private fun alarmManager(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pendiente(c: Context, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(
            c, CODIGO, Intent(c, EstudioReceiver::class.java).setAction(ACCION),
            flags or PendingIntent.FLAG_IMMUTABLE,
        )

    fun cancelar(c: Context) {
        pendiente(c, PendingIntent.FLAG_NO_CREATE)?.let {
            alarmManager(c).cancel(it)
            it.cancel()
        }
    }

    /** Arma el próximo aviso, o lo cancela si está apagado o ya no hay exámenes por venir. */
    fun programar(c: Context, ahora: ZonedDateTime = ZonedDateTime.now()) {
        EstudioRepo.cargar(c)
        val ajustes = EstudioRepo.ajustes.value
        val hoy = ahora.toLocalDate().toEpochDay()
        val hayExamenes = EstudioRepo.examenes.value.any { it.fecha > hoy }
        if (!ajustes.avisoActivo || !hayExamenes) {
            cancelar(c)
            return
        }
        var momento = ahora.toLocalDate().atTime(ajustes.avisoMin / 60, ajustes.avisoMin % 60).atZone(ahora.zone)
        if (!momento.isAfter(ahora.plusSeconds(30))) momento = momento.plusDays(1)
        val pi = pendiente(c, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        val ms = momento.toInstant().toEpochMilli()
        val am = alarmManager(c)
        try {
            if (Permisos.alarmasExactas(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        }
    }
}
