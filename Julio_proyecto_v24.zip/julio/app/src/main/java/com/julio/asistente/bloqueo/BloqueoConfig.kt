package com.julio.asistente.bloqueo

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Decisión del usuario sobre el bloqueo de apps. Por defecto está APAGADO: solo se enciende
 * cuando el usuario acepta la pantalla de consentimiento en Modo enfoque.
 */
object BloqueoConfig {
    private const val ARCHIVO = "bloqueo"

    private val _activo = MutableStateFlow(false)
    val activo: StateFlow<Boolean> = _activo.asStateFlow()

    private val _paquetes = MutableStateFlow<Set<String>>(emptySet())
    val paquetes: StateFlow<Set<String>> = _paquetes.asStateFlow()

    private var cargado = false

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    @Synchronized
    fun cargar(c: Context) {
        if (cargado) return
        val p = sp(c)
        _activo.value = p.getBoolean("activo", false)
        _paquetes.value = p.getStringSet("paquetes", emptySet())?.toSet() ?: emptySet()
        cargado = true
    }

    @Synchronized
    fun activar(c: Context, valor: Boolean) {
        cargar(c)
        _activo.value = valor
        sp(c).edit().putBoolean("activo", valor).commit()
        BloqueoControl.sincronizar(c)
    }

    @Synchronized
    fun guardarPaquetes(c: Context, paquetes: Set<String>) {
        cargar(c)
        _paquetes.value = paquetes
        sp(c).edit().putStringSet("paquetes", HashSet(paquetes)).commit()
        BloqueoControl.sincronizar(c)
    }
}
