package com.julio.asistente.ui.screens

import com.julio.asistente.ui.components.PanelJulio

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.horario.DiasSemana
import com.julio.asistente.horario.HorarioViewModel
import com.julio.asistente.horario.Ocurrencia
import com.julio.asistente.horario.Ocurrencias
import com.julio.asistente.horario.Recurrencia
import com.julio.asistente.recordatorios.etiquetaAviso
import com.julio.asistente.ui.components.SelectorFecha
import com.julio.asistente.ui.components.SelectorHora
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

private enum class VistaHorario(val etiqueta: String) {
    DIA("Día"),
    PROXIMAS("Próximas"),
}

@Composable
fun HorarioScreen(vm: HorarioViewModel = viewModel()) {
    val lista by vm.actividades.collectAsStateWithLifecycle()
    val actividades = lista
    val zona = ZoneId.systemDefault()

    var vista by rememberSaveable { mutableStateOf(VistaHorario.DIA) }
    var diaEpoch by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }
    val dia = LocalDate.ofEpochDay(diaEpoch)

    var dialogoAbierto by remember { mutableStateOf(false) }
    var enEdicion by remember { mutableStateOf<ActividadEntity?>(null) }
    // Si es una actividad que se repite, se pregunta si el cambio es solo para ese día o para toda la serie.
    var soloEstaFecha by remember { mutableStateOf<LocalDate?>(null) }
    var alcanceEdicion by remember { mutableStateOf<Ocurrencia?>(null) }
    var porEliminar by remember { mutableStateOf<Ocurrencia?>(null) }
    var selectorDiaAbierto by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Text(
                "Horario",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VistaHorario.entries.forEach { v ->
                    FilterChip(
                        selected = vista == v,
                        onClick = { vista = v },
                        label = { Text(v.etiqueta) },
                    )
                }
            }

            if (vista == VistaHorario.DIA) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { diaEpoch -= 1 }) {
                        Icon(Icons.Filled.ChevronLeft, contentDescription = "Día anterior")
                    }
                    TextButton(
                        onClick = { selectorDiaAbierto = true },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            Fechas.textoLargo(dia),
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center,
                        )
                    }
                    IconButton(onClick = { diaEpoch += 1 }) {
                        Icon(Icons.Filled.ChevronRight, contentDescription = "Día siguiente")
                    }
                }
                if (dia != LocalDate.now()) {
                    TextButton(onClick = { diaEpoch = LocalDate.now().toEpochDay() }) {
                        Text("Volver a hoy")
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            if (actividades == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                val ocurrencias = if (vista == VistaHorario.DIA) {
                    Ocurrencias.entre(actividades, dia, dia, zona)
                } else {
                    Ocurrencias.proximas(actividades, LocalDateTime.now(), 14, zona)
                }
                if (ocurrencias.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (vista == VistaHorario.DIA) "No hay actividades este día."
                            else "No tienes actividades en los próximos 14 días.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 96.dp),
                    ) {
                        ocurrencias.groupBy { it.fecha }.forEach { (fecha, delDia) ->
                            if (vista == VistaHorario.PROXIMAS) {
                                item(key = "cab-${fecha.toEpochDay()}") {
                                    Text(
                                        etiquetaDia(fecha),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(top = 8.dp),
                                    )
                                }
                            }
                            items(
                                delDia,
                                key = { "${it.actividad.id}-${it.fecha.toEpochDay()}" },
                            ) { o ->
                                OcurrenciaItem(
                                    o = o,
                                    onEditar = {
                                        if (Recurrencia.de(o.actividad.recurrencia) != Recurrencia.NINGUNA) {
                                            alcanceEdicion = o
                                        } else {
                                            enEdicion = o.actividad; soloEstaFecha = null; dialogoAbierto = true
                                        }
                                    },
                                    onEliminar = { porEliminar = o },
                                )
                            }
                        }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { enEdicion = null; soloEstaFecha = null; dialogoAbierto = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Nueva actividad") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    if (dialogoAbierto) {
        DialogoActividad(
            inicial = enEdicion,
            diaPorDefecto = dia,
            zona = zona,
            soloEsta = soloEstaFecha,
            onGuardar = {
                val serie = enEdicion
                val fechaSolo = soloEstaFecha
                if (serie != null && fechaSolo != null) vm.guardarSoloEsta(serie, fechaSolo, it) else vm.guardar(it)
                dialogoAbierto = false
            },
            onCancelar = { dialogoAbierto = false },
        )
    }

    if (selectorDiaAbierto) {
        SelectorFecha(
            inicial = dia,
            onAceptar = { diaEpoch = it.toEpochDay(); selectorDiaAbierto = false },
            onCancelar = { selectorDiaAbierto = false },
        )
    }

    alcanceEdicion?.let { o ->
        AlertDialog(
            onDismissRequest = { alcanceEdicion = null },
            title = { Text("Actividad que se repite") },
            text = { Text("«${o.actividad.titulo}» se repite. ¿Qué quieres modificar?") },
            confirmButton = {
                TextButton(onClick = {
                    enEdicion = o.actividad; soloEstaFecha = null; dialogoAbierto = true; alcanceEdicion = null
                }) { Text("Toda la serie") }
            },
            dismissButton = {
                TextButton(onClick = {
                    enEdicion = o.actividad; soloEstaFecha = o.fecha; dialogoAbierto = true; alcanceEdicion = null
                }) { Text("Solo el ${Fechas.textoLargo(o.fecha)}") }
            },
        )
    }

    porEliminar?.let { o ->
        val a = o.actividad
        val repite = Recurrencia.de(a.recurrencia) != Recurrencia.NINGUNA
        AlertDialog(
            onDismissRequest = { porEliminar = null },
            title = { Text("Eliminar actividad") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        if (repite) "«${a.titulo}» se repite. ¿Qué quieres eliminar?" else "¿Eliminar «${a.titulo}»?",
                    )
                    if (repite) {
                        TextButton(onClick = { vm.eliminarSoloEsta(a, o.fecha); porEliminar = null }) {
                            Text("Solo el ${Fechas.textoLargo(o.fecha)}")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.eliminar(a); porEliminar = null }) {
                    Text(if (repite) "Toda la serie" else "Eliminar")
                }
            },
            dismissButton = { TextButton(onClick = { porEliminar = null }) { Text("Cancelar") } },
        )
    }
}

private fun etiquetaDia(f: LocalDate): String {
    val hoy = LocalDate.now()
    return when (f) {
        hoy -> "Hoy · ${Fechas.textoLargo(f)}"
        hoy.plusDays(1) -> "Mañana · ${Fechas.textoLargo(f)}"
        else -> Fechas.textoLargo(f)
    }
}

private fun textoRepeticion(a: ActividadEntity): String = when (Recurrencia.de(a.recurrencia)) {
    Recurrencia.DIAS -> DiasSemana.describir(a.diasMascara ?: 0, a.intervaloSemanas ?: 1)
    else -> Recurrencia.de(a.recurrencia).etiqueta.lowercase()
}

private enum class ModoRepetir(val etiqueta: String) {
    UNA_VEZ("Una sola vez"),
    TODOS("Todos los días"),
    LUN_VIE("Lunes a viernes"),
    FIN_SEMANA("Fin de semana"),
    ELEGIDOS("Días elegidos"),
    PERSONALIZADA("Cada varias semanas"),
    MENSUAL("Cada mes"),
}

/** Cómo se muestra una actividad guardada en el formulario: modo, días elegidos y cada cuántas semanas. */
private fun modoInicial(a: ActividadEntity?, zona: ZoneId): Triple<ModoRepetir, Int, Int> {
    if (a == null) return Triple(ModoRepetir.UNA_VEZ, 0, 2)
    val dia = Instant.ofEpochMilli(a.inicio).atZone(zona).dayOfWeek
    return when (Recurrencia.de(a.recurrencia)) {
        Recurrencia.NINGUNA -> Triple(ModoRepetir.UNA_VEZ, 0, 2)
        Recurrencia.DIARIA -> Triple(ModoRepetir.TODOS, DiasSemana.TODOS, 2)
        Recurrencia.MENSUAL -> Triple(ModoRepetir.MENSUAL, 0, 2)
        Recurrencia.SEMANAL -> Triple(ModoRepetir.ELEGIDOS, DiasSemana.bit(dia), 2)
        Recurrencia.DIAS -> {
            val mascara = a.diasMascara ?: DiasSemana.bit(dia)
            val cada = a.intervaloSemanas ?: 1
            val modo = when {
                cada > 1 -> ModoRepetir.PERSONALIZADA
                mascara == DiasSemana.LUNES_A_VIERNES -> ModoRepetir.LUN_VIE
                mascara == DiasSemana.FIN_DE_SEMANA -> ModoRepetir.FIN_SEMANA
                mascara == DiasSemana.TODOS -> ModoRepetir.TODOS
                else -> ModoRepetir.ELEGIDOS
            }
            Triple(modo, mascara, cada.coerceAtLeast(2))
        }
    }
}

@Composable
private fun OcurrenciaItem(o: Ocurrencia, onEditar: () -> Unit, onEliminar: () -> Unit) {
    val a = o.actividad
    val rec = Recurrencia.de(a.recurrencia)
    PanelJulio(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                val horas = o.horaFin?.let { "${Fechas.textoHora(o.horaInicio)} – ${Fechas.textoHora(it)}" }
                    ?: Fechas.textoHora(o.horaInicio)
                Text(horas, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(a.titulo, style = MaterialTheme.typography.titleMedium)
                if (a.descripcion.isNotBlank()) {
                    Text(
                        a.descripcion,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (rec != Recurrencia.NINGUNA) {
                    Text(
                        "Se repite: ${textoRepeticion(a)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                a.recordatorioMin?.let {
                    Text(
                        "Aviso: ${etiquetaAviso(it).lowercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            IconButton(onClick = onEditar) { Icon(Icons.Filled.Edit, contentDescription = "Editar actividad") }
            IconButton(onClick = onEliminar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar actividad") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun DialogoActividad(
    inicial: ActividadEntity?,
    diaPorDefecto: LocalDate,
    zona: ZoneId,
    soloEsta: LocalDate?,
    onGuardar: (ActividadEntity) -> Unit,
    onCancelar: () -> Unit,
) {
    val inicioZ = inicial?.let { Instant.ofEpochMilli(it.inicio).atZone(zona) }
    var titulo by remember { mutableStateOf(inicial?.titulo ?: "") }
    var descripcion by remember { mutableStateOf(inicial?.descripcion ?: "") }
    var fecha by remember { mutableStateOf(soloEsta ?: inicioZ?.toLocalDate() ?: diaPorDefecto) }
    var hora by remember {
        mutableStateOf<LocalTime?>(inicioZ?.toLocalTime()?.withSecond(0)?.withNano(0))
    }
    var horaFin by remember {
        mutableStateOf<LocalTime?>(
            inicial?.fin?.let { Instant.ofEpochMilli(it).atZone(zona).toLocalTime().withSecond(0).withNano(0) },
        )
    }
    val modoGuardado = remember { modoInicial(inicial, zona) }
    var modo by remember { mutableStateOf(modoGuardado.first) }
    var mascara by remember { mutableStateOf(modoGuardado.second) }
    var cadaSemanas by remember { mutableStateOf(modoGuardado.third) }
    var recordatorio by remember { mutableStateOf(inicial?.recordatorioMin) }
    var selectorFecha by remember { mutableStateOf(false) }
    var selectorHora by remember { mutableStateOf(false) }
    var selectorHoraFin by remember { mutableStateOf(false) }

    val h = hora
    val hf = horaFin
    val finInvalido = h != null && hf != null && !hf.isAfter(h)
    val mascaraEfectiva = when (modo) {
        ModoRepetir.TODOS -> DiasSemana.TODOS
        ModoRepetir.LUN_VIE -> DiasSemana.LUNES_A_VIERNES
        ModoRepetir.FIN_SEMANA -> DiasSemana.FIN_DE_SEMANA
        ModoRepetir.ELEGIDOS, ModoRepetir.PERSONALIZADA -> mascara
        else -> 0
    }
    val usaDias = modo == ModoRepetir.LUN_VIE || modo == ModoRepetir.FIN_SEMANA ||
        modo == ModoRepetir.ELEGIDOS || modo == ModoRepetir.PERSONALIZADA
    val faltanDias = (modo == ModoRepetir.ELEGIDOS || modo == ModoRepetir.PERSONALIZADA) && mascara == 0

    AlertDialog(
        onDismissRequest = onCancelar,
        title = {
            Text(
                when {
                    soloEsta != null -> "Editar solo el ${Fechas.textoLargo(soloEsta)}"
                    inicial == null -> "Nueva actividad"
                    else -> "Editar actividad"
                },
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it },
                    label = { Text("Título") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripción (opcional)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { selectorFecha = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        if (soloEsta == null && modo != ModoRepetir.UNA_VEZ) "Empieza el: ${Fechas.textoLargo(fecha)}"
                        else "Fecha: ${Fechas.textoLargo(fecha)}",
                    )
                }
                OutlinedButton(onClick = { selectorHora = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(h?.let { "Hora de inicio: ${Fechas.textoHora(it)}" } ?: "Elegir hora de inicio")
                }
                OutlinedButton(onClick = { selectorHoraFin = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(hf?.let { "Hora de fin: ${Fechas.textoHora(it)}" } ?: "Añadir hora de fin (opcional)")
                }
                if (hf != null) {
                    TextButton(onClick = { horaFin = null }) { Text("Quitar hora de fin") }
                }
                if (finInvalido) {
                    Text(
                        "La hora de fin debe ser posterior a la de inicio.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (h == null) {
                    Text(
                        "Elige la hora de inicio para poder guardar.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                if (soloEsta == null) {
                    Text("Repetir", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModoRepetir.entries.forEach { m ->
                            FilterChip(
                                selected = modo == m,
                                onClick = {
                                    modo = m
                                    if ((m == ModoRepetir.ELEGIDOS || m == ModoRepetir.PERSONALIZADA) && mascara == 0) {
                                        mascara = DiasSemana.bit(fecha.dayOfWeek)
                                    }
                                },
                                label = { Text(m.etiqueta) },
                            )
                        }
                    }
                    if (modo == ModoRepetir.ELEGIDOS || modo == ModoRepetir.PERSONALIZADA) {
                        Text("Días de la semana", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            (0..6).forEach { i ->
                                FilterChip(
                                    selected = (mascara and DiasSemana.bit(i)) != 0,
                                    onClick = { mascara = mascara xor DiasSemana.bit(i) },
                                    label = { Text(DiasSemana.corto(i)) },
                                )
                            }
                        }
                    }
                    if (modo == ModoRepetir.PERSONALIZADA) {
                        Text("Se repite cada", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(2, 3, 4).forEach { n ->
                                FilterChip(
                                    selected = cadaSemanas == n,
                                    onClick = { cadaSemanas = n },
                                    label = { Text("$n semanas") },
                                )
                            }
                        }
                    }
                    if (faltanDias) {
                        Text(
                            "Elige al menos un día de la semana.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    } else if (modo != ModoRepetir.UNA_VEZ) {
                        val resumen = when (modo) {
                            ModoRepetir.MENSUAL -> "cada mes"
                            ModoRepetir.PERSONALIZADA -> DiasSemana.describir(mascaraEfectiva, cadaSemanas)
                            else -> DiasSemana.describir(mascaraEfectiva)
                        }
                        Text("Se repetirá $resumen.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text("Aviso", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf<Int?>(null, 0, 5, 10, 15, 30, 60).forEach { opcion ->
                        FilterChip(
                            selected = recordatorio == opcion,
                            onClick = { recordatorio = opcion },
                            label = { Text(etiquetaAviso(opcion)) },
                        )
                    }
                }
                if (inicial != null && soloEsta == null && modo != ModoRepetir.UNA_VEZ) {
                    Text(
                        "Los cambios se aplican a todas las repeticiones.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = titulo.isNotBlank() && h != null && !finInvalido && !faltanDias,
                onClick = {
                    if (h != null) {
                        // En series por días, el primer día es el primero que de verdad cae en un día elegido.
                        val fechaEf = if (soloEsta == null && usaDias) DiasSemana.primerDia(fecha, mascaraEfectiva) else fecha
                        val inicioMs = LocalDateTime.of(fechaEf, h).atZone(zona).toInstant().toEpochMilli()
                        val finMs = hf?.let { LocalDateTime.of(fechaEf, it).atZone(zona).toInstant().toEpochMilli() }
                        val rec = when {
                            soloEsta != null || modo == ModoRepetir.UNA_VEZ -> Recurrencia.NINGUNA
                            modo == ModoRepetir.TODOS -> Recurrencia.DIARIA
                            modo == ModoRepetir.MENSUAL -> Recurrencia.MENSUAL
                            else -> Recurrencia.DIAS
                        }
                        val base = inicial ?: ActividadEntity(titulo = "", inicio = inicioMs)
                        onGuardar(
                            base.copy(
                                titulo = titulo.trim(),
                                descripcion = descripcion.trim(),
                                inicio = inicioMs,
                                fin = finMs,
                                recurrencia = rec.name,
                                diasMascara = if (rec == Recurrencia.DIAS) mascaraEfectiva else null,
                                intervaloSemanas = if (rec == Recurrencia.DIAS && modo == ModoRepetir.PERSONALIZADA) cadaSemanas else null,
                                recordatorioMin = recordatorio,
                            ),
                        )
                    }
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )

    if (selectorFecha) {
        SelectorFecha(
            inicial = fecha,
            onAceptar = { fecha = it; selectorFecha = false },
            onCancelar = { selectorFecha = false },
        )
    }
    if (selectorHora) {
        SelectorHora(
            titulo = "Hora de inicio",
            inicial = h ?: LocalTime.of(8, 0),
            onAceptar = { hora = it; selectorHora = false },
            onCancelar = { selectorHora = false },
        )
    }
    if (selectorHoraFin) {
        SelectorHora(
            titulo = "Hora de fin",
            inicial = hf ?: (h?.plusHours(1) ?: LocalTime.of(9, 0)),
            onAceptar = { horaFin = it; selectorHoraFin = false },
            onCancelar = { selectorHoraFin = false },
        )
    }
}
