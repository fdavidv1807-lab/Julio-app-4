package com.julio.asistente.estudio

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class AjustesEstudio(val avisoActivo: Boolean = true, /** minutos desde medianoche */ val avisoMin: Int = 19 * 60)

/** Una sesión de estudio terminada a la que falta ponerle nota («¿cómo te fue?»). */
data class PendienteNota(val examenId: Long, val sesionId: Int)

/**
 * Guarda los exámenes y sus sesiones en el teléfono (SharedPreferences, JSON).
 * Cada operación se escribe y se vuelve a leer: solo devuelve «bien» si de verdad quedó guardado.
 */
object EstudioRepo {
    private const val ARCHIVO = "julio_estudio"
    const val MINUTOS_POR_DEFECTO = 45

    private val _examenes = MutableStateFlow<List<Examen>>(emptyList())
    val examenes: StateFlow<List<Examen>> = _examenes.asStateFlow()

    private val _ajustes = MutableStateFlow(AjustesEstudio())
    val ajustes: StateFlow<AjustesEstudio> = _ajustes.asStateFlow()

    private val _pendienteNota = MutableStateFlow<PendienteNota?>(null)
    val pendienteNota: StateFlow<PendienteNota?> = _pendienteNota.asStateFlow()

    private var cargado = false

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    @Synchronized
    fun cargar(c: Context) {
        if (cargado) return
        val p = sp(c)
        _examenes.value = leer(p.getString("examenes", null))
        _ajustes.value = AjustesEstudio(p.getBoolean("avisoActivo", true), p.getInt("avisoMin", 19 * 60))
        _pendienteNota.value = leerPendiente(p.getLong("pendExamen", -1L), p.getInt("pendSesion", -1))
        cargado = true
    }

    // ---------- JSON ----------

    private fun aJson(lista: List<Examen>): String {
        val arr = JSONArray()
        for (e in lista) {
            val o = JSONObject()
            o.put("id", e.id).put("materia", e.materia).put("fecha", e.fecha)
                .put("minutos", e.minutos).put("creado", e.creadoEn)
                .put("temas", JSONArray(e.temas))
            val ses = JSONArray()
            for (s in e.sesiones) {
                ses.put(
                    JSONObject().put("id", s.id).put("fecha", s.fecha).put("titulo", s.titulo)
                        .put("temas", JSONArray(s.temas)).put("minutos", s.minutos)
                        .put("hecha", s.hecha).put("hechaEn", s.hechaEn).put("nota", s.nota)
                        .put("refuerzo", s.refuerzo),
                )
            }
            o.put("sesiones", ses)
            arr.put(o)
        }
        return arr.toString()
    }

    private fun lista(a: JSONArray?): List<String> =
        if (a == null) emptyList() else List(a.length()) { a.getString(it) }

    private fun leer(json: String?): List<Examen> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val ses = o.optJSONArray("sesiones")
                Examen(
                    id = o.getLong("id"), materia = o.getString("materia"), fecha = o.getLong("fecha"),
                    temas = lista(o.optJSONArray("temas")), minutos = o.optInt("minutos", MINUTOS_POR_DEFECTO),
                    sesiones = if (ses == null) emptyList() else List(ses.length()) { j ->
                        val s = ses.getJSONObject(j)
                        SesionEstudio(
                            id = s.getInt("id"), fecha = s.getLong("fecha"), titulo = s.getString("titulo"),
                            temas = lista(s.optJSONArray("temas")), minutos = s.getInt("minutos"),
                            hecha = s.optBoolean("hecha", false), hechaEn = s.optLong("hechaEn", 0L),
                            nota = s.optInt("nota", 0), refuerzo = s.optBoolean("refuerzo", false),
                        )
                    },
                    creadoEn = o.optLong("creado", 0L),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun leerPendiente(examen: Long, sesion: Int): PendienteNota? =
        if (examen >= 0 && sesion >= 0) PendienteNota(examen, sesion) else null

    /** Escribe y vuelve a leer del teléfono; solo entonces actualiza lo que ve la pantalla. */
    @Synchronized
    private fun guardar(c: Context, nueva: List<Examen>): Boolean {
        val json = aJson(nueva)
        val ok = sp(c).edit().putString("examenes", json).commit()
        if (!ok) return false
        val releida = leer(sp(c).getString("examenes", null))
        if (releida != nueva) return false
        _examenes.value = releida
        return true
    }

    // ---------- operaciones ----------

    /** Crea el examen y reparte las sesiones. Devuelve null si no hay días para estudiar o no se pudo guardar. */
    @Synchronized
    fun crear(c: Context, materia: String, fecha: LocalDate, temas: List<String>, minutos: Int, hoy: LocalDate = LocalDate.now()): Examen? {
        cargar(c)
        val sesiones = Planificador.generar(materia, temas, fecha, hoy, minutos)
        if (sesiones.isEmpty()) return null
        val examen = Examen(
            id = System.currentTimeMillis(), materia = materia.trim(), fecha = fecha.toEpochDay(),
            temas = temas.map { it.trim() }.filter { it.isNotEmpty() }, minutos = minutos,
            sesiones = sesiones, creadoEn = System.currentTimeMillis(),
        )
        return if (guardar(c, _examenes.value + examen)) examen else null
    }

    /**
     * Cambia materia, fecha, temas o tiempo por bloque de un examen. Las sesiones que ya hiciste se conservan
     * tal cual; las pendientes se vuelven a repartir desde hoy hasta el día antes del nuevo examen.
     */
    @Synchronized
    fun editar(
        c: Context, id: Long, materia: String, fecha: LocalDate, temas: List<String>, minutos: Int,
        hoy: LocalDate = LocalDate.now(),
    ): Examen? {
        cargar(c)
        val actual = _examenes.value.firstOrNull { it.id == id } ?: return null
        val nuevas = Planificador.generar(materia, temas, fecha, hoy, minutos)
        if (nuevas.isEmpty()) return null
        // Si había una sesión de enfoque marcada para este examen, sus números ya no valen.
        val p = sp(c)
        if (p.getLong("curExamen", -1L) == id) limpiarEnCurso(c)
        val conservadas = actual.sesiones.filter { it.hecha }
        var siguiente = (conservadas.maxOfOrNull { it.id } ?: 0) + 1
        val renumeradas = nuevas.map { it.copy(id = siguiente++) }
        val examen = actual.copy(
            materia = materia.trim(), fecha = fecha.toEpochDay(),
            temas = temas.map { it.trim() }.filter { it.isNotEmpty() }, minutos = minutos,
            sesiones = (conservadas + renumeradas).sortedBy { it.fecha },
        )
        return if (guardar(c, _examenes.value.map { if (it.id == id) examen else it })) examen else null
    }

    /** Los exámenes como texto JSON (para la copia de seguridad). */
    @Synchronized
    fun exportarJson(c: Context): String {
        cargar(c)
        return aJson(_examenes.value)
    }

    /** Reemplaza todos los exámenes por los de una copia de seguridad. Devuelve false si el texto no es válido. */
    @Synchronized
    fun reemplazarDesdeJson(c: Context, json: String): Boolean {
        cargar(c)
        val lista = try {
            JSONArray(json)
            leer(json)
        } catch (e: Exception) {
            return false
        }
        limpiarEnCurso(c)
        limpiarPendiente(c)
        return guardar(c, lista)
    }

    @Synchronized
    fun eliminar(c: Context, id: Long): Boolean {
        cargar(c)
        if (_pendienteNota.value?.examenId == id) limpiarPendiente(c)
        val nueva = _examenes.value.filter { it.id != id }
        return guardar(c, nueva) && nueva.none { it.id == id }
    }

    private fun actualizarSesion(c: Context, examenId: Long, sesionId: Int, cambio: (SesionEstudio) -> SesionEstudio): Boolean {
        cargar(c)
        val ex = _examenes.value.firstOrNull { it.id == examenId } ?: return false
        if (ex.sesiones.none { it.id == sesionId }) return false
        val nuevo = ex.copy(sesiones = ex.sesiones.map { if (it.id == sesionId) cambio(it) else it })
        return guardar(c, _examenes.value.map { if (it.id == examenId) nuevo else it })
    }

    @Synchronized
    fun marcarHecha(c: Context, examenId: Long, sesionId: Int, hoy: LocalDate = LocalDate.now()): Boolean =
        actualizarSesion(c, examenId, sesionId) { it.copy(hecha = true, hechaEn = hoy.toEpochDay()) } &&
            _examenes.value.firstOrNull { it.id == examenId }?.sesiones?.firstOrNull { it.id == sesionId }?.hecha == true

    @Synchronized
    fun moverAHoy(c: Context, examenId: Long, sesionId: Int, hoy: LocalDate = LocalDate.now()): Boolean =
        actualizarSesion(c, examenId, sesionId) { it.copy(fecha = hoy.toEpochDay()) }

    /**
     * Guarda cómo te fue. Con «mal» o «regular» agrega una sesión de refuerzo al día siguiente si el examen
     * todavía no llega. Devuelve un texto que explica lo que se hizo, o null si no se pudo guardar.
     */
    @Synchronized
    fun calificar(c: Context, examenId: Long, sesionId: Int, nota: Int, hoy: LocalDate = LocalDate.now()): String? {
        cargar(c)
        val ex = _examenes.value.firstOrNull { it.id == examenId } ?: return null
        val ses = ex.sesiones.firstOrNull { it.id == sesionId } ?: return null
        var sesiones = ex.sesiones.map { if (it.id == sesionId) it.copy(nota = nota) else it }
        var extra = ""
        if (nota in 1..2) {
            val manana = hoy.plusDays(1).toEpochDay()
            if (manana < ex.fecha) {
                val nuevoId = (sesiones.maxOfOrNull { it.id } ?: 0) + 1
                sesiones = sesiones + SesionEstudio(
                    id = nuevoId, fecha = manana, titulo = "Refuerzo: " + ses.temas.joinToString(", "),
                    temas = ses.temas, minutos = ses.minutos, refuerzo = true,
                )
                extra = " Agregué una sesión de refuerzo para mañana."
            }
        }
        val ok = guardar(c, _examenes.value.map { if (it.id == examenId) ex.copy(sesiones = sesiones.sortedBy { s -> s.fecha }) else it })
        if (!ok) return null
        limpiarPendiente(c)
        return when (nota) {
            3 -> "¡Muy bien! Sigue así."
            2 -> "Anotado: te fue regular.$extra"
            1 -> "Anotado: te fue mal; no pasa nada.$extra"
            else -> "Listo."
        }
    }

    fun diasHechos(): Set<Long> = Agenda.diasHechos(_examenes.value)

    // ---------- ajustes del aviso diario ----------

    @Synchronized
    fun guardarAviso(c: Context, activo: Boolean, minutos: Int) {
        cargar(c)
        _ajustes.value = AjustesEstudio(activo, minutos)
        sp(c).edit().putBoolean("avisoActivo", activo).putInt("avisoMin", minutos).commit()
        EstudioAviso.programar(c)
    }

    // ---------- enlace con el modo enfoque ----------

    /** La sesión de enfoque en curso corresponde a esta sesión de estudio. */
    @Synchronized
    fun marcarEnCurso(c: Context, examenId: Long, sesionId: Int) {
        cargar(c)
        sp(c).edit().putLong("curExamen", examenId).putInt("curSesion", sesionId).commit()
    }

    /** Lo llama EnfoqueControl al empezar o cancelar una sesión: ya no hay sesión de estudio en curso. */
    @Synchronized
    fun limpiarEnCurso(c: Context) {
        sp(c).edit().remove("curExamen").remove("curSesion").commit()
    }

    /** Lo llama EnfoqueControl cuando un ENFOQUE llega a su fin: se da por hecha y se pide la nota. */
    @Synchronized
    fun enfoqueTerminado(c: Context, hoy: LocalDate = LocalDate.now()) {
        cargar(c)
        val p = sp(c)
        val examen = p.getLong("curExamen", -1L)
        val sesion = p.getInt("curSesion", -1)
        limpiarEnCurso(c)
        if (examen < 0 || sesion < 0) return
        if (marcarHecha(c, examen, sesion, hoy)) {
            p.edit().putLong("pendExamen", examen).putInt("pendSesion", sesion).commit()
            _pendienteNota.value = PendienteNota(examen, sesion)
        }
    }

    @Synchronized
    fun limpiarPendiente(c: Context) {
        sp(c).edit().remove("pendExamen").remove("pendSesion").commit()
        _pendienteNota.value = null
    }
}
