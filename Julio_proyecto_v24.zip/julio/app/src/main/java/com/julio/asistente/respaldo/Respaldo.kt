package com.julio.asistente.respaldo

import android.content.Context
import androidx.room.withTransaction
import com.julio.asistente.JulioApp
import com.julio.asistente.alarmas.AlarmaProgramador
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.data.local.MetaEntity
import com.julio.asistente.data.local.TareaEntity
import com.julio.asistente.estudio.EstudioAviso
import com.julio.asistente.estudio.EstudioRepo
import com.julio.asistente.recordatorios.RecordatorioProgramador
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Copia de seguridad: todos tus datos en un solo archivo de texto (JSON) que tú guardas donde quieras.
 * Restaurar REEMPLAZA los datos actuales; antes se guarda una copia automática de lo que había.
 */
object Respaldo {
    const val VERSION = 1

    data class Resumen(val tareas: Int, val actividades: Int, val alarmas: Int, val metas: Int, val examenes: Int) {
        fun texto(): String =
            "$tareas tareas, $actividades actividades del horario, $alarmas alarmas, $metas metas y $examenes exámenes"
    }

    private fun JSONObject.poner(k: String, v: Any?): JSONObject = if (v != null) put(k, v) else this
    private fun JSONObject.largo(k: String): Long? = if (has(k) && !isNull(k)) getLong(k) else null
    private fun JSONObject.entero(k: String): Int? = if (has(k) && !isNull(k)) getInt(k) else null
    private fun JSONObject.texto(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null

    private fun db(c: Context) = (c.applicationContext as JulioApp).database

    suspend fun exportar(c: Context): String {
        val db = db(c)
        val o = JSONObject()
        o.put("app", "julio").put("version", VERSION).put("creado", System.currentTimeMillis())
        o.put("tareas", JSONArray().also { a ->
            db.tareaDao().observarTodas().first().forEach { t ->
                a.put(
                    JSONObject().put("id", t.id).put("titulo", t.titulo).put("descripcion", t.descripcion)
                        .put("prioridad", t.prioridad).put("completada", t.completada).put("creadaEn", t.creadaEn)
                        .poner("fechaLimite", t.fechaLimite).poner("recordatorioMinutoDia", t.recordatorioMinutoDia),
                )
            }
        })
        o.put("actividades", JSONArray().also { a ->
            db.actividadDao().observarTodas().first().forEach { x ->
                a.put(
                    JSONObject().put("id", x.id).put("titulo", x.titulo).put("descripcion", x.descripcion)
                        .put("inicio", x.inicio).put("recurrencia", x.recurrencia).put("creadaEn", x.creadaEn)
                        .poner("fin", x.fin).poner("recordatorioMin", x.recordatorioMin)
                        .poner("diasMascara", x.diasMascara).poner("intervaloSemanas", x.intervaloSemanas)
                        .poner("excluidas", x.excluidas),
                )
            }
        })
        o.put("alarmas", JSONArray().also { a ->
            db.alarmaDao().observarTodas().first().forEach { x ->
                a.put(
                    JSONObject().put("id", x.id).put("nombre", x.nombre).put("hora", x.hora).put("minuto", x.minuto)
                        .put("diasMascara", x.diasMascara).put("activa", x.activa).put("creadaEn", x.creadaEn)
                        .poner("fechaEpochDay", x.fechaEpochDay).poner("sonidoUri", x.sonidoUri),
                )
            }
        })
        o.put("metas", JSONArray().also { a ->
            db.metaDao().observarTodas().first().forEach { m ->
                a.put(
                    JSONObject().put("id", m.id).put("titulo", m.titulo).put("descripcion", m.descripcion)
                        .put("progreso", m.progreso).put("completada", m.completada).put("creadaEn", m.creadaEn)
                        .poner("fechaObjetivo", m.fechaObjetivo),
                )
            }
        })
        o.put("estudio", JSONArray(EstudioRepo.exportarJson(c)))
        return o.toString()
    }

    /** Comprueba que el texto es una copia de Julio y cuenta lo que trae. null = no es una copia válida. */
    fun analizar(json: String): Resumen? = try {
        val o = JSONObject(json)
        if (o.optString("app") != "julio" || o.optInt("version", 0) !in 1..VERSION) {
            null
        } else {
            Resumen(
                o.getJSONArray("tareas").length(), o.getJSONArray("actividades").length(),
                o.getJSONArray("alarmas").length(), o.getJSONArray("metas").length(),
                o.getJSONArray("estudio").length(),
            )
        }
    } catch (e: Exception) {
        null
    }

    private suspend fun contar(c: Context): Resumen {
        val db = db(c)
        EstudioRepo.cargar(c)
        return Resumen(
            db.tareaDao().observarTodas().first().size, db.actividadDao().observarTodas().first().size,
            db.alarmaDao().observarTodas().first().size, db.metaDao().observarTodas().first().size,
            EstudioRepo.examenes.value.size,
        )
    }

    private suspend fun rearmarAvisos(c: Context) {
        val db = db(c)
        db.alarmaDao().activas().forEach { AlarmaProgramador.programar(c, it) }
        RecordatorioProgramador.reprogramarTodos(c)
        EstudioAviso.programar(c)
    }

    /**
     * Reemplaza todos los datos por los de la copia. Primero lee y valida TODO la copia (si algo está mal, no toca nada),
     * guarda una copia automática de lo actual (`respaldo_previo.json`) y hace el cambio en una sola transacción.
     * Devuelve lo que quedó guardado, o null si no se pudo comprobar.
     */
    private class Datos(
        val tareas: List<TareaEntity>, val actividades: List<ActividadEntity>,
        val alarmas: List<AlarmaEntity>, val metas: List<MetaEntity>, val estudio: String,
    )

    /** Lee TODA la copia antes de tocar nada; si algo no cuadra, devuelve null. */
    private fun leer(json: String): Datos? = try {
            val o = JSONObject(json)
            val tareas = o.getJSONArray("tareas").let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    TareaEntity(
                        id = x.getLong("id"), titulo = x.getString("titulo"), descripcion = x.optString("descripcion", ""),
                        prioridad = x.optInt("prioridad", 1), fechaLimite = x.largo("fechaLimite"),
                        completada = x.optBoolean("completada", false), creadaEn = x.optLong("creadaEn", System.currentTimeMillis()),
                        recordatorioMinutoDia = x.entero("recordatorioMinutoDia"),
                    )
                }
            }
            val actividades = o.getJSONArray("actividades").let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    ActividadEntity(
                        id = x.getLong("id"), titulo = x.getString("titulo"), descripcion = x.optString("descripcion", ""),
                        inicio = x.getLong("inicio"), fin = x.largo("fin"), recurrencia = x.optString("recurrencia", "NINGUNA"),
                        creadaEn = x.optLong("creadaEn", System.currentTimeMillis()), recordatorioMin = x.entero("recordatorioMin"),
                        diasMascara = x.entero("diasMascara"), intervaloSemanas = x.entero("intervaloSemanas"),
                        excluidas = x.texto("excluidas"),
                    )
                }
            }
            val alarmas = o.getJSONArray("alarmas").let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    AlarmaEntity(
                        id = x.getLong("id"), nombre = x.optString("nombre", ""), hora = x.getInt("hora"), minuto = x.getInt("minuto"),
                        fechaEpochDay = x.largo("fechaEpochDay"), diasMascara = x.optInt("diasMascara", 0),
                        activa = x.optBoolean("activa", true), sonidoUri = x.texto("sonidoUri"),
                        creadaEn = x.optLong("creadaEn", System.currentTimeMillis()),
                    )
                }
            }
            val metas = o.getJSONArray("metas").let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    MetaEntity(
                        id = x.getLong("id"), titulo = x.getString("titulo"), descripcion = x.optString("descripcion", ""),
                        progreso = x.optInt("progreso", 0), completada = x.optBoolean("completada", false),
                        fechaObjetivo = x.largo("fechaObjetivo"), creadaEn = x.optLong("creadaEn", System.currentTimeMillis()),
                    )
                }
            }
            Datos(tareas, actividades, alarmas, metas, o.getJSONArray("estudio").toString())
    } catch (e: Exception) {
        null
    }

    suspend fun restaurar(c: Context, json: String): Resumen? {
        val esperado = analizar(json) ?: return null
        val db = db(c)

        val d = leer(json) ?: return null

        // Copia automática de lo que hay ahora, por si algo no sale como esperas.
        try {
            File(c.filesDir, "respaldo_previo.json").writeText(exportar(c), Charsets.UTF_8)
        } catch (e: Exception) {
            return null
        }

        // Los avisos programados de lo actual dejan de valer.
        db.alarmaDao().observarTodas().first().forEach { AlarmaProgramador.cancelar(c, it.id) }
        db.tareaDao().observarTodas().first().forEach { RecordatorioProgramador.cancelar(c, RecordatorioProgramador.TIPO_TAREA, it.id) }
        db.actividadDao().observarTodas().first().forEach { RecordatorioProgramador.cancelar(c, RecordatorioProgramador.TIPO_ACTIVIDAD, it.id) }

        try {
            db.withTransaction {
                db.tareaDao().borrarTodo(); db.actividadDao().borrarTodo(); db.alarmaDao().borrarTodo(); db.metaDao().borrarTodo()
                d.tareas.forEach { db.tareaDao().insertar(it) }
                d.actividades.forEach { db.actividadDao().insertar(it) }
                d.alarmas.forEach { db.alarmaDao().insertar(it) }
                d.metas.forEach { db.metaDao().insertar(it) }
            }
        } catch (e: Exception) {
            rearmarAvisos(c)   // la transacción se deshizo: los datos actuales siguen ahí
            return null
        }
        val estudioOk = EstudioRepo.reemplazarDesdeJson(c, d.estudio)
        rearmarAvisos(c)
        val despues = contar(c)
        return if (estudioOk && despues == esperado) despues else null
    }
}
