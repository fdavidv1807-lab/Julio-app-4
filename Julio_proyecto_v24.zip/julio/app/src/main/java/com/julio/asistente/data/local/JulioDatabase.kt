package com.julio.asistente.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [TareaEntity::class, ActividadEntity::class, AlarmaEntity::class, MetaEntity::class],
    version = 3,
    exportSchema = false,
)
abstract class JulioDatabase : RoomDatabase() {
    abstract fun tareaDao(): TareaDao
    abstract fun actividadDao(): ActividadDao
    abstract fun alarmaDao(): AlarmaDao
    abstract fun metaDao(): MetaDao

    companion object {
        /** v1 -> v2: recordatorios. Solo añade columnas anulables; no toca los datos existentes. */
        val MIGRACION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE actividades ADD COLUMN recordatorioMin INTEGER")
                db.execSQL("ALTER TABLE tareas ADD COLUMN recordatorioMinutoDia INTEGER")
            }
        }

        /**
         * v2 -> v3: horarios de varios días. Solo añade columnas anulables a «actividades»;
         * las actividades existentes quedan exactamente igual (se repiten como antes).
         */
        val MIGRACION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE actividades ADD COLUMN diasMascara INTEGER")
                db.execSQL("ALTER TABLE actividades ADD COLUMN intervaloSemanas INTEGER")
                db.execSQL("ALTER TABLE actividades ADD COLUMN excluidas TEXT")
            }
        }

        @Volatile private var instancia: JulioDatabase? = null

        fun get(context: Context): JulioDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    JulioDatabase::class.java,
                    "julio.db",
                ).addMigrations(MIGRACION_1_2, MIGRACION_2_3).build().also { instancia = it }
            }
    }
}
