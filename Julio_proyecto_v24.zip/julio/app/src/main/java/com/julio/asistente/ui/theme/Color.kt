package com.julio.asistente.ui.theme

import androidx.compose.ui.graphics.Color

// Identidad futurista equilibrada: negro azulado y azul marino profundo, con azul eléctrico y cian como luz.

val NegroAzulado = Color(0xFF04070F)
val AzulMarino = Color(0xFF071226)
val CianElectrico = Color(0xFF45D4FF)
val AzulElectrico = Color(0xFF2F7BFF)
val AzulHielo = Color(0xFF9FD8FF)
val TextoPrincipal = Color(0xFFE8F3FC)
val TextoSecundario = Color(0xFFB4CBE0)

// Tema claro (opcional, desde Configuración)
val ClaFondo = Color(0xFFF4F7FC)
val ClaSuperficie = Color(0xFFFFFFFF)
val ClaTexto = Color(0xFF101828)
val ClaTextoSecundario = Color(0xFF47566B)
val ClaAcento = Color(0xFF1F5FD6)
