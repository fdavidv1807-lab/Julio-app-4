package com.julio.asistente.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.julio.asistente.R
import com.julio.asistente.ui.components.BarraSuperior
import com.julio.asistente.ui.components.FondoHud
import com.julio.asistente.ui.navigation.Destino
import com.julio.asistente.ui.screens.AlarmasScreen
import com.julio.asistente.ui.screens.ConfiguracionPanel
import com.julio.asistente.ui.screens.EnfoqueScreen
import com.julio.asistente.ui.screens.EstudioScreen
import com.julio.asistente.ui.screens.HorarioScreen
import com.julio.asistente.ui.screens.TareasScreen
import com.julio.asistente.ui.screens.VozScreen
import com.julio.asistente.ui.theme.AzulElectrico
import com.julio.asistente.ui.theme.CianElectrico
import com.julio.asistente.voz.VozViewModel
import kotlinx.coroutines.launch

/**
 * Distribución: panel izquierdo (secciones), centro (la pantalla actual) y panel derecho (configuración).
 * En teléfono los dos paneles se abren desde la barra superior; en pantallas anchas (tableta, plegable) quedan fijos.
 * Las rutas y las pantallas son las mismas de siempre: aquí solo cambia cómo se presentan.
 */
@Composable
fun JulioRoot() {
    val nav = rememberNavController()
    // Un solo VozViewModel para el centro y el panel de configuración (así hay un solo motor de voz).
    val vozVm: VozViewModel = viewModel()
    val entrada by nav.currentBackStackEntryAsState()
    val rutaActual = entrada?.destination?.route
    val tituloActual = Destino.entries.firstOrNull { it.ruta == rutaActual }?.let { if (it == Destino.VOZ) "Julio" else it.titulo } ?: "Julio"

    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    var ajustesAbiertos by rememberSaveable { mutableStateOf(false) }

    fun ir(d: Destino) {
        nav.navigate(d.ruta) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun probarEjemplo(texto: String) {
        ir(Destino.VOZ)
        ajustesAbiertos = false
        vozVm.enviarTexto(texto)
    }

    BackHandler(enabled = ajustesAbiertos) { ajustesAbiertos = false }

    FondoHud {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val ancha = maxWidth >= 840.dp
            if (ancha) {
                Row(Modifier.fillMaxSize()) {
                    Column(Modifier.width(248.dp).fillMaxHeight().statusBarsPadding().navigationBarsPadding()) {
                        ContenidoNavegacion(rutaActual) { ir(it) }
                    }
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        BarraSuperior(tituloActual, alMenu = null, alAjustes = null)
                        Contenido(nav, vozVm, Modifier.weight(1f).navigationBarsPadding())
                    }
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    ConfiguracionPanel(
                        vm = vozVm,
                        alCerrar = null,
                        alProbarEjemplo = { probarEjemplo(it) },
                        modifier = Modifier.width(360.dp).fillMaxHeight().statusBarsPadding().navigationBarsPadding(),
                    )
                }
            } else {
                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f)) {
                            ContenidoNavegacion(rutaActual) { destino ->
                                scope.launch { drawerState.close() }
                                ir(destino)
                            }
                        }
                    },
                ) {
                    Column(Modifier.fillMaxSize()) {
                        BarraSuperior(
                            tituloActual,
                            alMenu = { scope.launch { drawerState.open() } },
                            alAjustes = { ajustesAbiertos = true },
                        )
                        Contenido(nav, vozVm, Modifier.weight(1f).navigationBarsPadding())
                    }
                }

                // Panel derecho (configuración): se desliza desde el borde derecho sobre un fondo atenuado.
                AnimatedVisibility(visible = ajustesAbiertos, enter = fadeIn(), exit = fadeOut()) {
                    Spacer(
                        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f))
                            .pointerInput(Unit) { detectTapGestures { ajustesAbiertos = false } },
                    )
                }
                AnimatedVisibility(
                    visible = ajustesAbiertos,
                    modifier = Modifier.align(Alignment.CenterEnd),
                    enter = slideInHorizontally { it },
                    exit = slideOutHorizontally { it },
                ) {
                    Surface(
                        modifier = Modifier.fillMaxHeight().fillMaxWidth(0.9f).widthIn(max = 400.dp),
                        shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
                        tonalElevation = 1.dp,
                        shadowElevation = 16.dp,
                        border = BorderStroke(
                            1.dp,
                            Brush.verticalGradient(listOf(CianElectrico.copy(alpha = 0.55f), AzulElectrico.copy(alpha = 0.15f))),
                        ),
                    ) {
                        ConfiguracionPanel(
                            vm = vozVm,
                            alCerrar = { ajustesAbiertos = false },
                            alProbarEjemplo = { probarEjemplo(it) },
                            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Contenido(nav: NavHostController, vozVm: VozViewModel, modifier: Modifier) {
    NavHost(navController = nav, startDestination = Destino.VOZ.ruta, modifier = modifier) {
        composable(Destino.VOZ.ruta) { VozScreen(vozVm) }
        composable(Destino.HORARIO.ruta) { HorarioScreen() }
        composable(Destino.TAREAS.ruta) { TareasScreen() }
        composable(Destino.ESTUDIO.ruta) { EstudioScreen() }
        composable(Destino.ALARMAS.ruta) { AlarmasScreen() }
        composable(Destino.ENFOQUE.ruta) { EnfoqueScreen() }
    }
}

/** Panel izquierdo: las secciones de la app. */
@Composable
private fun ContenidoNavegacion(rutaActual: String?, alElegir: (Destino) -> Unit) {
    Column(Modifier.padding(horizontal = 12.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.julio_orbe),
                contentDescription = null,
                modifier = Modifier
                    .size(40.dp)
                    .border(1.dp, CianElectrico.copy(alpha = 0.7f), CircleShape)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
            )
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Julio", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Asistente personal",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.size(8.dp))
        Destino.entries.forEach { d ->
            val elegido = rutaActual == d.ruta
            NavigationDrawerItem(
                label = { Text(d.titulo) },
                icon = { Icon(d.icono, contentDescription = null) },
                selected = elegido,
                onClick = { alElegir(d) },
                modifier = if (elegido) {
                    Modifier.border(
                        1.dp,
                        Brush.horizontalGradient(listOf(CianElectrico.copy(alpha = 0.7f), AzulElectrico.copy(alpha = 0.2f))),
                        CircleShape,
                    )
                } else Modifier,
                colors = NavigationDrawerItemDefaults.colors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    unselectedContainerColor = Color.Transparent,
                ),
            )
        }
    }
}
