package com.julio.asistente

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.julio.asistente.ui.JulioRoot
import com.julio.asistente.ui.theme.Apariencia
import com.julio.asistente.ui.theme.JulioTheme
import com.julio.asistente.ui.theme.esOscuro

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Apariencia.cargar(applicationContext)
        setContent {
            val modo by Apariencia.modo.collectAsState()
            val oscuro = esOscuro(modo)
            // Iconos de la barra de estado y de navegación claros u oscuros según el tema.
            DisposableEffect(oscuro) {
                val estilo = if (oscuro) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = estilo, navigationBarStyle = estilo)
                onDispose { }
            }
            JulioTheme(modo) {
                JulioRoot()
            }
        }
    }
}
