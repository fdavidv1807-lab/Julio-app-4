package com.julio.asistente.bloqueo

import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.enfoque.Fase

/**
 * Mientras dura un enfoque, detecta qué app está en primer plano (Acceso de uso) y, si es una
 * de las elegidas, la cubre con una pantalla de bloqueo (Mostrar sobre otras apps).
 * No lee el contenido de ninguna app ni envía información a ningún sitio.
 */
class BloqueoService : Service() {

    companion object {
        private const val ID_NOTIFICACION = 6001
        private const val EVENTO_PRIMER_PLANO = 1 // = ACTIVITY_RESUMED = MOVE_TO_FOREGROUND
        private const val INTERVALO_MS = 600L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var iniciado = false
    private var detenido = false
    private var desde = 0L
    private var ultimoPaquete: String? = null
    private var protegidas: Set<String> = emptySet()

    private var overlay: View? = null
    private var textoTiempo: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (detenido) return
            comprobar()
            if (!detenido) handler.postDelayed(this, INTERVALO_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        primerPlano()
        if (!iniciado) {
            iniciado = true
            protegidas = BloqueoControl.protegidas(this)
            // Primera lectura con una hora hacia atrás para saber qué app está abierta ya.
            desde = System.currentTimeMillis() - 3_600_000L
            handler.post(tick)
        }
        return START_NOT_STICKY
    }

    private fun primerPlano() {
        val abrir = PendingIntent.getActivity(
            this, 50, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, Canales.ENFOQUE_PROGRESO)
            .setSmallIcon(R.drawable.ic_enfoque)
            .setContentTitle("Bloqueo de apps activo")
            .setContentText("Durante tu enfoque se bloquean las apps que elegiste.")
            .setOngoing(true)
            .setContentIntent(abrir)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID_NOTIFICACION, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID_NOTIFICACION, n)
        }
    }

    private fun comprobar() {
        val s = EnfoqueControl.sesion.value
        val enfoqueEnMarcha = s.estado == EstadoSesion.CORRIENDO && s.fase == Fase.ENFOQUE
        if (!BloqueoConfig.activo.value || !enfoqueEnMarcha || !BloqueoControl.permisos(this).ok) {
            detenerTodo()
            return
        }
        leerPrimerPlano()
        val actual = ultimoPaquete
        val bloqueada = actual != null &&
            actual in BloqueoConfig.paquetes.value &&
            actual !in protegidas
        if (bloqueada) {
            mostrarOverlay()
            val restante = (s.finMs - System.currentTimeMillis()).coerceAtLeast(0L)
            textoTiempo?.text = "Quedan ${formato(restante)}"
        } else {
            ocultarOverlay()
        }
    }

    private fun leerPrimerPlano() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ahora = System.currentTimeMillis()
        try {
            val eventos = usm.queryEvents(desde, ahora)
            val e = UsageEvents.Event()
            while (eventos.hasNextEvent()) {
                eventos.getNextEvent(e)
                if (e.eventType == EVENTO_PRIMER_PLANO) ultimoPaquete = e.packageName
            }
        } catch (ex: SecurityException) {
            // Se revocó el acceso de uso: la próxima comprobación detendrá el servicio.
        }
        desde = ahora - 2_000L
    }

    private fun formato(ms: Long): String {
        val total = (ms + 999) / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun texto(t: String, tamano: Float, negrita: Boolean = false) = TextView(this).apply {
        text = t
        textSize = tamano
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        if (negrita) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun mostrarOverlay() {
        if (overlay != null) return
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(245, 11, 22, 32))
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        raiz.addView(texto("Es momento de enfocarte", 26f, true))
        raiz.addView(texto("Esta app está bloqueada durante tu sesión de enfoque.", 16f))
        val tiempo = texto("", 40f, true)
        raiz.addView(tiempo)
        textoTiempo = tiempo

        val ancho = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dp(16) }

        raiz.addView(
            Button(this).apply {
                text = "Ir al inicio"
                setOnClickListener { irAInicio() }
            },
            ancho,
        )

        var confirmando = false
        raiz.addView(
            Button(this).apply {
                text = "Finalizar sesión de enfoque"
                setOnClickListener {
                    if (!confirmando) {
                        confirmando = true
                        text = "Toca otra vez para finalizar"
                    } else {
                        // Salida segura: termina la sesión y con ella el bloqueo.
                        ocultarOverlay()
                        EnfoqueControl.finalizar(applicationContext)
                    }
                }
            },
            ancho,
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(raiz, params)
            overlay = raiz
        } catch (e: Exception) {
            BloqueoControl.ultimoError = "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun ocultarOverlay() {
        val v = overlay ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
            // Ya no estaba.
        }
        overlay = null
        textoTiempo = null
    }

    private fun irAInicio() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    private fun detenerTodo() {
        detenido = true
        handler.removeCallbacksAndMessages(null)
        ocultarOverlay()
        stopSelf()
    }

    override fun onDestroy() {
        detenido = true
        handler.removeCallbacksAndMessages(null)
        ocultarOverlay()
        super.onDestroy()
    }
}
