package com.julio.asistente.voz

import java.io.File
import kotlin.math.log10
import kotlin.math.sqrt

/** Pequeñas funciones puras del reconocimiento sin internet (se prueban sin Android). */
object ReconocimientoUtil {
    private val CAMPO = Regex("\"(text|partial)\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")

    /** Saca el texto de la respuesta de Vosk: {"text": "hola"} o {"partial": "ho"}. Vacío si no hay. */
    fun extraer(json: String, clave: String): String {
        for (m in CAMPO.findAll(json)) {
            if (m.groupValues[1] == clave) return desescapar(m.groupValues[2]).trim()
        }
        return ""
    }

    private fun desescapar(s: String): String {
        if (!s.contains('\\')) return s
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (val d = s[i + 1]) {
                    'n', 't', 'r' -> { sb.append(' '); i += 2 }
                    'u' -> {
                        val hex = if (i + 6 <= s.length) s.substring(i + 2, i + 6) else ""
                        val v = hex.toIntOrNull(16)
                        if (v != null) { sb.append(v.toChar()); i += 6 } else { sb.append('u'); i += 2 }
                    }
                    else -> { sb.append(d); i += 2 }
                }
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    /** Nivel 0..1 del micrófono para animar el orbe, a partir de las muestras de 16 bits. */
    fun nivel(muestras: ShortArray, n: Int): Float {
        if (n <= 0) return 0f
        var suma = 0.0
        for (i in 0 until n) {
            val v = muestras[i].toDouble() / 32768.0
            suma += v * v
        }
        val rms = sqrt(suma / n)
        val db = 20.0 * log10(rms + 1e-6)
        return ((db + 55.0) / 35.0).toFloat().coerceIn(0f, 1f)
    }

    /** Para descomprimir: ¿el archivo de destino queda DENTRO de la carpeta de instalación? */
    fun esRutaSegura(raiz: File, destino: File): Boolean =
        destino.canonicalPath.startsWith(raiz.canonicalPath + File.separator)
}
