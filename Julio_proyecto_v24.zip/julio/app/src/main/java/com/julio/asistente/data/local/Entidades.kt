package com.julio.asistente.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Todas las fechas se guardan como milisegundos epoch UTC; se convierten a hora local al mostrarlas. */

@Entity(tableName = "tareas")
data class TareaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titulo: String,
    val descripcion: String = "",
    /** 0 = baja, 1 = media, 2 = alta */
    val prioridad: Int = 1,
    val fechaLimite: Long? = null,
    val completada: Boolean = false,
    val creadaEn: Long = System.currentTimeMillis(),
    /** Aviso el día de la fecha límite, a esta hora (minutos desde medianoche). null = sin aviso. */
    val recordatorioMinutoDia: Int? = null,
)

@Entity(tableName = "actividades")
data class ActividadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titulo: String,
    val descripcion: String = "",
    val inicio: Long,
    val fin: Long? = null,
    /** NINGUNA, DIARIA, SEMANAL, MENSUAL, DIAS */
    val recurrencia: String = "NINGUNA",
    val creadaEn: Long = System.currentTimeMillis(),
    /** Aviso X minutos antes del inicio (0 = al empezar). null = sin aviso. */
    val recordatorioMin: Int? = null,
    /** Solo con recurrencia DIAS: días de la semana (bit 0 = lunes ... bit 6 = domingo). */
    val diasMascara: Int? = null,
    /** Solo con recurrencia DIAS: cada cuántas semanas se repite (null = cada semana). */
    val intervaloSemanas: Int? = null,
    /** Días (epoch day, separados por coma) en que la serie NO ocurre: se movió o eliminó solo esa ocurrencia. */
    val excluidas: String? = null,
)

@Entity(tableName = "alarmas")
data class AlarmaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String = "",
    val hora: Int,
    val minuto: Int,
    /** Fecha concreta (epoch day) para alarmas de una sola vez; null si solo usa días de repetición. */
    val fechaEpochDay: Long? = null,
    /** Máscara de bits de días repetidos: bit 0 = lunes ... bit 6 = domingo. 0 = no se repite. */
    val diasMascara: Int = 0,
    val activa: Boolean = true,
    val sonidoUri: String? = null,
    val creadaEn: Long = System.currentTimeMillis(),
)

@Entity(tableName = "metas")
data class MetaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titulo: String,
    val descripcion: String = "",
    /** 0..100 */
    val progreso: Int = 0,
    val completada: Boolean = false,
    val fechaObjetivo: Long? = null,
    val creadaEn: Long = System.currentTimeMillis(),
)
