package com.julio.asistente.voz

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

sealed class EstadoVosk {
    object NoInstalado : EstadoVosk()
    data class Instalando(val progreso: Float, val mb: Long, val etapa: String) : EstadoVosk()
    object Listo : EstadoVosk()
    data class Error(val mensaje: String) : EstadoVosk()
}

/**
 * El modelo de reconocimiento en español para Vosk (Kaldi). No va dentro del APK (pesa 39 MB comprimido).
 * Procedencia: https://alphacephei.com/vosk/models (Alpha Cephei), licencia Apache 2.0.
 * Se instala UNA vez, solo cuando la persona lo pide: bajándolo (la pantalla muestra origen y tamaño antes)
 * o eligiendo el .zip que ya tenga en el teléfono. Después el reconocimiento funciona sin internet.
 */
object VoskModelo {
    const val NOMBRE = "vosk-model-small-es-0.42"
    const val URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"
    const val ORIGEN = "alphacephei.com/vosk/models"
    const val TAMANO_ZIP_MB = 39
    const val LICENCIA = "Apache 2.0"

    private val _estado = MutableStateFlow<EstadoVosk>(EstadoVosk.NoInstalado)
    val estado: StateFlow<EstadoVosk> = _estado.asStateFlow()

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var cancelado = false

    private fun carpeta(c: Context) = File(c.applicationContext.filesDir, "vosk/modelo")

    /** Carpeta que contiene el modelo (la que tiene am/final.mdl y conf/). null = no está completo. */
    private fun localizar(raiz: File): File? {
        if (!raiz.isDirectory) return null
        return raiz.walkTopDown().maxDepth(3).firstOrNull { d ->
            d.isDirectory && File(d, "am/final.mdl").isFile && File(d, "conf").isDirectory
        }
    }

    /** Ruta del modelo listo para usar, o null si no está instalado. */
    fun ruta(c: Context): String? = localizar(carpeta(c))?.absolutePath

    fun iniciar(c: Context) {
        if (_estado.value is EstadoVosk.Instalando) return
        File(c.applicationContext.filesDir, "vosk/.instalando").deleteRecursively()
        _estado.value = if (ruta(c) != null) EstadoVosk.Listo else EstadoVosk.NoInstalado
    }

    /** Descarga el .zip y lo descomprime al vuelo. Solo se llama cuando la persona toca el botón. */
    fun descargar(c: Context) {
        if (_estado.value is EstadoVosk.Instalando) return
        val app = c.applicationContext
        cancelado = false
        _estado.value = EstadoVosk.Instalando(-1f, 0, "Descargando")
        alcance.launch {
            val temporal = File(app.filesDir, "vosk/.instalando")
            try {
                temporal.deleteRecursively()
                temporal.mkdirs()
                val conexion = URL(URL_ZIP).openConnection() as HttpURLConnection
                conexion.connectTimeout = 20_000
                conexion.readTimeout = 30_000
                conexion.instanceFollowRedirects = true
                try {
                    if (conexion.responseCode !in 200..299) throw IOException("el servidor respondió ${conexion.responseCode}")
                    extraer(conexion.inputStream, temporal, conexion.contentLengthLong, "Descargando")
                } finally {
                    conexion.disconnect()
                }
                publicar(app, temporal)
            } catch (e: Exception) {
                temporal.deleteRecursively()
                fallo(e, "No pude descargar el modelo. Revisa tu conexión e inténtalo otra vez")
            }
        }
    }

    /** Instala el modelo desde el .zip que la persona ya tiene en el teléfono (no necesita internet). */
    fun instalarDesdeZip(c: Context, uri: Uri) {
        if (_estado.value is EstadoVosk.Instalando) return
        val app = c.applicationContext
        cancelado = false
        _estado.value = EstadoVosk.Instalando(-1f, 0, "Instalando")
        alcance.launch {
            val temporal = File(app.filesDir, "vosk/.instalando")
            try {
                temporal.deleteRecursively()
                temporal.mkdirs()
                val entrada = app.contentResolver.openInputStream(uri) ?: throw IOException("No pude abrir el archivo.")
                extraer(entrada, temporal, -1L, "Instalando")
                publicar(app, temporal)
            } catch (e: Exception) {
                temporal.deleteRecursively()
                fallo(e, "No pude instalar el modelo")
            }
        }
    }

    fun cancelar() { cancelado = true }

    fun eliminar(c: Context) {
        cancelado = true
        carpeta(c).deleteRecursively()
        _estado.value = EstadoVosk.NoInstalado
    }

    private fun fallo(e: Exception, queHacia: String) {
        _estado.value = if (cancelado) EstadoVosk.NoInstalado
        else EstadoVosk.Error("$queHacia: ${e.message ?: e.javaClass.simpleName}")
    }

    private fun publicar(app: Context, temporal: File) {
        if (localizar(temporal) == null) throw IOException("El archivo no es un modelo de Vosk completo (falta am/final.mdl).")
        val destino = carpeta(app)
        destino.deleteRecursively()
        destino.parentFile?.mkdirs()
        if (!temporal.renameTo(destino)) throw IOException("No pude guardar el modelo en la memoria de Julio.")
        _estado.value = if (localizar(destino) != null) EstadoVosk.Listo else EstadoVosk.Error("El modelo no quedó completo.")
    }

    private class Contador(entrada: InputStream, private val alLeer: (Long) -> Unit) : FilterInputStream(entrada) {
        private var total = 0L
        override fun read(): Int {
            val b = super.read()
            if (b >= 0) { total++; alLeer(total) }
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { total += n; alLeer(total) }
            return n
        }
    }

    /** Descomprime un .zip leyéndolo por trozos (sin guardar el zip entero). [total] = bytes del zip, o -1 si no se sabe. */
    private fun extraer(entrada: InputStream, destino: File, total: Long, etapa: String) {
        var publicado = -1L
        val contado = Contador(entrada) { leidos ->
            if (cancelado) throw IOException("Instalación cancelada")
            val mb = leidos / 1_000_000
            if (mb != publicado) {
                publicado = mb
                _estado.value = EstadoVosk.Instalando(if (total > 0) leidos.toFloat() / total else -1f, mb, etapa)
            }
        }
        val raiz = destino.canonicalFile
        ZipInputStream(contado).use { zip ->
            var entradaZip = zip.nextEntry
            while (entradaZip != null) {
                val salida = File(raiz, entradaZip.name)
                if (!ReconocimientoUtil.esRutaSegura(raiz, salida)) throw IOException("El .zip trae una ruta no válida.")
                if (entradaZip.isDirectory) {
                    salida.mkdirs()
                } else {
                    salida.parentFile?.mkdirs()
                    salida.outputStream().use { fuera -> zip.copyTo(fuera) }
                }
                zip.closeEntry()
                entradaZip = zip.nextEntry
            }
        }
    }
}
