package com.julio.asistente.ui.screens

import com.julio.asistente.ui.components.PanelJulio

import android.app.Activity
import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.alarmas.AlarmasViewModel
import com.julio.asistente.core.Fechas
import com.julio.asistente.core.Permisos
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.ui.components.SelectorFecha
import com.julio.asistente.ui.components.SelectorHora
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun AlarmasScreen(vm: AlarmasViewModel = viewModel()) {
    val ctx = LocalContext.current
    val lista by vm.alarmas.collectAsStateWithLifecycle()
    val alarmas = lista
    val aviso by vm.aviso.collectAsStateWithLifecycle()

    var dialogoAbierto by remember { mutableStateOf(false) }
    var enEdicion by remember { mutableStateOf<AlarmaEntity?>(null) }
    var porEliminar by remember { mutableStateOf<AlarmaEntity?>(null) }

    var permisoNotif by remember { mutableStateOf(Permisos.notificaciones(ctx)) }
    var permisoPantalla by remember { mutableStateOf(Permisos.pantallaCompleta(ctx)) }
    var permisoExactas by remember { mutableStateOf(Permisos.alarmasExactas(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        permisoNotif = Permisos.notificaciones(ctx)
        permisoPantalla = Permisos.pantallaCompleta(ctx)
        permisoExactas = Permisos.alarmasExactas(ctx)
    }
    val pedirNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permisoNotif = Permisos.notificaciones(ctx)
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Text(
                "Alarmas",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            )

            if (!permisoExactas) {
                AvisoPermiso(
                    texto = "Android bloquea las alarmas de Julio hasta que permitas «Alarmas y recordatorios» " +
                        "para esta app. Sin eso, ninguna alarma sonará.",
                    boton = "Abrir ajustes",
                    onBoton = { ctx.startActivity(Permisos.ajustesAlarmasExactas(ctx)) },
                )
            }
            if (!permisoNotif) {
                AvisoPermiso(
                    texto = "Sin el permiso de notificaciones, Julio no puede mostrar la pantalla de la alarma " +
                        "ni sus botones. El sonido puede seguir funcionando, pero no está garantizado.",
                    boton = "Dar permiso",
                    onBoton = { pedirNotif.launch(android.Manifest.permission.POST_NOTIFICATIONS) },
                    botonSecundario = "Abrir ajustes",
                    onSecundario = { ctx.startActivity(Permisos.ajustesNotificaciones(ctx)) },
                )
            }
            if (!permisoPantalla) {
                AvisoPermiso(
                    texto = "Para que la alarma aparezca sobre la pantalla bloqueada, permite " +
                        "«notificaciones a pantalla completa» para Julio.",
                    boton = "Abrir ajustes",
                    onBoton = { ctx.startActivity(Permisos.ajustesPantallaCompleta(ctx)) },
                )
            }

            when {
                alarmas == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                alarmas.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No hay alarmas. Toca «Nueva alarma» para crear la primera.")
                }
                else -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 96.dp),
                ) {
                    items(alarmas, key = { it.id }) { a ->
                        AlarmaItem(
                            a = a,
                            onAlternar = { vm.alternar(a) },
                            onEditar = { enEdicion = a; dialogoAbierto = true },
                            onEliminar = { porEliminar = a },
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { enEdicion = null; dialogoAbierto = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Nueva alarma") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    if (dialogoAbierto) {
        DialogoAlarma(
            inicial = enEdicion,
            onGuardar = { vm.guardar(it); dialogoAbierto = false },
            onCancelar = { dialogoAbierto = false },
        )
    }

    porEliminar?.let { a ->
        AlertDialog(
            onDismissRequest = { porEliminar = null },
            title = { Text("Eliminar alarma") },
            text = { Text("¿Eliminar la alarma de ${textoHora(a)}? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { vm.eliminar(a); porEliminar = null }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { porEliminar = null }) { Text("Cancelar") } },
        )
    }

    aviso?.let { mensaje ->
        AlertDialog(
            onDismissRequest = { vm.limpiarAviso() },
            title = { Text("Alarmas") },
            text = { Text(mensaje) },
            confirmButton = { TextButton(onClick = { vm.limpiarAviso() }) { Text("Entendido") } },
        )
    }
}

private fun textoHora(a: AlarmaEntity): String = Fechas.textoHora(LocalTime.of(a.hora, a.minuto))

private fun nombreDia(d: DayOfWeek): String =
    d.getDisplayName(TextStyle.SHORT, Locale.getDefault()).replaceFirstChar { it.uppercase() }

private fun descripcionRepeticion(a: AlarmaEntity): String {
    val fecha = a.fechaEpochDay
    return when {
        a.diasMascara == 0x7F -> "Todos los días"
        a.diasMascara != 0 ->
            DayOfWeek.values().filter { (a.diasMascara and (1 shl (it.value - 1))) != 0 }
                .joinToString(", ") { nombreDia(it) }
        fecha != null -> Fechas.textoLargo(LocalDate.ofEpochDay(fecha))
        else -> "Una vez"
    }
}

@Composable
private fun AvisoPermiso(
    texto: String,
    boton: String,
    onBoton: () -> Unit,
    botonSecundario: String? = null,
    onSecundario: () -> Unit = {},
) {
    PanelJulio(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(texto, style = MaterialTheme.typography.bodySmall)
            Row {
                TextButton(onClick = onBoton) { Text(boton) }
                if (botonSecundario != null) {
                    TextButton(onClick = onSecundario) { Text(botonSecundario) }
                }
            }
        }
    }
}

@Composable
private fun AlarmaItem(
    a: AlarmaEntity,
    onAlternar: () -> Unit,
    onEditar: () -> Unit,
    onEliminar: () -> Unit,
) {
    PanelJulio(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    textoHora(a),
                    style = MaterialTheme.typography.headlineMedium,
                    color = if (a.activa) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (a.nombre.isNotBlank()) Text(a.nombre, style = MaterialTheme.typography.titleSmall)
                Text(
                    descripcionRepeticion(a),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Switch(checked = a.activa, onCheckedChange = { onAlternar() })
            IconButton(onClick = onEditar) { Icon(Icons.Filled.Edit, contentDescription = "Editar alarma") }
            IconButton(onClick = onEliminar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar alarma") }
        }
    }
}

private fun tituloSonido(c: Context, uri: String?): String {
    if (uri == null) return "Predeterminado"
    return try {
        RingtoneManager.getRingtone(c, Uri.parse(uri))?.getTitle(c) ?: "Personalizado"
    } catch (e: Exception) {
        "Personalizado"
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DialogoAlarma(
    inicial: AlarmaEntity?,
    onGuardar: (AlarmaEntity) -> Unit,
    onCancelar: () -> Unit,
) {
    val ctx = LocalContext.current
    var nombre by remember { mutableStateOf(inicial?.nombre ?: "") }
    var hora by remember {
        mutableStateOf<LocalTime?>(inicial?.let { LocalTime.of(it.hora, it.minuto) })
    }
    var dias by remember { mutableStateOf(inicial?.diasMascara ?: 0) }
    var fecha by remember { mutableStateOf<LocalDate?>(inicial?.fechaEpochDay?.let { LocalDate.ofEpochDay(it) }) }
    var sonido by remember { mutableStateOf(inicial?.sonidoUri) }
    var selectorHora by remember { mutableStateOf(false) }
    var selectorFecha by remember { mutableStateOf(false) }

    val elegirSonido = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uri = r.data?.let {
                IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            }
            sonido = uri?.toString()
        }
    }

    val h = hora
    val f = fecha
    val nombreSonido = remember(sonido) { tituloSonido(ctx, sonido) }

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text(if (inicial == null) "Nueva alarma" else "Editar alarma") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedButton(onClick = { selectorHora = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(h?.let { "Hora: ${Fechas.textoHora(it)}" } ?: "Elegir hora")
                }
                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre (opcional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Repetir los días", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DayOfWeek.values().forEach { d ->
                        val bit = 1 shl (d.value - 1)
                        FilterChip(
                            selected = (dias and bit) != 0,
                            onClick = { dias = dias xor bit },
                            label = { Text(nombreDia(d)) },
                        )
                    }
                }
                if (dias == 0) {
                    OutlinedButton(onClick = { selectorFecha = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(f?.let { "Fecha: ${Fechas.textoLargo(it)}" } ?: "Elegir fecha (opcional)")
                    }
                    if (f != null) {
                        TextButton(onClick = { fecha = null }) { Text("Quitar fecha") }
                    } else {
                        Text(
                            "Sin fecha ni días, sonará la próxima vez que llegue esa hora.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                OutlinedButton(
                    onClick = {
                        elegirSonido.launch(
                            android.content.Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Sonido de la alarma")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                putExtra(
                                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                                    sonido?.let { Uri.parse(it) },
                                )
                            },
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Sonido: $nombreSonido") }
                if (h == null) {
                    Text("Elige la hora para poder guardar.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = h != null,
                onClick = {
                    if (h != null) {
                        val base = inicial ?: AlarmaEntity(hora = h.hour, minuto = h.minute)
                        onGuardar(
                            base.copy(
                                nombre = nombre.trim(),
                                hora = h.hour,
                                minuto = h.minute,
                                diasMascara = dias,
                                fechaEpochDay = if (dias == 0) f?.toEpochDay() else null,
                                sonidoUri = sonido,
                                activa = true,
                            ),
                        )
                    }
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )

    if (selectorHora) {
        SelectorHora(
            titulo = "Hora de la alarma",
            inicial = h ?: LocalTime.of(7, 0),
            onAceptar = { hora = it; selectorHora = false },
            onCancelar = { selectorHora = false },
        )
    }
    if (selectorFecha) {
        SelectorFecha(
            inicial = f ?: LocalDate.now(),
            onAceptar = { fecha = it; selectorFecha = false },
            onCancelar = { selectorFecha = false },
        )
    }
}
