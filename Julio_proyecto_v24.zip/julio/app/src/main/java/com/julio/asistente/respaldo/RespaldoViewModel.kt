package com.julio.asistente.respaldo

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RespaldoViewModel(app: Application) : AndroidViewModel(app) {
    /** Una copia leída y validada, esperando que el usuario confirme que quiere restaurarla. */
    class Pendiente(val json: String, val resumen: Respaldo.Resumen)

    private val _mensaje = MutableStateFlow<String?>(null)
    val mensaje: StateFlow<String?> = _mensaje.asStateFlow()
    private val _pendiente = MutableStateFlow<Pendiente?>(null)
    val pendiente: StateFlow<Pendiente?> = _pendiente.asStateFlow()

    private val resolver get() = getApplication<Application>().contentResolver

    fun guardarEn(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val json = Respaldo.exportar(getApplication())
                val salida = resolver.openOutputStream(uri, "wt")
                if (salida == null) {
                    _mensaje.value = "No pude abrir el archivo para guardar la copia."
                    return@launch
                }
                salida.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                // Se vuelve a leer el archivo para comprobar que de verdad quedó bien.
                val leido = resolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                val resumen = leido?.let { Respaldo.analizar(it) }
                _mensaje.value = if (resumen != null) "Copia guardada: ${resumen.texto()}."
                else "No pude comprobar que el archivo se guardara bien. Intenta guardarlo en otra carpeta."
            } catch (e: Exception) {
                _mensaje.value = "No pude guardar la copia: ${e.message ?: "error desconocido"}."
            }
        }
    }

    fun leerDe(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val json = resolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                val resumen = json?.let { Respaldo.analizar(it) }
                if (json == null || resumen == null) {
                    _mensaje.value = "Ese archivo no parece una copia de seguridad de Julio. No cambié nada."
                } else {
                    _pendiente.value = Pendiente(json, resumen)
                }
            } catch (e: Exception) {
                _mensaje.value = "No pude leer el archivo: ${e.message ?: "error desconocido"}."
            }
        }
    }

    fun confirmarRestaurar() {
        val p = _pendiente.value ?: return
        _pendiente.value = null
        viewModelScope.launch(Dispatchers.IO) {
            val r = try { Respaldo.restaurar(getApplication(), p.json) } catch (e: Exception) { null }
            _mensaje.value = if (r != null) "Copia restaurada: ${r.texto()}."
            else "No pude restaurar la copia por completo. Si algo se ve raro, tu copia automática anterior quedó en la memoria de Julio."
        }
    }

    fun cancelarRestaurar() { _pendiente.value = null }
    fun cerrarMensaje() { _mensaje.value = null }
}
