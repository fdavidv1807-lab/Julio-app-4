package com.julio.asistente.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.julio.asistente.ui.theme.AzulElectrico
import com.julio.asistente.ui.theme.CianElectrico

/** Resplandor suave alrededor de un elemento (tres anillos translúcidos). Discreto: nunca tapa el texto. */
fun Modifier.brilloSuave(color: Color, radioEsquina: Dp, intensidad: Float = 1f): Modifier = drawBehind {
    val r = radioEsquina.toPx()
    for (i in 3 downTo 1) {
        val e = i * 2.5.dp.toPx()
        drawRoundRect(
            color = color.copy(alpha = (0.03f * i * intensidad).coerceIn(0f, 1f)),
            topLeft = Offset(-e, -e),
            size = Size(size.width + 2f * e, size.height + 2f * e),
            cornerRadius = CornerRadius(r + e),
        )
    }
}

/** Igual que [brilloSuave], pero la luz «respira» muy despacio (animación suave, solo se redibuja). */
@Composable
fun Modifier.brilloRespirando(color: Color, radioEsquina: Dp): Modifier {
    val transicion = rememberInfiniteTransition(label = "respira")
    val pulso by transicion.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulso",
    )
    return drawBehind {
        val r = radioEsquina.toPx()
        for (i in 3 downTo 1) {
            val e = i * 2.5.dp.toPx()
            drawRoundRect(
                color = color.copy(alpha = (0.03f * i * pulso).coerceIn(0f, 1f)),
                topLeft = Offset(-e, -e),
                size = Size(size.width + 2f * e, size.height + 2f * e),
                cornerRadius = CornerRadius(r + e),
            )
        }
    }
}

/** Tarjeta de la app: borde luminoso sutil (cian a azul), fondo azul marino algo translúcido y un leve resplandor. */
@Composable
fun PanelJulio(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val oscuro = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val borde = if (oscuro) {
        Brush.linearGradient(listOf(CianElectrico.copy(alpha = 0.55f), AzulElectrico.copy(alpha = 0.20f)))
    } else {
        Brush.linearGradient(listOf(MaterialTheme.colorScheme.outlineVariant, MaterialTheme.colorScheme.outlineVariant))
    }
    Card(
        modifier = if (oscuro) modifier.brilloSuave(CianElectrico, 14.dp, 0.7f) else modifier,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = if (oscuro) 0.92f else 1f),
        ),
        border = BorderStroke(1.dp, borde),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        content = content,
    )
}

/**
 * Fondo de la app: negro azulado que se aclara a azul marino, con resplandores azul y cian en las esquinas y una
 * cuadrícula casi invisible. En tema claro queda liso.
 */
@Composable
fun FondoHud(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val fondo = MaterialTheme.colorScheme.background
    val oscuro = fondo.luminance() < 0.5f
    Box(
        modifier
            .fillMaxSize()
            .background(fondo)
            .drawBehind {
                if (!oscuro) return@drawBehind
                drawRect(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF050E22), fondo),
                        startY = 0f, endY = size.height * 0.6f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(AzulElectrico.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(size.width * 0.15f, 0f), radius = size.width * 0.95f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(CianElectrico.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.92f), radius = size.width * 0.9f,
                    ),
                )
                val paso = 40.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(CianElectrico.copy(alpha = 0.035f), Offset(x, 0f), Offset(x, size.height), 1f)
                    x += paso
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(CianElectrico.copy(alpha = 0.035f), Offset(0f, y), Offset(size.width, y), 1f)
                    y += paso
                }
            },
        content = content,
    )
}

/** Barra superior: menú (panel izquierdo), título con un indicador que late despacio, y configuración (panel derecho). */
@Composable
fun BarraSuperior(
    titulo: String,
    alMenu: (() -> Unit)?,
    alAjustes: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val oscuro = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val transicion = rememberInfiniteTransition(label = "indicador")
    val pulso by transicion.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulso",
    )
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .drawBehind {
                if (oscuro) {
                    drawLine(
                        brush = Brush.horizontalGradient(listOf(CianElectrico.copy(alpha = 0.55f), AzulElectrico.copy(alpha = 0.10f), Color.Transparent)),
                        start = Offset(0f, size.height), end = Offset(size.width, size.height), strokeWidth = 1.dp.toPx(),
                    )
                }
            }
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (alMenu != null) {
            IconButton(onClick = alMenu) { Icon(Icons.Filled.Menu, contentDescription = "Abrir el menú") }
        } else {
            Box(Modifier.padding(start = 12.dp))
        }
        Box(
            Modifier.size(8.dp).drawBehind {
                drawCircle(CianElectrico.copy(alpha = 0.25f * pulso), radius = size.minDimension * 1.1f)
                drawCircle(CianElectrico.copy(alpha = 0.55f + 0.45f * pulso), radius = size.minDimension / 2f)
            },
        )
        Spacer(Modifier.width(10.dp))
        Text(
            titulo,
            style = MaterialTheme.typography.titleLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (alAjustes != null) {
            IconButton(onClick = alAjustes) { Icon(Icons.Filled.Settings, contentDescription = "Abrir la configuración") }
        }
    }
}
