package com.julio.asistente.ui.screens

import com.julio.asistente.ui.components.PanelJulio

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.MetaEntity
import com.julio.asistente.metas.MetasViewModel
import com.julio.asistente.ui.components.SelectorFecha
import java.time.LocalDate
import java.time.ZoneOffset

/** «Mis metas»: vive dentro de la pantalla Voz, no es una sección de la navegación. */
@Composable
fun MetasSection(vm: MetasViewModel = viewModel()) {
    val lista by vm.metas.collectAsStateWithLifecycle()
    val metas = lista

    var dialogoAbierto by remember { mutableStateOf(false) }
    var enEdicion by remember { mutableStateOf<MetaEntity?>(null) }
    var porEliminar by remember { mutableStateOf<MetaEntity?>(null) }
    var progresoDe by remember { mutableStateOf<MetaEntity?>(null) }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mis metas", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            FilledTonalButton(onClick = { enEdicion = null; dialogoAbierto = true }) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Nueva meta")
            }
        }
        when {
            metas == null -> CircularProgressIndicator()
            metas.isEmpty() -> Text(
                "Aún no tienes metas. Toca «Nueva meta» para crear la primera.",
                style = MaterialTheme.typography.bodyMedium,
            )
            else -> metas.forEach { m ->
                key(m.id) {
                    MetaItem(
                        m = m,
                        onProgreso = { progresoDe = m },
                        onCompletar = { vm.completar(m) },
                        onEditar = { enEdicion = m; dialogoAbierto = true },
                        onEliminar = { porEliminar = m },
                    )
                }
            }
        }
    }

    if (dialogoAbierto) {
        DialogoMeta(
            inicial = enEdicion,
            onGuardar = { vm.guardar(it); dialogoAbierto = false },
            onCancelar = { dialogoAbierto = false },
        )
    }

    progresoDe?.let { m ->
        DialogoProgreso(
            meta = m,
            onGuardar = { vm.actualizarProgreso(m, it); progresoDe = null },
            onCancelar = { progresoDe = null },
        )
    }

    porEliminar?.let { m ->
        AlertDialog(
            onDismissRequest = { porEliminar = null },
            title = { Text("Eliminar meta") },
            text = { Text("¿Eliminar «${m.titulo}»? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { vm.eliminar(m); porEliminar = null }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { porEliminar = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun MetaItem(
    m: MetaEntity,
    onProgreso: () -> Unit,
    onCompletar: () -> Unit,
    onEditar: () -> Unit,
    onEliminar: () -> Unit,
) {
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    m.titulo,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (m.completada) TextDecoration.LineThrough else null,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onEditar) { Icon(Icons.Filled.Edit, contentDescription = "Editar meta") }
                IconButton(onClick = onEliminar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar meta") }
            }
            if (m.descripcion.isNotBlank()) {
                Text(m.descripcion, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(end = 12.dp))
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { m.progreso / 100f },
                modifier = Modifier.fillMaxWidth().padding(end = 12.dp),
            )
            val detalle = buildString {
                append(if (m.completada) "Completada · 100 %" else "${m.progreso} %")
                m.fechaObjetivo?.let { append(" · Objetivo: ${Fechas.texto(it)}") }
            }
            Text(detalle, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
            Row {
                TextButton(onClick = onProgreso) { Text("Actualizar progreso") }
                if (!m.completada) TextButton(onClick = onCompletar) { Text("Marcar completada") }
            }
        }
    }
}

@Composable
private fun DialogoMeta(inicial: MetaEntity?, onGuardar: (MetaEntity) -> Unit, onCancelar: () -> Unit) {
    var titulo by remember { mutableStateOf(inicial?.titulo ?: "") }
    var descripcion by remember { mutableStateOf(inicial?.descripcion ?: "") }
    var fecha by remember { mutableStateOf<Long?>(inicial?.fechaObjetivo) }
    var selector by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text(if (inicial == null) "Nueva meta" else "Editar meta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it },
                    label = { Text("Título") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripción (opcional)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { selector = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(fecha?.let { "Fecha objetivo: ${Fechas.texto(it)}" } ?: "Añadir fecha objetivo (opcional)")
                }
                if (fecha != null) {
                    TextButton(onClick = { fecha = null }) { Text("Quitar fecha objetivo") }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = titulo.isNotBlank(),
                onClick = {
                    val base = inicial ?: MetaEntity(titulo = "")
                    onGuardar(base.copy(titulo = titulo.trim(), descripcion = descripcion.trim(), fechaObjetivo = fecha))
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )

    if (selector) {
        SelectorFecha(
            inicial = fecha?.let { Fechas.deMillisUtc(it) } ?: LocalDate.now(),
            onAceptar = {
                fecha = it.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                selector = false
            },
            onCancelar = { selector = false },
        )
    }
}

@Composable
private fun DialogoProgreso(meta: MetaEntity, onGuardar: (Int) -> Unit, onCancelar: () -> Unit) {
    var valor by remember { mutableStateOf(meta.progreso.toFloat()) }
    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text("Progreso de la meta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(meta.titulo, style = MaterialTheme.typography.titleSmall)
                Text("${valor.toInt()} %", style = MaterialTheme.typography.headlineMedium)
                Slider(value = valor, onValueChange = { valor = it }, valueRange = 0f..100f, steps = 19)
                if (valor.toInt() == 100) {
                    Text("Al llegar a 100 % la meta se marca como completada.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onClick = { onGuardar(valor.toInt()) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )
}
