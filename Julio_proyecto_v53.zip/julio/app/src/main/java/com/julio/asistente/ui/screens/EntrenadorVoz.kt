package com.julio.asistente.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.voz.FaseEntrenador
import com.julio.asistente.voz.VozViewModel

/**
 * Entrenador de voz «Julio» (v53), al estilo de «Hey Google»: dices «Julio» seis veces (normal, más bajo, más rápido), ves en pantalla
 * lo que Julio entendió en cada una y aprende cómo suena TU «Julio». Después sigue con tu perfil de «solo mi voz» (más abajo en esta sección).
 */
@Composable
fun EntrenadorVozPanel(vm: VozViewModel) {
    val ctx = LocalContext.current
    val fase by vm.entrenador.collectAsStateWithLifecycle()
    val aprendidas by vm.duenoAprendidas.collectAsStateWithLifecycle()
    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.entrenarJulio() }
    val empezar = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.entrenarJulio()
        else pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (val f = fase) {
            is FaseEntrenador.Inactivo -> {
                Text(
                    "Entrenador de voz. Vas a decir «Julio» seis veces (normal, más bajo, más rápido o cansado). Julio aprende CÓMO LO OYE con tu voz " +
                        "y desde entonces te despierta también con esas formas. El audio no se guarda ni sale del teléfono.",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (aprendidas.isNotEmpty()) {
                    Text(
                        "Ahora Julio te entiende también cuando dices: " + aprendidas.joinToString(", ") { "«$it»" } + ".",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Button(onClick = { empezar() }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (aprendidas.isEmpty()) "Empezar entrenamiento" else "Entrenar otra vez")
                }
                if (aprendidas.isNotEmpty()) {
                    OutlinedButton(onClick = { vm.olvidarAprendidas() }, modifier = Modifier.fillMaxWidth()) { Text("Olvidar lo aprendido") }
                }
            }

            is FaseEntrenador.Repitiendo -> {
                Text(
                    "Repetición ${f.i} de ${f.total}",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                Text(
                    if (f.escuchando) "Di: «Julio»" else "Listo",
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                Text(
                    f.consigna.replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                // Puntos de avance, como Google: lleno = hecha.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    for (n in 1..f.total) {
                        Text(if (n < f.i || (n == f.i && !f.escuchando)) "●" else "○", fontSize = 22.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
                if (f.oyo != null) {
                    Text(
                        "Te escuché: " + f.oyo,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                    )
                }
            }

            is FaseEntrenador.Listo -> {
                Text(f.mensaje, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                Text(
                    "Sigue ahora el perfil de «solo mi voz» (tres muestras más). Si no se inicia, instala el modelo de hablante más abajo y toca «Entrenar mi voz».",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedButton(onClick = { vm.cerrarEntrenador() }, modifier = Modifier.fillMaxWidth()) { Text("Entendido") }
            }

            is FaseEntrenador.Error -> {
                Text(f.mensaje, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                Button(onClick = { empezar() }, modifier = Modifier.fillMaxWidth()) { Text("Reintentar") }
                OutlinedButton(onClick = { vm.cerrarEntrenador() }, modifier = Modifier.fillMaxWidth()) { Text("Cerrar") }
            }
        }
    }
}
