# PLAN DE TRABAJO — Proyecto Julio

> Fuente principal de continuidad. Léelo primero; no releas todo el documento de requisitos.
> Última actualización: Etapas 1, 2 y parte de la 3 (icono).

## 1. Decisiones técnicas
| Tema | Decisión | Motivo |
|---|---|---|
| Lenguaje / UI | **Kotlin nativo + Jetpack Compose (Material 3)** | Alarmas exactas, servicios en segundo plano, AccessibilityService/UsageStats y SpeechRecognizer/TextToSpeech son APIs nativas de Android; sin capa intermedia. |
| minSdk / target | 26 (Android 8.0) / 35 | Iconos adaptativos y canales de notificación sin parches. |
| Almacenamiento | **Room (SQLite)** 2.6.1 vía KSP; DataStore para preferencias (Etapa 5+) | Persistencia local, consultas por fecha, sin servidor. |
| Arquitectura | UI (Compose) → ViewModel → repositorio → DAO. Interpretación de comandos separada de UI y datos. | Requisito 3 y 11. |
| Build | Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01 | Combinación compatible conocida. |
| Paquete | `com.julio.asistente` | |

## 2. Estructura
```
app/src/main/java/com/julio/asistente/
  JulioApp.kt, MainActivity.kt
  ui/ (JulioRoot, navigation/, theme/, components/, screens/)
  data/local/ (Entidades, Daos, JulioDatabase)
  voz/ comandos/ horario/ tareas/ alarmas/ metas/ enfoque/ core/   <- reservados (LEEME.txt)
```

## 3. Limitaciones de Android a abordar
- **Voz**: `SpeechRecognizer` necesita permiso RECORD_AUDIO; el reconocimiento offline depende del paquete de idioma y del dispositivo. `TextToSpeech` usará la mejor voz masculina en español instalada (la disponibilidad varía por fabricante). Servicio externo de voz/IA: solo con aviso de datos enviados, coste y clave guardada fuera del repositorio.
- **Conversación real**: requiere un modelo de lenguaje externo (API con clave del usuario). Sin ella, solo comandos estructurados; no se simulará con respuestas fijas.
- **Alarmas**: `AlarmManager.setAlarmClock()` / exactas (`SCHEDULE_EXACT_ALARM` en Android 12+, `POST_NOTIFICATIONS` en 13+), reprogramar tras reinicio (`BOOT_COMPLETED`). Restricciones de batería por fabricante: se documentarán.
- **Bloqueo de apps**: solo viable con `PACKAGE_USAGE_STATS` + superposición o `AccessibilityService`, con consentimiento explícito. Se entrega primero el temporizador funcional.

## 4. Estado de las etapas
| Etapa | Estado |
|---|---|
| 1 Planificación | ✅ Hecha (este documento) |
| 2 Base (proyecto, navegación, tema, Room) | 🟡 Código escrito, **NO compilado** (ver §5) |
| 3 Identidad visual | 🟡 Icono real (mipmaps + adaptativo) y mascota añadidos; falta pantalla Voz real |
| 4 Horario y Tareas | ⬜ |
| 5 Alarmas | ⬜ |
| 6 Modo enfoque | ⬜ |
| 7 Mis metas | ⬜ |
| 8 Voz e inteligencia | ⬜ |
| 9 Integración, pruebas, APK de producción | ⬜ |

## 5. Qué se verificó y qué NO
**Verificado**: los XML son válidos; el icono se generó desde la imagen original y se inspeccionó visualmente (máscara circular del icono adaptativo incluida).
**No verificado**: compilación, ejecución, icono en el lanzador. El entorno de desarrollo no tenía Android SDK, Flutter ni red. Puede haber errores de compilación hasta que se ejecute Gradle por primera vez.
**No hay APK generada.**

## 6. Cómo compilar
- **Android Studio** (recomendado): abrir la carpeta, dejar sincronizar Gradle, `Build > Build APK(s)`. Ruta: `app/build/outputs/apk/debug/app-debug.apk`.
- **GitHub Actions**: `.github/workflows/build.yml` compila en cada push a `desarrollo-julio` y sube la APK como artefacto.
- El wrapper (`gradlew`) no está incluido; Android Studio lo genera, o `gradle wrapper --gradle-version 8.9`.
- APK de producción: requiere keystore propio (Etapa 9). Nunca subirlo al repositorio.

## 7. Errores conocidos / pendientes
- Pantallas Horario/Tareas/Alarmas/Enfoque son avisos honestos «Aún no implementado», sin botones falsos.
- DAOs y entidades existen pero aún no están conectados a la UI.
- No hay pruebas automatizadas todavía (se añaden con la lógica de comandos y fechas).

## 8. Siguiente tarea concreta
1. Compilar en Android Studio o Actions y corregir cualquier error de la Etapa 2.
2. Confirmar que el icono aparece en el lanzador.
3. Etapa 4: repositorios + ViewModels + pantallas de Tareas, luego Horario.

## 9. Prompt para continuar en otro chat
> Continúa el proyecto Julio (app Android, Kotlin + Compose). Lee primero `PLAN_DE_TRABAJO.md`. No reinicies ni reescribas lo hecho. Estado: Etapas 1-2 escritas (sin compilar), icono listo. Empieza por la «Siguiente tarea concreta». Archivos a revisar: `PLAN_DE_TRABAJO.md`, `app/build.gradle.kts`, `gradle/libs.versions.toml`, `data/local/*`, `ui/JulioRoot.kt`, `ui/screens/*`. Trabaja por etapas, sé honesto sobre lo verificado y actualiza el plan al final.
