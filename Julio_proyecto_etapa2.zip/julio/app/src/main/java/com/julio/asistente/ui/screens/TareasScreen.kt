package com.julio.asistente.ui.screens

import androidx.compose.runtime.Composable
import com.julio.asistente.ui.components.SeccionBase

@Composable
fun TareasScreen() {
    SeccionBase(
        titulo = "Lista de tareas",
        etapa = "Etapa 4",
        descripcion = "Tareas pendientes con prioridad, fecha límite y filtro entre pendientes y completadas.",
    )
}
