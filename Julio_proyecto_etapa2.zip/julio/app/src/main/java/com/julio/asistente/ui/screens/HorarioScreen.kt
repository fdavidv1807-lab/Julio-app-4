package com.julio.asistente.ui.screens

import androidx.compose.runtime.Composable
import com.julio.asistente.ui.components.SeccionBase

@Composable
fun HorarioScreen() {
    SeccionBase(
        titulo = "Horario",
        etapa = "Etapa 4",
        descripcion = "Actividades con fecha y hora, recurrencia, edición y consulta de próximas actividades.",
    )
}
