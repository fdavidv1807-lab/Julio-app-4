package com.julio.asistente.escritorio

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Estado del modo escritorio (teléfono fijo, siempre enchufado). Se recuerda aunque se cierre la app. */
object EscritorioControl {
    private const val ARCHIVO = "julio_escritorio"
    private val _activo = MutableStateFlow(false)
    val activo: StateFlow<Boolean> = _activo.asStateFlow()

    /** Último motivo por el que Android no dejó iniciar el servicio (para mostrarlo; nunca se oculta). */
    @Volatile var ultimoError: String? = null

    fun cargar(c: Context) {
        _activo.value = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("activo", false)
    }

    private fun guardar(c: Context, valor: Boolean) {
        _activo.value = valor
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("activo", valor).apply()
    }

    /** Entra al modo escritorio. Se llama con la app visible (Android 12+ no deja iniciar servicios desde el fondo). */
    fun entrar(c: Context) {
        guardar(c, true)
        iniciarServicio(c)
    }

    fun salir(c: Context) {
        guardar(c, false)
        c.applicationContext.stopService(Intent(c.applicationContext, JulioServicio::class.java))
    }

    /** Tras reiniciar el teléfono: si el modo estaba activo, vuelve a levantar el servicio (la pantalla se abre al abrir la app). */
    fun reanudarServicio(c: Context) {
        cargar(c)
        if (_activo.value) iniciarServicio(c, conMicrofono = false) // desde el arranque Android no permite el tipo micrófono
    }

    /**
     * Pide al servicio el tipo «micrófono» (hace falta para oír «Julio» con el teléfono en el escritorio).
     * Solo se puede con la app visible, por eso la pantalla de escritorio lo llama al abrirse (también tras reiniciar).
     */
    fun asegurarServicio(c: Context) {
        if (_activo.value) iniciarServicio(c, conMicrofono = true)
    }

    private fun iniciarServicio(c: Context, conMicrofono: Boolean = true) {
        val app = c.applicationContext
        try {
            ContextCompat.startForegroundService(
                app,
                Intent(app, JulioServicio::class.java).putExtra(JulioServicio.EXTRA_MICROFONO, conMicrofono),
            )
            ultimoError = null
        } catch (e: Exception) {
            ultimoError = e.message ?: e.javaClass.simpleName
        }
    }
}
