package com.julio.asistente.estudio

import android.content.Context

/** Guarda las tarjetas de estudio en SharedPreferences («julio_tarjetas»). Todo queda en este teléfono. */
object TarjetasAjustes {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("julio_tarjetas", Context.MODE_PRIVATE)

    fun leer(c: Context): List<Tarjeta> = TarjetasLogica.leer(sp(c).getString("tarjetas", "") ?: "")

    fun guardar(c: Context, lista: List<Tarjeta>) {
        sp(c).edit().putString("tarjetas", TarjetasLogica.serializar(lista)).apply()
    }

    /** Agrega varias a la vez (las que ya existían o no valen se saltan). Devuelve cuántas se agregaron. */
    fun agregarVarias(c: Context, tema: String, pares: List<Pair<String, String>>, hoy: Long): Int {
        var lista = leer(c)
        var nuevas = 0
        var id = System.currentTimeMillis()
        for ((p, r) in pares) {
            val l = TarjetasLogica.agregar(lista, tema, p, r, hoy, id++) ?: continue
            lista = l
            nuevas++
        }
        if (nuevas > 0) guardar(c, lista)
        return nuevas
    }
}
