package com.julio.asistente.comandos

/**
 * «Julio, hablemos» (v52): mientras dura, lo que NO sea una orden que Julio entienda va a la IA (con memoria corta del hilo).
 * Es explícito (se enciende y se apaga a propósito) para no mandar a internet lo que se oiga mal. Lógica pura: se prueba con JUnit.
 */
object ModoConversacion {
    /** Sin hablar durante este tiempo, la conversación se termina sola (en silencio). */
    const val SILENCIO_MS = 45_000L

    private val INICIAR = Regex(
        """^(?:julio )?(?:(?:vamos a|quiero|podemos|puedes|podrias|me gustaria) )?(?:hablar|platicar|conversar|charlar|hablemos|platiquemos|conversemos|charlemos)""" +
            """(?: un rato| conmigo| contigo| de algo)*(?: con la ia| con gemini| con la inteligencia artificial)?$""",
    )

    /** «termina», «adiós», «eso es todo»... Solo se mira mientras hay una conversación en curso. */
    private val TERMINAR = Regex(
        """^(?:julio )?(?:termina|terminar|terminamos|adios|hasta luego|eso es todo|ya no mas|ya fue|""" +
            """(?:termina|terminar|finaliza|finalizar|cierra|cerrar|deja|dejar|acaba|acabar|sal|salir|para|parar) (?:de |con )?(?:la |el |esta |esa )?(?:conversacion|charla|chat|platica)|""" +
            """ya no quiero (?:hablar|conversar)|fin de la conversacion)$""",
    )

    /** «Termina la conversación» dicho sin estar conversando: Julio contesta que no estaban conversando. */
    private val TERMINAR_EXPLICITO = Regex(
        """^(?:julio )?(?:termina|terminar|finaliza|finalizar|cierra|cerrar|deja|dejar|acaba|acabar|sal|salir|para|parar) (?:de |con )?(?:la |el |esta |esa )?(?:conversacion|charla|chat|platica)$|^(?:julio )?fin de la conversacion$""",
    )

    fun pideIniciar(n: String): Boolean = INICIAR.containsMatchIn(n.trim())
    fun pideTerminar(n: String): Boolean = TERMINAR.containsMatchIn(n.trim())
    fun pideTerminarExplicito(n: String): Boolean = TERMINAR_EXPLICITO.containsMatchIn(n.trim())

    /** ¿Pasó demasiado silencio desde la última vez que se habló? */
    fun vencida(ultimaMs: Long, ahoraMs: Long): Boolean = ahoraMs - ultimaMs > SILENCIO_MS

    /** Lo que Julio no entendió como orden va a la IA (las órdenes reales siguen funcionando durante la conversación). */
    fun debeIrALaIA(i: Intencion): Boolean = i is Intencion.Desconocida || i is Intencion.Ambigua
}
