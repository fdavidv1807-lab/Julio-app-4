package com.julio.asistente.repaso

/** Un tema de estudio con su calendario de repaso. [proximo] = día (epoch day) en que toca repasarlo. */
data class TemaRepaso(val nombre: String, val paso: Int, val proximo: Long)

/**
 * Repaso espaciado (v55): cada tema se repasa a los 1, 3, 7, 14 y 30 días. Si te fue bien sube un paso; si te fue mal vuelve al primero.
 * Solo se guardan nombres de temas y fechas (nada de preguntas ni respuestas). Lógica pura: se prueba con JUnit.
 */
object RepasoLogica {
    val INTERVALOS = listOf(1, 3, 7, 14, 30)
    private const val SEP = '\u001F'
    private const val FILA = '\u001E'

    private fun clave(nombre: String): String = nombre.trim().lowercase()

    /** Agrega el tema si no estaba (toca repasarlo en 1 día). Si ya estaba, no cambia nada. */
    fun agregar(lista: List<TemaRepaso>, nombre: String, hoy: Long): List<TemaRepaso> {
        val limpio = nombre.trim().take(60)
        if (limpio.isEmpty() || lista.any { clave(it.nombre) == clave(limpio) }) return lista
        return lista + TemaRepaso(limpio, 0, hoy + INTERVALOS[0])
    }

    /** Anota un repaso: [bien] sube un paso (hasta el último); si no, vuelve al primero. El tema se agrega si no estaba. */
    fun registrar(lista: List<TemaRepaso>, nombre: String, bien: Boolean, hoy: Long): List<TemaRepaso> {
        val base = if (lista.any { clave(it.nombre) == clave(nombre) }) lista else agregar(lista, nombre, hoy)
        return base.map {
            if (clave(it.nombre) != clave(nombre)) it
            else {
                val paso = if (bien) minOf(it.paso + 1, INTERVALOS.size - 1) else 0
                it.copy(paso = paso, proximo = hoy + INTERVALOS[paso])
            }
        }
    }

    /** Los que ya tocan (o se pasaron), los más atrasados primero. */
    fun vencidos(lista: List<TemaRepaso>, hoy: Long): List<TemaRepaso> = lista.filter { it.proximo <= hoy }.sortedBy { it.proximo }

    fun quitar(lista: List<TemaRepaso>, nombre: String): List<TemaRepaso> = lista.filter { clave(it.nombre) != clave(nombre) }

    fun textoDeVencidos(v: List<TemaRepaso>): String = when {
        v.isEmpty() -> "No tienes nada pendiente de repasar hoy."
        v.size == 1 -> "Hoy te toca repasar: ${v[0].nombre}."
        else -> "Hoy te toca repasar: ${v.take(5).joinToString(", ") { it.nombre }}" + if (v.size > 5) " y ${v.size - 5} más." else "."
    }

    /** Lo que se le pide a la IA: solo el nombre del tema, una pregunta a la vez. */
    fun pedidoDeRepaso(tema: String): String =
        "Hazme un repaso tipo examen sobre «${tema.trim().take(80)}» para un estudiante de medicina de segundo año. " +
            "Hazme UNA pregunta de opción múltiple a la vez (A, B, C, D) y espera mi respuesta. Después dime si acerté, explica en una o dos frases " +
            "y sigue con la siguiente. Después de 5 preguntas dime cómo me fue. Responde corto."

    fun serializar(lista: List<TemaRepaso>): String =
        lista.joinToString(FILA.toString()) { "${it.nombre.replace(SEP, ' ').replace(FILA, ' ')}$SEP${it.paso}$SEP${it.proximo}" }

    fun leer(texto: String): List<TemaRepaso> {
        if (texto.isBlank()) return emptyList()
        return texto.split(FILA).mapNotNull {
            val c = it.split(SEP)
            if (c.size != 3) return@mapNotNull null
            val paso = c[1].toIntOrNull() ?: return@mapNotNull null
            val prox = c[2].toLongOrNull() ?: return@mapNotNull null
            if (c[0].isBlank() || paso !in INTERVALOS.indices) null else TemaRepaso(c[0], paso, prox)
        }
    }
}
