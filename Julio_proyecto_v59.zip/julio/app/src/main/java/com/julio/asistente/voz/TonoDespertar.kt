package com.julio.asistente.voz

import android.media.AudioManager
import android.media.ToneGenerator

/** Tono corto (v52) para que se note que Julio oyó su nombre y ya está escuchando. Suave y breve; si el sistema no lo permite, no pasa nada. */
object TonoDespertar {
    fun sonar() {
        try {
            val t = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 55)
            t.startTone(ToneGenerator.TONE_PROP_ACK, 110)
            // El generador se libera solo un poco después de que termine el tono.
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ try { t.release() } catch (e: Exception) { } }, 400L)
        } catch (e: Exception) { }
    }
}
