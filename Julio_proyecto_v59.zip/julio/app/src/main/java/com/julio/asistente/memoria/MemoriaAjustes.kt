package com.julio.asistente.memoria

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Guarda la memoria de Julio (SharedPreferences «julio_memoria») y sus dos interruptores. Todo queda en este teléfono. */
object MemoriaAjustes {
    private const val ARCHIVO = "julio_memoria"
    private val _hechos = MutableStateFlow<List<Hecho>>(emptyList())
    val hechos: StateFlow<List<Hecho>> = _hechos.asStateFlow()
    private val _usarEnIa = MutableStateFlow(true)
    /** Encendido de fábrica: cuando le preguntas algo a la IA, se le pasan (en ese mensaje) los pocos hechos que vienen al caso. */
    val usarEnIa: StateFlow<Boolean> = _usarEnIa.asStateFlow()
    private val _automatica = MutableStateFlow(false)
    /** APAGADO de fábrica: tras cada charla con la IA, una segunda consulta saca datos duraderos y los guarda. */
    val automatica: StateFlow<Boolean> = _automatica.asStateFlow()

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun cargar(c: Context) {
        val p = sp(c)
        _hechos.value = MemoriaLogica.leer(p.getString("hechos", "") ?: "")
        _usarEnIa.value = p.getBoolean("usarEnIa", true)
        _automatica.value = p.getBoolean("automatica", false)
    }

    fun leer(c: Context): List<Hecho> = MemoriaLogica.leer(sp(c).getString("hechos", "") ?: "")

    @Synchronized
    fun guardar(c: Context, lista: List<Hecho>) {
        sp(c).edit().putString("hechos", MemoriaLogica.serializar(lista)).apply()
        _hechos.value = lista
    }

    fun fijarUsarEnIa(c: Context, v: Boolean) { sp(c).edit().putBoolean("usarEnIa", v).apply(); _usarEnIa.value = v }
    fun fijarAutomatica(c: Context, v: Boolean) { sp(c).edit().putBoolean("automatica", v).apply(); _automatica.value = v }
}
