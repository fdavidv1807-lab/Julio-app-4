package com.julio.asistente.ia

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Validación del proveedor de respaldo (lógica pura, se prueba sin Android). */
object ProveedorRespaldo {
    const val URL_POR_DEFECTO = "https://api.groq.com/openai/v1"
    const val MODELO_POR_DEFECTO = "llama-3.3-70b-versatile"

    private val URL_OK = Regex("^https://[A-Za-z0-9.-]+(:[0-9]{1,5})?(/[A-Za-z0-9._~/-]*)?$")
    private val MODELO_OK = Regex("[A-Za-z0-9._:/-]{3,80}")

    /** Solo HTTPS y una dirección sencilla (sin parámetros, sin usuario ni contraseña en la dirección). */
    fun urlValida(u: String): Boolean = URL_OK.matches(u.trim())
    fun modeloValido(m: String): Boolean = MODELO_OK.matches(m.trim())

    /** Dirección final del servicio de conversación. */
    fun direccion(base: String): String = base.trim().trimEnd('/') + "/chat/completions"
}

/**
 * Respaldo (v52): OTRO proveedor gratuito con clave propia que habla el mismo formato que OpenAI («chat/completions»: Groq, OpenRouter, Mistral...).
 * Solo se usa si Gemini llegó a su límite, el modelo ya no existe o el servidor falló. Devuelve solo TEXTO. Bloquea hasta ~40 s: usar fuera del hilo principal.
 * Nunca registra la clave ni la pregunta. Solo se manda lo que la persona dijo (más hasta 3 turnos anteriores), igual que a Gemini.
 */
object Respaldo {
    fun preguntar(base: String, clave: String, modelo: String, historial: List<Turno>, pregunta: String): ResultadoIA {
        if (!ProveedorRespaldo.urlValida(base) || !ProveedorRespaldo.modeloValido(modelo) || clave.isBlank()) return ResultadoIA.Falla(ErrorIA.CLAVE)
        val mensajes = JSONArray()
        mensajes.put(JSONObject().put("role", "system").put("content", PoliticaIA.INSTRUCCION))
        for (t in historial) {
            mensajes.put(JSONObject().put("role", "user").put("content", t.pregunta))
            mensajes.put(JSONObject().put("role", "assistant").put("content", t.respuesta))
        }
        mensajes.put(JSONObject().put("role", "user").put("content", pregunta))
        val cuerpo = JSONObject().put("model", modelo.trim()).put("messages", mensajes).put("temperature", 0.3).put("max_tokens", 1024)

        var conexion: HttpURLConnection? = null
        return try {
            conexion = URL(ProveedorRespaldo.direccion(base)).openConnection() as HttpURLConnection
            conexion.requestMethod = "POST"
            conexion.connectTimeout = 10_000
            conexion.readTimeout = 30_000
            conexion.doOutput = true
            conexion.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conexion.setRequestProperty("Authorization", "Bearer " + clave.trim())
            conexion.outputStream.use { it.write(cuerpo.toString().toByteArray(Charsets.UTF_8)) }
            val codigo = conexion.responseCode
            if (codigo in 200..299) {
                val texto = conexion.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                extraer(texto, modelo)
            } else {
                val err = (conexion.errorStream ?: conexion.inputStream).bufferedReader(Charsets.UTF_8).use { it.readText() }
                ResultadoIA.Falla(PoliticaIA.clasificar(codigo, err))
            }
        } catch (e: IOException) {
            ResultadoIA.Falla(ErrorIA.SIN_RED)
        } catch (e: Exception) {
            ResultadoIA.Falla(ErrorIA.OTRO)
        } finally {
            conexion?.disconnect()
        }
    }

    /** Saca `choices[0].message.content`; si no hay, la respuesta vino vacía o fue bloqueada. */
    private fun extraer(json: String, modelo: String): ResultadoIA {
        val opciones = JSONObject(json).optJSONArray("choices")
        if (opciones == null || opciones.length() == 0) return ResultadoIA.Falla(ErrorIA.BLOQUEADA)
        val texto = opciones.getJSONObject(0).optJSONObject("message")?.optString("content", "")?.trim().orEmpty()
        return if (texto.isEmpty()) ResultadoIA.Falla(ErrorIA.BLOQUEADA) else ResultadoIA.Texto(texto, modelo)
    }
}
