package com.julio.asistente.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Todas las fechas se guardan como milisegundos epoch UTC; se convierten a hora local al mostrarlas. */

@Entity(tableName = "tareas")
data class TareaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titulo: String,
    val descripcion: String = "",
    /** 0 = baja, 1 = media, 2 = alta */
    val prioridad: Int = 1,
    val fechaLimite: Long? = null,
    val completada: Boolean = false,
    val creadaEn: Long = System.currentTimeMillis(),
    /** Aviso el día de la fecha límite, a esta hora (minutos desde medianoche). null = sin aviso. */
    val recordatorioMinutoDia: Int? = null,
)

@Entity(tableName = "actividades")
data class ActividadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titulo: String,
    val descripcion: String = "",
    val inicio: Long,
    val fin: Long? = null,
    /** NINGUNA, DIARIA, SEMANAL, MENSUAL, DIAS */
    val recurrencia: String = "NINGUNA",
    val creadaEn: Long = System.currentTimeMillis(),
    /** Aviso X minutos antes del inicio (0 = al empezar). null = sin aviso. */
    val recordatorioMin: Int? = null,
    /** Solo con recurrencia DIAS: días de la semana (bit 0 = lunes ... bit 6 = domingo). */
    val diasMascara: Int? = null,
    /** Solo con recurrencia DIAS: cada cuántas semanas se repite (null = cada semana). */
    val intervaloSemanas: Int? = null,
    /** Días (epoch day, separados por coma) en que la serie NO ocurre: se movió o eliminó solo esa ocurrencia. */
    val excluidas: String? = null,
)

@Entity(tableName = "alarmas")
data class AlarmaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String = "",
    val hora: Int,
    val minuto: Int,
    /** Fecha concreta (epoch day) para alarmas de una sola vez; null si solo usa días de repetición. */
    val fechaEpochDay: Long? = null,
    /** Máscara de bits de días repetidos: bit 0 = lunes ... bit 6 = domingo. 0 = no se repite. */
    val diasMascara: Int = 0,
    val activa: Boolean = true,
    val sonidoUri: String? = null,
    val creadaEn: Long = System.currentTimeMillis(),
)

@Entity(tableName = "metas")
data class MetaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titulo: String,
    val descripcion: String = "",
    /** 0..100 */
    val progreso: Int = 0,
    val completada: Boolean = false,
    val fechaObjetivo: Long? = null,
    val creadaEn: Long = System.currentTimeMillis(),
)

/**
 * Una rutina (v49): una lista de órdenes (una por línea, tal como se le dicen a Julio) con un disparador.
 * Solo acepta órdenes de nivel 0 y 1 (ver [com.julio.asistente.ejecutor.Ejecutor]).
 */
@Entity(tableName = "rutinas")
data class RutinaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    /** Frase que la dispara por voz (sin acentos ni signos, en minúsculas). Vacía si el disparador no es VOZ. */
    val frase: String = "",
    /** VOZ, HORA o CARGADOR */
    val disparador: String = "VOZ",
    /** Solo con HORA: minutos desde medianoche. */
    val minutoDia: Int? = null,
    /** Solo con HORA: días de la semana (bit 0 = lunes ... bit 6 = domingo). 0 = todos los días. */
    val diasMascara: Int = 0,
    /** Una orden por línea. */
    val acciones: String = "",
    val activa: Boolean = true,
    /** Cuándo se ejecutó por última vez (epoch ms). null = nunca. */
    val ultimaEjecucion: Long? = null,
    val creadaEn: Long = System.currentTimeMillis(),
)

/**
 * Registro de sincronización (v52): qué hay anotado de cada tarea, actividad o alarma para compartirlo con el otro teléfono.
 * [clave] = «creadaEn» del elemento. [datos] = sus campos serializados. [borrado] = lápida. [entregado] = el otro teléfono ya lo confirmó.
 * No toca ninguna tabla existente.
 */
@Entity(tableName = "sync_estado", primaryKeys = ["tipo", "clave"])
data class SyncEstadoEntity(
    val tipo: String,
    val clave: Long,
    val datos: String,
    val actualizadoEn: Long,
    val borrado: Boolean,
    val entregado: Boolean,
)
