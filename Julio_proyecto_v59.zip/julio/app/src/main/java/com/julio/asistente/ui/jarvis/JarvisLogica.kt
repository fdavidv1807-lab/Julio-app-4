package com.julio.asistente.ui.jarvis

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Las pantallas de la interfaz holográfica. JULIO = solo Julio; MANUAL = Julio con las dos burbujas; MI_DIA y CONFIG = Julio se desplazó y sale el menú. */
enum class Vista { JULIO, MANUAL, MI_DIA, CONFIG }

/** De qué lado queda Julio y de cuál el contenido. IZQUIERDA = Julio a la izquierda (se eligió el botón derecho). */
enum class LadoJulio { CENTRO, IZQUIERDA, DERECHA }

/**
 * Lógica pura (sin Compose ni Android) de la interfaz «Jarvis»: se prueba con JUnit.
 */
object JarvisLogica {
    /** Julio se desplaza hacia el lado donde NO se escogió el botón: Configuración (derecha) → Julio a la izquierda; Mi día (izquierda) → a la derecha. */
    fun ladoJulio(v: Vista): LadoJulio = when (v) {
        Vista.JULIO, Vista.MANUAL -> LadoJulio.CENTRO
        Vista.CONFIG -> LadoJulio.IZQUIERDA
        Vista.MI_DIA -> LadoJulio.DERECHA
    }

    /** Lo que hace «atrás» (o tocar a Julio) en cada pantalla. Un panel abierto se cierra primero. */
    fun atras(v: Vista, panelAbierto: Boolean): Pair<Vista, Boolean> = when {
        panelAbierto -> v to false
        v == Vista.MI_DIA || v == Vista.CONFIG -> Vista.MANUAL to false
        v == Vista.MANUAL -> Vista.JULIO to false
        else -> Vista.JULIO to false
    }

    /** Cuántos segundos sin tocar antes de volver solo a «Julio» (el Cuerpo no debe quedarse en un menú). */
    fun segundosParaVolver(v: Vista): Int = when (v) {
        Vista.JULIO -> 0
        Vista.MANUAL -> 20
        Vista.MI_DIA, Vista.CONFIG -> 300
    }

    /** ¿Esta persona puede elegir el modo? Solo la primera vez: después es permanente (se cambia desinstalando). */
    fun puedeElegirModo(actual: ModoApp.Modo): Boolean = actual == ModoApp.Modo.SIN_ELEGIR

    /** ¿Dos valores están (casi) en el mismo lugar? Ayuda para las pruebas. */
    fun cerca(a: Float, b: Float, eps: Float = 1e-4f): Boolean = abs(a - b) < eps
}

/**
 * Cuenta toques sobre Julio: [necesarios] toques seguidos dentro de [ventanaMs] activan el modo manual.
 * Cada toque cuenta desde el primero que sigue vivo; tras activarse empieza de cero.
 */
class ContadorToques(private val necesarios: Int = 4, private val ventanaMs: Long = 2_500L) {
    private val tiempos = ArrayDeque<Long>()

    /** Registra un toque. Devuelve true si este toque completa la secuencia. */
    fun registrar(ahoraMs: Long): Boolean {
        while (tiempos.isNotEmpty() && ahoraMs - tiempos.first() > ventanaMs) tiempos.removeFirst()
        tiempos.addLast(ahoraMs)
        if (tiempos.size >= necesarios) {
            tiempos.clear()
            return true
        }
        return false
    }

    fun reiniciar() = tiempos.clear()
}


/**
 * Menú en cuarto de círculo (v47). El centro del círculo está en la esquina de abajo del lado elegido; el cuarto se divide en
 * sectores (uno por opción) y se gira con el dedo. Todo en grados: φ = 0 es el borde de abajo y φ = 90 el borde de ese lado.
 * La opción 0 queda arriba (φ alto) cuando [scroll] = 0; al girar, las demás suben. Lógica pura: se prueba con JUnit.
 */
object MenuSector {
    const val ABERTURA = 90f
    const val PASO = 27f

    /** Cuánto se puede girar: lo que sobra de las opciones respecto al cuarto de círculo (0 si caben todas). */
    fun giroMaximo(n: Int, paso: Float = PASO): Float = max(0f, n * paso - ABERTURA)

    fun limitar(scroll: Float, n: Int, paso: Float = PASO): Float = scroll.coerceIn(0f, giroMaximo(n, paso))

    /** Al soltar el dedo, el menú se acomoda en la opción más cercana (incluido el final exacto). */
    fun acomodar(scroll: Float, n: Int, paso: Float = PASO): Float {
        val tope = giroMaximo(n, paso)
        val cerca = (scroll / paso).roundToInt() * paso
        val candidatos = listOf(cerca.coerceIn(0f, tope), tope)
        return candidatos.minByOrNull { abs(it - scroll) } ?: 0f
    }

    /** Ángulo φ del centro de la opción [i]. */
    fun anguloCentro(i: Int, scroll: Float, paso: Float = PASO): Float = ABERTURA - (i + 0.5f) * paso + scroll

    /** ¿El texto de la opción cabe dentro del cuarto (su centro no está pegado al borde)? */
    fun textoVisible(i: Int, scroll: Float, paso: Float = PASO): Boolean {
        val c = anguloCentro(i, scroll, paso)
        return c >= paso * 0.35f && c <= ABERTURA - paso * 0.35f
    }

    /** Ángulo φ de un punto a ([dx], [dy]) del centro del cuarto (ambos ≥ 0: dx hacia dentro de la pantalla, dy hacia arriba). */
    fun anguloDePunto(dx: Float, dy: Float): Float = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()

    /** Qué opción hay en el ángulo φ (null si está fuera del cuarto o no hay opción ahí). */
    fun opcionEn(phi: Float, scroll: Float, n: Int, paso: Float = PASO): Int? {
        if (phi < 0f || phi > ABERTURA) return null
        val k = floor((ABERTURA + scroll - phi) / paso).toInt()
        return if (k in 0 until n) k else null
    }

    /** Radio exterior del cuarto (dp): casi todo el ancho o el alto de la pantalla, el menor. */
    fun radioExterior(ancho: Float, alto: Float): Float = min(ancho * 0.92f, alto * 0.98f)

    /** Radio interior: deja libre el hueco de la esquina. */
    fun radioInterior(exterior: Float): Float = exterior * 0.38f
}
