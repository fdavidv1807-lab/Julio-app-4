package com.julio.asistente.comandos

/** Un contacto con su número (ya tomado de la agenda). Los contactos NUNCA salen del teléfono. */
data class ContactoInfo(val nombre: String, val numero: String)

sealed class BusquedaContacto {
    data class Uno(val contacto: ContactoInfo) : BusquedaContacto()
    data class Varios(val contactos: List<ContactoInfo>) : BusquedaContacto()
    object Ninguno : BusquedaContacto()
}

/** Busca entre los contactos al que la persona nombró («mamá», «Ana Pérez»). Lógica pura (se prueba sin Android). */
object Contactos {
    private val RELLENO = Regex("\\b(mi|mis|el|la|los|las|a|al|de|del|por favor|julio)\\b")

    /** Solo dígitos y un «+» inicial. */
    fun limpiarNumero(n: String): String {
        val t = n.trim()
        val digitos = t.filter { it.isDigit() }
        return if (t.startsWith("+")) "+$digitos" else digitos
    }

    private fun palabras(texto: String): List<String> =
        RELLENO.replace(Texto.normalizar(texto), " ").split(Regex("\\s+")).filter { it.isNotBlank() }

    fun buscar(pedido: String, lista: List<ContactoInfo>): BusquedaContacto {
        val buscadas = palabras(pedido)
        if (buscadas.isEmpty()) return BusquedaContacto.Ninguno
        // Un mismo contacto puede aparecer con el mismo número repetido: se junta.
        val unicos = lista.filter { limpiarNumero(it.numero).length >= 3 }
            .distinctBy { Texto.normalizar(it.nombre) + "|" + limpiarNumero(it.numero).takeLast(9) }
        val exactos = unicos.filter { palabras(it.nombre) == buscadas }
        if (exactos.isNotEmpty()) return resultado(exactos)
        val contienen = unicos.filter { c ->
            val p = palabras(c.nombre)
            buscadas.all { b -> p.any { it == b || it.startsWith(b) } }
        }
        return resultado(contienen)
    }

    private fun resultado(c: List<ContactoInfo>): BusquedaContacto {
        if (c.isEmpty()) return BusquedaContacto.Ninguno
        // Varios números del MISMO nombre = una sola persona con varios teléfonos: se pregunta cuál.
        return if (c.size == 1) BusquedaContacto.Uno(c[0]) else BusquedaContacto.Varios(c.take(5))
    }

    /** «terminado en 1234»: así Julio confirma el número sin leerlo entero. */
    fun finalDe(numero: String): String = limpiarNumero(numero).takeLast(4)
}
