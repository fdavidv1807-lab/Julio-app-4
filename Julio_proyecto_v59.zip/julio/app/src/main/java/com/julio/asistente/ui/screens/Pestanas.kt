package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Pestañas sencillas (v58): una fila de botones arriba y debajo el contenido de la elegida. Sirven para juntar pantallas que antes eran
 * entradas separadas de «Mi día» (Hoy + Alarmas, Horario + Tareas, Estudio + Tarjetas + Enfoque) sin tocar ninguna de ellas.
 */
@Composable
fun Pestanas(titulos: List<String>, contenido: @Composable (Int) -> Unit) {
    var elegida by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            titulos.forEachIndexed { i, t ->
                if (i == elegida) Button(onClick = { elegida = i }) { Text(t) } else OutlinedButton(onClick = { elegida = i }) { Text(t) }
            }
        }
        Box(Modifier.weight(1f)) { contenido(elegida) }
    }
}
