package com.julio.asistente.estudio

import com.julio.asistente.repaso.RepasoLogica
import java.util.Random

/** Una tarjeta de estudio: pregunta por un lado, respuesta por el otro. [proximo] = día (epoch day) en que toca repasarla. */
data class Tarjeta(val id: Long, val tema: String, val pregunta: String, val respuesta: String, val paso: Int, val proximo: Long)

/**
 * Tarjetas de estudio y simulacros (v56). Cada tarjeta sigue el mismo calendario del repaso espaciado (1, 3, 7, 14, 30 días):
 * «Bien» sube un paso, «Mal» vuelve al primero. Un simulacro es una tanda al azar de tarjetas con nota al final.
 * Lógica pura (sin Android): se prueba con JUnit y con el espejo de Python.
 */
object TarjetasLogica {
    const val MAX_TARJETAS = 500
    private const val SEP = '\u001F'
    private const val FILA = '\u001E'

    private fun limpio(s: String, max: Int) = s.replace(SEP, ' ').replace(FILA, ' ').trim().take(max)

    /** Agrega una tarjeta (toca repasarla mañana). null si falta pregunta o respuesta, si ya existe esa pregunta en el tema, o si hay demasiadas. */
    fun agregar(lista: List<Tarjeta>, tema: String, pregunta: String, respuesta: String, hoy: Long, id: Long): List<Tarjeta>? {
        val p = limpio(pregunta, 300)
        val r = limpio(respuesta, 600)
        val t = limpio(tema, 60).ifBlank { "General" }
        if (p.isEmpty() || r.isEmpty() || lista.size >= MAX_TARJETAS) return null
        if (lista.any { it.tema.equals(t, ignoreCase = true) && it.pregunta.equals(p, ignoreCase = true) }) return null
        return lista + Tarjeta(id, t, p, r, 0, hoy + RepasoLogica.INTERVALOS[0])
    }

    /** Las que ya tocan, las más atrasadas primero. */
    fun pendientes(lista: List<Tarjeta>, hoy: Long): List<Tarjeta> = lista.filter { it.proximo <= hoy }.sortedBy { it.proximo }

    /** Anota cómo te fue con una tarjeta: bien sube un paso, mal vuelve al primero. */
    fun responder(lista: List<Tarjeta>, id: Long, bien: Boolean, hoy: Long): List<Tarjeta> = lista.map {
        if (it.id != id) it
        else {
            val paso = if (bien) minOf(it.paso + 1, RepasoLogica.INTERVALOS.size - 1) else 0
            it.copy(paso = paso, proximo = hoy + RepasoLogica.INTERVALOS[paso])
        }
    }

    fun quitar(lista: List<Tarjeta>, id: Long): List<Tarjeta> = lista.filter { it.id != id }

    fun temas(lista: List<Tarjeta>): List<String> = lista.map { it.tema }.distinct().sorted()

    /** Tanda al azar para un simulacro: [n] tarjetas (o las que haya), de un tema o de todos. [semilla] fija el orden (para pruebas). */
    fun simulacro(lista: List<Tarjeta>, n: Int, tema: String?, semilla: Long): List<Tarjeta> {
        val base = if (tema == null) lista else lista.filter { it.tema.equals(tema, ignoreCase = true) }
        return base.shuffled(Random(semilla)).take(n.coerceAtLeast(0))
    }

    /** «Sacaste 7 de 10 (70 %). Muy bien.» */
    fun nota(aciertos: Int, total: Int): String {
        if (total <= 0) return "No hubo tarjetas en este simulacro."
        val pct = Math.round(100f * aciertos / total)
        val animo = when {
            pct >= 90 -> "Excelente."
            pct >= 70 -> "Muy bien."
            pct >= 50 -> "Vas bien, repasa las que fallaste."
            else -> "Hay que repasar más; las que fallaste volverán mañana."
        }
        return "Sacaste $aciertos de $total ($pct %). $animo"
    }

    // ---------- Tarjetas hechas por la IA ----------

    fun pedidoDeTarjetas(tema: String, cuantas: Int = 5): String =
        "Crea $cuantas tarjetas de estudio sobre «${tema.trim().take(80)}» para un estudiante de medicina de segundo año. " +
            "Responde SOLO con $cuantas líneas, una por tarjeta, con este formato exacto: pregunta || respuesta. " +
            "La respuesta en una o dos frases. Sin numeración, sin títulos y sin texto extra."

    /** Lee la respuesta de la IA: una tarjeta por línea con «pregunta || respuesta». Ignora numeración, viñetas y líneas sin «||». */
    fun leerDeIa(texto: String): List<Pair<String, String>> = texto.lines().mapNotNull { linea ->
        val sinNumero = linea.trim().replace(Regex("^(?:\\d{1,2}[.)]\\s*|[-•*]\\s+)"), "")
        val partes = sinNumero.split("||")
        if (partes.size != 2) return@mapNotNull null
        val p = partes[0].trim().trim('«', '»', '"')
        val r = partes[1].trim().trim('«', '»', '"')
        if (p.length < 5 || r.isEmpty()) null else p to r
    }

    // ---------- Guardado ----------

    fun serializar(lista: List<Tarjeta>): String = lista.joinToString(FILA.toString()) {
        listOf(it.id.toString(), it.tema, it.pregunta, it.respuesta, it.paso.toString(), it.proximo.toString()).joinToString(SEP.toString())
    }

    fun leer(texto: String): List<Tarjeta> {
        if (texto.isBlank()) return emptyList()
        return texto.split(FILA).mapNotNull {
            val c = it.split(SEP)
            if (c.size != 6) return@mapNotNull null
            val id = c[0].toLongOrNull() ?: return@mapNotNull null
            val paso = c[4].toIntOrNull() ?: return@mapNotNull null
            val prox = c[5].toLongOrNull() ?: return@mapNotNull null
            if (c[2].isBlank() || c[3].isBlank() || paso !in RepasoLogica.INTERVALOS.indices) null else Tarjeta(id, c[1], c[2], c[3], paso, prox)
        }
    }
}
