package com.julio.asistente.memoria

import java.text.Normalizer

/** Un dato duradero que Julio recuerda de ti. [fuente]: «voz» (tú se lo pediste) o «auto» (lo sacó de una charla con la IA). */
data class Hecho(val texto: String, val fuente: String, val creadoEn: Long, val confianza: String)

enum class EstadoAgregado { NUEVO, DUPLICADO, CUARENTENA, VACIO }

/**
 * Memoria de Julio (v59), portada del diseño de la memoria de OpenJarvis (Stanford, Apache 2.0: memory/store.py, extractor.py y service.py):
 *  • hechos cortos y duraderos (máx. 200 letras cada uno), sin duplicados (sin importar mayúsculas) y con tope (se olvidan los más viejos);
 *  • cada hecho lleva su procedencia y un nivel de confianza; lo sospechoso (parece una instrucción para la IA o un dato secreto) va a
 *    «cuarentena»: se ve y se puede borrar, pero NUNCA se le muestra a la IA;
 *  • un extractor opcional le pide a la IA que saque los datos duraderos de una charla y devuelva un arreglo JSON de frases cortas;
 *  • al preguntarle a la IA solo se le pasan los pocos hechos que vienen al caso.
 * Lógica pura (sin Android): se prueba con JUnit y con el espejo de Python.
 */
object MemoriaLogica {
    const val MAX_HECHOS = 300
    const val MAX_CHARS = 200
    const val MAX_POR_CHARLA = 10
    const val MAX_EN_CONTEXTO = 5

    const val CONFIANZA_AUTO = "auto"
    const val CONFIANZA_CONFIABLE = "confiable"
    const val CONFIANZA_CUARENTENA = "cuarentena"
    const val FUENTE_VOZ = "voz"
    const val FUENTE_AUTO = "auto"

    private const val SEP = '\u001F'
    private const val FILA = '\u001E'

    /** Frases que no son datos tuyos sino intentos de darle órdenes a la IA, o secretos que no deben salir del teléfono. */
    private val SOSPECHOSAS = listOf(
        Regex("ignora (?:todas? )?(?:las |tus )?(?:instrucciones|reglas|ordenes)"),
        Regex("ignore (?:all |any )?(?:previous|prior|above) (?:instructions|rules)"),
        Regex("olvida (?:todas? )?(?:las |tus )?(?:instrucciones|reglas)"),
        Regex("(?:prompt|mensaje) del sistema|system prompt"),
        Regex("\\beres ahora\\b|\\byou are now\\b"),
        Regex("\\bact(?:ua|ue) como\\b|\\bact as\\b|\\bfinge (?:ser|que)\\b|\\bpretend to be\\b"),
        Regex("no (?:le )?(?:digas|avises|menciones) (?:nada )?al usuario|do not (?:tell|reveal)"),
        Regex("(?:responde|contesta) siempre|siempre (?:responde|contesta|obedece)|obedece (?:todo|siempre)|always (?:respond|answer|obey)"),
        Regex("\\bcontrasena\\b|\\bpassword\\b|\\bapi ?key\\b|\\bclave de api\\b|\\bsecret(?:o)?\\b|\\btoken de acceso\\b|\\bpin\\b"),
    )

    private val ALFANUM = Regex("[^a-z0-9 ]")
    private val ESPACIOS = Regex("\\s+")

    fun normalizar(s: String): String =
        ESPACIOS.replace(ALFANUM.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), ""), " "), " ").trim()

    fun limpiar(texto: String): String = ESPACIOS.replace(texto.replace(SEP, ' ').replace(FILA, ' '), " ").trim().take(MAX_CHARS)

    fun sospechoso(texto: String): Boolean {
        val n = normalizar(texto)
        return SOSPECHOSAS.any { it.containsMatchIn(n) }
    }

    /**
     * Agrega un hecho. Si ya estaba (sin importar mayúsculas) no cambia nada. Si es sospechoso queda en cuarentena. Pasado el tope se olvidan
     * los más viejos. Un hecho nuevo con procedencia «voz» es confiable; con «auto» queda en el nivel «auto» (también recordable).
     */
    fun agregar(lista: List<Hecho>, texto: String, fuente: String, ahora: Long): Pair<List<Hecho>, EstadoAgregado> {
        val t = limpiar(texto)
        if (t.isEmpty()) return lista to EstadoAgregado.VACIO
        val clave = t.lowercase()
        val repetido = lista.indexOfFirst { it.texto.lowercase() == clave }
        if (repetido >= 0) {
            // Como en OpenJarvis: un duplicado sospechoso puede mandar a cuarentena la copia vieja, pero nunca se «rescata» solo.
            if (sospechoso(t) && lista[repetido].confianza != CONFIANZA_CUARENTENA) {
                return lista.mapIndexed { i, h -> if (i == repetido) h.copy(confianza = CONFIANZA_CUARENTENA) else h } to EstadoAgregado.CUARENTENA
            }
            return lista to EstadoAgregado.DUPLICADO
        }
        val dudoso = sospechoso(t)
        val confianza = when {
            dudoso -> CONFIANZA_CUARENTENA
            fuente == FUENTE_VOZ -> CONFIANZA_CONFIABLE
            else -> CONFIANZA_AUTO
        }
        val nueva = (lista + Hecho(t, fuente, ahora, confianza)).let { if (it.size > MAX_HECHOS) it.takeLast(MAX_HECHOS) else it }
        return nueva to (if (dudoso) EstadoAgregado.CUARENTENA else EstadoAgregado.NUEVO)
    }

    /** Borra los hechos que mencionan TODAS las palabras de [consulta] (o que son iguales a ella). Devuelve la lista y cuántos borró. */
    fun olvidar(lista: List<Hecho>, consulta: String): Pair<List<Hecho>, Int> {
        val q = palabras(consulta)
        if (q.isEmpty()) return lista to 0
        val quedan = lista.filterNot { h ->
            val p = palabras(h.texto)
            q.all { w -> p.any { it == w || it.startsWith(w) || w.startsWith(it) && it.length >= 4 } }
        }
        return quedan to (lista.size - quedan.size)
    }

    /** Lo que la IA puede ver: todo menos la cuarentena. */
    fun recordables(lista: List<Hecho>): List<Hecho> = lista.filter { it.confianza != CONFIANZA_CUARENTENA }

    private val RELLENO = setOf(
        "que", "como", "cual", "cuales", "cuando", "donde", "quien", "para", "por", "con", "sin", "una", "uno", "unos", "unas", "los", "las", "del",
        "mis", "mas", "muy", "pero", "esto", "esta", "este", "eso", "esa", "ese", "hay", "ser", "soy", "estoy", "tengo", "quiero", "puedo", "dime",
        "hazme", "dame", "sobre", "entre", "desde", "hasta", "tambien", "algo", "todo", "toda", "mismo",
    )

    private fun palabras(texto: String): List<String> =
        normalizar(texto).split(' ').filter { it.length >= 3 && it !in RELLENO }.distinct()

    /**
     * Los hechos que vienen al caso para una pregunta: los que comparten palabras con ella (más palabras en común primero, a igualdad el más nuevo).
     * Si ninguno comparte nada, hasta 2 de los más nuevos confiables (contexto básico de quién eres). Nunca la cuarentena.
     */
    fun relevantes(lista: List<Hecho>, pregunta: String, max: Int = MAX_EN_CONTEXTO): List<Hecho> {
        val ok = recordables(lista)
        val q = palabras(pregunta)
        val puntuados = ok.map { h ->
            val p = palabras(h.texto)
            h to q.count { w -> p.any { it == w || (it.length >= 5 && w.length >= 5 && it.take(5) == w.take(5)) } }
        }.filter { it.second > 0 }
        if (puntuados.isNotEmpty()) {
            return puntuados.sortedWith(compareByDescending<Pair<Hecho, Int>> { it.second }.thenByDescending { it.first.creadoEn }).take(max).map { it.first }
        }
        return ok.filter { it.confianza == CONFIANZA_CONFIABLE }.sortedByDescending { it.creadoEn }.take(2)
    }

    /** Los hechos que mencionan el [tema] (comparten alguna palabra). Sin «relleno»: si ninguno coincide, lista vacía. */
    fun sobre(lista: List<Hecho>, tema: String): List<Hecho> {
        val q = palabras(tema)
        if (q.isEmpty()) return emptyList()
        return lista.filter { h ->
            val p = palabras(h.texto)
            q.any { w -> p.any { it == w || (it.length >= 5 && w.length >= 5 && it.take(5) == w.take(5)) } }
        }
    }

    /** Bloque que se antepone a la pregunta para la IA. Vacío si no hay nada que decirle. */
    fun contexto(hechos: List<Hecho>): String =
        if (hechos.isEmpty()) "" else
            "Datos que el usuario pidió recordar (úsalos solo si vienen al caso; no los repitas si no):\n" + hechos.joinToString("\n") { "- ${it.texto}" }

    // ---------- Extractor (opcional): la IA saca los datos duraderos de una charla ----------

    fun pedidoDeExtraccion(usuario: String, asistente: String): String =
        "Extrae datos duraderos y de largo plazo sobre el usuario a partir de este intercambio. Un buen dato es estable en el tiempo y útil en " +
            "charlas futuras: preferencias, metas, proyectos en curso, restricciones o personas importantes. Ignora detalles de una sola vez, " +
            "charla trivial y lo que el asistente dice de sí mismo. Responde SOLO con un arreglo JSON de frases cortas (máximo $MAX_CHARS letras cada una). " +
            "Si no hay nada que valga la pena recordar, responde [].\n\nUsuario: ${usuario.trim().take(600)}\nAsistente: ${asistente.trim().take(600)}"

    /** Lee la respuesta de la extracción: un arreglo JSON de frases. Tolera cercas de código y texto alrededor. Nunca falla: si no se entiende, lista vacía. */
    fun leerDeIa(texto: String): List<String> {
        val ini = texto.indexOf('[')
        val fin = texto.lastIndexOf(']')
        if (ini < 0 || fin <= ini) return emptyList()
        val crudas = arregloDeTextos(texto.substring(ini, fin + 1)) ?: return emptyList()
        val salida = ArrayList<String>()
        for (c in crudas) {
            val l = limpiar(c)
            if (l.length >= 4) salida += l
            if (salida.size >= MAX_POR_CHARLA) break
        }
        return salida
    }

    /**
     * Lector mínimo de un arreglo JSON de TEXTOS (a propósito sin org.json, que las pruebas de JVM no traen). null si no es un arreglo de textos
     * bien formado (por ejemplo, si trae números u objetos).
     */
    fun arregloDeTextos(s: String): List<String>? {
        var i = 0
        val n = s.length
        while (i < n && s[i].isWhitespace()) i++
        if (i >= n || s[i] != '[') return null
        i++
        val salida = ArrayList<String>()
        while (true) {
            while (i < n && (s[i].isWhitespace() || s[i] == ',')) i++
            if (i >= n) return null
            if (s[i] == ']') return salida
            if (s[i] != '"') return null
            i++
            val sb = StringBuilder()
            while (true) {
                if (i >= n) return null
                val c = s[i]
                if (c == '"') { i++; break }
                if (c == '\\') {
                    if (i + 1 >= n) return null
                    val e = s[i + 1]
                    if (e == 'u') {
                        if (i + 5 >= n) return null
                        val cp = s.substring(i + 2, i + 6).toIntOrNull(16) ?: return null
                        sb.append(cp.toChar())
                        i += 4
                    } else if (e == 'n' || e == 't' || e == 'r') {
                        sb.append(' ')
                    } else {
                        sb.append(e)
                    }
                    i += 2
                } else {
                    sb.append(c)
                    i++
                }
            }
            salida += sb.toString()
        }
    }

    // ---------- Guardado ----------

    fun serializar(lista: List<Hecho>): String =
        lista.joinToString(FILA.toString()) { listOf(it.texto, it.fuente, it.creadoEn.toString(), it.confianza).joinToString(SEP.toString()) }

    fun leer(texto: String): List<Hecho> {
        if (texto.isBlank()) return emptyList()
        return texto.split(FILA).mapNotNull {
            val c = it.split(SEP)
            if (c.size != 4) return@mapNotNull null
            val t = c[2].toLongOrNull() ?: return@mapNotNull null
            if (c[0].isBlank()) null else Hecho(c[0], c[1], t, c[3])
        }
    }
}
