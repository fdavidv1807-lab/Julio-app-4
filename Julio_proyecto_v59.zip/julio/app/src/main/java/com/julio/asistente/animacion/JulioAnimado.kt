package com.julio.asistente.animacion

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp as mezclarColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.julio.asistente.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

// Un color por estado.
private val AZUL = Color(0xFF3B82F6)
private val CIAN = Color(0xFF22D3EE)
private val VIOLETA = Color(0xFF8B5CF6)
private val VERDE = Color(0xFF22C55E)
private val INDIGO = Color(0xFF3730A3)
private val AMBAR = Color(0xFFF59E0B)
private val ROJO = Color(0xFFEF4444)

// Las 5 imágenes del holograma (v47: PNG con fondo transparente; el verde de las fotos originales ya se quitó).
private const val IMG_REPOSO = 0 // ojos abiertos, boca cerrada con sonrisa
private const val IMG_OJOS = 1 // ojos cerrados, boca cerrada (parpadeo y dormido)
private const val IMG_MEDIA = 2 // habla, boca a medio abrir
private const val IMG_ABIERTA = 3 // habla, boca abierta
private const val IMG_HABLA_OJOS = 4 // habla con los ojos cerrados (parpadeo mientras habla)

private val DOS_PI = (2.0 * PI).toFloat()
private val UN_PI = PI.toFloat()

// ----- Ajustes del holograma (se afinan aquí, sin tocar nada más) -----
private const val ESCANEO_ALFA = 0.16f // fuerza de las líneas de escaneo (0 = sin líneas)
private const val TINTE_ALFA = 0.10f // tinte suave del color del estado sobre el holograma
private const val BARRIDO_ALFA = 0.20f // fuerza de la franja de luz que sube
private const val RESPLANDOR_ALFA = 0.16f // resplandor suave detrás (NO es un anillo)

/** Sin tocar ni hablar durante este rato (con Julio en reposo y la pantalla abierta), Julio se duerme. */
private const val DORMIR_MS = 10 * 60_000L

/**
 * Calcula, cuadro por cuadro, cómo se ve Julio. No dibuja: solo deja listos los números que usa el Canvas.
 * v47: se quitaron los anillos 3D, las partículas y el ecualizador de las versiones anteriores (los anillos de Julio son
 * ahora los del HUD, `HudAnillos`); aquí solo queda el holograma del gorila.
 */
private class Animador {
    // ----- Lo que se dibuja -----
    var color: Color = AZUL
    var intensidad = 0.5f // 0 a 1: brillo general
    var imagen = IMG_REPOSO
    var escala = 1f
    var dx = 0f // temblor horizontal (fracción del ancho)
    var dy = 0f // saltito (fracción del ancho; negativo = hacia arriba)
    var opacidad = 1f
    var barrido = -1f // 0 a 1: posición de la franja de luz; -1 = apagada
    var inclinacion = 0f // grados
    var lineas = true

    /** Cuánto esperar para el próximo cuadro: 0 = al ritmo de la pantalla; si no, milisegundos. */
    var esperaMs = 100L

    // ----- Memoria interna -----
    private var ultimo = 0L
    private var principalPrevio: Principal? = null
    private var capaVista = -1
    private var capaTipo = Capa.NINGUNA
    private var capaInicio = 0L
    private var nivelMic = 0f
    private var nivelVoz = 0f
    private var boca = 0 // 0 cerrada, 1 media, 2 abierta
    private var palabrasVistas = 0
    private var impulsoInicio = -10_000L
    private var proximoParpadeo = 0L
    private var parpadeoHasta = 0L

    private fun intervaloParpadeo(p: Principal): Long =
        if (p == Principal.ENFOCADO) Random.nextLong(14_000L, 24_000L) else Random.nextLong(3_000L, 6_000L)

    /**
     * @param mic nivel del micrófono (0 a 1).
     * @param habla nivel real de la voz de Julio (0 a 1), o -1 si no hay dato real (voz del teléfono):
     *              entonces la boca sigue el ritmo de las palabras.
     */
    fun actualizar(
        ahora: Long, p: Principal, ev: EventoCapa,
        mic: Float, habla: Float, palabras: Int, colorPorEstado: Boolean,
    ) {
        val dt = if (ultimo == 0L) 16L else (ahora - ultimo).coerceIn(1L, 500L)
        ultimo = ahora
        val t = ahora / 1000f

        // ----- Capa (aviso / error) -----
        if (capaVista == -1) capaVista = ev.id // un aviso viejo no se vuelve a animar al abrir la pantalla
        if (ev.id != capaVista) {
            capaVista = ev.id
            capaTipo = ev.capa
            capaInicio = ahora
        }
        val capaDur = when (capaTipo) {
            Capa.AVISO -> if (p == Principal.ENFOCADO) 900L else 1400L
            Capa.ERROR -> 800L
            Capa.NINGUNA -> 0L
        }
        val capaT = ahora - capaInicio
        val capaViva = capaTipo != Capa.NINGUNA && capaT < capaDur
        val x = if (capaViva) capaT.toFloat() / capaDur.toFloat() else 1f

        // Un impulso por cada palabra (solo se usa si no hay nivel real de la voz).
        if (palabras != palabrasVistas) {
            palabrasVistas = palabras
            impulsoInicio = ahora
        }

        // ----- Estado principal -----
        var colorObjetivo: Color
        var brillo: Float
        var pulso = 0f // cuánto crece el holograma (fracción)
        var op: Float
        when (p) {
            Principal.REPOSO -> {
                colorObjetivo = AZUL
                brillo = 0.55f
                pulso = 0.012f * sin(t * DOS_PI / 5f) // respiración lenta (5 s)
                op = 0.92f
            }
            Principal.DORMIDO -> {
                colorObjetivo = AZUL
                brillo = 0.14f
                pulso = 0.006f * sin(t * DOS_PI / 7f)
                op = 0.42f
            }
            Principal.ESCUCHANDO -> {
                colorObjetivo = CIAN
                brillo = 0.9f
                nivelMic += (mic - nivelMic) * (if (mic > nivelMic) 0.6f else 0.15f)
                pulso = 0.02f + 0.05f * nivelMic
                op = 1f
            }
            Principal.PENSANDO -> {
                colorObjetivo = VIOLETA
                brillo = 0.8f
                pulso = 0.015f + 0.02f * sin(t * DOS_PI / 1.1f)
                op = 0.96f
            }
            Principal.HABLANDO -> {
                colorObjetivo = VERDE
                brillo = 0.9f
                val objetivo = if (habla >= 0f) habla else max(0f, 1f - (ahora - impulsoInicio) / 200f)
                nivelVoz += (objetivo - nivelVoz) * (if (objetivo > nivelVoz) 0.7f else 0.35f)
                pulso = 0.015f + 0.05f * nivelVoz
                op = 1f
            }
            Principal.ENFOCADO -> {
                colorObjetivo = INDIGO
                brillo = 0.6f
                pulso = -0.06f + 0.003f * sin(t * DOS_PI / 8f) // un poco más pequeño y firme
                op = 0.78f
            }
        }
        if (p != Principal.ESCUCHANDO) nivelMic = 0f
        if (p != Principal.HABLANDO) nivelVoz = 0f
        if (!colorPorEstado) colorObjetivo = CIAN

        // ----- Efectos de la capa -----
        var salto = 0f
        var temblor = 0f
        if (capaViva) {
            when (capaTipo) {
                Capa.AVISO -> {
                    if (p == Principal.ENFOCADO) {
                        pulso += 0.04f * sin(UN_PI * x)
                        colorObjetivo = mezclarColor(colorObjetivo, AMBAR, 0.6f)
                    } else {
                        pulso += 0.07f * abs(sin(3f * UN_PI * x)) * (1f - 0.4f * x)
                        colorObjetivo = AMBAR
                        if (capaT < 450L) salto = -0.02f * sin(UN_PI * capaT.toFloat() / 450f)
                    }
                }
                Capa.ERROR -> {
                    colorObjetivo = ROJO
                    val f = 1f - x
                    pulso -= 0.10f * f * f
                    if (capaT < 450L) temblor = 0.014f * sin(capaT.toFloat() * 0.085f) * (1f - capaT.toFloat() / 450f)
                }
                Capa.NINGUNA -> {}
            }
            brillo = max(brillo, 0.75f)
        }

        // ----- Color: cambia suave, salvo al interrumpir (verde a cian al instante) -----
        val interrupcion = principalPrevio == Principal.HABLANDO && p == Principal.ESCUCHANDO
        principalPrevio = p
        color = if (interrupcion) colorObjetivo else mezclarColor(color, colorObjetivo, 1f - exp(-dt / 120f))

        // ----- Parpadeo (no dormido; en enfoque, muy raro) -----
        val puedeParpadear = p != Principal.DORMIDO
        if (puedeParpadear) {
            if (proximoParpadeo == 0L) proximoParpadeo = ahora + intervaloParpadeo(p)
            if (ahora >= proximoParpadeo) {
                parpadeoHasta = ahora + 135L
                proximoParpadeo = ahora + intervaloParpadeo(p)
            }
        }
        val parpadeando = puedeParpadear && ahora < parpadeoHasta

        // ----- Boca al hablar: según el volumen, con histéresis para que no parpadee entre imágenes -----
        if (p == Principal.HABLANDO) {
            boca = when (boca) {
                0 -> if (nivelVoz > 0.42f) 2 else if (nivelVoz > 0.14f) 1 else 0
                1 -> if (nivelVoz > 0.42f) 2 else if (nivelVoz < 0.09f) 0 else 1
                else -> if (nivelVoz < 0.09f) 0 else if (nivelVoz < 0.32f) 1 else 2
            }
        } else {
            boca = 0
        }

        imagen = when {
            p == Principal.DORMIDO -> IMG_OJOS
            p == Principal.HABLANDO && boca > 0 ->
                if (parpadeando) IMG_HABLA_OJOS else if (boca == 1) IMG_MEDIA else IMG_ABIERTA
            parpadeando -> IMG_OJOS
            else -> IMG_REPOSO
        }

        // ----- Barrido de luz sobre el holograma: lento en reposo, más rápido si está activo, ninguno en enfoque ni dormido -----
        val periodoBarrido = when (p) {
            Principal.REPOSO -> 8000L
            Principal.ESCUCHANDO, Principal.PENSANDO, Principal.HABLANDO -> 3000L
            else -> 0L
        }
        barrido = if (periodoBarrido == 0L) -1f else (ahora % periodoBarrido).toFloat() / periodoBarrido.toFloat()
        lineas = p != Principal.DORMIDO

        // Inclinación leve al escuchar (se mueve la imagen COMPLETA, no se deforma).
        val inclObjetivo = if (p == Principal.ESCUCHANDO) -3f else 0f
        inclinacion += (inclObjetivo - inclinacion) * (1f - exp(-dt / 220f))

        // ----- Resultado para dibujar -----
        intensidad = brillo
        escala = 1f + pulso
        opacidad = op
        dx = temblor
        dy = salto

        // ----- Batería: movimiento en vivo solo si hay actividad; en reposo casi quieto -----
        val vivo = capaViva || p == Principal.ESCUCHANDO || p == Principal.PENSANDO || p == Principal.HABLANDO
        esperaMs = when {
            vivo -> 0L
            parpadeando || (puedeParpadear && proximoParpadeo - ahora < 150L) -> 33L
            p == Principal.ENFOCADO -> 150L
            p == Principal.DORMIDO -> 250L
            else -> 66L // reposo: la franja de luz sube suave
        }
    }
}

/**
 * Julio animado: el gorila médico HOLOGRÁFICO (5 imágenes PNG con fondo transparente). Se mueve entre imágenes (ojos, boca) y se
 * le mezclan efectos al dibujarlo: tinte del color del estado, líneas de escaneo y una franja de luz que sube. NO lleva anillos:
 * los anillos son los del HUD (`HudAnillos`).
 *
 * REGLA: los PNG no se editan ni se deforman. Solo se cambia entre imágenes y se escala, mueve o inclina la imagen COMPLETA.
 *
 * @param nivelMic nivel del micrófono (0 a 1) mientras escucha.
 * @param nivelHabla nivel real de la voz de Julio (0 a 1), o -1 si no hay dato real.
 * @param palabras contador de palabras dichas (respaldo para la boca con la voz del teléfono).
 * @param alToque tocar a Julio (si está hablando, lo interrumpe).
 */
@Composable
fun JulioAnimado(
    principal: Principal,
    capa: EventoCapa,
    nivelMic: () -> Float,
    nivelHabla: () -> Float,
    palabras: () -> Int,
    alToque: () -> Unit,
    modifier: Modifier = Modifier,
    colorPorEstado: Boolean = true,
) {
    val reposo = ImageBitmap.imageResource(R.drawable.julio_holo_reposo)
    val ojos = ImageBitmap.imageResource(R.drawable.julio_holo_ojos_cerrados)
    val media = ImageBitmap.imageResource(R.drawable.julio_holo_habla_media)
    val abierta = ImageBitmap.imageResource(R.drawable.julio_holo_habla_abierta)
    val hablaOjos = ImageBitmap.imageResource(R.drawable.julio_holo_habla_ojos)
    val imagenes = remember(reposo, ojos, media, abierta, hablaOjos) { arrayOf(reposo, ojos, media, abierta, hablaOjos) }

    val animador = remember { Animador() }
    var tick by remember { mutableLongStateOf(0L) }
    var toques by remember { mutableIntStateOf(0) }

    val principalAct by rememberUpdatedState(principal)
    val capaAct by rememberUpdatedState(capa)
    val micAct by rememberUpdatedState(nivelMic)
    val hablaAct by rememberUpdatedState(nivelHabla)
    val palabrasAct by rememberUpdatedState(palabras)
    val colorAct by rememberUpdatedState(colorPorEstado)
    val toqueAct by rememberUpdatedState(alToque)

    // Pausar todo cuando la app no está visible.
    val dueno = LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(dueno.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(dueno) {
        val observador = LifecycleEventObserver { _, evento ->
            if (evento == Lifecycle.Event.ON_START) visible = true
            if (evento == Lifecycle.Event.ON_STOP) visible = false
        }
        dueno.lifecycle.addObserver(observador)
        onDispose { dueno.lifecycle.removeObserver(observador) }
    }

    // Un solo bucle de animación.
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (isActive) {
            animador.actualizar(
                ahora = SystemClock.uptimeMillis(),
                p = principalAct,
                ev = capaAct,
                mic = micAct(),
                habla = hablaAct(),
                palabras = palabrasAct(),
                colorPorEstado = colorAct,
            )
            tick++
            if (animador.esperaMs == 0L) withFrameNanos { } else delay(animador.esperaMs)
        }
    }

    // Dormido: tras mucho rato en reposo sin que nadie hable ni toque.
    LaunchedEffect(principal, capa.id, toques, visible) {
        if (principal == Principal.REPOSO && visible) {
            delay(DORMIR_MS)
            JulioEstado.dormir()
        }
    }

    Canvas(
        modifier
            .aspectRatio(640f / 708f)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    toques++
                    JulioEstado.despertar()
                    toqueAct()
                })
            },
    ) {
        if (tick < 0L) return@Canvas // leer «tick» hace que se redibuje en cada cuadro

        val w = size.width
        val h = size.height
        val c = animador.color
        val a = animador.intensidad
        val centro = Offset(w / 2f + animador.dx * w, h / 2f + animador.dy * w)

        // Tamaño de la imagen: ocupa casi todo el cuadro (el PNG ya trae su propio borde luminoso).
        val iw = w * 0.96f * animador.escala
        val ih = iw * 708f / 640f
        val x0 = centro.x - iw / 2f
        val y0 = centro.y - ih / 2f

        // 1) Resplandor suave detrás (sin borde duro; NO es un anillo).
        drawCircle(
            brush = Brush.radialGradient(
                0f to c.copy(alpha = a * RESPLANDOR_ALFA * 2f),
                1f to Color.Transparent,
                center = centro,
                radius = w * 0.55f,
            ),
            radius = w * 0.55f,
            center = centro,
        )

        withTransform({ rotate(animador.inclinacion, centro) }) {
            // 2) El holograma y los efectos que solo se dibujan DONDE hay imagen (SrcAtop).
            drawIntoCanvas { it.saveLayer(Rect(0f, 0f, w, h), Paint()) }
            drawImage(
                image = imagenes[animador.imagen],
                dstOffset = IntOffset(x0.roundToInt(), y0.roundToInt()),
                dstSize = IntSize(iw.roundToInt(), ih.roundToInt()),
                alpha = animador.opacidad,
                filterQuality = FilterQuality.High,
            )
            // Tinte del color del estado.
            drawRect(
                color = c.copy(alpha = TINTE_ALFA * (0.4f + a)),
                topLeft = Offset(x0, y0),
                size = androidx.compose.ui.geometry.Size(iw, ih),
                blendMode = BlendMode.SrcAtop,
            )
            // Líneas de escaneo.
            if (animador.lineas) {
                val paso = 3.dp.toPx()
                val grosor = 1.dp.toPx()
                var y = y0
                while (y < y0 + ih) {
                    drawLine(Color.Black.copy(alpha = ESCANEO_ALFA), Offset(x0, y), Offset(x0 + iw, y), grosor, blendMode = BlendMode.SrcAtop)
                    y += paso
                }
            }
            // Franja de luz que sube.
            if (animador.barrido >= 0f) {
                val yb = y0 + ih * (1f - animador.barrido)
                val alto = ih * 0.14f
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.5f to c.copy(alpha = BARRIDO_ALFA * (0.5f + a)),
                        1f to Color.Transparent,
                        startY = yb - alto,
                        endY = yb + alto,
                    ),
                    topLeft = Offset(x0, yb - alto),
                    size = androidx.compose.ui.geometry.Size(iw, alto * 2f),
                    blendMode = BlendMode.SrcAtop,
                )
            }
            drawIntoCanvas { it.restore() }
        }
    }
}
