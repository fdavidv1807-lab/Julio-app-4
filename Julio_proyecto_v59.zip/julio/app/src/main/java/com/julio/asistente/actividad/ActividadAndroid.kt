package com.julio.asistente.actividad

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import com.julio.asistente.bloqueo.BloqueoControl
import java.time.LocalDate
import java.time.ZoneId

/** Mide el uso real del teléfono con UsageStatsManager (el mismo «Acceso de uso» que ya pide el bloqueo de apps). Solo lee. */
object ActividadAndroid {
    fun hayPermiso(c: Context): Boolean = try { BloqueoControl.permisos(c).acceso } catch (e: Exception) { false }

    /** null si falta el permiso o el sistema no dio datos. [dia] = epoch day. */
    fun resumenDelDia(c: Context, dia: Long): ResumenUso? {
        if (!hayPermiso(c)) return null
        return try {
            val app = c.applicationContext
            val zona = ZoneId.systemDefault()
            val desde = LocalDate.ofEpochDay(dia).atStartOfDay(zona).toInstant().toEpochMilli()
            val hasta = minOf(LocalDate.ofEpochDay(dia + 1).atStartOfDay(zona).toInstant().toEpochMilli(), System.currentTimeMillis())
            if (hasta <= desde) return ResumenUso(dia, emptyList())
            val usm = app.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val porPaquete = HashMap<String, Long>()
            // Los eventos «diarios» pueden repetir una app: se suman. El tiempo cuenta solo con la app en primer plano.
            for (u in usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, desde, hasta).orEmpty()) {
                if (u.lastTimeUsed < desde) continue
                porPaquete[u.packageName] = (porPaquete[u.packageName] ?: 0L) + u.totalTimeInForeground
            }
            val pm = app.packageManager
            val apps = porPaquete.filter { it.value >= 60_000L && it.key != app.packageName && !esDelSistema(it.key) }.map { (p, ms) ->
                var nombre = p
                var categoria = -1
                try {
                    val info = pm.getApplicationInfo(p, 0)
                    nombre = pm.getApplicationLabel(info).toString()
                    if (Build.VERSION.SDK_INT >= 26) categoria = info.category
                } catch (e: Exception) { }
                UsoApp(p, nombre, ActividadUso.categoriaDe(p, categoria), ms)
            }
            ResumenUso(dia, apps)
        } catch (e: Exception) {
            null
        }
    }

    private fun esDelSistema(p: String): Boolean =
        p == "com.android.systemui" || p.contains("launcher") || p == "com.sec.android.app.launcher" || p == "com.google.android.apps.nexuslauncher"
}
