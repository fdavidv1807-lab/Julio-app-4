package com.julio.asistente.sync

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException

/** Tipos de cosas que se sincronizan entre el Cuerpo y el Diario (v52): tareas, actividades del horario y alarmas. */
object TipoSync {
    const val TAREA = "T"
    const val ACTIVIDAD = "A"
    const val ALARMA = "L"
    /** Uso del teléfono de diario por día (clave = epoch day). Solo viaja al Cuerpo para mostrarlo; no se guarda en ninguna tabla real. */
    const val USO = "U"
    val TODOS = listOf(TAREA, ACTIVIDAD, ALARMA, USO)
}

/**
 * Un elemento sincronizable. [clave] identifica al elemento en los dos teléfonos (es su «creadaEn»: milisegundos de creación),
 * [datos] son sus campos ya serializados, [actualizadoEn] decide quién gana y [borrado] es la «lápida» (para no revivir lo borrado).
 */
class RegistroSync(val tipo: String, val clave: Long, val datos: String, val actualizadoEn: Long, val borrado: Boolean) {
    override fun equals(other: Any?): Boolean =
        other is RegistroSync && tipo == other.tipo && clave == other.clave && datos == other.datos &&
            actualizadoEn == other.actualizadoEn && borrado == other.borrado
    override fun hashCode(): Int = ((tipo.hashCode() * 31 + clave.hashCode()) * 31 + datos.hashCode()) * 31 + actualizadoEn.hashCode()
}

/** Cómo se ve el elemento ahora mismo en la base de datos del teléfono (sin hora de cambio: eso lo pone [SyncLogica.diferencias]). */
class Instantanea(val tipo: String, val clave: Long, val datos: String)

/** Lo que el otro teléfono dice haber recibido de nosotros: se marca como entregado. */
class Confirmacion(val tipo: String, val clave: Long, val actualizadoEn: Long)

/** Un paquete de cambios (una ronda del intercambio). */
class LoteSync(val id: String, val tiempo: Long, val hayMas: Boolean, val registros: List<RegistroSync>, val confirmaciones: List<Confirmacion>)

object SyncLogica {
    const val MAX_LOTE = 200
    private const val SEP = '\u001F'

    // ---------- Campos ----------

    private fun limpiar(s: String): String = s.replace(SEP, ' ').replace('\u001E', ' ')

    /** Une los campos en un texto. null se marca aparte para distinguirlo de un texto vacío. */
    fun unir(campos: List<String?>): String = campos.joinToString(SEP.toString()) { if (it == null) "n" else "v" + limpiar(it) }

    fun separar(datos: String): List<String?> = datos.split(SEP).map { if (it.startsWith("v")) it.substring(1) else null }

    // ---------- Combinar ----------

    /**
     * ¿Hay que aplicar [entrante] sobre lo que ya hay ([local], null = no se conoce)? Gana el cambio más reciente.
     * En un empate exacto de hora se decide igual en los dos teléfonos: gana el borrado y, si no, el contenido mayor.
     */
    fun debeAplicar(local: RegistroSync?, entrante: RegistroSync): Boolean {
        if (local == null) return true
        if (entrante.actualizadoEn > local.actualizadoEn) return true
        if (entrante.actualizadoEn < local.actualizadoEn) return false
        if (entrante.borrado == local.borrado && entrante.datos == local.datos) return false
        if (entrante.borrado != local.borrado) return entrante.borrado
        return entrante.datos > local.datos
    }

    /**
     * Compara lo que había anotado ([previos], de UN tipo, con lápidas) con lo que hay ahora ([actuales]) y devuelve los cambios
     * a anotar con la hora [ahora]: elementos nuevos o cambiados, y lápidas de lo que desapareció. Dos elementos con la misma clave:
     * solo cuenta el primero (límite conocido: dos cosas creadas en el mismo milisegundo).
     */
    fun diferencias(previos: List<RegistroSync>, actuales: List<Instantanea>, ahora: Long): List<RegistroSync> {
        val salida = mutableListOf<RegistroSync>()
        val porClave = previos.associateBy { it.clave }
        val vistos = HashSet<Long>()
        for (a in actuales) {
            if (!vistos.add(a.clave)) continue
            val p = porClave[a.clave]
            if (p == null || p.borrado || p.datos != a.datos) salida += RegistroSync(a.tipo, a.clave, a.datos, ahora, false)
        }
        for (p in previos) {
            if (!p.borrado && p.clave !in vistos) salida += RegistroSync(p.tipo, p.clave, p.datos, ahora, true)
        }
        return salida
    }

    // ---------- Formato del lote (se cifra y autentica en Protocolo) ----------

    fun codificarLote(l: LoteSync): ByteArray {
        val b = ByteArrayOutputStream()
        DataOutputStream(b).use {
            it.writeLong(l.tiempo)
            it.writeUTF(l.id.take(40))
            it.writeBoolean(l.hayMas)
            val regs = l.registros.take(MAX_LOTE)
            it.writeShort(regs.size)
            for (r in regs) {
                it.writeUTF(r.tipo)
                it.writeLong(r.clave)
                it.writeUTF(r.datos.take(12_000))
                it.writeLong(r.actualizadoEn)
                it.writeBoolean(r.borrado)
            }
            val confs = l.confirmaciones.take(MAX_LOTE)
            it.writeShort(confs.size)
            for (c in confs) {
                it.writeUTF(c.tipo)
                it.writeLong(c.clave)
                it.writeLong(c.actualizadoEn)
            }
        }
        return b.toByteArray()
    }

    /** null si el contenido está mal formado o trae un tipo desconocido. */
    fun decodificarLote(datos: ByteArray): LoteSync? = try {
        DataInputStream(ByteArrayInputStream(datos)).use {
            val tiempo = it.readLong()
            val id = it.readUTF()
            val hayMas = it.readBoolean()
            val n = it.readUnsignedShort()
            if (n > MAX_LOTE) return null
            val regs = ArrayList<RegistroSync>(n)
            repeat(n) {_ ->
                val tipo = it.readUTF()
                val clave = it.readLong()
                val d = it.readUTF()
                val act = it.readLong()
                val borrado = it.readBoolean()
                if (tipo !in TipoSync.TODOS) return null
                regs += RegistroSync(tipo, clave, d, act, borrado)
            }
            val m = it.readUnsignedShort()
            if (m > MAX_LOTE) return null
            val confs = ArrayList<Confirmacion>(m)
            repeat(m) {_ ->
                val tipo = it.readUTF()
                val clave = it.readLong()
                val act = it.readLong()
                if (tipo !in TipoSync.TODOS) return null
                confs += Confirmacion(tipo, clave, act)
            }
            LoteSync(id, tiempo, hayMas, regs, confs)
        }
    } catch (e: IOException) {
        null
    }
}
