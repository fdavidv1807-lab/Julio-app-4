package com.julio.asistente.voz

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * «Escuchar “Julio” en este teléfono» (v55), solo para el teléfono de diario. Apagado de fábrica. Mientras está encendido y Julio está
 * abierto en pantalla, el diario oye la palabra «Julio» igual que el Cuerpo. Android no deja abrir el micrófono con la app en segundo plano
 * sin un servicio dedicado, así que NO escucha con la pantalla apagada ni con otra app encima.
 */
object DiarioEscucha {
    private const val ARCHIVO = "julio_diario_escucha"
    private val _activo = MutableStateFlow(false)
    val activo: StateFlow<Boolean> = _activo.asStateFlow()

    fun cargar(c: Context) {
        _activo.value = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("activo", false)
    }

    fun fijar(c: Context, valor: Boolean) {
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("activo", valor).apply()
        _activo.value = valor
    }
}
