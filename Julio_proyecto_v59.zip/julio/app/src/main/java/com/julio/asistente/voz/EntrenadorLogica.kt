package com.julio.asistente.voz

import java.text.Normalizer

/**
 * Entrenador de voz (v53), tipo «Hey Google»: la persona dice «Julio» varias veces y Julio APRENDE CÓMO LO OYE el reconocedor.
 * Si a tu voz el reconocedor le entiende «hulio», «yulio» o «julián», esas formas pasan a despertar a Julio también.
 * Además calibra la exigencia de «solo mi voz» con TUS propias muestras (en vez de un valor fijo para todos).
 * Lógica pura (sin Android): se prueba con JUnit y con el espejo de Python.
 */
object EntrenadorLogica {
    const val REPETICIONES = 6
    const val SEGUNDOS_REPETICION = 4
    const val MAX_ALIAS = 6
    const val PALABRA = "julio"

    /** Palabras corrientes que NUNCA se aprenden como «Julio» (despertarían a Julio con cualquier conversación). */
    private val PROHIBIDAS = setOf(
        "el", "la", "los", "las", "un", "una", "y", "a", "o", "no", "si", "de", "que", "lo", "es", "en", "por", "para", "con", "mi", "tu", "su",
        "se", "me", "te", "hola", "gracias", "bueno", "bien", "ya", "ah", "eh", "unk", "pues", "este", "esto", "ese", "eso", "uno", "dos", "tres",
    )

    fun normalizar(w: String): String =
        Normalizer.normalize(w.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim(',', '.', '¡', '!', '¿', '?', ' ', '"')

    fun palabras(texto: String): List<String> =
        texto.split(' ').map { normalizar(it) }.filter { it.isNotEmpty() && it != "[unk]" }

    /** Distancia de edición (cuántas letras hay que cambiar para pasar de una palabra a otra). */
    fun distancia(a: String, b: String): Int {
        if (a == b) return 0
        var anterior = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val actual = IntArray(b.length + 1)
            actual[0] = i
            for (j in 1..b.length) {
                val costo = if (a[i - 1] == b[j - 1]) 0 else 1
                actual[j] = minOf(actual[j - 1] + 1, anterior[j] + 1, anterior[j - 1] + costo)
            }
            anterior = actual
        }
        return anterior[b.length]
    }

    /** ¿Suena a «Julio»? («hulio», «yulio», «julián»…). Exige parecido real en letras y la raíz «ul». */
    fun parecidaAJulio(w: String): Boolean {
        val n = normalizar(w)
        if (n == PALABRA) return true
        if (n.length !in 4..9 || n in PROHIBIDAS) return false
        return distancia(n, PALABRA) <= 2 && n.contains("ul")
    }

    /** ¿Esta frase oída contiene «julio» o algo que suene a «julio»? Sirve para contar los aciertos del entrenamiento. */
    fun contieneParecida(texto: String): Boolean = palabras(texto).any { parecidaAJulio(it) }

    /**
     * De lo que el reconocedor oyó en cada repetición saca las formas que de ahora en adelante despiertan a Julio:
     *  1) las que suenan a «julio»; 2) las que el reconocedor repitió SOLAS en al menos 3 repeticiones (así te entiende a ti).
     * Nunca devuelve «julio» (ya despierta) ni palabras corrientes prohibidas. Máximo [MAX_ALIAS], las más repetidas primero.
     */
    fun aprender(oidos: List<String>): List<String> {
        val veces = LinkedHashMap<String, Int>()
        val soloEsa = HashMap<String, Int>()
        for (t in oidos) {
            val ws = palabras(t)
            for (w in ws.distinct()) veces[w] = (veces[w] ?: 0) + 1
            if (ws.size == 1) soloEsa[ws[0]] = (soloEsa[ws[0]] ?: 0) + 1
        }
        return veces.filter { (w, _) ->
            w != PALABRA && w !in PROHIBIDAS && w.length in 3..10 && (parecidaAJulio(w) || (soloEsa[w] ?: 0) >= 3)
        }.entries.sortedByDescending { it.value }.take(MAX_ALIAS).map { it.key }
    }

    /** ¿El texto trae «julio» o alguna de las formas aprendidas, como palabra entera? */
    fun reconoce(texto: String, aprendidas: Collection<String>): Boolean {
        val set = aprendidas.map { normalizar(it) }.toSet()
        return palabras(texto).any { it == PALABRA || it in set }
    }

    /** Vocabulario para el vigía de despertar de Vosk: «julio», lo aprendido y «[unk]» para todo lo demás. */
    fun gramatica(aprendidas: Collection<String>): String =
        (listOf(PALABRA) + aprendidas.map { normalizar(it) }.filter { it.isNotEmpty() && it != PALABRA }.distinct() + "[unk]")
            .joinToString(prefix = "[", postfix = "]") { "\"$it\"" }

    /** Qué decir en cada repetición: primero solo «Julio» y luego frases cortas (dan más voz para el perfil de «solo mi voz»). */
    fun frase(i: Int): String = when {
        i <= 2 -> "Julio"
        i <= 4 -> "Julio, ¿qué tengo hoy?"
        else -> "Julio, pon música"
    }

    /** Qué pedirle a la persona en cada repetición (como Google: normal, más bajo, más rápido). */
    fun consigna(i: Int): String = when {
        i <= 2 -> "con tu voz normal"
        i <= 4 -> "más bajo, como de noche"
        else -> "más rápido o como cansado"
    }

    /**
     * Exigencia de «solo mi voz» calibrada con las distancias de TUS muestras a tu perfil: un 60 % más amplia que tu muestra más lejana,
     * pero nunca menos que el valor normal ni más que el permisivo (para que no deje pasar a cualquiera).
     */
    fun umbralPersonal(distancias: List<Float>): Float {
        if (distancias.isEmpty()) return HablanteMath.UMBRAL_NORMAL
        return (distancias.max() * 1.6f).coerceIn(HablanteMath.UMBRAL_NORMAL, HablanteMath.UMBRAL_PERMISIVO)
    }

    /** Mínimo de fotogramas de voz (en total, sumando las 6 repeticiones) para armar el perfil de «solo mi voz». */
    const val FRAMES_PERFIL = 100

    /** Lo que se muestra al terminar. */
    fun resumen(aciertos: Int, total: Int, aprendidas: List<String>, soloMiVoz: Boolean? = null): String {
        val oyo = "Te entendí $aciertos de $total veces."
        val base = if (aprendidas.isEmpty()) {
            if (aciertos >= total - 1) "$oyo Tu «Julio» se entiende bien tal cual."
            else "$oyo No encontré una forma estable de tu «Julio». Repite más cerca del micrófono y en un lugar silencioso."
        } else {
            "$oyo Ahora Julio también despierta cuando te oye decir: ${aprendidas.joinToString(", ") { "«$it»" }}."
        }
        return base + when (soloMiVoz) {
            true -> " «Solo mi voz» quedó activado y calibrado a tu voz."
            false -> " No pude armar «solo mi voz» (se oyó poca voz); Julio te hace caso igual. Puedes volver a entrenar cuando quieras."
            null -> ""
        }
    }
}
