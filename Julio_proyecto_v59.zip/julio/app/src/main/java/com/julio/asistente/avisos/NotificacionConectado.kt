package com.julio.asistente.avisos

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.MainActivity
import com.julio.asistente.R
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.core.Permisos

/**
 * Notificación fija «Julio conectado» del teléfono de diario (v52): le recuerda al sistema (Samsung) que Julio está vivo
 * y le dice a la persona que el enlace está vigilando. Solo se muestra con el rol «diario» y el servicio conectado.
 */
object NotificacionConectado {
    private const val ID = 4202

    fun mostrar(c: Context) {
        val app = c.applicationContext
        try {
            if (!Permisos.notificaciones(app)) return
            val abrir = PendingIntent.getActivity(
                app, 0, Intent(app, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val n = NotificationCompat.Builder(app, Canales.CONECTADO)
                .setSmallIcon(R.drawable.ic_enfoque)
                .setContentTitle("Julio conectado")
                .setContentText("Vigilando tus avisos y sincronizando con el Cuerpo.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(abrir)
                .build()
            NotificationManagerCompat.from(app).notify(ID, n)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones: no pasa nada, el diagnóstico lo dice.
        } catch (e: Exception) { }
    }

    fun quitar(c: Context) {
        try { c.applicationContext.getSystemService(NotificationManager::class.java).cancel(ID) } catch (e: Exception) { }
    }
}
