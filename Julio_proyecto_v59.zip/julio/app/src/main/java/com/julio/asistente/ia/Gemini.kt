package com.julio.asistente.ia

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Resultado de una consulta a la IA. */
sealed class ResultadoIA {
    data class Texto(val texto: String, val modelo: String) : ResultadoIA()
    /** La IA propuso una ORDEN (v49, solo si las herramientas están encendidas). [texto] es lo que dijo además (puede venir vacío). La IA no ejecuta nada. */
    data class Orden(val texto: String, val orden: String, val modelo: String) : ResultadoIA()
    data class Falla(val error: ErrorIA) : ResultadoIA()
}

/**
 * Cliente de la API de Gemini (HTTPS, clave del dueño en el encabezado «x-goog-api-key»). Solo devuelve TEXTO: no ejecuta nada.
 * Bloquea hasta ~40 s por modelo: llamar siempre fuera del hilo principal (Dispatchers.IO). Nunca registra la clave ni la pregunta.
 */
object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    /** Prueba cada modelo en orden mientras el error sea de límite, modelo inexistente o servidor; con otro error se detiene. */
    fun preguntar(clave: String, modelos: List<String>, historial: List<Turno>, pregunta: String, herramientas: Boolean = false): ResultadoIA {
        if (modelos.isEmpty()) return ResultadoIA.Falla(ErrorIA.MODELO)
        var ultimo = ErrorIA.OTRO
        for (modelo in modelos) {
            when (val r = unaVez(clave, modelo, historial, pregunta, herramientas)) {
                is ResultadoIA.Texto -> return r
                is ResultadoIA.Orden -> return r
                is ResultadoIA.Falla -> {
                    ultimo = r.error
                    if (!PoliticaIA.sirveProbarOtroModelo(r.error)) return r
                }
            }
        }
        return ResultadoIA.Falla(ultimo)
    }

    private fun turno(rol: String, texto: String): JSONObject =
        JSONObject().put("role", rol).put("parts", JSONArray().put(JSONObject().put("text", texto)))

    private fun unaVez(clave: String, modelo: String, historial: List<Turno>, pregunta: String, herramientas: Boolean): ResultadoIA {
        val contenidos = JSONArray()
        for (t in historial) {
            contenidos.put(turno("user", t.pregunta))
            contenidos.put(turno("model", t.respuesta))
        }
        contenidos.put(turno("user", pregunta))
        val instruccion = if (herramientas) PoliticaIA.INSTRUCCION + " " + PoliticaIA.INSTRUCCION_HERRAMIENTAS else PoliticaIA.INSTRUCCION
        val cuerpo = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruccion))))
            .put("contents", contenidos)
            // Margen amplio: en los modelos que «piensan», ese razonamiento también cuenta contra el máximo.
            .put("generationConfig", JSONObject().put("temperature", 0.3).put("maxOutputTokens", 2048))
        if (herramientas) cuerpo.put("tools", JSONArray().put(herramientaProponerOrden()))

        var conexion: HttpURLConnection? = null
        return try {
            conexion = URL(BASE + modelo + ":generateContent").openConnection() as HttpURLConnection
            conexion.requestMethod = "POST"
            conexion.connectTimeout = 10_000
            conexion.readTimeout = 30_000
            conexion.doOutput = true
            conexion.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conexion.setRequestProperty("x-goog-api-key", clave)
            conexion.outputStream.use { it.write(cuerpo.toString().toByteArray(Charsets.UTF_8)) }
            val codigo = conexion.responseCode
            if (codigo in 200..299) {
                val texto = conexion.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                extraer(texto, modelo)
            } else {
                val err = (conexion.errorStream ?: conexion.inputStream).bufferedReader(Charsets.UTF_8).use { it.readText() }
                ResultadoIA.Falla(PoliticaIA.clasificar(codigo, err))
            }
        } catch (e: IOException) {
            ResultadoIA.Falla(ErrorIA.SIN_RED)
        } catch (e: Exception) {
            ResultadoIA.Falla(ErrorIA.OTRO)
        } finally {
            conexion?.disconnect()
        }
    }

    /** Declaración de la única herramienta: proponer UNA orden en español. No hace nada por sí sola: Julio decide si la ejecuta. */
    private fun herramientaProponerOrden(): JSONObject {
        val propiedades = JSONObject().put(
            "orden",
            JSONObject().put("type", "STRING").put(
                "description",
                "La orden en español, tal como se la diría el usuario a Julio. Ejemplos: «baja el brillo al veinte por ciento», " +
                    "«pon música para estudiar», «silencia el volumen», «inicia enfoque por 25 minutos».",
            ),
        )
        val parametros = JSONObject().put("type", "OBJECT").put("properties", propiedades).put("required", JSONArray().put("orden"))
        val declaracion = JSONObject()
            .put("name", PoliticaIA.NOMBRE_HERRAMIENTA)
            .put("description", "Propone a Julio una orden para el teléfono del usuario. Julio decide si la ejecuta, la confirma o la rechaza.")
            .put("parameters", parametros)
        return JSONObject().put("functionDeclarations", JSONArray().put(declaracion))
    }

    /** Saca el texto de `candidates[0].content.parts[*].text`; si no hay, la respuesta fue bloqueada o vino vacía. */
    private fun extraer(json: String, modelo: String): ResultadoIA {
        val raiz = JSONObject(json)
        val candidatos = raiz.optJSONArray("candidates")
        if (candidatos == null || candidatos.length() == 0) return ResultadoIA.Falla(ErrorIA.BLOQUEADA)
        val partes = candidatos.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        var orden: String? = null
        if (partes != null) {
            for (i in 0 until partes.length()) {
                val parte = partes.getJSONObject(i)
                val t = parte.optString("text", "")
                if (t.isNotEmpty()) sb.append(t)
                val llamada = parte.optJSONObject("functionCall")
                if (llamada != null && orden == null && llamada.optString("name", "") == PoliticaIA.NOMBRE_HERRAMIENTA) {
                    orden = llamada.optJSONObject("args")?.optString("orden", "")?.trim()?.takeIf { it.isNotEmpty() }
                }
            }
        }
        val texto = sb.toString().trim()
        if (orden != null) return ResultadoIA.Orden(texto, orden, modelo)
        return if (texto.isEmpty()) ResultadoIA.Falla(ErrorIA.BLOQUEADA) else ResultadoIA.Texto(texto, modelo)
    }
}
