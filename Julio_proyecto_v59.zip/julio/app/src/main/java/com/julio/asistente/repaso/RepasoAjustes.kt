package com.julio.asistente.repaso

import android.content.Context

/** Guarda la lista de temas de repaso en SharedPreferences («julio_repaso»). Solo nombres y fechas. */
object RepasoAjustes {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("julio_repaso", Context.MODE_PRIVATE)

    fun leer(c: Context): List<TemaRepaso> = RepasoLogica.leer(sp(c).getString("temas", "") ?: "")

    fun guardar(c: Context, lista: List<TemaRepaso>) {
        sp(c).edit().putString("temas", RepasoLogica.serializar(lista)).apply()
    }
}
