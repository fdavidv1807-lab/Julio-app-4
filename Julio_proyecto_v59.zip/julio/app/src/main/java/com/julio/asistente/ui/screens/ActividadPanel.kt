package com.julio.asistente.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.actividad.ActividadAndroid
import com.julio.asistente.actividad.ActividadUso
import com.julio.asistente.actividad.ResumenUso
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.sync.TipoSync
import com.julio.asistente.ui.components.PanelJulio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Configuración > Actividad del teléfono (v52): cuánto se usó hoy el teléfono, por categoría y por app, con barras.
 * En el teléfono de diario lo mide el propio teléfono (Acceso de uso); en el Cuerpo se muestra lo que el diario sincronizó.
 * Los nombres de las apps nunca salen de tu Wi-Fi ni van a la IA.
 */
@Composable
fun ActividadPanel() {
    val ctx = LocalContext.current
    val rol by EnlaceAjustes.rol.collectAsStateWithLifecycle()
    var version by remember { mutableStateOf(0) }
    var resumen by remember { mutableStateOf<ResumenUso?>(null) }
    var mensaje by remember { mutableStateOf("Midiendo…") }
    var semana by remember { mutableStateOf<List<Pair<Long, Long>>>(emptyList()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { version++ }

    LaunchedEffect(version, rol) {
        val dia = LocalDate.now().toEpochDay()
        val r = withContext(Dispatchers.IO) {
            if (rol == RolEnlace.CUERPO) {
                JulioDatabase.get(ctx).syncDao().uno(TipoSync.USO, dia)?.takeIf { !it.borrado }?.let { ActividadUso.leer(dia, it.datos) }
            } else {
                ActividadAndroid.resumenDelDia(ctx, dia)
            }
        }
        resumen = r
        // Últimos 7 días: lo que hay anotado (el diario mide hoy y ayer cada vuelta; los demás días quedan guardados) y hoy en vivo.
        val filas = withContext(Dispatchers.IO) { JulioDatabase.get(ctx).syncDao().deTipo(TipoSync.USO) }
        val porDia = filas.filter { !it.borrado && it.clave in (dia - 6)..dia }
            .associate { it.clave to (ActividadUso.leer(it.clave, it.datos)?.totalMs ?: 0L) }.toMutableMap()
        if (r != null) porDia[dia] = r.totalMs
        semana = ((dia - 6)..dia).map { it to (porDia[it] ?: 0L) }
        mensaje = when {
            r != null -> ""
            rol == RolEnlace.CUERPO -> "Todavía no llegó el uso del teléfono de diario. Ese teléfono necesita el acceso de uso y estar en tu Wi-Fi con la sincronización encendida."
            !ActividadAndroid.hayPermiso(ctx) -> "Falta el acceso de uso: dalo en Permisos, «Acceso de uso»."
            else -> "No pude leer el uso del teléfono."
        }
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val r = resumen
            if (r == null) {
                Text(mensaje, style = MaterialTheme.typography.bodySmall)
            } else if (r.apps.isEmpty()) {
                Text("Todavía no hay uso registrado hoy.", style = MaterialTheme.typography.bodySmall)
            } else {
                Text(
                    (if (rol == RolEnlace.CUERPO) "Hoy, en el teléfono de diario: " else "Hoy: ") + ActividadUso.tiempoHablado(r.totalMs),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text("Por tipo de app", style = MaterialTheme.typography.labelMedium)
                val cats = r.porCategoria()
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Pastel(cats, Modifier.size(110.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        cats.forEachIndexed { i, (nombre, ms) ->
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Box(Modifier.size(10.dp).background(COLORES_PASTEL[i % COLORES_PASTEL.size]))
                                Text(
                                    "  $nombre · ${ActividadUso.tiempoHablado(ms)}",
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }
                }
                Text("Últimos 7 días", style = MaterialTheme.typography.labelMedium)
                BarrasSemana(semana)
                Text("Apps con más tiempo", style = MaterialTheme.typography.labelMedium)
                val top = r.top(8)
                top.forEach { Barra(it.nombre, it.ms, top.first().ms) }
            }
        }
    }
}

@Composable
private fun Barra(etiqueta: String, ms: Long, maxMs: Long) {
    val fraccion = if (maxMs <= 0L) 0f else (ms.toFloat() / maxMs.toFloat()).coerceIn(0.02f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row {
            Text(etiqueta, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text(ActividadUso.tiempoHablado(ms), style = MaterialTheme.typography.bodySmall)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))) {
            Box(Modifier.fillMaxWidth(fraccion).height(8.dp).background(MaterialTheme.colorScheme.primary))
        }
    }
}

private val COLORES_PASTEL = listOf(
    Color(0xFF4285F4), Color(0xFFEA4335), Color(0xFFFBBC05), Color(0xFF34A853), Color(0xFF9C27B0), Color(0xFF00ACC1),
)

/** Gráfico de pastel: cada tipo de app con su porción del tiempo. */
@Composable
private fun Pastel(categorias: List<Pair<String, Long>>, modifier: Modifier) {
    val total = categorias.sumOf { it.second }.coerceAtLeast(1L).toFloat()
    Canvas(modifier) {
        var inicio = -90f
        categorias.forEachIndexed { i, (_, ms) ->
            val barrido = 360f * ms / total
            drawArc(color = COLORES_PASTEL[i % COLORES_PASTEL.size], startAngle = inicio, sweepAngle = barrido, useCenter = true)
            inicio += barrido
        }
    }
}

/** Siete barras (una por día, la última es hoy) con el tiempo total de uso. */
@Composable
private fun BarrasSemana(dias: List<Pair<Long, Long>>) {
    val maximo = dias.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
    Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.Bottom) {
        dias.forEach { (dia, ms) ->
            Column(Modifier.weight(1f), horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                Text(if (ms >= 60_000L) "${ms / 3_600_000L}h${(ms / 60_000L) % 60}" else "", style = MaterialTheme.typography.labelSmall)
                Box(
                    Modifier.fillMaxWidth().height((70f * ms / maximo).coerceAtLeast(2f).dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = if (ms >= 60_000L) 1f else 0.2f)),
                )
                Text(
                    LocalDate.ofEpochDay(dia).dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale("es")).take(3),
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}
