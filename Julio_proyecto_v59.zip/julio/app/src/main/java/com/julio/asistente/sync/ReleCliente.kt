package com.julio.asistente.sync

import org.json.JSONObject
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Habla con Firebase Realtime Database por su API REST (sin librerías). Solo mueve texto ya cifrado. Todo bloquea (hasta ~8 s por llamada):
 * usar fuera del hilo principal. Nunca registra direcciones ni contenido.
 */
object ReleCliente {
    private fun abrir(direccion: String, metodo: String): HttpURLConnection {
        val c = URL(direccion).openConnection() as HttpURLConnection
        c.requestMethod = metodo
        c.connectTimeout = 8_000
        c.readTimeout = 8_000
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        return c
    }

    private fun leerCuerpo(c: HttpURLConnection): String =
        (if (c.responseCode in 200..299) c.inputStream else c.errorStream ?: c.inputStream).bufferedReader(Charsets.UTF_8).use { it.readText() }

    /** Guarda un texto en el buzón. true si Firebase lo aceptó. */
    fun poner(base: String, canal: String, tipo: String, id: String, texto: String): Boolean = try {
        val c = abrir(ReleLogica.direccion(base, canal, tipo, id), "PUT")
        c.doOutput = true
        c.outputStream.use { it.write(JSONObject.quote(texto).toByteArray(Charsets.UTF_8)) }
        val ok = c.responseCode in 200..299
        c.disconnect()
        ok
    } catch (e: IOException) {
        false
    } catch (e: Exception) {
        false
    }

    /** El texto guardado en ese buzón, o null si no hay nada (o no se pudo leer). */
    fun leer(base: String, canal: String, tipo: String, id: String): String? = try {
        val c = abrir(ReleLogica.direccion(base, canal, tipo, id), "GET")
        val cuerpo = if (c.responseCode in 200..299) leerCuerpo(c) else ""
        c.disconnect()
        JSONTokener(cuerpo).nextValue() as? String
    } catch (e: Exception) {
        null
    }

    /** Todos los textos de un buzón: id -> texto. */
    fun listar(base: String, canal: String, tipo: String): Map<String, String> = try {
        val c = abrir(ReleLogica.direccion(base, canal, tipo), "GET")
        val cuerpo = if (c.responseCode in 200..299) leerCuerpo(c) else ""
        c.disconnect()
        val v = JSONTokener(cuerpo).nextValue()
        val salida = HashMap<String, String>()
        if (v is JSONObject) {
            for (k in v.keys()) (v.opt(k) as? String)?.let { salida[k] = it }
        }
        salida
    } catch (e: Exception) {
        emptyMap()
    }

    fun borrar(base: String, canal: String, tipo: String, id: String) {
        try {
            val c = abrir(ReleLogica.direccion(base, canal, tipo, id), "DELETE")
            c.responseCode
            c.disconnect()
        } catch (e: Exception) { /* se limpia en otra vuelta */ }
    }

    /** Prueba la dirección: escribe, lee y borra un texto. null = todo bien; si no, qué pasó. */
    fun probar(base: String): String? {
        if (!ReleLogica.urlValida(base)) return "La dirección no es de Firebase (debe empezar con https:// y terminar en firebaseio.com o firebasedatabase.app)."
        val canal = "prueba" + ReleLogica.nuevoId().take(10)
        return try {
            val direccion = ReleLogica.direccion(base, canal, "req", "x")
            val c = abrir(direccion, "PUT")
            c.doOutput = true
            c.outputStream.use { it.write("\"ok\"".toByteArray()) }
            val codigo = c.responseCode
            c.disconnect()
            when {
                codigo == 401 || codigo == 403 -> "Firebase rechazó la escritura: revisa las reglas de la base de datos (están en GUIA_RELE.md)."
                codigo !in 200..299 -> "Firebase contestó con el código $codigo."
                leer(base, canal, "req", "x") != "ok" -> "Se pudo escribir pero no leer: revisa las reglas."
                else -> { borrar(base, canal, "req", "x"); null }
            }
        } catch (e: IOException) {
            "No pude conectar: revisa el internet y la dirección."
        } catch (e: Exception) {
            e.message ?: "Error desconocido."
        }
    }
}
