package com.julio.asistente.sync

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Ajustes del relé cifrado (SharedPreferences «julio_rele»). APAGADO de fábrica. */
object ReleAjustes {
    private const val ARCHIVO = "julio_rele"
    private val _activo = MutableStateFlow(false)
    val activo: StateFlow<Boolean> = _activo.asStateFlow()
    private val _url = MutableStateFlow("")
    val url: StateFlow<String> = _url.asStateFlow()
    private val _estado = MutableStateFlow("")
    val estado: StateFlow<String> = _estado.asStateFlow()

    fun cargar(c: Context) {
        val p = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)
        _activo.value = p.getBoolean("activo", false)
        _url.value = p.getString("url", "") ?: ""
    }

    fun fijar(c: Context, activo: Boolean, url: String) {
        val limpia = ReleLogica.base(url)
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("activo", activo).putString("url", limpia).apply()
        _activo.value = activo
        _url.value = limpia
    }

    fun ponerEstado(t: String) { _estado.value = t }

    /** ¿Está encendido y con una dirección de Firebase válida? */
    fun listo(): Boolean = _activo.value && ReleLogica.urlValida(_url.value)
}
