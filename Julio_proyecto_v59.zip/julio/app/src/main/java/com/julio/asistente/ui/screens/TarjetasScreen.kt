package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.julio.asistente.estudio.Tarjeta
import com.julio.asistente.estudio.TarjetasAjustes
import com.julio.asistente.estudio.TarjetasLogica
import com.julio.asistente.ui.components.PanelJulio
import java.time.LocalDate

/** Mi día > Estudio con dos pestañas (v56): las sesiones y exámenes de siempre, y las tarjetas de estudio con simulacros. */
@Composable
fun EstudioConTarjetas() {
    var pestana by rememberSaveable { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (pestana == 0) Button(onClick = { pestana = 0 }) { Text("Sesiones y exámenes") } else OutlinedButton(onClick = { pestana = 0 }) { Text("Sesiones y exámenes") }
            if (pestana == 1) Button(onClick = { pestana = 1 }) { Text("Tarjetas") } else OutlinedButton(onClick = { pestana = 1 }) { Text("Tarjetas") }
        }
        Box(Modifier.weight(1f)) { if (pestana == 0) EstudioScreen() else TarjetasScreen() }
    }
}

/**
 * Tarjetas de estudio: repasar las pendientes (calendario de 1, 3, 7, 14 y 30 días) o hacer un simulacro de 10 tarjetas al azar con nota.
 * Se agregan a mano o con la voz («Julio, hazme tarjetas de la mitosis»: la IA las arma y solo recibe el tema). Todo queda en este teléfono.
 */
@Composable
fun TarjetasScreen() {
    val ctx = LocalContext.current
    var lista by remember { mutableStateOf(TarjetasAjustes.leer(ctx)) }
    var hoy by remember { mutableStateOf(LocalDate.now().toEpochDay()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        lista = TarjetasAjustes.leer(ctx) // por si la voz agregó tarjetas mientras tanto
        hoy = LocalDate.now().toEpochDay()
    }
    var cola by remember { mutableStateOf<List<Tarjeta>>(emptyList()) }
    var indice by remember { mutableStateOf(0) }
    var mostrada by remember { mutableStateOf(false) }
    var aciertos by remember { mutableStateOf(0) }
    var enSesion by remember { mutableStateOf(false) }
    var esSimulacro by remember { mutableStateOf(false) }
    var terminado by remember { mutableStateOf(false) }
    var dialogoNueva by remember { mutableStateOf(false) }
    var porBorrar by remember { mutableStateOf<Tarjeta?>(null) }

    fun guardar(nueva: List<Tarjeta>) {
        lista = nueva
        TarjetasAjustes.guardar(ctx, nueva)
    }

    fun empezar(tarjetas: List<Tarjeta>, simulacro: Boolean) {
        cola = tarjetas
        indice = 0
        aciertos = 0
        mostrada = false
        esSimulacro = simulacro
        terminado = false
        enSesion = tarjetas.isNotEmpty()
    }

    fun responder(t: Tarjeta, bien: Boolean) {
        guardar(TarjetasLogica.responder(lista, t.id, bien, hoy))
        if (bien) aciertos++
        if (indice + 1 >= cola.size) {
            terminado = true
            enSesion = false
        } else {
            indice++
            mostrada = false
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (terminado) {
            Text(
                if (esSimulacro) TarjetasLogica.nota(aciertos, cola.size) else "Repaso terminado: $aciertos de ${cola.size} bien.",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
            )
            Text("Las que fallaste vuelven mañana; las que acertaste se espacian más.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = { terminado = false }, modifier = Modifier.fillMaxWidth()) { Text("Volver") }
        } else if (enSesion && indice < cola.size) {
            val t = cola[indice]
            Text(
                "Tarjeta ${indice + 1} de ${cola.size}" + if (esSimulacro) " · Simulacro" else "",
                style = MaterialTheme.typography.labelLarge,
            )
            PanelJulio(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(t.tema, style = MaterialTheme.typography.labelSmall)
                    Text(t.pregunta, style = MaterialTheme.typography.titleMedium)
                    if (mostrada) {
                        Text("Respuesta", style = MaterialTheme.typography.labelMedium)
                        Text(t.respuesta, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            if (!mostrada) {
                Button(onClick = { mostrada = true }, modifier = Modifier.fillMaxWidth()) { Text("Mostrar respuesta") }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { responder(t, false) }, modifier = Modifier.weight(1f)) { Text("Mal") }
                    Button(onClick = { responder(t, true) }, modifier = Modifier.weight(1f)) { Text("Bien") }
                }
            }
            TextButton(onClick = { enSesion = false }) { Text("Salir") }
        } else {
            val pendientes = TarjetasLogica.pendientes(lista, hoy)
            Text("Tarjetas: ${lista.size} · pendientes hoy: ${pendientes.size}", style = MaterialTheme.typography.titleMedium)
            Button(onClick = { empezar(pendientes, false) }, enabled = pendientes.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Text("Repasar pendientes (${pendientes.size})")
            }
            OutlinedButton(
                onClick = { empezar(TarjetasLogica.simulacro(lista, 10, null, System.currentTimeMillis()), true) },
                enabled = lista.size >= 3,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Simulacro de 10 tarjetas") }
            OutlinedButton(onClick = { dialogoNueva = true }, modifier = Modifier.fillMaxWidth()) { Text("Agregar tarjeta") }
            Text(
                "Tip: di «Julio, hazme tarjetas de» y el tema, y la IA las arma por ti (solo recibe el tema).",
                style = MaterialTheme.typography.bodySmall,
            )
            lista.sortedWith(compareBy({ it.tema.lowercase() }, { it.proximo })).forEach { t ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.pregunta, style = MaterialTheme.typography.bodyMedium)
                        val d = t.proximo - hoy
                        Text(
                            t.tema + " · " + if (d <= 0) "toca hoy" else "en $d ${if (d == 1L) "día" else "días"}",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    IconButton(onClick = { porBorrar = t }) { Icon(Icons.Filled.Delete, contentDescription = "Borrar tarjeta") }
                }
            }
        }
    }

    if (dialogoNueva) {
        DialogoNuevaTarjeta(
            temas = TarjetasLogica.temas(lista),
            alCancelar = { dialogoNueva = false },
            alGuardar = { tema, pregunta, respuesta ->
                val nueva = TarjetasLogica.agregar(lista, tema, pregunta, respuesta, hoy, System.currentTimeMillis())
                if (nueva != null) guardar(nueva)
                dialogoNueva = false
            },
        )
    }
    porBorrar?.let { t ->
        AlertDialog(
            onDismissRequest = { porBorrar = null },
            title = { Text("¿Borrar la tarjeta?") },
            text = { Text(t.pregunta) },
            confirmButton = { TextButton(onClick = { guardar(TarjetasLogica.quitar(lista, t.id)); porBorrar = null }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { porBorrar = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun DialogoNuevaTarjeta(temas: List<String>, alCancelar: () -> Unit, alGuardar: (String, String, String) -> Unit) {
    var tema by rememberSaveable { mutableStateOf(temas.firstOrNull() ?: "") }
    var pregunta by rememberSaveable { mutableStateOf("") }
    var respuesta by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = alCancelar,
        title = { Text("Nueva tarjeta") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = tema, onValueChange = { tema = it.take(60) }, label = { Text("Tema (ej. Mitosis)") }, singleLine = true)
                OutlinedTextField(value = pregunta, onValueChange = { pregunta = it.take(300) }, label = { Text("Pregunta") })
                OutlinedTextField(value = respuesta, onValueChange = { respuesta = it.take(600) }, label = { Text("Respuesta") })
            }
        },
        confirmButton = {
            TextButton(onClick = { alGuardar(tema, pregunta, respuesta) }, enabled = pregunta.isNotBlank() && respuesta.isNotBlank()) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = alCancelar) { Text("Cancelar") } },
    )
}
