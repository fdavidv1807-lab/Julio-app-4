package com.julio.asistente.avisos

/** Si los servicios que leen notificaciones están conectados ahora (solo en memoria). Lo escriben los dos listeners. */
object EstadoListener {
    @Volatile var avisosConectado: Boolean = false
    @Volatile var diarioConectado: Boolean = false
}
