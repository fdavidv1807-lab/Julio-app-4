package com.julio.asistente.avisos

import android.app.NotificationManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.core.Permisos
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.escritorio.EscritorioControl

/** Reúne los hechos reales del teléfono para [DiagnosticoAvisos]. Solo lee; no cambia nada. */
object DiagnosticoAvisosAndroid {
    fun hechos(c: Context): HechosAvisos {
        val app = c.applicationContext
        val nm = app.getSystemService(NotificationManager::class.java)
        fun canalActivo(id: String): Boolean = try {
            (nm.getNotificationChannel(id)?.importance ?: NotificationManager.IMPORTANCE_DEFAULT) != NotificationManager.IMPORTANCE_NONE
        } catch (e: Exception) { true }
        val permitidas = Permisos.notificaciones(app) && NotificationManagerCompat.from(app).areNotificationsEnabled()
        val bateria = try {
            (app.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(app.packageName)
        } catch (e: Exception) { true }
        val noMolestar = try {
            val f = nm.currentInterruptionFilter
            f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        } catch (e: Exception) { false }
        val acceso = try { NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName) } catch (e: Exception) { false }
        val rol = EnlaceAjustes.rol.value
        val conectado: Boolean? = if (!acceso) null else when (rol) {
            RolEnlace.DIARIO -> EstadoListener.diarioConectado
            RolEnlace.CUERPO -> EstadoListener.avisosConectado
            else -> null
        }
        val wifi = try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (e: Exception) { false }
        val elegidas = if (rol == RolEnlace.CUERPO) CuerpoAjustes.permitidas.value.size else EnlaceAjustes.permitidas.value.size
        return HechosAvisos(
            notificacionesPermitidas = permitidas,
            canalAlarmasActivo = canalActivo(Canales.ALARMAS),
            canalRecordatoriosActivo = canalActivo(Canales.RECORDATORIOS),
            alarmasExactas = Permisos.alarmasExactas(app),
            sinRestriccionBateria = bateria,
            noMolestarActivo = noMolestar,
            rol = rol.name,
            accesoNotificaciones = acceso,
            listenerConectado = conectado,
            emparejado = EnlaceAjustes.secreto() != null,
            hayWifi = wifi,
            lecturaDeAvisosEncendida = CuerpoAjustes.activo.value,
            modoEscritorioAbierto = EscritorioControl.activo.value,
            appsElegidas = elegidas,
        )
    }

    fun diagnosticar(c: Context): List<LineaDiagnostico> = DiagnosticoAvisos.evaluar(hechos(c))
}
