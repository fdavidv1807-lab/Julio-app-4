package com.julio.asistente.ui.jarvis

/**
 * Primer arranque (v47). Orden pedido por el dueño:
 *  1. VOZ: descargar el reconocedor de voz (Vosk) y la voz neuronal (Piper). Obligatorio.
 *  2. ENTRENAR: aprender su voz (huella numérica, nunca audio).
 *  3. MODO: ¿Cuerpo (escritorio) o Diario? (solo si aún no se eligió; es permanente).
 *  4. PERMISOS: micrófono, notificaciones, acceso a notificaciones y acceso de uso (con atajos para Honor y Samsung).
 *  5. ENLACE (v55): emparejar los dos teléfonos (QR del Cuerpo / escanear en el Diario). Se puede omitir y hacer después.
 *  6. BATERÍA: solo en el Cuerpo (sin restricciones, inicio automático).
 *  7. IA: botón que lleva a Google AI Studio para sacar la clave gratis de Gemini (se puede omitir).
 * Lógica pura (sin Compose ni Android): se prueba con JUnit.
 */
enum class PasoArranque { VOZ, ENTRENAR, MODO, PERMISOS, ENLACE, BATERIA, IA }

object ArranqueLogica {
    private val ORDEN = PasoArranque.values().toList()

    /** ¿Este paso aplica con el modo actual? El modo solo se pregunta si aún no se eligió; la batería solo en el Cuerpo. */
    fun aplica(paso: PasoArranque, modo: ModoApp.Modo): Boolean = when (paso) {
        PasoArranque.MODO -> modo == ModoApp.Modo.SIN_ELEGIR
        PasoArranque.ENLACE -> modo != ModoApp.Modo.SIN_ELEGIR
        PasoArranque.BATERIA -> modo == ModoApp.Modo.ESCRITORIO
        else -> true
    }

    /** El paso que sigue (null = se terminó). */
    fun siguiente(actual: PasoArranque, modo: ModoApp.Modo): PasoArranque? =
        ORDEN.drop(ORDEN.indexOf(actual) + 1).firstOrNull { aplica(it, modo) }

    /** Si el paso guardado ya no aplica (por ejemplo MODO cuando ya se eligió), salta al siguiente que sí. */
    fun normalizar(paso: PasoArranque, modo: ModoApp.Modo): PasoArranque? =
        if (aplica(paso, modo)) paso else siguiente(paso, modo)

    /** «PASO 2 DE 5»: posición entre los pasos que aplican. */
    fun posicion(paso: PasoArranque, modo: ModoApp.Modo): Pair<Int, Int> {
        // Mientras no se haya elegido el modo, se cuenta la batería como si fuera a aplicar solo si se elige Cuerpo: se muestra sin ella.
        val lista = ORDEN.filter { aplica(it, modo) }
        return (lista.indexOf(paso) + 1).coerceAtLeast(1) to lista.size
    }

    /** El reconocedor es obligatorio; la voz neuronal también, salvo que esta compilación no traiga el motor. */
    fun vozLista(voskListo: Boolean, piperLista: Boolean, piperDisponible: Boolean): Boolean =
        voskListo && (piperLista || !piperDisponible)

    /** Obligatorios de la pantalla de permisos. El acceso de uso solo es obligatorio en el Diario. */
    fun permisosListos(microfono: Boolean, notificaciones: Boolean, accesoNotificaciones: Boolean, accesoUso: Boolean, modo: ModoApp.Modo): Boolean =
        microfono && notificaciones && accesoNotificaciones && (modo != ModoApp.Modo.DIARIO || accesoUso)

    /** Cada uno de los pasos de entrenamiento pide un tono distinto (normal, bajo, rápido/cansado). */
    fun consignaEntrenamiento(paso: Int): String = when (paso) {
        1 -> "con tu voz normal"
        2 -> "más bajo, como de noche"
        else -> "más rápido o como cansado"
    }
}

/** Marca del teléfono, para dar las instrucciones del menú de ajustes que le toca. */
enum class Marca { HONOR, SAMSUNG, OTRA }

object MarcaTelefono {
    fun deFabricante(fabricante: String, marca: String = ""): Marca {
        val t = (fabricante + " " + marca).lowercase()
        return when {
            "honor" in t || "huawei" in t -> Marca.HONOR
            "samsung" in t -> Marca.SAMSUNG
            else -> Marca.OTRA
        }
    }

    /** Cuando «Acceso a notificaciones» sale en gris (Android bloquea los ajustes de apps instaladas fuera de la tienda). */
    fun ajustesRestringidos(m: Marca): String = when (m) {
        Marca.SAMSUNG ->
            "Si sale en gris: toca «Abrir información de la app», luego ⋮ (arriba a la derecha) > «Permitir ajustes restringidos». " +
                "Después vuelve y toca «Abrir ajustes» otra vez."
        Marca.HONOR ->
            "Si sale en gris: toca «Abrir información de la app», luego ⋮ (arriba a la derecha) > «Permitir ajustes restringidos». " +
                "Si no ves el ⋮, ábrelo desde Ajustes > Aplicaciones > Julio. Después vuelve y toca «Abrir ajustes»."
        Marca.OTRA ->
            "Si sale en gris: «Abrir información de la app» > ⋮ > «Permitir ajustes restringidos»."
    }

    /** Dónde está «Acceso de uso» si el botón no abre la página directa (NO verificado: cambia con la versión del teléfono). */
    fun accesoUso(m: Marca): String = when (m) {
        Marca.SAMSUNG -> "Si el botón no abre Julio: Ajustes > Aplicaciones > ⋮ > Acceso especial > Acceso de uso de datos > Julio."
        Marca.HONOR -> "Si el botón no abre Julio: Ajustes > Aplicaciones > Acceso especial (o Seguridad) > Acceso de uso > Julio."
        Marca.OTRA -> ""
    }

    /** Qué hacer para que el teléfono no cierre a Julio (solo en el Cuerpo). */
    fun bateria(m: Marca): String = when (m) {
        Marca.SAMSUNG ->
            "1) Toca «Abrir ajustes de batería» y deja Julio en «Sin restricciones». " +
                "2) Ajustes > Batería > Límites de uso en segundo plano > «Apps que nunca se suspenden» > agrega Julio."
        Marca.HONOR ->
            "1) Toca «Abrir ajustes de batería» y deja Julio en «Sin restricciones». " +
                "2) Ajustes > Batería > Inicio de aplicaciones > Julio > «Gestionar manualmente» y activa Inicio automático, " +
                "Inicio secundario y Ejecutar en segundo plano."
        Marca.OTRA ->
            "Toca «Abrir ajustes de batería» y deja Julio en «Sin restricciones»."
    }
}
