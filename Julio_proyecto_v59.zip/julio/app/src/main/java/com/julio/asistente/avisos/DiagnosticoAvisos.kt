package com.julio.asistente.avisos

/** Lo que se pudo comprobar del teléfono para saber por qué Julio no avisa. Los valores null = no se pudo comprobar. */
data class HechosAvisos(
    val notificacionesPermitidas: Boolean,
    val canalAlarmasActivo: Boolean,
    val canalRecordatoriosActivo: Boolean,
    val alarmasExactas: Boolean,
    val sinRestriccionBateria: Boolean,
    val noMolestarActivo: Boolean,
    /** NINGUNO, DIARIO o CUERPO (texto, para que esta lógica no dependa de Android). */
    val rol: String,
    val accesoNotificaciones: Boolean,
    val listenerConectado: Boolean?,
    val emparejado: Boolean,
    val hayWifi: Boolean,
    val lecturaDeAvisosEncendida: Boolean,
    val modoEscritorioAbierto: Boolean,
    val appsElegidas: Int,
)

enum class Gravedad { OK, AVISO, FALLA }

class LineaDiagnostico(val gravedad: Gravedad, val texto: String)

/**
 * Diagnóstico de avisos (v52). Lógica pura: se prueba con JUnit. Mira lo que de verdad hace que Julio NO avise:
 * permisos, canales apagados, batería, No molestar, y en el enlace entre teléfonos: código, Wi-Fi y el servicio que lee avisos.
 * Siempre da el siguiente paso concreto. Las fallas salen primero.
 */
object DiagnosticoAvisos {
    fun evaluar(h: HechosAvisos): List<LineaDiagnostico> {
        val l = mutableListOf<LineaDiagnostico>()
        fun falla(t: String) = l.add(LineaDiagnostico(Gravedad.FALLA, t))
        fun aviso(t: String) = l.add(LineaDiagnostico(Gravedad.AVISO, t))
        fun ok(t: String) = l.add(LineaDiagnostico(Gravedad.OK, t))

        // 1) Los avisos propios de Julio (alarmas, recordatorios, resumen de la mañana).
        if (!h.notificacionesPermitidas) falla("Las notificaciones de Julio están bloqueadas. Actívalas en Ajustes, Apps, Julio, Notificaciones.")
        else ok("Notificaciones de Julio permitidas.")
        if (h.notificacionesPermitidas && !h.canalAlarmasActivo) falla("El canal «Alarmas» está apagado. Actívalo en los ajustes de notificaciones de Julio.")
        if (h.notificacionesPermitidas && !h.canalRecordatoriosActivo) falla("El canal «Recordatorios» está apagado: no llegarán avisos de clases ni tareas. Actívalo en los ajustes de notificaciones de Julio.")
        if (!h.alarmasExactas) falla("Falta el permiso de alarmas exactas: las alarmas y recordatorios pueden llegar tarde o no sonar. Ajustes, Apps, Julio, Alarmas y recordatorios.")
        else ok("Alarmas exactas permitidas.")
        if (!h.sinRestriccionBateria) aviso("La batería de Julio está optimizada: el sistema puede dormirlo y no avisar. Ponla en «Sin restricciones».")
        else ok("Batería sin restricciones.")
        if (h.noMolestarActivo) aviso("No molestar está activo: silencia los avisos. Permite a Julio como excepción o apágalo.")

        // 2) El enlace entre los dos teléfonos y la lectura de notificaciones.
        when (h.rol) {
            "NINGUNO" -> aviso("Este teléfono todavía no es ni Cuerpo ni Diario.")
            "DIARIO" -> {
                if (!h.accesoNotificaciones) falla("Falta el «Acceso a notificaciones» de Julio en este teléfono: sin eso no puede leer tus avisos.")
                else if (h.listenerConectado == false) falla("El servicio que lee notificaciones está desconectado (el sistema lo durmió). Apaga y enciende el acceso a notificaciones de Julio.")
                else ok("Lectura de notificaciones conectada.")
                if (!h.emparejado) falla("No está emparejado con el Cuerpo. Escanea su QR en Configuración, Notificaciones y enlace.")
                else if (!h.hayWifi) aviso("Sin Wi-Fi: los avisos esperan hasta 10 minutos y luego se pierden. Conéctate a la misma Wi-Fi que el Cuerpo.")
                else ok("Emparejado y con Wi-Fi.")
                if (h.appsElegidas == 0) aviso("No hay ninguna app elegida: no se enviará ningún aviso. Elige WhatsApp u otras en Notificaciones y enlace.")
            }
            "CUERPO" -> {
                if (!h.modoEscritorioAbierto) falla("El modo escritorio no está abierto: el Cuerpo no escucha ni lee avisos.")
                if (!h.lecturaDeAvisosEncendida) falla("La lectura de avisos está apagada. Enciéndela en Configuración, Notificaciones y enlace.")
                if (!h.accesoNotificaciones) falla("Falta el «Acceso a notificaciones» de Julio en el Cuerpo.")
                else if (h.listenerConectado == false) falla("El servicio que lee notificaciones está desconectado. Apaga y enciende el acceso a notificaciones de Julio.")
                if (h.lecturaDeAvisosEncendida && h.appsElegidas == 0) aviso("No hay ninguna app elegida para leer en voz alta.")
                if (!h.emparejado) aviso("Todavía no hay código de emparejamiento para el Diario (Mostrar el QR).")
            }
        }
        return l.sortedBy { -it.gravedad.ordinal }
    }

    /** Lo que Julio dice en voz alta: solo lo que falla (máx. 3) y cuántas cosas más hay en pantalla. */
    fun resumenHablado(lineas: List<LineaDiagnostico>): String {
        val malas = lineas.filter { it.gravedad != Gravedad.OK }
        if (malas.isEmpty()) return "Revisé los avisos y todo está bien: permisos, canales, batería y enlace. Si aun así no llega algo, dime qué aviso esperabas."
        val fallas = malas.count { it.gravedad == Gravedad.FALLA }
        val cabeza = if (fallas > 0) "Encontré $fallas ${if (fallas == 1) "falla" else "fallas"}." else "No hay fallas graves, pero hay ${malas.size} ${if (malas.size == 1) "cosa" else "cosas"} que revisar."
        val dichas = malas.take(3).joinToString(" ") { it.texto }
        val resto = malas.size - 3
        return "$cabeza $dichas" + if (resto > 0) " Hay $resto más en la pantalla de diagnóstico." else ""
    }

    fun textoPantalla(lineas: List<LineaDiagnostico>): String = lineas.joinToString("\n") {
        (when (it.gravedad) { Gravedad.OK -> "✓ "; Gravedad.AVISO -> "! "; Gravedad.FALLA -> "✗ " }) + it.texto
    }
}
