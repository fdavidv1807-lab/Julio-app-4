package com.julio.asistente.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.voz.EstadoVosk
import com.julio.asistente.voz.FaseEntrenador
import com.julio.asistente.voz.VozViewModel

/**
 * Entrenador de voz «Julio» (v54): UNO solo, fijo, al estilo de «Hey Google». Un botón, seis repeticiones (~30 s) y listo:
 * Julio aprende cómo suena TU «Julio» y tu voz para «solo mi voz». No hay muestras sueltas ni pasos extra.
 * Si falta el reconocedor de voz sin internet, muestra su descarga aquí mismo.
 */
@Composable
fun EntrenadorVozPanel(vm: VozViewModel) {
    val ctx = LocalContext.current
    val fase by vm.entrenador.collectAsStateWithLifecycle()
    val aprendidas by vm.duenoAprendidas.collectAsStateWithLifecycle()
    val huella by vm.duenoHuella.collectAsStateWithLifecycle()
    val soloMiVoz by vm.soloMiVoz.collectAsStateWithLifecycle()
    val voskEstado by vm.voskEstado.collectAsStateWithLifecycle()
    val mensaje by vm.duenoMensaje.collectAsStateWithLifecycle()
    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.entrenarJulio() }
    val empezar = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.entrenarJulio()
        else pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO)
    }
    val entrenada = huella || aprendidas.isNotEmpty()

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (val f = fase) {
            is FaseEntrenador.Inactivo -> {
                if (voskEstado !is EstadoVosk.Listo) {
                    // Primero el reconocedor de voz (una sola vez): su descarga aparece aquí mismo.
                    Text(
                        "Para entrenar tu voz Julio necesita el reconocedor de voz sin internet. Se descarga una sola vez.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    VoskPanel(vm)
                } else {
                    Text(
                        if (entrenada) "✓ Tu voz está entrenada" else "Entrena tu voz",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (entrenada) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        if (entrenada) {
                            (if (aprendidas.isNotEmpty()) "Julio te entiende también cuando dices: " + aprendidas.joinToString(", ") { "«$it»" } + ". " else "") +
                                (if (soloMiVoz) "«Solo mi voz» está activado." else "")
                        } else {
                            "Un botón, seis repeticiones (unos 30 segundos) y listo. Julio aprende cómo suena tu «Julio» y tu voz. " +
                                "No se guarda audio, solo datos numéricos."
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (mensaje != null) Text(mensaje ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Button(onClick = { empezar() }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (entrenada) "Entrenar otra vez" else "Empezar")
                    }
                    if (huella) {
                        OutlinedButton(onClick = { vm.probarMiVoz() }, modifier = Modifier.fillMaxWidth()) { Text("Probar mi voz (5 segundos)") }
                    }
                    if (entrenada) {
                        OutlinedButton(onClick = { vm.borrarEntrenamiento() }, modifier = Modifier.fillMaxWidth()) { Text("Borrar mi entrenamiento") }
                    }
                }
            }

            is FaseEntrenador.Preparando -> {
                Text(f.mensaje, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }

            is FaseEntrenador.Repitiendo -> {
                Text(
                    "Repetición ${f.i} de ${f.total}",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                Text(
                    if (f.escuchando) "Di: «${f.frase}»" else "Listo",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                Text(
                    f.consigna.replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
                // Puntos de avance, como Google: lleno = hecha.
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    for (n in 1..f.total) {
                        Text(if (n < f.i || (n == f.i && !f.escuchando)) "●" else "○", fontSize = 22.sp, modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
                if (f.oyo != null) {
                    Text(
                        "Te escuché: " + f.oyo,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                    )
                }
            }

            is FaseEntrenador.Listo -> {
                Text("✓ Listo", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text(f.mensaje, style = MaterialTheme.typography.bodyMedium)
                OutlinedButton(onClick = { vm.cerrarEntrenador() }, modifier = Modifier.fillMaxWidth()) { Text("Entendido") }
            }

            is FaseEntrenador.Error -> {
                Text(f.mensaje, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                Button(onClick = { empezar() }, modifier = Modifier.fillMaxWidth()) { Text("Reintentar") }
                OutlinedButton(onClick = { vm.cerrarEntrenador() }, modifier = Modifier.fillMaxWidth()) { Text("Cerrar") }
            }
        }
    }
}
