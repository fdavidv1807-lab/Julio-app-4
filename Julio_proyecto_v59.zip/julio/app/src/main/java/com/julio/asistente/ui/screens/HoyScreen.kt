package com.julio.asistente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.core.Fechas
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.cuerpo.CuerpoAvisos
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.estudio.Agenda
import com.julio.asistente.estudio.EstudioRepo
import com.julio.asistente.estudio.Rachas
import com.julio.asistente.horario.Ocurrencias
import com.julio.asistente.ui.components.PanelJulio
import java.time.LocalDate
import java.time.LocalDateTime

/**
 * Mi día > Hoy (v49): lo que sigue hoy y lo pendiente, con datos reales de Horario, Tareas, Estudio y Avisos, y las tendencias
 * de la semana. Solo lee: no cambia nada.
 */
@Composable
fun HoyScreen() {
    val ctx = LocalContext.current
    val db = remember { JulioDatabase.get(ctx) }
    val flujoActividades = remember { db.actividadDao().observarTodas() }
    val flujoTareas = remember { db.tareaDao().observarTodas() }
    val actividades by flujoActividades.collectAsStateWithLifecycle(initialValue = emptyList())
    val tareas by flujoTareas.collectAsStateWithLifecycle(initialValue = emptyList())
    val examenes by EstudioRepo.examenes.collectAsStateWithLifecycle()
    val avisosActivos by CuerpoAjustes.activo.collectAsStateWithLifecycle()

    val ahora = remember { LocalDateTime.now() }
    val hoy: LocalDate = ahora.toLocalDate()

    val proximas = Ocurrencias.proximas(actividades, ahora, 7).take(4)
    val pendientes = tareas.filter { !it.completada }
    val hechas = tareas.size - pendientes.size
    val vencidas = pendientes.count { it.fechaLimite != null && Fechas.estaVencida(it.fechaLimite, hoy) }
    val estudioHoy = Agenda.deHoy(examenes, hoy)
    val atrasadas = Agenda.atrasadas(examenes, hoy)
    val racha = Rachas.actual(EstudioRepo.diasHechos(), hoy.toEpochDay())
    val minutosPorDia = (6 downTo 0).map { atras ->
        val d = hoy.minusDays(atras.toLong())
        val epoch = d.toEpochDay()
        val min = examenes.flatMap { it.sesiones }.filter { it.hecha && it.hechaEn == epoch }.sumOf { it.minutos }
        d to min
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Hoy", style = MaterialTheme.typography.headlineMedium)
        Text(Fechas.textoLargo(hoy), style = MaterialTheme.typography.bodyMedium)

        Tarjeta("Lo que sigue") {
            if (proximas.isEmpty()) {
                Text("No hay actividades en los próximos 7 días.", style = MaterialTheme.typography.bodyMedium)
            } else {
                proximas.forEach { o ->
                    val cuando = if (o.fecha == hoy) "Hoy" else Fechas.textoLargo(o.fecha)
                    Text("$cuando · ${Fechas.textoHora(o.horaInicio)} · ${o.actividad.titulo}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Tarjeta("Tareas") {
            Text(
                "${pendientes.size} pendientes" + (if (vencidas > 0) " ($vencidas vencidas)" else "") + " · $hechas completadas",
                style = MaterialTheme.typography.bodyMedium,
            )
            pendientes.take(3).forEach { t ->
                val limite = t.fechaLimite?.let { " (hasta ${Fechas.texto(it)})" } ?: ""
                Text("• ${t.titulo}$limite", style = MaterialTheme.typography.bodySmall)
            }
        }

        Tarjeta("Estudio") {
            val minHoy = estudioHoy.sumOf { it.second.minutos }
            Text(
                if (estudioHoy.isEmpty()) "Hoy no tienes sesiones de estudio pendientes."
                else "Hoy: ${estudioHoy.size} sesión(es), $minHoy min.",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (atrasadas.isNotEmpty()) Text("Atrasadas: ${atrasadas.size}", style = MaterialTheme.typography.bodySmall)
            Text("Racha de estudio: $racha día(s).", style = MaterialTheme.typography.bodySmall)
        }

        Tarjeta("Avisos") {
            Text(
                if (avisosActivos) "Avisos recientes en este teléfono: ${CuerpoAvisos.recientes().size}."
                else "La lectura de avisos está apagada (Configuración, Avisos del Cuerpo).",
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        Tarjeta("Tendencias de la semana") {
            val maximo = (minutosPorDia.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
            Text("Minutos de estudio por día (sesiones marcadas como hechas):", style = MaterialTheme.typography.bodySmall)
            Row(
                Modifier.fillMaxWidth().height(96.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                minutosPorDia.forEach { (_, min) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        Text("$min", style = MaterialTheme.typography.labelSmall)
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height((60f * min / maximo).coerceAtLeast(2f).dp)
                                .background(MaterialTheme.colorScheme.primary),
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                minutosPorDia.forEach { (d, _) ->
                    Text(
                        d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.getDefault()).take(2),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Text(
                "Tareas: $hechas completadas y ${pendientes.size} pendientes en total (Julio no guarda el día en que se completó cada una).",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun Tarjeta(titulo: String, contenido: @Composable () -> Unit) {
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleMedium)
            contenido()
        }
    }
}
