package com.julio.asistente.actividad

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.julio.asistente.comandos.ContactoInfo

/** Agenda y llamadas (v52). Los contactos solo se leen en este teléfono: no se envían a la IA, no se guardan y no viajan al otro teléfono. */
object ContactosAndroid {
    fun puedeLeer(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun puedeLlamar(c: Context): Boolean =
        ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED

    /** Todos los contactos con teléfono (hasta 3000). Lista vacía si falta el permiso. */
    fun todos(c: Context): List<ContactoInfo> {
        if (!puedeLeer(c)) return emptyList()
        val salida = ArrayList<ContactoInfo>()
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null,
            )?.use { cur ->
                val iN = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val iT = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cur.moveToNext() && salida.size < 3000) {
                    val nombre = cur.getString(iN).orEmpty()
                    val numero = cur.getString(iT).orEmpty()
                    if (nombre.isNotBlank() && numero.isNotBlank()) salida += ContactoInfo(nombre, numero)
                }
            }
        } catch (e: Exception) { }
        return salida
    }

    /** Marca el número. Con el permiso de llamadas llama directo; sin él abre el marcador con el número puesto. null = bien; si no, el motivo. */
    fun llamar(c: Context, numero: String): String? {
        val limpio = numero.filter { it.isDigit() || it == '+' }
        if (limpio.length < 3) return "el número no es válido"
        return try {
            val accion = if (puedeLlamar(c)) Intent.ACTION_CALL else Intent.ACTION_DIAL
            c.startActivity(Intent(accion, Uri.parse("tel:" + Uri.encode(limpio))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) {
            e.message ?: e.javaClass.simpleName
        }
    }
}
