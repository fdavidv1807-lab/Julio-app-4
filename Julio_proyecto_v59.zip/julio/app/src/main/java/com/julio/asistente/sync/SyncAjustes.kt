package com.julio.asistente.sync

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Ajustes y estado de la sincronización entre el Cuerpo y el Diario (SharedPreferences «julio_sync»; no toca Room). */
object SyncAjustes {
    private const val ARCHIVO = "julio_sync"

    private val _activo = MutableStateFlow(true)
    /** Encendida de fábrica: solo hace algo si los dos teléfonos ya están emparejados. Se puede apagar. */
    val activo: StateFlow<Boolean> = _activo.asStateFlow()

    private val _estado = MutableStateFlow("Todavía no se ha sincronizado.")
    val estado: StateFlow<String> = _estado.asStateFlow()

    private val _pendientes = MutableStateFlow(0)
    /** Cambios que esperan en la cola a que el otro teléfono esté al alcance. */
    val pendientes: StateFlow<Int> = _pendientes.asStateFlow()

    fun cargar(c: Context) {
        _activo.value = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getBoolean("activo", true)
    }

    fun fijarActivo(c: Context, valor: Boolean) {
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putBoolean("activo", valor).apply()
        _activo.value = valor
    }

    fun ponerEstado(texto: String) { _estado.value = texto }
    fun ponerPendientes(n: Int) { _pendientes.value = n }
}
