package com.julio.asistente.sync

import android.content.Context
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.Protocolo
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.escritorio.EscritorioControl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Lado «Cuerpo» del relé cifrado (v57): mientras el modo escritorio está abierto y el relé encendido, revisa cada pocos segundos el buzón
 * «req» del canal, atiende las peticiones del Diario con [SyncCuerpo.responder] (solo horario, tareas y alarmas) y deja la respuesta en «res».
 * No hace nada si el relé está apagado, si este teléfono no es el Cuerpo o si no está emparejado.
 */
object ReleCuerpo {
    private const val ESPERA_ACTIVO_MS = 6_000L
    private const val ESPERA_INACTIVO_MS = 30_000L
    private val iniciado = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val procesados = LinkedHashSet<String>()

    /** Arranca el ciclo (una sola vez por proceso). Seguro llamarlo varias veces. */
    fun iniciar(c: Context) {
        val app = c.applicationContext
        if (!iniciado.compareAndSet(false, true)) return
        scope.launch {
            while (isActive) {
                var espera = ESPERA_INACTIVO_MS
                try { if (vuelta(app)) espera = ESPERA_ACTIVO_MS } catch (e: Exception) { /* una vuelta mala no apaga el ciclo */ }
                delay(espera)
            }
        }
    }

    /** true = el relé está trabajando (se vuelve a mirar pronto). */
    private fun vuelta(app: Context): Boolean {
        if (EnlaceAjustes.rol.value != RolEnlace.CUERPO || !ReleAjustes.listo() || !SyncAjustes.activo.value || !EscritorioControl.activo.value) return false
        val secreto = EnlaceAjustes.secreto() ?: return false
        val clave = Protocolo.claveDe(secreto)
        val canal = ReleLogica.canal(secreto)
        val base = ReleLogica.base(ReleAjustes.url.value)
        for ((id, texto) in ReleCliente.listar(base, canal, ReleLogica.TIPO_PETICION)) {
            if (!ReleLogica.idValido(id) || id in procesados) {
                ReleCliente.borrar(base, canal, ReleLogica.TIPO_PETICION, id)
                continue
            }
            procesados.add(id)
            if (procesados.size > 200) procesados.remove(procesados.first())
            val trama = ReleLogica.deTexto(texto)
            val respuesta = if (trama == null) ReleLogica.envolverRespuesta(Protocolo.ACK_MALFORMADO, null) else SyncCuerpo.responder(app, trama, clave, true)
            ReleCliente.poner(base, canal, ReleLogica.TIPO_RESPUESTA, id, ReleLogica.aTexto(respuesta))
            ReleCliente.borrar(base, canal, ReleLogica.TIPO_PETICION, id)
        }
        return true
    }
}
