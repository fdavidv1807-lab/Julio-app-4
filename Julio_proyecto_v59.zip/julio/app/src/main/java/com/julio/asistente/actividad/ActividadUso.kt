package com.julio.asistente.actividad

import com.julio.asistente.sync.SyncLogica

/** Cuánto se usó una app en un día. */
class UsoApp(val paquete: String, val nombre: String, val categoria: String, val ms: Long)

/** El uso del teléfono en un día ([dia] = epoch day). */
class ResumenUso(val dia: Long, val apps: List<UsoApp>) {
    val totalMs: Long get() = apps.sumOf { it.ms }
    fun top(n: Int): List<UsoApp> = apps.sortedByDescending { it.ms }.take(n)
    fun porCategoria(): List<Pair<String, Long>> =
        apps.groupBy { it.categoria }.map { (c, l) -> c to l.sumOf { it.ms } }.sortedByDescending { it.second }
}

/** Lógica pura del uso del teléfono (v52): categorías, texto hablado y formato para sincronizar. Se prueba sin Android. */
object ActividadUso {
    const val REDES = "Redes y mensajes"
    const val JUEGOS = "Juegos"
    const val MEDIA = "Video y música"
    const val PRODUCTIVIDAD = "Productividad"
    const val OTRAS = "Otras"
    const val MAX_APPS = 15

    private val REDES_PAQUETES = listOf("com.whatsapp", "org.telegram", "com.instagram", "com.facebook", "com.zhiliaoapp", "com.twitter", "com.snapchat", "com.discord")
    private val MEDIA_PAQUETES = listOf("com.google.android.youtube", "com.spotify", "com.netflix", "com.google.android.apps.youtube.music", "tv.twitch")

    /** [categoriaAndroid] = ApplicationInfo.category (-1 si no tiene). Los paquetes conocidos mandan sobre la categoría. */
    fun categoriaDe(paquete: String, categoriaAndroid: Int): String {
        if (REDES_PAQUETES.any { paquete.startsWith(it) }) return REDES
        if (MEDIA_PAQUETES.any { paquete.startsWith(it) }) return MEDIA
        return when (categoriaAndroid) {
            4 -> REDES
            0 -> JUEGOS
            1, 2 -> MEDIA
            7 -> PRODUCTIVIDAD
            else -> OTRAS
        }
    }

    /** «2 horas y 5 minutos», «40 minutos», «menos de un minuto». */
    fun tiempoHablado(ms: Long): String {
        val min = ms / 60_000L
        if (min < 1) return "menos de un minuto"
        val h = min / 60
        val m = min % 60
        val horas = if (h == 1L) "1 hora" else "$h horas"
        val minutos = if (m == 1L) "1 minuto" else "$m minutos"
        return when {
            h == 0L -> minutos
            m == 0L -> horas
            else -> "$horas y $minutos"
        }
    }

    fun resumenHablado(r: ResumenUso, esHoy: Boolean = true): String {
        if (r.apps.isEmpty() || r.totalMs < 60_000L) return "No hay uso del teléfono registrado ${if (esHoy) "hoy" else "ese día"}."
        val cabeza = "${if (esHoy) "Hoy" else "Ese día"} usaste el teléfono ${tiempoHablado(r.totalMs)}."
        val top = r.top(3).joinToString(", ") { "${it.nombre} ${tiempoHablado(it.ms)}" }
        val cat = r.porCategoria().firstOrNull()?.let { " Lo que más: ${it.first.lowercase()}, ${tiempoHablado(it.second)}." } ?: ""
        return "$cabeza Las apps con más tiempo: $top.$cat"
    }

    /** Campos en grupos de 4: paquete, nombre, categoría, milisegundos. Solo las [MAX_APPS] con más uso (y más de 1 minuto). */
    fun serializar(r: ResumenUso): String {
        val campos = ArrayList<String?>()
        for (a in r.apps.filter { it.ms >= 60_000L }.sortedByDescending { it.ms }.take(MAX_APPS)) {
            campos += a.paquete.take(150); campos += a.nombre.take(60); campos += a.categoria; campos += a.ms.toString()
        }
        return SyncLogica.unir(campos)
    }

    fun leer(dia: Long, datos: String): ResumenUso? {
        if (datos.isEmpty()) return ResumenUso(dia, emptyList())
        val c = SyncLogica.separar(datos)
        if (c.size % 4 != 0) return null
        val apps = ArrayList<UsoApp>()
        for (i in c.indices step 4) {
            apps += UsoApp(c[i] ?: return null, c[i + 1] ?: return null, c[i + 2] ?: OTRAS, c[i + 3]?.toLongOrNull() ?: return null)
        }
        return ResumenUso(dia, apps)
    }
}
