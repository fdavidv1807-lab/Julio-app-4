package com.julio.asistente.sync

import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.data.local.TareaEntity

/**
 * Convierte tareas, actividades y alarmas a campos de texto y de vuelta (v52). Lógica pura (sin Android).
 * Lo que es propio de cada teléfono NO viaja: el sonido elegido de una alarma. Los textos largos se cortan al serializar
 * (así los dos teléfonos guardan exactamente lo mismo y no se «rebotan» cambios).
 */
object SerializadorSync {
    fun datosTarea(t: TareaEntity): String = SyncLogica.unir(
        listOf(t.titulo.take(300), t.descripcion.take(4000), t.prioridad.toString(), t.fechaLimite?.toString(), if (t.completada) "1" else "0", t.recordatorioMinutoDia?.toString()),
    )

    fun tareaDe(datos: String, clave: Long, id: Long): TareaEntity? {
        val c = SyncLogica.separar(datos)
        if (c.size < 6) return null
        return TareaEntity(
            id = id, titulo = c[0] ?: return null, descripcion = c[1] ?: "", prioridad = c[2]?.toIntOrNull() ?: 1,
            fechaLimite = c[3]?.toLongOrNull(), completada = c[4] == "1", creadaEn = clave, recordatorioMinutoDia = c[5]?.toIntOrNull(),
        )
    }

    fun datosActividad(a: ActividadEntity): String = SyncLogica.unir(
        listOf(
            a.titulo.take(300), a.descripcion.take(4000), a.inicio.toString(), a.fin?.toString(), a.recurrencia,
            a.recordatorioMin?.toString(), a.diasMascara?.toString(), a.intervaloSemanas?.toString(), a.excluidas?.take(2000),
        ),
    )

    fun actividadDe(datos: String, clave: Long, id: Long): ActividadEntity? {
        val c = SyncLogica.separar(datos)
        if (c.size < 9) return null
        return ActividadEntity(
            id = id, titulo = c[0] ?: return null, descripcion = c[1] ?: "", inicio = c[2]?.toLongOrNull() ?: return null,
            fin = c[3]?.toLongOrNull(), recurrencia = c[4] ?: "NINGUNA", creadaEn = clave, recordatorioMin = c[5]?.toIntOrNull(),
            diasMascara = c[6]?.toIntOrNull(), intervaloSemanas = c[7]?.toIntOrNull(), excluidas = c[8],
        )
    }

    fun datosAlarma(a: AlarmaEntity): String = SyncLogica.unir(
        listOf(a.nombre.take(100), a.hora.toString(), a.minuto.toString(), a.fechaEpochDay?.toString(), a.diasMascara.toString(), if (a.activa) "1" else "0"),
    )

    /** [sonido] = el sonido que ya tenía la alarma en ESTE teléfono (null si es nueva). */
    fun alarmaDe(datos: String, clave: Long, id: Long, sonido: String?): AlarmaEntity? {
        val c = SyncLogica.separar(datos)
        if (c.size < 6) return null
        return AlarmaEntity(
            id = id, nombre = c[0] ?: "", hora = c[1]?.toIntOrNull() ?: return null, minuto = c[2]?.toIntOrNull() ?: return null,
            fechaEpochDay = c[3]?.toLongOrNull(), diasMascara = c[4]?.toIntOrNull() ?: 0, activa = c[5] == "1", sonidoUri = sonido, creadaEn = clave,
        )
    }
}
