package com.julio.asistente.sync

import java.util.Base64
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Relé cifrado (v57), lógica pura. El relé es una base de datos gratis de Firebase (Realtime Database) que solo guarda TEXTO CIFRADO de
 * extremo a extremo con el secreto del QR: ni el servidor ni nadie sin ese secreto puede leer ni alterar nada. Solo sirve para sincronizar
 * horario, tareas y alarmas fuera de casa (nunca avisos, ni códigos, ni el uso del teléfono). Apagado de fábrica.
 * Dos buzones por canal: «req» (peticiones del Diario) y «res» (respuestas del Cuerpo).
 */
object ReleLogica {
    const val TIPO_PETICION = "req"
    const val TIPO_RESPUESTA = "res"

    private val URL_FIREBASE = Regex("^https://[a-z0-9][a-z0-9-]*(\\.[a-z0-9-]+)*\\.(firebaseio\\.com|firebasedatabase\\.app)$")
    private val ID_OK = Regex("[a-f0-9]{32}")

    fun base(url: String): String = url.trim().trimEnd('/')

    /** Solo bases de Firebase Realtime Database y solo por HTTPS (nunca una dirección cualquiera). */
    fun urlValida(url: String): Boolean = URL_FIREBASE.matches(base(url))

    /** Nombre secreto del canal: HMAC del secreto del QR. Quien no tiene el QR no lo puede adivinar ni sacar del texto cifrado. */
    fun canal(secreto: ByteArray): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secreto, "HmacSHA256"))
        return mac.doFinal("julio-rele-v1".toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(32)
    }

    fun nuevoId(): String = UUID.randomUUID().toString().replace("-", "")

    /** Solo ids que este programa crea (evita que un nombre raro se cuele en la dirección). */
    fun idValido(id: String): Boolean = ID_OK.matches(id)

    fun direccion(base: String, canal: String, tipo: String, id: String? = null): String =
        base(base) + "/julio/" + canal + "/" + tipo + (if (id != null) "/$id" else "") + ".json"

    fun aTexto(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    fun deTexto(texto: String): ByteArray? = try { Base64.getDecoder().decode(texto) } catch (e: IllegalArgumentException) { null }

    /** La respuesta del Cuerpo: un byte de aceptación y, si todo salió bien, la trama cifrada con sus cambios. */
    fun envolverRespuesta(ack: Int, trama: ByteArray?): ByteArray = byteArrayOf(ack.toByte()) + (trama ?: ByteArray(0))

    class Respuesta(val ack: Int, val trama: ByteArray?)

    fun leerRespuesta(bytes: ByteArray): Respuesta? =
        if (bytes.isEmpty()) null else Respuesta(bytes[0].toInt() and 0xFF, if (bytes.size > 1) bytes.copyOfRange(1, bytes.size) else null)
}
