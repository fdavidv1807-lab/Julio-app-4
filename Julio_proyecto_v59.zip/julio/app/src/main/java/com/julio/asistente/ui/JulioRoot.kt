package com.julio.asistente.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.ui.jarvis.InterfazDiario
import com.julio.asistente.ui.jarvis.ModoApp
import com.julio.asistente.ui.jarvis.PantallaElegirModo
import com.julio.asistente.ui.jarvis.PantallaPrimerArranque
import com.julio.asistente.ui.jarvis.PrimerArranque
import com.julio.asistente.ui.screens.EscritorioScreen
import com.julio.asistente.voz.VozViewModel

/**
 * Raíz de la app (v47). La primera vez va el PRIMER ARRANQUE: primero se deja bien a Julio (voz), luego se entrena la voz, luego se
 * elige el modo de este teléfono (queda PERMANENTE: se cambia desinstalando y reinstalando), luego los permisos.
 *  - ESCRITORIO: el Cuerpo de Julio (solo Julio; «modo manual» o 4 toques abren Mi día y Configuración).
 *  - DIARIO: Julio con Mi día, Configuración y Consola a la vista.
 * Se quitaron la navegación lateral, la barra superior y el panel derecho de las versiones anteriores.
 */
@Composable
fun JulioRoot() {
    val ctx = LocalContext.current
    // Un solo VozViewModel para toda la app (así hay un solo motor de voz).
    val vozVm: VozViewModel = viewModel()
    val modo by ModoApp.modo.collectAsStateWithLifecycle()
    // Primer arranque (v47): voz → entrenar voz → modo → permisos → batería (solo Cuerpo) → IA. Se hace una sola vez.
    var arranqueListo by remember { mutableStateOf(PrimerArranque.terminado(ctx)) }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (!arranqueListo) {
            PantallaPrimerArranque(vozVm) { arranqueListo = true }
        } else {
            when (modo) {
                // No debería pasar (el modo se elige dentro del primer arranque), pero por si acaso:
                ModoApp.Modo.SIN_ELEGIR -> PantallaElegirModo { elegido -> ModoApp.elegir(ctx, elegido) }
                ModoApp.Modo.DIARIO -> InterfazDiario(vozVm)
                ModoApp.Modo.ESCRITORIO -> {
                    EscritorioScreen(vozVm)
                    LaunchedEffect(Unit) {
                        if (!EscritorioControl.activo.value) EscritorioControl.entrar(ctx)
                    }
                }
            }
        }
    }
}
