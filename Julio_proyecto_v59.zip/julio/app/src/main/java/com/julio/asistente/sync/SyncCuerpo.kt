package com.julio.asistente.sync

import android.content.Context
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.Protocolo
import com.julio.asistente.enlace.Verificador
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.io.InputStream
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Lado «Cuerpo» de la sincronización (v52, ampliado en v57): atiende una petición del Diario. Primero aplica lo del Diario y SOLO DESPUÉS
 * contesta «OK» con sus propios cambios; así el Diario nunca saca de su cola algo que el Cuerpo no guardó.
 * [responder] hace el trabajo y lo usan dos caminos: el servidor local (Wi-Fi) y el relé cifrado (fuera de casa).
 */
object SyncCuerpo {
    private val verificador = Verificador()
    private val horaFmt get() = SimpleDateFormat("HH:mm", Locale.getDefault())

    private fun solo(codigo: Int): ByteArray = byteArrayOf(codigo.toByte())

    /**
     * Procesa UNA petición ya leída y devuelve la respuesta: un byte de aceptación y, si todo salió bien, la trama cifrada con los cambios
     * del Cuerpo. [soloHorario] = viene del relé: no se mezcla el uso del teléfono. Bloquea: usar fuera del hilo principal.
     */
    fun responder(app: Context, trama: ByteArray, clave: ByteArray, soloHorario: Boolean): ByteArray {
        val carga = Protocolo.decodificarSync(trama, clave)
        if (carga == null) {
            EnlaceAjustes.ponerEstado("Un teléfono sin el código correcto intentó sincronizar (rechazado).")
            return solo(Protocolo.ACK_NO_AUTORIZADO)
        }
        val lote = SyncLogica.decodificarLote(carga) ?: return solo(Protocolo.ACK_MALFORMADO)
        val r = verificador.revisarId(lote.id, lote.tiempo, System.currentTimeMillis())
        if (r != Protocolo.ACK_OK) return solo(r)
        if (!SyncAjustes.activo.value) return solo(Protocolo.ACK_SIN_PERMISO)
        val respuesta = try {
            runBlocking(Dispatchers.IO) {
                val recibidos = Sincronizador.recibir(app, lote, soloHorario)
                val pend = Sincronizador.prepararLote(app, soloHorario)
                LoteSync(UUID.randomUUID().toString(), System.currentTimeMillis(), pend.hayMas, pend.registros, recibidos)
            }
        } catch (e: Exception) {
            return solo(Protocolo.ACK_NO_DISPONIBLE)
        }
        SyncAjustes.ponerEstado("Sincronizado con el Diario${if (soloHorario) " (por el relé)" else ""} a las ${horaFmt.format(Date())}.")
        return ReleLogica.envolverRespuesta(Protocolo.ACK_OK, Protocolo.codificarSync(SyncLogica.codificarLote(respuesta), clave))
    }

    /** [entrada] es el flujo con la trama todavía sin leer (el servidor ya miró los dos primeros bytes). */
    fun atender(app: Context, s: Socket, entrada: InputStream, clave: ByteArray) {
        val trama = Protocolo.leerTramaSync(entrada)
        s.getOutputStream().write(responder(app, trama, clave, false))
        s.getOutputStream().flush()
    }
}
