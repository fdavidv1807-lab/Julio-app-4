package com.julio.asistente.rutinas

import com.julio.asistente.comandos.Intencion
import com.julio.asistente.comandos.Interprete
import com.julio.asistente.comandos.Texto
import com.julio.asistente.data.local.RutinaEntity
import com.julio.asistente.ejecutor.Decision
import com.julio.asistente.ejecutor.Ejecutor
import com.julio.asistente.ejecutor.Solicitante
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/** Qué dijo el dueño sobre las rutinas. */
sealed class ComandoRutina {
    object Listar : ComandoRutina()
    data class Ejecutar(val nombre: String) : ComandoRutina()
    data class Alternar(val nombre: String, val activar: Boolean) : ComandoRutina()
    data class Crear(val nombre: String, val acciones: List<String>) : ComandoRutina()
    /** «Borra la rutina X»: Julio no borra por voz; manda a la pantalla. */
    data class Borrar(val nombre: String) : ComandoRutina()
    /** «Instala las rutinas básicas» (v52): crea «Buenos días», «Me voy a dormir» y «Modo concentración» si no existen. */
    object InstalarBasicas : ComandoRutina()
}

/** Una rutina de ejemplo lista para instalar. Solo usa órdenes de nivel 0 y 1. */
class PlantillaRutina(val nombre: String, val acciones: List<String>)

/** Lógica pura de las rutinas (v49): se prueba con JUnit y con el espejo de Python (`espejo10.py`). */
object RutinasLogica {
    const val VOZ = "VOZ"
    const val HORA = "HORA"
    const val CARGADOR = "CARGADOR"
    /** v51: al llegar un aviso que Julio lee en voz alta (solo cuenta que llegó; el texto del aviso NUNCA se usa). */
    const val AVISO = "AVISO"
    const val MAX_ACCIONES = 8
    const val MAX_NOMBRE = 40
    /** Una rutina de HORA se dispara si Julio la ve dentro de estos minutos después de su hora (por si estaba hablando). */
    const val VENTANA_MIN = 5

    private val RELLENO = setOf("julio", "por", "favor", "porfa", "oye", "hola", "ey")

    fun normalizar(texto: String): String = Texto.normalizar(texto)

    /** Una orden por línea, sin espacios sobrantes ni líneas vacías. */
    fun acciones(texto: String): List<String> =
        texto.split("\n", ";").map { it.trim() }.filter { it.isNotEmpty() }

    /** «7:30» o «07:30» -> 450 minutos; null si no es una hora válida. */
    fun parsearHora(texto: String): Int? {
        val m = Regex("^\\s*([01]?\\d|2[0-3])\\s*[:.hH]\\s*([0-5]\\d)\\s*$").find(texto) ?: return null
        return m.groupValues[1].toInt() * 60 + m.groupValues[2].toInt()
    }

    fun textoHora(minutoDia: Int): String = "%02d:%02d".format(minutoDia / 60, minutoDia % 60)

    private fun sinRelleno(normal: String): List<String> = normal.split(" ").filter { it.isNotEmpty() && it !in RELLENO }

    /** ¿Lo que se dijo es exactamente la frase de la rutina (sin «Julio», «por favor»…)? Igualdad completa, nunca «contiene». */
    fun coincideVoz(frase: String, dicho: String): Boolean {
        val a = sinRelleno(normalizar(frase))
        val b = sinRelleno(normalizar(dicho))
        return a.isNotEmpty() && a == b
    }

    /** La rutina de voz activa que coincide con lo dicho, o null. */
    fun porVoz(rutinas: List<RutinaEntity>, dicho: String): RutinaEntity? =
        rutinas.firstOrNull { it.activa && it.disparador == VOZ && coincideVoz(it.frase, dicho) }

    /** Busca por nombre: igualdad primero y luego «contiene». */
    fun buscar(rutinas: List<RutinaEntity>, nombre: String): RutinaEntity? {
        val n = normalizar(nombre)
        if (n.isEmpty()) return null
        return rutinas.firstOrNull { normalizar(it.nombre) == n } ?: rutinas.firstOrNull { normalizar(it.nombre).contains(n) }
    }

    /**
     * ¿Toca disparar una rutina de HORA? Solo si está activa, es de hoy (según los días), la hora ya llegó pero no pasaron más de
     * [VENTANA_MIN] minutos, y no se ejecutó ya hoy a esa hora o después.
     */
    fun tocaAhora(r: RutinaEntity, ahora: LocalDateTime, zona: ZoneId = ZoneId.systemDefault()): Boolean {
        if (!r.activa || r.disparador != HORA) return false
        val minuto = r.minutoDia ?: return false
        val dia = ahora.dayOfWeek.value - 1 // lunes = 0
        if (r.diasMascara != 0 && (r.diasMascara shr dia) and 1 == 0) return false
        val ahoraMin = ahora.hour * 60 + ahora.minute
        if (ahoraMin < minuto || ahoraMin - minuto >= VENTANA_MIN) return false
        val ultima = r.ultimaEjecucion ?: return true
        val inicio = ahora.toLocalDate().atTime(minuto / 60, minuto % 60).atZone(zona).toInstant().toEpochMilli()
        return ultima < inicio
    }

    // ---------- Validar las órdenes de una rutina ----------

    /** Devuelve los problemas de una orden (lista vacía = sirve). Usa el mismo intérprete y los mismos niveles que la ejecución. */
    fun problemasDe(orden: String, hoy: LocalDate, ahora: LocalTime): List<String> {
        val i = Interprete.interpretar(orden, hoy, ahora)
        val d = Ejecutor.decidir(Solicitante.RUTINA, i)
        if (d is Decision.Rechazar) return listOf("«$orden»: ${d.motivo}.")
        val falta = when (i) {
            is Intencion.CrearAlarma -> if (i.hora == null && i.enMinutos == null) "dime a qué hora o en cuántos minutos" else null
            is Intencion.AbrirApp -> if (i.nombre.isNullOrBlank()) "falta decir qué app abrir" else null
            is Intencion.PreguntarIA -> if (i.pregunta.isBlank()) "falta la pregunta" else null
            else -> null
        }
        return if (falta != null) listOf("«$orden»: $falta.") else emptyList()
    }

    /** Problemas de toda la rutina (nombre, órdenes, disparador). Lista vacía = se puede guardar. */
    fun validar(
        nombre: String, disparador: String, minutoDia: Int?, acciones: List<String>,
        hoy: LocalDate = LocalDate.now(), ahora: LocalTime = LocalTime.now(),
    ): List<String> {
        val errores = mutableListOf<String>()
        if (nombre.isBlank()) errores += "Falta el nombre."
        if (nombre.trim().length > MAX_NOMBRE) errores += "El nombre es muy largo (máximo $MAX_NOMBRE letras)."
        if (disparador == VOZ && sinRelleno(normalizar(nombre)).isEmpty()) errores += "El nombre sirve de frase para llamarla por voz: necesita al menos una palabra."
        if (disparador == HORA && minutoDia == null) errores += "Falta la hora."
        if (disparador != VOZ && disparador != HORA && disparador != CARGADOR && disparador != AVISO) errores += "Disparador desconocido."
        if (acciones.isEmpty()) errores += "Agrega al menos una orden."
        if (acciones.size > MAX_ACCIONES) errores += "Máximo $MAX_ACCIONES órdenes por rutina."
        for (a in acciones.take(MAX_ACCIONES)) errores += problemasDe(a, hoy, ahora)
        return errores
    }

    /** Resumen corto del disparador para listas y para decirlo en voz alta. */
    fun textoDisparador(r: RutinaEntity): String = when (r.disparador) {
        HORA -> {
            val h = r.minutoDia?.let { textoHora(it) } ?: "?"
            val d = if (r.diasMascara == 0) "todos los días" else nombresDias(r.diasMascara)
            "a las $h, $d"
        }
        CARGADOR -> "al conectar el cargador"
        AVISO -> "al llegar un aviso"
        else -> "al decir «${r.nombre}»"
    }

    private val DIAS = listOf("lun", "mar", "mié", "jue", "vie", "sáb", "dom")

    fun nombresDias(mascara: Int): String = DIAS.filterIndexed { k, _ -> (mascara shr k) and 1 == 1 }.joinToString(", ")

    // ---------- Órdenes de voz sobre rutinas ----------

    private val CORTE = Regex(
        "\\s+y\\s+(?=(pon|sube|baja|silencia|abre|activa|inicia|empieza|comienza|pausa|deten|reanuda|sigue|termina|finaliza|" +
            "siguiente|retrocede|dime|cuales|cual|cuanto|cuantas|muestra|muestrame|programa|crea|enciende|apaga|quita|consulta)\\b)",
    )
    private val SEPARADOR = Regex("\\s*,\\s*|\\s*;\\s*|\\s+(?:y\\s+)?(?:luego|despues|ademas)\\s+")

    /** Separa «sube el volumen, pon música y baja el brillo» en tres órdenes (ya normalizadas, sin acentos). */
    fun separarOrdenes(normal: String): List<String> =
        normal.split(SEPARADOR).flatMap { it.split(CORTE) }.map { it.trim() }.filter { it.isNotEmpty() }

    private val CREAR = Regex(
        "^(?:julio\\s+)?(?:crea|crear|haz|hacer|agrega|agregar|programa|programar|guarda|guardar)\\s+(?:una\\s+|la\\s+|mi\\s+)?(?:nueva\\s+)?rutina\\s+" +
            "(?:de\\s+|llamada\\s+)?(.+?)\\s+(?:que\\s+haga|que\\s+ejecute|que\\s+diga|que|con)\\s+(.+)$",
    )
    private val LISTAR = Regex("\\b(que|cuales|dime|lista|muestrame|muestra|mis)\\b.*\\brutinas?\\b|\\brutinas?\\b.*\\b(tengo|hay|guardadas|activas)\\b")
    private val ALTERNAR = Regex("^(?:julio\\s+)?(enciende|prende|activa|activar|apaga|desactiva|desactivar)\\s+(?:la\\s+)?rutina\\s+(?:de\\s+)?(.+)$")
    private val EJECUTAR = Regex("^(?:julio\\s+)?(?:ejecuta|ejecutar|corre|correr|lanza|lanzar|haz|hacer|inicia|iniciar|empieza|comienza)\\s+(?:la\\s+)?rutina\\s+(?:de\\s+)?(.+)$")
    private val BORRAR = Regex("^(?:julio\\s+)?(?:borra|borrar|elimina|eliminar|quita|quitar)\\s+(?:la\\s+)?rutina\\s+(?:de\\s+)?(.+)$")

    /** Rutinas de ejemplo (v52). Se llaman por voz con su nombre: «buenos días», «me voy a dormir», «modo concentración». */
    val PLANTILLAS = listOf(
        PlantillaRutina("Buenos días", listOf("qué tengo programado hoy", "qué tareas tengo pendientes")),
        PlantillaRutina("Me voy a dormir", listOf("pausa la música", "baja el brillo", "silencia el teléfono")),
        PlantillaRutina("Modo concentración", listOf("inicia una sesión de enfoque de 25 minutos", "pon música para estudiar")),
    )

    private val INSTALAR = Regex(
        "^(?:julio\\s+)?(?:instala|instalar|crea|crear|agrega|agregar|pon|poner|carga|cargar|dame)\\s+(?:las\\s+|mis\\s+)?rutinas\\s+(?:basicas|de ejemplo|predefinidas|iniciales|de muestra)$",
    )

    /** Solo mira frases que traen la palabra «rutina»; todo lo demás sigue su camino normal. */
    fun comando(texto: String): ComandoRutina? {
        // normalizar borra las comas: antes se vuelven «luego», que es uno de los separadores de órdenes.
        val n = normalizar(texto.replace(Regex("[,;]"), " luego "))
        if (!Regex("\\brutinas?\\b").containsMatchIn(n)) return null
        if (INSTALAR.containsMatchIn(n.trim())) return ComandoRutina.InstalarBasicas
        CREAR.find(n)?.let { m ->
            val nombre = m.groupValues[1].trim()
            val ordenes = separarOrdenes(m.groupValues[2])
            if (nombre.isNotEmpty() && ordenes.isNotEmpty()) return ComandoRutina.Crear(nombre, ordenes)
        }
        BORRAR.find(n)?.let { return ComandoRutina.Borrar(it.groupValues[1].trim()) }
        ALTERNAR.find(n)?.let { m ->
            val activar = m.groupValues[1].let { it.startsWith("enciende") || it.startsWith("prende") || it.startsWith("activa") }
            return ComandoRutina.Alternar(m.groupValues[2].trim(), activar)
        }
        EJECUTAR.find(n)?.let { return ComandoRutina.Ejecutar(it.groupValues[1].trim()) }
        if (LISTAR.containsMatchIn(n)) return ComandoRutina.Listar
        return null
    }
}
