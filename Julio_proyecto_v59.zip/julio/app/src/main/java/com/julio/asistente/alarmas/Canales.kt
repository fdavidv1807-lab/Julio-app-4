package com.julio.asistente.alarmas

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.RingtoneManager

object Canales {
    /** Canal del servicio que reproduce el sonido por su cuenta (sin sonido propio). */
    const val ALARMAS = "alarmas"

    /** Canal de respaldo: si el sistema no deja iniciar el servicio, la notificación suena sola. */
    const val RESPALDO = "alarmas_respaldo"

    /** Avisos de actividades del horario y fechas límite de tareas. */
    const val RECORDATORIOS = "recordatorios"

    /** Cuenta regresiva silenciosa de la sesión de enfoque. */
    const val ENFOQUE_PROGRESO = "enfoque_progreso"

    /** Aviso (con sonido) cuando termina un enfoque o un descanso. */
    const val ENFOQUE_FIN = "enfoque_fin"

    /** Resumen de la mañana y pendientes de la tarde. */
    const val AVISOS = "avisos_julio"

    /** Notificación fija «Julio conectado» del teléfono de diario (silenciosa, importancia mínima). */
    const val CONECTADO = "julio_conectado"

    /** Avisos del enfoque estricto (intentaste abrir una app bloqueada, sesión rota, falta un permiso). */
    const val ENFOQUE_AVISO = "enfoque_aviso"

    fun crear(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)

        val principal = NotificationChannel(ALARMAS, "Alarmas", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pantalla y controles cuando suena una alarma"
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(principal)

        val atributos = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val respaldo = NotificationChannel(RESPALDO, "Alarmas (respaldo)", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Se usa solo si el sistema bloquea la alarma normal"
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), atributos)
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(respaldo)

        nm.createNotificationChannel(
            NotificationChannel(RECORDATORIOS, "Recordatorios", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Avisos de actividades del horario y tareas con fecha límite"
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(ENFOQUE_PROGRESO, "Modo enfoque (en curso)", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Tiempo restante de la sesión de enfoque"
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(ENFOQUE_FIN, "Modo enfoque (fin)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Aviso al terminar un enfoque o un descanso"
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(AVISOS, "Resumen y pendientes", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Resumen de tu día por la mañana y tareas pendientes por la tarde"
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(ENFOQUE_AVISO, "Modo estricto (avisos)", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Cuando intentas abrir una app bloqueada o se rompe una sesión estricta"
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CONECTADO, "Julio conectado", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Aviso fijo y silencioso del teléfono de diario mientras vigila tus avisos"
            },
        )
    }
}
