package com.julio.asistente.sync

import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.data.local.TareaEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Sincronización Cuerpo ↔ Diario (v52): combinar, detectar cambios, formato del lote y serialización. Sin Android. */
class SyncLogicaTest {
    private fun r(clave: Long, datos: String, act: Long, borrado: Boolean = false) = RegistroSync(TipoSync.TAREA, clave, datos, act, borrado)

    @Test fun unirYSepararConservanNulosYVacios() {
        val campos = listOf("a", null, "", "x y")
        assertEquals(campos, SyncLogica.separar(SyncLogica.unir(campos)))
    }

    @Test fun ganaElCambioMasReciente() {
        assertTrue(SyncLogica.debeAplicar(null, r(1, "a", 1)))
        assertTrue(SyncLogica.debeAplicar(r(1, "a", 1), r(1, "b", 2)))
        assertFalse(SyncLogica.debeAplicar(r(1, "a", 5), r(1, "b", 2)))
    }

    @Test fun enUnEmpateGanaElBorradoYNoSeRevive() {
        assertTrue(SyncLogica.debeAplicar(r(1, "a", 5), r(1, "a", 5, borrado = true)))
        assertFalse(SyncLogica.debeAplicar(r(1, "a", 5, borrado = true), r(1, "a", 5)))
    }

    @Test fun elEmpateSeDecideIgualEnLosDosTelefonos() {
        val a = r(1, "a", 5)
        val b = r(1, "b", 5)
        assertTrue(SyncLogica.debeAplicar(a, b) != SyncLogica.debeAplicar(b, a))
        assertFalse(SyncLogica.debeAplicar(a, a))
    }

    @Test fun diferenciasAnotaNuevosCambiadosYBorrados() {
        val previos = listOf(r(1, "x", 1), r(2, "y", 1), r(3, "z", 1, borrado = true))
        val actuales = listOf(Instantanea(TipoSync.TAREA, 1, "x"), Instantanea(TipoSync.TAREA, 2, "y2"), Instantanea(TipoSync.TAREA, 4, "nuevo"))
        val d = SyncLogica.diferencias(previos, actuales, 99)
        assertEquals(2, d.count { !it.borrado })
        assertTrue(d.any { it.clave == 2L && it.datos == "y2" && it.actualizadoEn == 99L })
        assertTrue(d.any { it.clave == 4L && !it.borrado })
        assertTrue(d.none { it.clave == 1L })
        assertTrue(d.none { it.clave == 3L }) // la lápida vieja no se repite
    }

    @Test fun lasCosasQueDesaparecenDejanLapida() {
        val d = SyncLogica.diferencias(listOf(r(1, "x", 1)), emptyList(), 50)
        assertEquals(1, d.size)
        assertTrue(d[0].borrado)
        assertEquals(50L, d[0].actualizadoEn)
    }

    @Test fun loteDaLaVueltaCompleta() {
        val lote = LoteSync("id-1", 123L, true, listOf(r(1, "a", 2), RegistroSync(TipoSync.USO, 20_000, "datos", 5, false)), listOf(Confirmacion(TipoSync.ALARMA, 7, 8)))
        val leido = SyncLogica.decodificarLote(SyncLogica.codificarLote(lote))
        assertNotNull(leido)
        assertEquals("id-1", leido!!.id)
        assertTrue(leido.hayMas)
        assertEquals(lote.registros, leido.registros)
        assertEquals(7L, leido.confirmaciones[0].clave)
    }

    @Test fun unLoteMalFormadoOConTipoRaroSeRechaza() {
        assertNull(SyncLogica.decodificarLote(byteArrayOf(1, 2, 3)))
        val raro = LoteSync("x", 1, false, listOf(RegistroSync("Z", 1, "d", 1, false)), emptyList())
        assertNull(SyncLogica.decodificarLote(SyncLogica.codificarLote(raro)))
    }

    @Test fun lasTareasDanLaVueltaSinCambiarNada() {
        val t = TareaEntity(id = 5, titulo = "Informe", descripcion = "d", prioridad = 2, fechaLimite = 1000L, completada = true, creadaEn = 777L, recordatorioMinutoDia = 480)
        val datos = SerializadorSync.datosTarea(t)
        val vuelta = SerializadorSync.tareaDe(datos, 777L, 9)!!
        assertEquals(t.copy(id = 9), vuelta)
        assertEquals(datos, SerializadorSync.datosTarea(vuelta)) // no hay «rebote» de cambios
    }

    @Test fun lasActividadesDanLaVuelta() {
        val a = ActividadEntity(id = 1, titulo = "Anatomía", inicio = 5000L, fin = 6000L, recurrencia = "DIAS", creadaEn = 55L, recordatorioMin = 10, diasMascara = 5, intervaloSemanas = 2, excluidas = "1,2")
        val vuelta = SerializadorSync.actividadDe(SerializadorSync.datosActividad(a), 55L, 1)!!
        assertEquals(a, vuelta)
        val sinNada = ActividadEntity(id = 1, titulo = "x", inicio = 1L, creadaEn = 2L)
        assertEquals(sinNada, SerializadorSync.actividadDe(SerializadorSync.datosActividad(sinNada), 2L, 1))
    }

    @Test fun lasAlarmasConservanSuSonidoLocal() {
        val a = AlarmaEntity(id = 3, nombre = "Clase", hora = 6, minuto = 30, fechaEpochDay = null, diasMascara = 31, activa = false, sonidoUri = "content://mio", creadaEn = 9L)
        val vuelta = SerializadorSync.alarmaDe(SerializadorSync.datosAlarma(a), 9L, 3, "content://otro")!!
        assertEquals("content://otro", vuelta.sonidoUri) // el sonido es de cada teléfono
        assertEquals(a.copy(sonidoUri = "content://otro"), vuelta)
    }

    @Test fun datosRarosNoRompen() {
        assertNull(SerializadorSync.tareaDe("v", 1, 0))
        assertNull(SerializadorSync.alarmaDe(SyncLogica.unir(listOf("a", "x", "y", null, "0", "1")), 1, 0, null))
    }
}
