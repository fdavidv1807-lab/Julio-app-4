package com.julio.asistente.avisos

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DiagnosticoAvisosTest {
    private val bien = HechosAvisos(
        notificacionesPermitidas = true, canalAlarmasActivo = true, canalRecordatoriosActivo = true, alarmasExactas = true,
        sinRestriccionBateria = true, noMolestarActivo = false, rol = "DIARIO", accesoNotificaciones = true, listenerConectado = true,
        emparejado = true, hayWifi = true, lecturaDeAvisosEncendida = true, modoEscritorioAbierto = true, appsElegidas = 2,
    )

    @Test fun todoBienNoTieneFallasNiAvisos() {
        val l = DiagnosticoAvisos.evaluar(bien)
        assertTrue(l.none { it.gravedad != Gravedad.OK })
        assertTrue(DiagnosticoAvisos.resumenHablado(l).startsWith("Revisé los avisos y todo está bien"))
    }

    @Test fun lasFallasSalenPrimeroYDicenQueHacer() {
        val l = DiagnosticoAvisos.evaluar(bien.copy(canalRecordatoriosActivo = false, sinRestriccionBateria = false, listenerConectado = false))
        assertEquals(Gravedad.FALLA, l[0].gravedad)
        assertTrue(l.first { it.texto.contains("Recordatorios") }.gravedad == Gravedad.FALLA)
        assertTrue(l.any { it.gravedad == Gravedad.AVISO && it.texto.contains("batería") })
        assertTrue(DiagnosticoAvisos.resumenHablado(l).startsWith("Encontré 2 fallas."))
    }

    @Test fun sinWifiEsAvisoYSinCodigoEsFalla() {
        assertEquals(Gravedad.AVISO, DiagnosticoAvisos.evaluar(bien.copy(hayWifi = false)).first { it.texto.contains("Sin Wi-Fi") }.gravedad)
        assertEquals(Gravedad.FALLA, DiagnosticoAvisos.evaluar(bien.copy(emparejado = false)).first { it.texto.contains("emparejado") }.gravedad)
    }

    @Test fun elCuerpoRevisaLaLecturaYElModoEscritorio() {
        val l = DiagnosticoAvisos.evaluar(bien.copy(rol = "CUERPO", lecturaDeAvisosEncendida = false, modoEscritorioAbierto = false))
        assertTrue(l.any { it.texto.contains("modo escritorio") })
        assertTrue(l.any { it.texto.contains("lectura de avisos está apagada") })
    }
}
