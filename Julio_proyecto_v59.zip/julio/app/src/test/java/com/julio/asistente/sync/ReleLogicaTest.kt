package com.julio.asistente.sync

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Relé cifrado (v57): direcciones, canal secreto y formato de la respuesta. Sin Android ni internet. */
class ReleLogicaTest {
    @Test fun soloAceptaFirebaseConHttps() {
        assertTrue(ReleLogica.urlValida("https://julio-sync-default-rtdb.firebaseio.com"))
        assertTrue(ReleLogica.urlValida("https://julio-sync-default-rtdb.firebaseio.com/"))
        assertTrue(ReleLogica.urlValida("https://julio-sync-default-rtdb.europe-west1.firebasedatabase.app"))
        assertFalse(ReleLogica.urlValida("http://julio-sync-default-rtdb.firebaseio.com"))
        assertFalse(ReleLogica.urlValida("https://example.com"))
        assertFalse(ReleLogica.urlValida("https://firebaseio.com.malo.com"))
        assertFalse(ReleLogica.urlValida("https://usuario:clave@x.firebaseio.com"))
        assertFalse(ReleLogica.urlValida("https://x.firebaseio.com/ruta?auth=1"))
        assertFalse(ReleLogica.urlValida(""))
    }

    @Test fun elCanalEsEstableSecretoYDistintoPorSecreto() {
        val a = ByteArray(32) { 1 }
        val b = ByteArray(32) { 2 }
        assertEquals(32, ReleLogica.canal(a).length)
        assertTrue(ReleLogica.canal(a).matches(Regex("[0-9a-f]{32}")))
        assertEquals(ReleLogica.canal(a), ReleLogica.canal(a))
        assertNotEquals(ReleLogica.canal(a), ReleLogica.canal(b))
    }

    @Test fun direcciones() {
        assertEquals(
            "https://x-default-rtdb.firebaseio.com/julio/abc/req/id1.json",
            ReleLogica.direccion("https://x-default-rtdb.firebaseio.com/", "abc", ReleLogica.TIPO_PETICION, "id1"),
        )
        assertEquals("https://x-default-rtdb.firebaseio.com/julio/abc/res.json", ReleLogica.direccion("https://x-default-rtdb.firebaseio.com", "abc", ReleLogica.TIPO_RESPUESTA))
    }

    @Test fun idsYTextoBase64() {
        val id = ReleLogica.nuevoId()
        assertTrue(ReleLogica.idValido(id))
        assertFalse(ReleLogica.idValido("../otro"))
        assertFalse(ReleLogica.idValido(id + "x"))
        val bytes = byteArrayOf(0, 1, 2, -1, -128, 127)
        assertArrayEquals(bytes, ReleLogica.deTexto(ReleLogica.aTexto(bytes)))
        assertNull(ReleLogica.deTexto("esto no es base64 !!"))
    }

    @Test fun laRespuestaLlevaElCodigoYLaTrama() {
        val r = ReleLogica.leerRespuesta(ReleLogica.envolverRespuesta(0, byteArrayOf(9, 8, 7)))!!
        assertEquals(0, r.ack)
        assertArrayEquals(byteArrayOf(9, 8, 7), r.trama)
        val sola = ReleLogica.leerRespuesta(ReleLogica.envolverRespuesta(22, null))!!
        assertEquals(22, sola.ack)
        assertNull(sola.trama)
        assertNull(ReleLogica.leerRespuesta(ByteArray(0)))
    }
}
