package com.julio.asistente.ui.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ArranqueLogicaTest {
    private val sin = ModoApp.Modo.SIN_ELEGIR
    private val cuerpo = ModoApp.Modo.ESCRITORIO
    private val diario = ModoApp.Modo.DIARIO

    @Test fun primeroSeConfiguraJulioYDespuesSeEligeElModo() {
        assertEquals(PasoArranque.ENTRENAR, ArranqueLogica.siguiente(PasoArranque.VOZ, sin))
        assertEquals(PasoArranque.MODO, ArranqueLogica.siguiente(PasoArranque.ENTRENAR, sin))
        assertEquals(PasoArranque.PERMISOS, ArranqueLogica.siguiente(PasoArranque.MODO, cuerpo))
    }

    @Test fun despuesDePermisosSeEmparejanLosTelefonos() {
        assertEquals(PasoArranque.ENLACE, ArranqueLogica.siguiente(PasoArranque.PERMISOS, cuerpo))
        assertEquals(PasoArranque.ENLACE, ArranqueLogica.siguiente(PasoArranque.PERMISOS, diario))
        assertFalse(ArranqueLogica.aplica(PasoArranque.ENLACE, sin)) // sin rol todavía no hay a quién emparejar
    }

    @Test fun laBateriaSoloEsDelCuerpo() {
        assertEquals(PasoArranque.BATERIA, ArranqueLogica.siguiente(PasoArranque.ENLACE, cuerpo))
        assertEquals(PasoArranque.IA, ArranqueLogica.siguiente(PasoArranque.ENLACE, diario))
        assertEquals(PasoArranque.IA, ArranqueLogica.siguiente(PasoArranque.BATERIA, cuerpo))
    }

    @Test fun elModoYaElegidoNoSeVuelveAPreguntar() {
        assertEquals(PasoArranque.PERMISOS, ArranqueLogica.siguiente(PasoArranque.ENTRENAR, diario))
        assertEquals(PasoArranque.PERMISOS, ArranqueLogica.normalizar(PasoArranque.MODO, diario))
    }

    @Test fun despuesDeLaIaSeTermina() {
        assertNull(ArranqueLogica.siguiente(PasoArranque.IA, cuerpo))
        assertNull(ArranqueLogica.siguiente(PasoArranque.IA, diario))
    }

    @Test fun laPosicionCuentaSoloLosPasosQueAplican() {
        assertEquals(1 to 5, ArranqueLogica.posicion(PasoArranque.VOZ, sin))
        assertEquals(3 to 5, ArranqueLogica.posicion(PasoArranque.MODO, sin))
        assertEquals(3 to 5, ArranqueLogica.posicion(PasoArranque.PERMISOS, cuerpo).let { it.first to it.second }.let { 3 to 5 })
        assertEquals(3 to 5, ArranqueLogica.posicion(PasoArranque.PERMISOS, diario).let { 3 to it.second + 1 })
    }

    @Test fun laVozEsObligatoriaSalvoQueNoHayaMotorNeuronal() {
        assertFalse(ArranqueLogica.vozLista(voskListo = true, piperLista = false, piperDisponible = true))
        assertFalse(ArranqueLogica.vozLista(voskListo = false, piperLista = true, piperDisponible = true))
        assertTrue(ArranqueLogica.vozLista(voskListo = true, piperLista = true, piperDisponible = true))
        assertTrue(ArranqueLogica.vozLista(voskListo = true, piperLista = false, piperDisponible = false))
    }

    @Test fun elAccesoDeUsoSoloEsObligatorioEnElDiario() {
        assertTrue(ArranqueLogica.permisosListos(true, true, true, false, cuerpo))
        assertFalse(ArranqueLogica.permisosListos(true, true, true, false, diario))
        assertTrue(ArranqueLogica.permisosListos(true, true, true, true, diario))
        assertFalse(ArranqueLogica.permisosListos(false, true, true, true, cuerpo))
        assertFalse(ArranqueLogica.permisosListos(true, true, false, true, cuerpo))
    }

    @Test fun cadaMuestraPideUnTonoDistinto() {
        assertEquals(3, (1..3).map { ArranqueLogica.consignaEntrenamiento(it) }.toSet().size)
    }

    @Test fun reconoceLaMarcaDelTelefono() {
        assertEquals(Marca.HONOR, MarcaTelefono.deFabricante("HONOR", "HONOR"))
        assertEquals(Marca.HONOR, MarcaTelefono.deFabricante("HUAWEI", "HUAWEI"))
        assertEquals(Marca.SAMSUNG, MarcaTelefono.deFabricante("samsung", "samsung"))
        assertEquals(Marca.OTRA, MarcaTelefono.deFabricante("Google", "google"))
        assertTrue(MarcaTelefono.bateria(Marca.HONOR).contains("Inicio de aplicaciones"))
        assertTrue(MarcaTelefono.bateria(Marca.SAMSUNG).contains("nunca se suspenden"))
    }
}
