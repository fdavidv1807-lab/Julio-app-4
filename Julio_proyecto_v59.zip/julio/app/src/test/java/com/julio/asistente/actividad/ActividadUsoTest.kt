package com.julio.asistente.actividad

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActividadUsoTest {
    private val min = 60_000L
    private val r = ResumenUso(
        20_000,
        listOf(
            UsoApp("com.whatsapp", "WhatsApp", ActividadUso.REDES, 70 * min),
            UsoApp("com.android.chrome", "Chrome", ActividadUso.OTRAS, 35 * min),
            UsoApp("com.juego", "Juego", ActividadUso.JUEGOS, 20 * min),
            UsoApp("com.tiny", "Poca", ActividadUso.OTRAS, 30_000L),
        ),
    )

    @Test fun tiempoHablado() {
        assertEquals("menos de un minuto", ActividadUso.tiempoHablado(30_000))
        assertEquals("1 minuto", ActividadUso.tiempoHablado(min))
        assertEquals("1 hora", ActividadUso.tiempoHablado(60 * min))
        assertEquals("2 horas y 5 minutos", ActividadUso.tiempoHablado(125 * min))
    }

    @Test fun categorias() {
        assertEquals(ActividadUso.REDES, ActividadUso.categoriaDe("com.whatsapp.w4b", -1))
        assertEquals(ActividadUso.MEDIA, ActividadUso.categoriaDe("com.spotify.music", 1))
        assertEquals(ActividadUso.JUEGOS, ActividadUso.categoriaDe("com.x", 0))
        assertEquals(ActividadUso.OTRAS, ActividadUso.categoriaDe("com.x", -1))
    }

    @Test fun resumenYCategoriaMayor() {
        assertEquals("WhatsApp", r.top(1)[0].nombre)
        assertEquals(ActividadUso.REDES, r.porCategoria()[0].first)
        val h = ActividadUso.resumenHablado(r)
        assertTrue(h.contains("WhatsApp 1 hora y 10 minutos"))
        assertTrue(ActividadUso.resumenHablado(ResumenUso(1, emptyList())).startsWith("No hay uso"))
    }

    @Test fun serializarDescartaLoMinimoYDaLaVuelta() {
        val vuelta = ActividadUso.leer(20_000, ActividadUso.serializar(r))!!
        assertEquals(3, vuelta.apps.size) // la de 30 s no viaja
        assertEquals(r.top(1)[0].ms, vuelta.top(1)[0].ms)
        assertEquals(0, ActividadUso.leer(1, ActividadUso.serializar(ResumenUso(1, emptyList())))!!.apps.size)
    }
}
