package com.julio.asistente.ejecutor

import com.julio.asistente.comandos.AccionMusica
import com.julio.asistente.comandos.AccionNivel
import com.julio.asistente.comandos.Intencion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EjecutorTest {
    private val eliminar = Intencion.Eliminar(null, "informe", null, null, null)

    @Test fun losNivelesDeLasOrdenes() {
        assertEquals(Nivel.N0, Ejecutor.nivel(Intencion.ConsultarTareas))
        assertEquals(Nivel.N1, Ejecutor.nivel(Intencion.AjustarVolumen(AccionNivel.SUBIR)))
        assertEquals(Nivel.N1, Ejecutor.nivel(Intencion.Musica(AccionMusica.PAUSAR)))
        assertEquals(Nivel.N1, Ejecutor.nivel(Intencion.IniciarEnfoque(25, estricto = false)))
        assertEquals(Nivel.N2, Ejecutor.nivel(Intencion.IniciarEnfoque(25, estricto = true)))
        assertEquals(Nivel.N2, Ejecutor.nivel(Intencion.AgregarTarea("informe")))
        assertEquals(Nivel.N2, Ejecutor.nivel(Intencion.Responder(null)))
        assertEquals(Nivel.N3, Ejecutor.nivel(eliminar))
        assertEquals(Nivel.N3, Ejecutor.nivel(Intencion.Desconocida))
    }

    @Test fun elDuenoConservaSusConfirmacionesDeSiempre() {
        assertTrue(Ejecutor.decidir(Solicitante.USUARIO, eliminar) is Decision.Ejecutar)
        assertTrue(Ejecutor.decidir(Solicitante.USUARIO, Intencion.AgregarTarea("x")) is Decision.Ejecutar)
    }

    @Test fun unaRutinaSoloHaceNivel0y1() {
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, Intencion.ConsultarHorario(java.time.LocalDate.of(2026, 11, 9))) is Decision.Ejecutar)
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, Intencion.AjustarBrillo(AccionNivel.BAJAR)) is Decision.Ejecutar)
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, Intencion.AgregarTarea("x")) is Decision.Rechazar)
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, eliminar) is Decision.Rechazar)
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, Intencion.Desconocida) is Decision.Rechazar)
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, Intencion.Ambigua("algo")) is Decision.Rechazar)
    }

    @Test fun laIaProponeYElEjecutorDecide() {
        assertTrue(Ejecutor.decidir(Solicitante.IA, Intencion.AjustarVolumen(AccionNivel.SILENCIAR)) is Decision.Ejecutar)
        assertTrue(Ejecutor.decidir(Solicitante.IA, Intencion.AgregarTarea("x")) is Decision.Confirmar)
        assertTrue(Ejecutor.decidir(Solicitante.IA, Intencion.Responder("Ana")) is Decision.Confirmar)
        assertTrue(Ejecutor.decidir(Solicitante.IA, eliminar) is Decision.Rechazar)
        assertTrue(Ejecutor.decidir(Solicitante.IA, Intencion.PreguntarIA("hola")) is Decision.Rechazar)
        assertTrue(Ejecutor.decidir(Solicitante.IA, Intencion.Desconocida) is Decision.Rechazar)
    }
}
