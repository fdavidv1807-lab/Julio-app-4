package com.julio.asistente.estudio

import com.julio.asistente.comandos.Intencion
import com.julio.asistente.comandos.Interprete
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** Tarjetas de estudio y simulacros (v56). Sin Android. */
class TarjetasLogicaTest {
    private val hoy = 20_000L

    @Test fun agregarValidaYNoDuplica() {
        val l = TarjetasLogica.agregar(emptyList(), "Mitosis", "¿Qué es la profase?", "Fase donde se condensa la cromatina", hoy, 1)!!
        assertEquals(Tarjeta(1, "Mitosis", "¿Qué es la profase?", "Fase donde se condensa la cromatina", 0, hoy + 1), l[0])
        assertNull(TarjetasLogica.agregar(l, "mitosis", "¿qué es la profase?", "otra", hoy, 2)) // misma pregunta en el mismo tema
        assertNull(TarjetasLogica.agregar(l, "Mitosis", "  ", "x", hoy, 3))
        assertNull(TarjetasLogica.agregar(l, "Mitosis", "x", "   ", hoy, 4))
        assertEquals("General", TarjetasLogica.agregar(emptyList(), " ", "pregunta?", "respuesta", hoy, 5)!![0].tema)
    }

    @Test fun respondiendoSeEspacia() {
        var l = TarjetasLogica.agregar(emptyList(), "T", "pregunta uno", "r", hoy, 1)!!
        l = TarjetasLogica.responder(l, 1, true, hoy)
        assertEquals(hoy + 3, l[0].proximo)
        l = TarjetasLogica.responder(l, 1, false, hoy)
        assertEquals(hoy + 1, l[0].proximo)
        assertEquals(0, l[0].paso)
        assertEquals(l, TarjetasLogica.responder(l, 99, true, hoy)) // una tarjeta que no existe no cambia nada
    }

    @Test fun pendientesYTemas() {
        val l = listOf(Tarjeta(1, "B", "p1", "r", 0, hoy - 1), Tarjeta(2, "A", "p2", "r", 1, hoy + 3), Tarjeta(3, "B", "p3", "r", 0, hoy))
        assertEquals(listOf(1L, 3L), TarjetasLogica.pendientes(l, hoy).map { it.id })
        assertEquals(listOf("A", "B"), TarjetasLogica.temas(l))
        assertEquals(listOf(2L), TarjetasLogica.quitar(l, 1).filter { it.tema == "A" }.map { it.id })
    }

    @Test fun simulacroTomaNYRespetaElTema() {
        val l = (1..20L).map { Tarjeta(it, if (it % 2 == 0L) "Par" else "Impar", "p$it", "r", 0, hoy) }
        assertEquals(10, TarjetasLogica.simulacro(l, 10, null, 7).size)
        assertEquals(10, TarjetasLogica.simulacro(l, 99, "par", 7).size)
        assertTrue(TarjetasLogica.simulacro(l, 5, "Par", 7).all { it.tema == "Par" })
        assertEquals(TarjetasLogica.simulacro(l, 10, null, 7), TarjetasLogica.simulacro(l, 10, null, 7)) // misma semilla, mismo orden
        assertEquals(3, TarjetasLogica.simulacro(l.take(3), 10, null, 1).size)
    }

    @Test fun laNotaDiceComoTeFue() {
        assertTrue(TarjetasLogica.nota(9, 10).startsWith("Sacaste 9 de 10 (90 %). Excelente"))
        assertTrue(TarjetasLogica.nota(7, 10).contains("Muy bien"))
        assertTrue(TarjetasLogica.nota(2, 10).contains("repasar más"))
        assertEquals("No hubo tarjetas en este simulacro.", TarjetasLogica.nota(0, 0))
    }

    @Test fun leeLasTarjetasQueArmoLaIa() {
        val texto = """
            Claro, aquí están:
            1. ¿Qué es la profase? || Fase en la que se condensa la cromatina
            - ¿Dónde ocurre la mitosis? || En las células somáticas
            «¿Qué es el huso mitótico?» || Estructura de microtúbulos
            esta línea no sirve
            ¿Pregunta sin respuesta? ||
            ok || respuesta con pregunta corta
        """.trimIndent()
        val pares = TarjetasLogica.leerDeIa(texto)
        assertEquals(3, pares.size)
        assertEquals("¿Qué es la profase?", pares[0].first)
        assertEquals("En las células somáticas", pares[1].second)
        assertEquals("¿Qué es el huso mitótico?", pares[2].first)
        assertTrue(TarjetasLogica.pedidoDeTarjetas("la mitosis").contains("pregunta || respuesta"))
    }

    @Test fun seGuardaYSeLeeSinPerderNada() {
        val l = listOf(Tarjeta(1, "Corazón", "¿Cuántas cavidades?", "Cuatro", 2, 20_005L), Tarjeta(2, "Mitosis", "p", "r", 0, 20_001L))
        assertEquals(l, TarjetasLogica.leer(TarjetasLogica.serializar(l)))
        assertEquals(emptyList<Tarjeta>(), TarjetasLogica.leer(""))
        assertEquals(emptyList<Tarjeta>(), TarjetasLogica.leer("basura"))
    }

    @Test fun ordenesDeVoz() {
        val f = LocalDate.of(2026, 11, 20)
        fun i(t: String) = Interprete.interpretar(t, f, LocalTime.of(9, 0))
        assertEquals(Intencion.CrearTarjetas("mitosis"), i("Hazme tarjetas de la mitosis"))
        assertEquals(Intencion.CrearTarjetas("anatomia del corazon"), i("Crea unas tarjetas de estudio sobre anatomía del corazón"))
        assertEquals(Intencion.CrearTarjetas(null), i("Hazme tarjetas"))
        assertEquals(Intencion.ConsultarTarjetas, i("¿Cuántas tarjetas tengo pendientes?"))
        assertEquals(Intencion.ConsultarTarjetas, i("Mis tarjetas"))
        assertNotNull(i("Hazme tarjetas de la mitosis"))
    }
}
