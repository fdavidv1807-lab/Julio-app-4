package com.julio.asistente.ui.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class JarvisLogicaTest {
    @Test fun cuatroToquesRapidosActivan() {
        val c = ContadorToques()
        assertFalse(c.registrar(0)); assertFalse(c.registrar(400)); assertFalse(c.registrar(800))
        assertTrue(c.registrar(1200))
    }

    @Test fun tresToquesNoActivan() {
        val c = ContadorToques()
        assertFalse(c.registrar(0)); assertFalse(c.registrar(300)); assertFalse(c.registrar(600))
    }

    @Test fun toquesLentosNoActivan() {
        val c = ContadorToques()
        for (i in 0 until 10) assertFalse(c.registrar(i * 1_500L))
    }

    @Test fun trasActivarEmpiezaDeCero() {
        val c = ContadorToques()
        for (t in listOf(0L, 100L, 200L)) c.registrar(t)
        assertTrue(c.registrar(300))
        assertFalse(c.registrar(400))
        assertFalse(c.registrar(500))
        assertFalse(c.registrar(600))
        assertTrue(c.registrar(700))
    }

    @Test fun julioSeVaAlLadoContrarioAlBotonElegido() {
        assertEquals(LadoJulio.IZQUIERDA, JarvisLogica.ladoJulio(Vista.CONFIG))
        assertEquals(LadoJulio.DERECHA, JarvisLogica.ladoJulio(Vista.MI_DIA))
        assertEquals(LadoJulio.CENTRO, JarvisLogica.ladoJulio(Vista.MANUAL))
        assertEquals(LadoJulio.CENTRO, JarvisLogica.ladoJulio(Vista.JULIO))
    }

    @Test fun atrasCierraPrimeroElPanel() {
        assertEquals(Vista.CONFIG to false, JarvisLogica.atras(Vista.CONFIG, true))
        assertEquals(Vista.MANUAL to false, JarvisLogica.atras(Vista.CONFIG, false))
        assertEquals(Vista.MANUAL to false, JarvisLogica.atras(Vista.MI_DIA, false))
        assertEquals(Vista.JULIO to false, JarvisLogica.atras(Vista.MANUAL, false))
        assertEquals(Vista.JULIO to false, JarvisLogica.atras(Vista.JULIO, false))
    }

    @Test fun sectoresNoGiranSiCabenTodos() {
        assertEquals(0f, MenuSector.giroMaximo(3), 1e-4f)
        assertEquals(0f, MenuSector.limitar(50f, 3), 1e-4f)
    }

    @Test fun sectoresGiranLoQueSobra() {
        // 9 opciones de 27° = 243°; el cuarto muestra 90°, sobran 153°.
        assertEquals(153f, MenuSector.giroMaximo(9), 1e-3f)
        assertEquals(153f, MenuSector.limitar(999f, 9), 1e-3f)
        assertEquals(0f, MenuSector.limitar(-20f, 9), 1e-3f)
    }

    @Test fun laPrimeraOpcionQuedaArribaYLaUltimaAbajoAlGirar() {
        assertEquals(76.5f, MenuSector.anguloCentro(0, 0f), 1e-3f)
        val tope = MenuSector.giroMaximo(9)
        assertEquals(13.5f, MenuSector.anguloCentro(8, tope), 1e-3f)
    }

    @Test fun elToqueEncuentraLaOpcionCorrecta() {
        assertEquals(0, MenuSector.opcionEn(80f, 0f, 9))
        assertEquals(1, MenuSector.opcionEn(60f, 0f, 9))
        assertEquals(2, MenuSector.opcionEn(10f, 0f, 9))
        // Girado hasta el final, abajo queda la última.
        assertEquals(8, MenuSector.opcionEn(5f, MenuSector.giroMaximo(9), 9))
        assertNull(MenuSector.opcionEn(95f, 0f, 9))
        assertNull(MenuSector.opcionEn(10f, 0f, 2)) // no hay tercera opción
    }

    @Test fun elAnguloDeUnPuntoVaDe0a90() {
        assertEquals(0f, MenuSector.anguloDePunto(10f, 0f), 1e-3f)
        assertEquals(90f, MenuSector.anguloDePunto(0f, 10f), 1e-3f)
        assertEquals(45f, MenuSector.anguloDePunto(7f, 7f), 1e-3f)
    }

    @Test fun alSoltarSeAcomodaEnLaOpcionMasCercana() {
        assertEquals(27f, MenuSector.acomodar(30f, 9), 1e-3f)
        assertEquals(0f, MenuSector.acomodar(5f, 9), 1e-3f)
        assertEquals(153f, MenuSector.acomodar(150f, 9), 1e-3f)
    }

    @Test fun elTextoSoloSeVeSiCabe() {
        assertTrue(MenuSector.textoVisible(0, 0f))
        assertFalse(MenuSector.textoVisible(8, 0f)) // fuera del cuarto
    }

    @Test fun elModoSoloSeEligeUnaVez() {
        assertTrue(JarvisLogica.puedeElegirModo(ModoApp.Modo.SIN_ELEGIR))
        assertFalse(JarvisLogica.puedeElegirModo(ModoApp.Modo.ESCRITORIO))
        assertFalse(JarvisLogica.puedeElegirModo(ModoApp.Modo.DIARIO))
    }

    @Test fun elCuerpoVuelveSoloAJulio() {
        assertEquals(0, JarvisLogica.segundosParaVolver(Vista.JULIO))
        assertTrue(JarvisLogica.segundosParaVolver(Vista.MANUAL) in 1..60)
        assertTrue(JarvisLogica.segundosParaVolver(Vista.CONFIG) > 60)
    }
}
