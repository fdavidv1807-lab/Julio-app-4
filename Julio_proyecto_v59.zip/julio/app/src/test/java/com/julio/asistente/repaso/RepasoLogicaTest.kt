package com.julio.asistente.repaso

import com.julio.asistente.comandos.Intencion
import com.julio.asistente.comandos.Interprete
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** Repaso espaciado y órdenes de voz de la v55. Sin Android. */
class RepasoLogicaTest {
    private val hoy = 20_000L

    @Test fun unTemaNuevoTocaEnUnDiaYNoSeDuplica() {
        val a = RepasoLogica.agregar(emptyList(), "Mitosis", hoy)
        assertEquals(listOf(TemaRepaso("Mitosis", 0, hoy + 1)), a)
        assertEquals(a, RepasoLogica.agregar(a, "  mitosis ", hoy)) // mismo tema, otra forma de escribirlo
        assertEquals(a, RepasoLogica.agregar(a, "   ", hoy))
    }

    @Test fun siTeFueBienSubeUnPasoYSiTeFueMalVuelveAlPrimero() {
        var l = RepasoLogica.agregar(emptyList(), "Mitosis", hoy)
        l = RepasoLogica.registrar(l, "mitosis", true, hoy)
        assertEquals(1, l[0].paso); assertEquals(hoy + 3, l[0].proximo)
        l = RepasoLogica.registrar(l, "Mitosis", true, hoy)
        assertEquals(hoy + 7, l[0].proximo)
        l = RepasoLogica.registrar(l, "Mitosis", false, hoy)
        assertEquals(0, l[0].paso); assertEquals(hoy + 1, l[0].proximo)
        repeat(10) { l = RepasoLogica.registrar(l, "Mitosis", true, hoy) }
        assertEquals(hoy + 30, l[0].proximo) // el último intervalo es de 30 días
    }

    @Test fun registrarUnTemaQueNoEstabaLoAgrega() {
        val l = RepasoLogica.registrar(emptyList(), "Meiosis", true, hoy)
        assertEquals(1, l.size)
        assertEquals(hoy + 3, l[0].proximo)
    }

    @Test fun vencidosSonLosQueYaTocan() {
        val l = listOf(TemaRepaso("a", 0, hoy - 2), TemaRepaso("b", 1, hoy + 3), TemaRepaso("c", 2, hoy))
        assertEquals(listOf("a", "c"), RepasoLogica.vencidos(l, hoy).map { it.nombre })
        assertEquals("No tienes nada pendiente de repasar hoy.", RepasoLogica.textoDeVencidos(emptyList()))
        assertEquals("Hoy te toca repasar: a, c.", RepasoLogica.textoDeVencidos(RepasoLogica.vencidos(l, hoy)))
    }

    @Test fun seGuardaYSeLeeSinPerderNada() {
        val l = listOf(TemaRepaso("Anatomía del corazón", 2, 20_005L), TemaRepaso("Mitosis", 0, 20_001L))
        assertEquals(l, RepasoLogica.leer(RepasoLogica.serializar(l)))
        assertEquals(emptyList<TemaRepaso>(), RepasoLogica.leer(""))
        assertEquals(emptyList<TemaRepaso>(), RepasoLogica.leer("basura"))
    }

    @Test fun elPedidoALaIaSoloLlevaElTema() {
        val p = RepasoLogica.pedidoDeRepaso("la mitosis")
        assertTrue(p.contains("«la mitosis»"))
        assertTrue(p.contains("UNA pregunta"))
    }

    private val fecha = LocalDate.of(2026, 11, 20)
    private fun i(t: String) = Interprete.interpretar(t, fecha, LocalTime.of(9, 0))

    @Test fun ordenesDeVozDelRepaso() {
        assertEquals(Intencion.Repasar("mitosis"), i("Repasa la mitosis"))
        assertEquals(Intencion.Repasar("embriologia"), i("Hazme un repaso de embriología"))
        assertEquals(Intencion.Repasar("anatomia del corazon"), i("Ponme un examen sobre anatomía del corazón"))
        assertEquals(Intencion.RepasoHecho("mitosis", true), i("Ya repasé la mitosis"))
        assertEquals(Intencion.RepasoHecho("mitosis", false), i("Me fue mal en la mitosis"))
        assertEquals(Intencion.RepasoHecho("meiosis", true), i("Me fue bien en la meiosis"))
        assertEquals(Intencion.ConsultarRepasos, i("¿Qué me toca repasar hoy?"))
        assertEquals(Intencion.ConsultarRepasos, i("Qué debo repasar"))
    }

    @Test fun repasarUnaCosaDelHorarioNoEsUnRepaso() {
        assertTrue(i("Repasa mi horario") !is Intencion.Repasar)
    }

    @Test fun vincularDeNuevo() {
        assertEquals(Intencion.Reconectar, i("Vincula de nuevo"))
        assertEquals(Intencion.Reconectar, i("Julio, reconecta"))
        assertEquals(Intencion.Reconectar, i("Empareja otra vez los teléfonos"))
    }
}
