package com.julio.asistente.comandos

import com.julio.asistente.ejecutor.Decision
import com.julio.asistente.ejecutor.Ejecutor
import com.julio.asistente.ejecutor.Nivel
import com.julio.asistente.ejecutor.Solicitante
import com.julio.asistente.rutinas.ComandoRutina
import com.julio.asistente.rutinas.RutinasLogica
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** Órdenes nuevas de la v52: conversación, llamadas, actividad, diagnóstico, sincronizar, configuración y rutinas básicas. Sin Android. */
class V52Test {
    private val hoy = LocalDate.of(2026, 11, 15)
    private val ahora = LocalTime.of(9, 0)
    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun hablemosIniciaLaConversacion() {
        assertEquals(Intencion.IniciarConversacion, i("Julio, hablemos"))
        assertEquals(Intencion.IniciarConversacion, i("Vamos a hablar"))
        assertEquals(Intencion.IniciarConversacion, i("Hablemos con la IA"))
    }

    @Test fun terminarSoloSeEntiendeSolitoDentroDeLaConversacion() {
        assertTrue(ModoConversacion.pideTerminar("termina"))
        assertTrue(ModoConversacion.pideTerminar("adios"))
        assertTrue(ModoConversacion.pideTerminar("termina la conversacion"))
        assertTrue(!ModoConversacion.pideTerminar("termina la tarea"))
        assertTrue(!ModoConversacion.pideTerminar("que es la mitosis"))
        assertEquals(Intencion.TerminarConversacion, i("Termina la conversación"))
    }

    @Test fun enConversacionLoQueNoEsOrdenVaALaIA() {
        assertTrue(ModoConversacion.debeIrALaIA(Intencion.Desconocida))
        assertTrue(ModoConversacion.debeIrALaIA(Intencion.Ambigua("x")))
        assertTrue(!ModoConversacion.debeIrALaIA(Intencion.AjustarVolumen(AccionNivel.SUBIR)))
        assertTrue(ModoConversacion.vencida(0, ModoConversacion.SILENCIO_MS + 1))
        assertTrue(!ModoConversacion.vencida(0, ModoConversacion.SILENCIO_MS))
    }

    @Test fun llamar() {
        assertEquals(Intencion.Llamar("mama"), i("Llama a mamá"))
        assertEquals(Intencion.Llamar("ana perez"), i("Julio, llámale a Ana Pérez"))
        assertEquals(Intencion.Llamar("papa"), i("Llama a mi papá"))
        assertEquals(Intencion.Llamar(null), i("Llama"))
        assertEquals(Intencion.Llamar("juan"), i("Marca a Juan"))
    }

    @Test fun llamarNoSeConfundeConOtrasOrdenes() {
        assertTrue(i("Marca como terminada la tarea del informe") is Intencion.CompletarTarea)
        assertTrue(i("Recuérdame llamar a mamá mañana a las cinco") !is Intencion.Llamar)
    }

    @Test fun actividadDelTelefonoNoChocaConElHorario() {
        assertEquals(Intencion.RevisarActividad, i("Revisa mi actividad"))
        assertEquals(Intencion.RevisarActividad, i("¿Cuánto he usado el teléfono?"))
        assertEquals(Intencion.RevisarActividad, i("Muéstrame el tiempo de pantalla"))
        assertTrue(i("Elimina la actividad de química") is Intencion.Eliminar)
    }

    @Test fun diagnosticoSincronizarYConfiguracion() {
        assertEquals(Intencion.DiagnosticarAvisos, i("Diagnóstico de avisos"))
        assertEquals(Intencion.DiagnosticarAvisos, i("¿Por qué no me avisas?"))
        assertEquals(Intencion.SincronizarAhora, i("Sincroniza"))
        assertEquals(Intencion.ModoManual, i("Julio, configuración"))
        assertTrue(i("¿Qué notificaciones tengo?") == Intencion.ConsultarAvisos)
    }

    @Test fun losNivelesDeLasOrdenesNuevas() {
        assertEquals(Nivel.N2, Ejecutor.nivel(Intencion.Llamar("mama")))
        assertEquals(Nivel.N0, Ejecutor.nivel(Intencion.RevisarActividad))
        assertEquals(Nivel.N0, Ejecutor.nivel(Intencion.DiagnosticarAvisos))
        assertEquals(Nivel.N1, Ejecutor.nivel(Intencion.IniciarConversacion))
        assertEquals(Nivel.N1, Ejecutor.nivel(Intencion.SincronizarAhora))
        // Una rutina nunca puede llamar; la IA solo con un «sí».
        assertTrue(Ejecutor.decidir(Solicitante.RUTINA, Intencion.Llamar("mama")) is Decision.Rechazar)
        assertTrue(Ejecutor.decidir(Solicitante.IA, Intencion.Llamar("mama")) is Decision.Confirmar)
    }

    @Test fun rutinasBasicas() {
        assertEquals(ComandoRutina.InstalarBasicas, RutinasLogica.comando("Instala las rutinas básicas"))
        assertEquals(ComandoRutina.InstalarBasicas, RutinasLogica.comando("Crea las rutinas de ejemplo"))
        assertTrue(RutinasLogica.comando("Crea la rutina noche que haga silencia el volumen") is ComandoRutina.Crear)
        for (p in RutinasLogica.PLANTILLAS) {
            assertEquals("la plantilla ${p.nombre} debe ser válida", emptyList<String>(), RutinasLogica.validar(p.nombre, RutinasLogica.VOZ, null, p.acciones, hoy, ahora))
        }
    }

    // ---- Contactos ----
    private val agenda = listOf(
        ContactoInfo("Mamá", "+504 9999-1234"), ContactoInfo("Mamá", "+50499991234"),
        ContactoInfo("Ana Pérez", "8888 5555"), ContactoInfo("Ana López", "7777 4444"), ContactoInfo("Dr. Juan", "2222 3333"),
    )

    @Test fun contactosUnoVariosONinguno() {
        assertTrue(Contactos.buscar("mamá", agenda) is BusquedaContacto.Uno) // el mismo número repetido es uno solo
        assertTrue(Contactos.buscar("ana", agenda) is BusquedaContacto.Varios)
        assertEquals("Ana Pérez", ((Contactos.buscar("ana perez", agenda)) as BusquedaContacto.Uno).contacto.nombre)
        assertTrue(Contactos.buscar("juan", agenda) is BusquedaContacto.Uno)
        assertTrue(Contactos.buscar("pedro", agenda) is BusquedaContacto.Ninguno)
        assertTrue(Contactos.buscar("mi mamá", agenda) is BusquedaContacto.Uno)
    }

    @Test fun numerosLimpios() {
        assertEquals("+50499991234", Contactos.limpiarNumero("+504 9999-1234"))
        assertEquals("88885555", Contactos.limpiarNumero("8888 5555"))
        assertEquals("1234", Contactos.finalDe("+504 9999-1234"))
    }
}
