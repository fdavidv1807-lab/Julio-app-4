# Espejo de MenuSector (v47): el menú en cuarto de círculo. Mismos casos que JarvisLogicaTest.
import math
ABERTURA, PASO = 90.0, 27.0
def giro_max(n, paso=PASO): return max(0.0, n*paso-ABERTURA)
def limitar(s, n): return min(max(s, 0.0), giro_max(n))
def acomodar(s, n):
    tope = giro_max(n); cerca = round(s/PASO)*PASO
    c = [min(max(cerca, 0.0), tope), tope]
    return min(c, key=lambda x: abs(x-s))
def centro(i, s): return ABERTURA-(i+0.5)*PASO+s
def texto_visible(i, s): c = centro(i, s); return PASO*0.35 <= c <= ABERTURA-PASO*0.35
def angulo(dx, dy): return math.degrees(math.atan2(dy, dx))
def opcion_en(phi, s, n):
    if phi < 0 or phi > ABERTURA: return None
    k = math.floor((ABERTURA+s-phi)/PASO)
    return k if 0 <= k < n else None
def ok(c, m): 
    assert c, m
ok(giro_max(3) == 0, "caben 3"); ok(limitar(50, 3) == 0, "limitar 3")
ok(abs(giro_max(9)-153) < 1e-6, "giro 9"); ok(limitar(999, 9) == 153, "tope"); ok(limitar(-20, 9) == 0, "piso")
ok(abs(centro(0, 0)-76.5) < 1e-6, "c0"); ok(abs(centro(8, 153)-13.5) < 1e-6, "c8")
ok(opcion_en(80, 0, 9) == 0, "o80"); ok(opcion_en(60, 0, 9) == 1, "o60"); ok(opcion_en(10, 0, 9) == 2, "o10")
ok(opcion_en(5, 153, 9) == 8, "final"); ok(opcion_en(95, 0, 9) is None, "fuera"); ok(opcion_en(10, 0, 2) is None, "sin opcion")
ok(abs(angulo(10, 0)) < 1e-6 and abs(angulo(0, 10)-90) < 1e-6 and abs(angulo(7, 7)-45) < 1e-6, "angulos")
ok(acomodar(30, 9) == 27 and acomodar(5, 9) == 0 and acomodar(150, 9) == 153, "acomodar")
ok(texto_visible(0, 0) and not texto_visible(8, 0), "texto")
# Cada opción de un menú de 9 es alcanzable: con el giro adecuado su centro queda dentro del cuarto.
for n in (6, 9):
    for i in range(n):
        alcanzable = any(0 < centro(i, s) < 90 for s in [k*PASO for k in range(0, 8)] + [giro_max(n)] if 0 <= s <= giro_max(n))
        ok(alcanzable, f"opcion {i} de {n}")
# Geometría: ángulos de pantalla del sector (derecha: φ-180; izquierda: -φ)
for phi in (0, 45, 90):
    ok(abs(math.degrees(math.atan2(-math.sin(math.radians(phi)), -math.cos(math.radians(phi))))-(phi-180)) < 1e-6 or phi == 0, "derecha")
print("espejo9 OK: menú en cuarto de círculo")
