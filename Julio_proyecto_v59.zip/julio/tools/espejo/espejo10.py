# Espejo de RutinasLogica (v49): voz, hora, separar órdenes y órdenes de voz sobre rutinas. Mismos casos que RutinasLogicaTest.
# No es el código real: valida las reglas (regex, ventanas, máscaras) cuando no hay compilador de Kotlin.
import re, unicodedata
from datetime import datetime, timedelta

def normalizar(s):
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]", " ", s)).strip()

RELLENO = {"julio", "por", "favor", "porfa", "oye", "hola", "ey"}
def sin_relleno(n): return [w for w in n.split(" ") if w and w not in RELLENO]
def coincide_voz(frase, dicho):
    a, b = sin_relleno(normalizar(frase)), sin_relleno(normalizar(dicho))
    return bool(a) and a == b

def parsear_hora(t):
    m = re.match(r"^\s*([01]?\d|2[0-3])\s*[:.hH]\s*([0-5]\d)\s*$", t)
    return int(m.group(1)) * 60 + int(m.group(2)) if m else None

VENTANA = 5
def toca_ahora(r, ahora):
    # r: dict(activa, disparador, minuto, mascara, ultima(datetime|None))
    if not r["activa"] or r["disparador"] != "HORA" or r["minuto"] is None: return False
    dia = ahora.weekday()  # lunes = 0
    if r["mascara"] != 0 and ((r["mascara"] >> dia) & 1) == 0: return False
    am = ahora.hour * 60 + ahora.minute
    if am < r["minuto"] or am - r["minuto"] >= VENTANA: return False
    if r["ultima"] is None: return True
    inicio = ahora.replace(hour=r["minuto"] // 60, minute=r["minuto"] % 60, second=0, microsecond=0)
    return r["ultima"] < inicio

CORTE = re.compile(r"\s+y\s+(?=(pon|sube|baja|silencia|abre|activa|inicia|empieza|comienza|pausa|deten|reanuda|sigue|termina|finaliza|siguiente|retrocede|dime|cuales|cual|cuanto|cuantas|muestra|muestrame|programa|crea|enciende|apaga|quita|consulta)\b)")
SEPARADOR = re.compile(r"\s*,\s*|\s*;\s*|\s+(?:y\s+)?(?:luego|despues|ademas)\s+")
def separar(n):
    partes = []
    for p in SEPARADOR.split(n):
        partes += CORTE.split(p) if False else re.split(CORTE, p)
    # re.split con grupo de captura mete el grupo; se filtra quedándose con los trozos que no son solo el verbo
    return partes

def separar_ordenes(n):
    out = []
    for p in SEPARADOR.split(n):
        # equivalente a Kotlin split(Regex) con lookahead (sin grupos de captura)
        pos, trozos = 0, []
        for m in CORTE.finditer(p):
            trozos.append(p[pos:m.start()]); pos = m.end()
        trozos.append(p[pos:])
        out += trozos
    return [x.strip() for x in out if x.strip()]

CREAR = re.compile(r"^(?:julio\s+)?(?:crea|crear|haz|hacer|agrega|agregar|programa|programar|guarda|guardar)\s+(?:una\s+|la\s+|mi\s+)?(?:nueva\s+)?rutina\s+(?:de\s+|llamada\s+)?(.+?)\s+(?:que\s+haga|que\s+ejecute|que\s+diga|que|con)\s+(.+)$")
LISTAR = re.compile(r"\b(que|cuales|dime|lista|muestrame|muestra|mis)\b.*\brutinas?\b|\brutinas?\b.*\b(tengo|hay|guardadas|activas)\b")
ALTERNAR = re.compile(r"^(?:julio\s+)?(enciende|prende|activa|activar|apaga|desactiva|desactivar)\s+(?:la\s+)?rutina\s+(?:de\s+)?(.+)$")
EJECUTAR = re.compile(r"^(?:julio\s+)?(?:ejecuta|ejecutar|corre|correr|lanza|lanzar|haz|hacer|inicia|iniciar|empieza|comienza)\s+(?:la\s+)?rutina\s+(?:de\s+)?(.+)$")
BORRAR = re.compile(r"^(?:julio\s+)?(?:borra|borrar|elimina|eliminar|quita|quitar)\s+(?:la\s+)?rutina\s+(?:de\s+)?(.+)$")

def comando(texto):
    n = normalizar(re.sub(r"[,;]", " luego ", texto))  # normalizar borra las comas: se vuelven «luego» antes
    if not re.search(r"\brutinas?\b", n): return None
    m = CREAR.search(n)
    if m:
        nombre, ords = m.group(1).strip(), separar_ordenes(m.group(2))
        if nombre and ords: return ("crear", nombre, ords)
    m = BORRAR.search(n)
    if m: return ("borrar", m.group(1).strip())
    m = ALTERNAR.search(n)
    if m:
        v = m.group(1)
        return ("alternar", m.group(2).strip(), v.startswith(("enciende", "prende", "activa")))
    m = EJECUTAR.search(n)
    if m: return ("ejecutar", m.group(1).strip())
    if LISTAR.search(n): return ("listar",)
    return None

def ok(c, m): assert c, m

# hora
ok(parsear_hora("7:30") == 450 and parsear_hora("07:30") == 450 and parsear_hora("23:59") == 1439, "hora ok")
ok(parsear_hora("24:00") is None and parsear_hora("7:5") is None and parsear_hora("abc") is None, "hora mala")
ok(parsear_hora("7h30") == 450 and parsear_hora(" 0:00 ") == 0, "hora variantes")
# voz
ok(coincide_voz("Buenos días", "Julio, buenos dias por favor"), "voz con relleno")
ok(not coincide_voz("buenos dias", "buenos dias de nuevo"), "voz no es 'contiene'")
ok(not coincide_voz("", "algo") and not coincide_voz("julio", "julio"), "voz vacía")
ok(coincide_voz("modo estudio", "modo estudio"), "voz igual")
# toca ahora (lunes 2026-11-09)
lun = datetime(2026, 11, 9, 7, 32)
r = dict(activa=True, disparador="HORA", minuto=450, mascara=0, ultima=None)
ok(toca_ahora(r, lun), "dentro de ventana")
ok(not toca_ahora(r, datetime(2026, 11, 9, 7, 29)), "antes de la hora")
ok(not toca_ahora(r, datetime(2026, 11, 9, 7, 35)), "ventana vencida (5 min)")
ok(toca_ahora(r, datetime(2026, 11, 9, 7, 34)), "último minuto de la ventana")
ok(not toca_ahora({**r, "ultima": datetime(2026, 11, 9, 7, 30, 20)}, lun), "ya ejecutada hoy")
ok(toca_ahora({**r, "ultima": datetime(2026, 11, 8, 7, 30)}, lun), "ejecutada ayer")
ok(not toca_ahora({**r, "mascara": 0b0000010}, lun), "solo martes: lunes no")
ok(toca_ahora({**r, "mascara": 0b0000001}, lun), "solo lunes: lunes sí")
ok(not toca_ahora({**r, "activa": False}, lun) and not toca_ahora({**r, "disparador": "VOZ"}, lun), "apagada/otro disparador")
# separar órdenes
ok(separar_ordenes("sube el volumen, pon musica y baja el brillo al 30") == ["sube el volumen", "pon musica", "baja el brillo al 30"], "separa 3")
ok(separar_ordenes("pon musica de bad bunny y karol g") == ["pon musica de bad bunny y karol g"], "no parte nombres con y")
ok(separar_ordenes("silencia luego abre whatsapp") == ["silencia", "abre whatsapp"], "luego")
# comandos
c = comando("Crea la rutina buenos días que haga sube el volumen, pon música y baja el brillo")
ok(c == ("crear", "buenos dias", ["sube el volumen", "pon musica", "baja el brillo"]), "crear %r" % (c,))
ok(comando("crea una rutina noche con silencia el volumen")[0:2] == ("crear", "noche"), "crear con 'con'")
ok(comando("¿Qué rutinas tengo?") == ("listar",), "listar")
ok(comando("apaga la rutina noche") == ("alternar", "noche", False), "apagar")
ok(comando("enciende la rutina de estudio") == ("alternar", "estudio", True), "encender")
ok(comando("ejecuta la rutina estudio") == ("ejecutar", "estudio"), "ejecutar")
ok(comando("haz la rutina estudio") == ("ejecutar", "estudio"), "haz la rutina = ejecutar")
ok(comando("borra la rutina noche") == ("borrar", "noche"), "borrar")
ok(comando("sube el volumen") is None and comando("cuanto dura la rutina") is None, "no toca otras frases")
print("espejo10 OK")
