"""Quita el fondo verde de las poses del gorila holográfico y deja PNG con transparencia."""
import sys
import numpy as np
from PIL import Image

D = "/mnt/user-data/attachments/e1c24dcf-0c9a-58d7-b4fb-c0dfee6f7612/"
OUT = sys.argv[1]
# nombre final -> (archivo, descripción)
POSES = {
    "julio_holo_reposo": "6ab04168",      # ojos abiertos, sonrisa cerrada
    "julio_holo_habla_media": "e4276d26", # boca medio abierta (horizontal)
    "julio_holo_habla_abierta": "c3b9c9ba",  # boca muy abierta
    "julio_holo_ojos_cerrados": "5328262d",  # ojos cerrados, boca cerrada (parpadeo / dormido)
    "julio_holo_habla_ojos": "e2fef22c",  # ojos cerrados, boca abierta (parpadeo al hablar)
}
BG = np.array([14.0, 240.0, 8.0])

def quitar(a):
    a = a.astype(np.float32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    d = g - np.maximum(r, b)             # el fondo es verde puro: g muy por encima de r y b
    alfa = np.clip((205.0 - d) / (205.0 - 35.0), 0, 1)
    alfa = alfa * alfa * (3 - 2 * alfa)  # suaviza el borde
    al = np.maximum(alfa, 1e-3)[..., None]
    fg = (a - (1 - alfa)[..., None] * BG) / al
    fg = np.clip(fg, 0, 255)
    # quitar el tinte verde que quede en el borde
    fg[..., 1] = np.minimum(fg[..., 1], np.maximum(fg[..., 0], fg[..., 2]) * 1.05 + 4)
    fg[alfa < 0.02] = 0
    return np.dstack([fg, alfa * 255]).astype(np.uint8)

def bbox(rgba, umbral=40):
    ys, xs = np.where(rgba[..., 3] > umbral)
    return xs.min(), ys.min(), xs.max() + 1, ys.max() + 1

res = {}
for nombre, f in POSES.items():
    im = np.array(Image.open(D + f + "-image.jpg").convert("RGB"))
    rgba = quitar(im)
    res[nombre] = (rgba, bbox(rgba))
    print(nombre, rgba.shape, res[nombre][1])

# caja común: la de las poses verticales (todas iguales); la horizontal se escala a esa caja.
ref = res["julio_holo_reposo"][1]
ANCHO = 640
M = 10
rw, rh = ref[2] - ref[0], ref[3] - ref[1]
alto = round(ANCHO * (rh + 2 * M) / (rw + 2 * M))
for nombre, (rgba, bb) in res.items():
    img = Image.fromarray(rgba, "RGBA")
    x0, y0, x1, y1 = bb
    if nombre == "julio_holo_habla_media":
        sc = rw / (x1 - x0)
        # lleva la caja de esta pose a la medida de la de referencia
        img = img.crop((x0 - M / sc, y0 - M * rh / (y1 - y0) / sc * 0 - M / sc, x1 + M / sc, y1 + M / sc))
        img = img.resize((rw + 2 * M, rh + 2 * M), Image.LANCZOS)
    else:
        img = img.crop((ref[0] - M, ref[1] - M, ref[2] + M, ref[3] + M))
    img = img.resize((ANCHO, alto), Image.LANCZOS)
    img.save(f"{OUT}/{nombre}.png", optimize=True)
    fondo = Image.new("RGBA", img.size, (0, 0, 0, 255)); fondo.alpha_composite(img)
    fondo.convert("RGB").save(f"{OUT}/_prev_{nombre}.png")
print("tamaño", ANCHO, alto)
