# Relé cifrado (opcional): sincronizar fuera de casa

**Para qué sirve:** que el horario, las tareas y las alarmas se sincronicen entre el Cuerpo y el Diario aunque el Diario no esté en tu Wi-Fi.
**Qué NO hace:** no manda avisos de WhatsApp, ni códigos, ni el uso del teléfono. Eso sigue siendo solo por tu Wi-Fi.
**Seguridad:** todo se cifra en tu teléfono con el secreto del QR antes de salir. El servidor (Firebase) solo guarda texto ilegible: sin el QR nadie puede leerlo ni cambiarlo. Es gratis (el plan Spark de Firebase alcanza de sobra). Está APAGADO de fábrica.

## Pasos (se pueden hacer desde el navegador del teléfono)
1. Entra a **console.firebase.google.com** con tu cuenta de Google y toca **Crear un proyecto**. Nombre: `julio-sync`. Desactiva Google Analytics. Crear.
2. En el menú **Compilación** (o Build) toca **Realtime Database** y luego **Crear base de datos**. Ubicación: la que te dé por defecto. Modo: **bloqueado** (locked mode). Habilitar.
3. Toca la pestaña **Reglas**. Borra todo lo que haya y pega EXACTAMENTE esto, luego toca **Publicar**:

```json
{
  "rules": {
    ".read": false,
    ".write": false,
    "julio": {
      "$canal": {
        ".read": "$canal.matches(/^[A-Za-z0-9]{10,64}$/)",
        ".write": "$canal.matches(/^[A-Za-z0-9]{10,64}$/)",
        "req": { "$id": { ".validate": "newData.isString() && newData.val().length < 400000" } },
        "res": { "$id": { ".validate": "newData.isString() && newData.val().length < 400000" } },
        "$otro": { ".validate": false }
      }
    }
  }
}
```

4. Toca la pestaña **Datos**. Arriba verás una dirección parecida a `https://julio-sync-default-rtdb.firebaseio.com`. Cópiala.
5. En **los dos teléfonos** (Cuerpo y Diario): Configuración > Avisos y enlace > «Fuera de casa (relé cifrado)». Pega la dirección, toca **Guardar**, enciende **Usar el relé fuera de casa** y toca **Probar**. Debe decir que funciona.
6. Listo. Con el Cuerpo en modo escritorio y conectado a internet, el Diario sincroniza por el relé cuando no encuentra al Cuerpo en tu Wi-Fi (puede tardar unos segundos).

## Si algo falla
- «Firebase rechazó la escritura»: las reglas no se publicaron bien (paso 3).
- «No pude conectar»: revisa el internet y que la dirección esté completa.
- El Cuerpo solo atiende el relé mientras el **modo escritorio está abierto** y la sincronización está encendida.
