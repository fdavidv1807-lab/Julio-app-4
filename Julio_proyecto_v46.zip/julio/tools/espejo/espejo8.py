"""Espejo (Python) de la lógica pura de v46: ContadorToques, abanico, atrás, regex de «modo manual»."""
import re

class ContadorToques:
    def __init__(s, necesarios=4, ventana=2500): s.n=necesarios; s.v=ventana; s.t=[]
    def registrar(s, ahora):
        while s.t and ahora - s.t[0] > s.v: s.t.pop(0)
        s.t.append(ahora)
        if len(s.t) >= s.n: s.t=[]; return True
        return False

def pos(i, total, gmax=7.0):
    if total <= 1: return (0.0, 1.0, 0.0)
    m=(total-1)/2; t=(i-m)/m; return (t, 1-t*t, t*gmax)

def alto(disp, total): return min(44.0, max(28.0, disp/total*0.82))

def atras(v, panel):
    if panel: return (v, False)
    if v in ("MI_DIA","CONFIG"): return ("MANUAL", False)
    if v == "MANUAL": return ("JULIO", False)
    return ("JULIO", False)

MM=re.compile(r"^(?:julio )?(?:(?:activa|activar|abre|abrir|pon|poner|entra a|entrar a|quiero|muestra|muestrame) )?(?:el )?modo manual$")

c=ContadorToques(); assert [c.registrar(x) for x in (0,400,800,1200)]==[False,False,False,True]
c=ContadorToques(); assert not any(c.registrar(i*1500) for i in range(10))
c=ContadorToques(); [c.registrar(x) for x in (0,100,200)]; assert c.registrar(300); assert not c.registrar(400)
a,z,m=pos(0,5),pos(4,5),pos(2,5); assert a[0]==-1 and z[0]==1 and m[0]==0 and a[1]==0 and m[1]==1 and a[2]==-z[2]
assert alto(900,5)==44 and alto(150,8)==28
assert atras("CONFIG",True)==("CONFIG",False) and atras("CONFIG",False)==("MANUAL",False) and atras("MANUAL",False)==("JULIO",False)
for ok in ("modo manual","julio modo manual","activa el modo manual","julio abre el modo manual"): assert MM.match(ok), ok
for no in ("modo automatico","pon musica manual","modo manual de la camara"): assert not MM.match(no), no
print("espejo8: todo pasa")
