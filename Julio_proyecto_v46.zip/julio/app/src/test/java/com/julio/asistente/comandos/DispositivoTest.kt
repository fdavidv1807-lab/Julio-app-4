package com.julio.asistente.comandos

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** Volumen, brillo y abrir apps (Etapa 3 del Proyecto Cuerpo). Sin Android. */
class DispositivoTest {
    private val hoy = LocalDate.of(2026, 11, 6)
    private val ahora = LocalTime.of(9, 0)
    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun modoManual() {
        assertEquals(Intencion.ModoManual, i("Modo manual"))
        assertEquals(Intencion.ModoManual, i("Julio, modo manual"))
        assertEquals(Intencion.ModoManual, i("Activa el modo manual"))
    }

    @Test fun subeYBajaElVolumen() {
        assertEquals(Intencion.AjustarVolumen(AccionNivel.SUBIR), i("Sube el volumen"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.BAJAR), i("Baja el volumen"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.BAJAR), i("Pon el volumen más bajo"))
    }

    @Test fun fijaElVolumenConNumeroOPalabras() {
        assertEquals(Intencion.AjustarVolumen(AccionNivel.FIJAR, 40), i("Pon el volumen al cuarenta por ciento"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.FIJAR, 40), i("Pon el volumen al 40%"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.FIJAR, 80), i("Sube el volumen al 80"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.FIJAR, 100), i("Volumen al máximo"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.FIJAR, 100), i("Volumen al cien por ciento"))
    }

    @Test fun silenciaYActivaElSonido() {
        assertEquals(Intencion.AjustarVolumen(AccionNivel.SILENCIAR), i("Silencia el teléfono"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.ACTIVAR), i("Activa el sonido"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.ACTIVAR), i("Quita el silencio"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.CONSULTAR), i("¿Cómo está el volumen?"))
    }

    @Test fun ajustaElBrillo() {
        assertEquals(Intencion.AjustarBrillo(AccionNivel.BAJAR), i("Baja el brillo"))
        assertEquals(Intencion.AjustarBrillo(AccionNivel.SUBIR), i("Sube el brillo un poco"))
        assertEquals(Intencion.AjustarBrillo(AccionNivel.FIJAR, 30), i("Brillo al treinta por ciento"))
        assertEquals(Intencion.AjustarBrillo(AccionNivel.FIJAR, 100), i("Pon el brillo al máximo"))
        assertEquals(Intencion.AjustarBrillo(AccionNivel.AUTOMATICO), i("Brillo automático"))
    }

    @Test fun abreAplicaciones() {
        assertEquals(Intencion.AbrirApp("whatsapp"), i("Abre WhatsApp"))
        assertEquals(Intencion.AbrirApp("whatsapp"), i("Julio abre WhatsApp"))
        assertEquals(Intencion.AbrirApp("spotify"), i("Abre la aplicación de Spotify"))
        assertEquals(Intencion.AbrirApp("google maps"), i("Abre Google Maps por favor"))
        assertEquals(Intencion.AbrirApp(null), i("Abre"))
    }

    @Test fun noRobaOrdenesDeAlarmasNiEnfoque() {
        assertEquals(
            Intencion.CrearAlarma(LocalTime.of(6, 0), LocalDate.of(2026, 11, 7), 0, null),
            i("Pon una alarma para mañana a las seis de la mañana"),
        )
        assertEquals(Intencion.IniciarEnfoque(35), i("Inicia una sesión de enfoque de 35 minutos"))
    }
}
