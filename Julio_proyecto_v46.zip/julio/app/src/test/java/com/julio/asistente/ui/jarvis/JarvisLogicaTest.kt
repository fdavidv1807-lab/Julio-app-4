package com.julio.asistente.ui.jarvis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class JarvisLogicaTest {
    @Test fun cuatroToquesRapidosActivan() {
        val c = ContadorToques()
        assertFalse(c.registrar(0)); assertFalse(c.registrar(400)); assertFalse(c.registrar(800))
        assertTrue(c.registrar(1200))
    }

    @Test fun tresToquesNoActivan() {
        val c = ContadorToques()
        assertFalse(c.registrar(0)); assertFalse(c.registrar(300)); assertFalse(c.registrar(600))
    }

    @Test fun toquesLentosNoActivan() {
        val c = ContadorToques()
        for (i in 0 until 10) assertFalse(c.registrar(i * 1_500L))
    }

    @Test fun trasActivarEmpiezaDeCero() {
        val c = ContadorToques()
        for (t in listOf(0L, 100L, 200L)) c.registrar(t)
        assertTrue(c.registrar(300))
        assertFalse(c.registrar(400))
        assertFalse(c.registrar(500))
        assertFalse(c.registrar(600))
        assertTrue(c.registrar(700))
    }

    @Test fun julioSeVaAlLadoContrarioAlBotonElegido() {
        assertEquals(LadoJulio.IZQUIERDA, JarvisLogica.ladoJulio(Vista.CONFIG))
        assertEquals(LadoJulio.DERECHA, JarvisLogica.ladoJulio(Vista.MI_DIA))
        assertEquals(LadoJulio.CENTRO, JarvisLogica.ladoJulio(Vista.MANUAL))
        assertEquals(LadoJulio.CENTRO, JarvisLogica.ladoJulio(Vista.JULIO))
    }

    @Test fun atrasCierraPrimeroElPanel() {
        assertEquals(Vista.CONFIG to false, JarvisLogica.atras(Vista.CONFIG, true))
        assertEquals(Vista.MANUAL to false, JarvisLogica.atras(Vista.CONFIG, false))
        assertEquals(Vista.MANUAL to false, JarvisLogica.atras(Vista.MI_DIA, false))
        assertEquals(Vista.JULIO to false, JarvisLogica.atras(Vista.MANUAL, false))
        assertEquals(Vista.JULIO to false, JarvisLogica.atras(Vista.JULIO, false))
    }

    @Test fun abanicoEsSimetrico() {
        val a = JarvisLogica.posicionAbanico(0, 5)
        val z = JarvisLogica.posicionAbanico(4, 5)
        val m = JarvisLogica.posicionAbanico(2, 5)
        assertEquals(-1f, a.t, 1e-4f); assertEquals(1f, z.t, 1e-4f); assertEquals(0f, m.t, 1e-4f)
        assertEquals(0f, a.empuje, 1e-4f); assertEquals(1f, m.empuje, 1e-4f)
        assertEquals(-z.grados, a.grados, 1e-4f)
    }

    @Test fun abanicoConUnSoloElemento() {
        assertEquals(JarvisLogica.PosicionAbanico(0f, 1f, 0f), JarvisLogica.posicionAbanico(0, 1))
    }

    @Test fun altoDelAbanicoQuedaEntre28y44() {
        assertEquals(44f, JarvisLogica.altoElementoAbanico(900f, 5), 1e-4f)
        assertEquals(28f, JarvisLogica.altoElementoAbanico(150f, 8), 1e-4f)
    }

    @Test fun elModoSoloSeEligeUnaVez() {
        assertTrue(JarvisLogica.puedeElegirModo(ModoApp.Modo.SIN_ELEGIR))
        assertFalse(JarvisLogica.puedeElegirModo(ModoApp.Modo.ESCRITORIO))
        assertFalse(JarvisLogica.puedeElegirModo(ModoApp.Modo.DIARIO))
    }

    @Test fun elCuerpoVuelveSoloAJulio() {
        assertEquals(0, JarvisLogica.segundosParaVolver(Vista.JULIO))
        assertTrue(JarvisLogica.segundosParaVolver(Vista.MANUAL) in 1..60)
        assertTrue(JarvisLogica.segundosParaVolver(Vista.CONFIG) > 60)
    }
}
