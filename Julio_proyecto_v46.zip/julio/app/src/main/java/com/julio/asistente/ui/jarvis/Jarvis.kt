package com.julio.asistente.ui.jarvis

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.animacion.EventoCapa
import com.julio.asistente.animacion.JulioEstado
import com.julio.asistente.animacion.Principal
import com.julio.asistente.ui.hud.HudColores
import com.julio.asistente.ui.hud.HudLogica
import com.julio.asistente.ui.hud.HudOrbe
import com.julio.asistente.ui.hud.HudPanel
import com.julio.asistente.ui.hud.esquinas
import com.julio.asistente.ui.hud.marco
import com.julio.asistente.ui.hud.rememberAlerta
import com.julio.asistente.ui.screens.AlarmasScreen
import com.julio.asistente.ui.screens.ConfiguracionPanel
import com.julio.asistente.ui.screens.EnfoqueScreen
import com.julio.asistente.ui.screens.EstudioScreen
import com.julio.asistente.ui.screens.HorarioScreen
import com.julio.asistente.ui.screens.SECCIONES_CONFIGURACION
import com.julio.asistente.ui.screens.TareasScreen
import com.julio.asistente.ui.screens.VozScreen
import com.julio.asistente.voz.VozViewModel

/**
 * Interfaz holográfica (v46, tipo Jarvis). Una sola pieza para los dos modos:
 *  - Cuerpo (escritorio): normalmente solo Julio; con «modo manual» o 4 toques salen los botones MI DÍA y CONFIGURACIÓN.
 *  - Diario: Julio con los dos botones siempre a la vista, más el botón CONSOLA (hablar, escribir, conversación).
 * Al elegir un botón, Julio se desplaza hacia el lado donde NO se eligió; ese otro botón se apaga y el elegido queda arriba
 * como título, con su abanico de opciones debajo.
 */

private val ITEMS_MI_DIA = listOf("Horario", "Tareas", "Estudio", "Alarmas", "Enfoque")
private const val PANEL_CONSOLA = "Consola"
private val MONO = FontFamily.Monospace

// ---------------------------------------------------------------------------------------------------------------------
// Elección del modo (solo la primera vez, permanente)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun PantallaElegirModo(alElegir: (ModoApp.Modo) -> Unit) {
    var pendiente by remember { mutableStateOf<ModoApp.Modo?>(null) }
    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Canvas(Modifier.fillMaxSize()) { esquinas(HudColores.Cian) }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        ) {
            TituloJulio(HudColores.Cian)
            Text("¿QUÉ SERÁ ESTE TELÉFONO?", color = HudColores.Blanco, fontSize = 14.sp, fontFamily = MONO, letterSpacing = 3.sp, textAlign = TextAlign.Center)
            HudPanel("ESCRITORIO", HudColores.Cian, Modifier.clickable { pendiente = ModoApp.Modo.ESCRITORIO }) {
                Text(
                    "El Cuerpo de Julio: fijo en tu escritorio, siempre enchufado. Escucha «Julio» y te lee los avisos.",
                    color = HudColores.Blanco, fontSize = 13.sp,
                )
            }
            HudPanel("DIARIO", HudColores.Turquesa, Modifier.clickable { pendiente = ModoApp.Modo.DIARIO }) {
                Text("El teléfono que llevas contigo todos los días.", color = HudColores.Blanco, fontSize = 13.sp)
            }
            Text(
                "La elección es PERMANENTE. Para cambiarla hay que desinstalar Julio y volver a instalarlo.",
                color = HudColores.Ambar, fontSize = 12.sp, fontFamily = MONO, textAlign = TextAlign.Center,
            )
        }
    }
    val m = pendiente
    if (m != null) {
        AlertDialog(
            onDismissRequest = { pendiente = null },
            title = { Text(if (m == ModoApp.Modo.ESCRITORIO) "¿Modo escritorio?" else "¿Modo diario?") },
            text = { Text("Es permanente: no se puede cambiar desde la app. Solo desinstalando Julio y volviéndolo a instalar.") },
            confirmButton = { Button(onClick = { pendiente = null; alElegir(m) }) { Text("Sí, elegir") } },
            dismissButton = { TextButton(onClick = { pendiente = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun TituloJulio(tono: Color) {
    Text(
        "J.U.L.I.O.",
        style = TextStyle(
            color = HudColores.Blanco,
            fontSize = 26.sp,
            fontWeight = FontWeight.Light,
            fontFamily = MONO,
            letterSpacing = 6.sp,
            shadow = Shadow(tono.copy(alpha = 0.8f), Offset.Zero, 18f),
        ),
    )
}

// ---------------------------------------------------------------------------------------------------------------------
// Teléfono de diario
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun InterfazDiario(vm: VozViewModel) {
    val principal by JulioEstado.principal.collectAsStateWithLifecycle()
    val capa by JulioEstado.capa.collectAsStateWithLifecycle()
    val orbeColor by vm.orbeColor.collectAsStateWithLifecycle()
    var vistaN by rememberSaveable { mutableStateOf(Vista.MANUAL.name) }
    var panel by rememberSaveable { mutableStateOf<String?>(null) }
    val vista = Vista.valueOf(vistaN)

    // «Atrás» cierra el panel, luego el abanico; en la pantalla principal deja salir de la app como siempre.
    BackHandler(enabled = panel != null || vista != Vista.MANUAL) {
        val (v, abierto) = JarvisLogica.atras(vista, panel != null)
        vistaN = (if (v == Vista.JULIO) Vista.MANUAL else v).name
        if (!abierto) panel = null
    }

    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        JarvisShell(
            vm = vm,
            principal = principal,
            capa = capa,
            orbeColor = orbeColor,
            vista = vista,
            panel = panel,
            alCambiarVista = { vistaN = it.name },
            alAbrirPanel = { panel = it },
            permanente = true,
        )
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// La pieza principal
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun JarvisShell(
    vm: VozViewModel,
    principal: Principal,
    capa: EventoCapa,
    orbeColor: Boolean,
    vista: Vista,
    panel: String?,
    alCambiarVista: (Vista) -> Unit,
    alAbrirPanel: (String?) -> Unit,
    permanente: Boolean,
    modifier: Modifier = Modifier,
) {
    val alerta = rememberAlerta(capa)
    val tono = HudColores.deTono(HudLogica.tono(principal, alerta))
    val lado = JarvisLogica.ladoJulio(vista)
    val suave = tween<Float>(700, easing = FastOutSlowInEasing)

    BoxWithConstraints(modifier.fillMaxSize()) {
        // «maxWidth» y «maxHeight» solo se pueden leer aquí (lección de la v44): se copian antes de usarlos en cajas anidadas.
        val ancho = maxWidth
        val alto = maxHeight
        val base = minOf(ancho.value, alto.value * 1.1f)
        val cyBase = if (permanente) 0.40f else 0.5f

        Canvas(Modifier.fillMaxSize()) { esquinas(tono) }

        // --- Julio: se desplaza y se achica ---
        val cxJ by animateFloatAsState(
            when (lado) { LadoJulio.CENTRO -> 0.5f; LadoJulio.IZQUIERDA -> 0.17f; LadoJulio.DERECHA -> 0.83f },
            suave, label = "cxJulio",
        )
        val cyJ by animateFloatAsState(if (lado == LadoJulio.CENTRO) cyBase else 0.5f, suave, label = "cyJulio")
        val diam by animateDpAsState(
            (base * (if (lado == LadoJulio.CENTRO) 0.36f else 0.28f)).dp,
            tween(700, easing = FastOutSlowInEasing), label = "diamJulio",
        )
        val toque: () -> Unit = {
            if (vista == Vista.MANUAL && !permanente) alCambiarVista(Vista.JULIO)
            else if (vista == Vista.MI_DIA || vista == Vista.CONFIG) alCambiarVista(Vista.MANUAL)
        }
        Box(Modifier.offset(x = ancho * cxJ - diam / 2, y = alto * cyJ - diam / 2).size(diam)) {
            HudOrbe(
                vm = vm,
                principal = principal,
                capa = capa,
                orbeColor = orbeColor,
                alToque = { vm.interrumpir(); toque() },
                modifier = Modifier.fillMaxSize(),
            )
        }

        // --- Título, estado y (en el diario) el botón de la consola, bajo Julio cuando está al centro ---
        val aCentro by animateFloatAsState(if (lado == LadoJulio.CENTRO) 1f else 0f, tween(400), label = "aCentro")
        if (aCentro > 0.01f) {
            Column(
                Modifier.offset(y = alto * cyJ + diam / 2 + 6.dp).fillMaxWidth().alpha(aCentro),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                TituloJulio(tono)
                Text(HudLogica.etiqueta(principal, alerta), color = tono, fontSize = 12.sp, fontFamily = MONO, letterSpacing = 4.sp)
                if (permanente) {
                    Spacer(Modifier.height(10.dp))
                    BotonHolo("CONSOLA", tono, Modifier.width(150.dp), enabled = vista == Vista.MANUAL) { alAbrirPanel(PANEL_CONSOLA) }
                }
            }
        }

        // --- Los dos botones: el elegido sube a ser título; el otro se apaga ---
        val anchoBoton = minOf(ancho.value * 0.30f, 130f).dp
        val aIzq by animateFloatAsState(if (vista == Vista.MANUAL || vista == Vista.MI_DIA) 1f else 0f, tween(450), label = "aIzq")
        val aDer by animateFloatAsState(if (vista == Vista.MANUAL || vista == Vista.CONFIG) 1f else 0f, tween(450), label = "aDer")
        val cxIzq by animateFloatAsState(if (vista == Vista.MI_DIA) 0.32f else 0.17f, suave, label = "cxIzq")
        val cxDer by animateFloatAsState(if (vista == Vista.CONFIG) 0.68f else 0.83f, suave, label = "cxDer")
        val cyIzq by animateFloatAsState(if (vista == Vista.MI_DIA) 0.07f else cyBase, suave, label = "cyIzq")
        val cyDer by animateFloatAsState(if (vista == Vista.CONFIG) 0.07f else cyBase, suave, label = "cyDer")
        if (aIzq > 0.01f) {
            BotonHolo(
                "MI DÍA", tono,
                Modifier.offset(x = ancho * cxIzq - anchoBoton / 2, y = alto * cyIzq - 22.dp).width(anchoBoton).alpha(aIzq),
                enabled = vista == Vista.MANUAL,
            ) { alCambiarVista(Vista.MI_DIA) }
        }
        if (aDer > 0.01f) {
            BotonHolo(
                "CONFIGURACIÓN", tono,
                Modifier.offset(x = ancho * cxDer - anchoBoton / 2, y = alto * cyDer - 22.dp).width(anchoBoton).alpha(aDer),
                enabled = vista == Vista.MANUAL,
            ) { alCambiarVista(Vista.CONFIG) }
        }

        // --- Abanicos (cada uno aparece solo en su vista y mientras no haya un panel abierto) ---
        Abanico(
            items = ITEMS_MI_DIA,
            visible = vista == Vista.MI_DIA && panel == null,
            contenidoADerecha = false,
            ancho = ancho, alto = alto, tono = tono,
            alElegir = { alAbrirPanel(it) },
        )
        Abanico(
            items = SECCIONES_CONFIGURACION,
            visible = vista == Vista.CONFIG && panel == null,
            contenidoADerecha = true,
            ancho = ancho, alto = alto, tono = tono,
            alElegir = { alAbrirPanel(it) },
        )

        // --- Panel abierto (pantalla completa, con «atrás») ---
        if (panel != null) {
            Column(
                Modifier.fillMaxSize()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.98f))
                    .pointerInput(Unit) { detectTapGestures(onTap = { }) },
            ) {
                Row(Modifier.fillMaxWidth().drawBehind { marco(tono) }.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { alAbrirPanel(null) }) {
                        Text("‹ ATRÁS", color = tono, fontFamily = MONO, fontSize = 13.sp, letterSpacing = 2.sp)
                    }
                    Text(panel.uppercase(), color = HudColores.Blanco, fontFamily = MONO, fontSize = 13.sp, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    ContenidoPanel(vm, vista, panel) { alAbrirPanel(null) }
                }
            }
        }
    }
}

@Composable
private fun ContenidoPanel(vm: VozViewModel, vista: Vista, panel: String, cerrar: () -> Unit) {
    when {
        panel == PANEL_CONSOLA -> VozScreen(vm)
        vista == Vista.CONFIG -> ConfiguracionPanel(
            vm = vm,
            alCerrar = null,
            alProbarEjemplo = { vm.enviarTexto(it); cerrar() },
            modifier = Modifier.fillMaxSize(),
            seccionUnica = panel,
        )
        panel == "Horario" -> HorarioScreen()
        panel == "Tareas" -> TareasScreen()
        panel == "Estudio" -> EstudioScreen()
        panel == "Alarmas" -> AlarmasScreen()
        panel == "Enfoque" -> EnfoqueScreen()
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Botones y abanico
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun BotonHolo(texto: String, color: Color, modifier: Modifier, enabled: Boolean = true, alPulsar: () -> Unit) {
    Box(
        modifier.height(44.dp).drawBehind { marco(color) }.clickable(enabled = enabled, onClick = alPulsar).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            texto,
            color = HudColores.Blanco,
            fontSize = 11.sp,
            fontFamily = MONO,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Clip,
        )
    }
}

/**
 * Abanico de opciones: una columna curva (el centro sale hacia Julio, los extremos quedan pegados al borde) que se despliega
 * escalonada. [contenidoADerecha] = el abanico está en el lado derecho (se eligió CONFIGURACIÓN) y Julio a la izquierda.
 */
@Composable
private fun Abanico(
    items: List<String>,
    visible: Boolean,
    contenidoADerecha: Boolean,
    ancho: Dp,
    alto: Dp,
    tono: Color,
    alElegir: (String) -> Unit,
) {
    val zonaX = if (contenidoADerecha) ancho * 0.36f else ancho * 0.02f
    val zonaAncho = ancho * 0.62f
    val anchoItem = minOf(zonaAncho.value * 0.85f, 230f).dp
    val empujeMax = zonaAncho * 0.14f
    val yTop = alto * 0.15f
    val span = alto * 0.80f
    val altoItem = JarvisLogica.altoElementoAbanico(span.value, items.size).dp
    items.forEachIndexed { i, texto ->
        val pos = JarvisLogica.posicionAbanico(i, items.size)
        val x = if (contenidoADerecha) zonaX + zonaAncho - anchoItem - empujeMax * pos.empuje else zonaX + empujeMax * pos.empuje
        val y = yTop + (span - altoItem) * ((pos.t + 1f) / 2f)
        ElementoAbanico(
            texto = texto, visible = visible, indice = i, x = x, y = y, w = anchoItem, h = altoItem,
            grados = if (contenidoADerecha) pos.grados else -pos.grados,
            desdeDerecha = contenidoADerecha, color = tono,
        ) { alElegir(texto) }
    }
}

@Composable
private fun ElementoAbanico(
    texto: String,
    visible: Boolean,
    indice: Int,
    x: Dp,
    y: Dp,
    w: Dp,
    h: Dp,
    grados: Float,
    desdeDerecha: Boolean,
    color: Color,
    alPulsar: () -> Unit,
) {
    val p by animateFloatAsState(
        if (visible) 1f else 0f,
        tween(380, delayMillis = if (visible) 250 + indice * 55 else 0),
        label = "abanico",
    )
    if (p < 0.01f) return
    val desplaza = (1f - p) * (if (desdeDerecha) 70f else -70f)
    Box(
        Modifier
            .offset(x = x + desplaza.dp, y = y)
            .size(w, h)
            .graphicsLayer { alpha = p; rotationZ = grados * p }
            .drawBehind { marco(color) }
            .clickable(enabled = visible, onClick = alPulsar)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(
            texto.uppercase(),
            color = HudColores.Blanco,
            fontSize = 12.sp,
            fontFamily = MONO,
            letterSpacing = 1.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
