package com.julio.asistente.ui.hud

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.animacion.Capa
import com.julio.asistente.animacion.EventoCapa
import com.julio.asistente.animacion.JulioAnimado
import com.julio.asistente.animacion.Principal
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.cuerpo.CuerpoAvisos
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.ia.IaAjustes
import com.julio.asistente.voz.EstadoPiper
import com.julio.asistente.voz.PiperModelo
import com.julio.asistente.voz.VozViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Colores del tema Cyber (HUD). */
object HudColores {
    val Cian = Color(0xFF00E5FF)
    val Turquesa = Color(0xFF2DD4BF)
    val Blanco = Color(0xFFE0F7FF)
    val Ambar = Color(0xFFFFB300)
    val Rojo = Color(0xFFFF3D5A)
    val Verde = Color(0xFF4ADE80)
    val Gris = Color(0xFF64748B)

    fun deTono(t: TonoHud): Color = when (t) {
        TonoHud.CIAN -> Cian
        TonoHud.TURQUESA -> Turquesa
        TonoHud.AMBAR -> Ambar
        TonoHud.ROJO -> Rojo
        TonoHud.VERDE -> Verde
    }

    fun deNivel(n: NivelHud): Color = when (n) {
        NivelHud.OK -> Turquesa
        NivelHud.AVISO -> Ambar
        NivelHud.ERROR -> Rojo
        NivelHud.APAGADO -> Gris
    }
}

/** El aviso o el error se notan 2 segundos sobre el color del estado y luego se apagan. */
@Composable
fun rememberAlerta(capa: EventoCapa): Capa {
    var alerta by remember { mutableStateOf(Capa.NINGUNA) }
    LaunchedEffect(capa.id) {
        if (capa.id != 0 && capa.capa != Capa.NINGUNA) {
            alerta = capa.capa
            delay(2_000L)
            alerta = Capa.NINGUNA
        }
    }
    return alerta
}

/** ¿La app está a la vista? Las animaciones se pausan cuando no (ahorra batería). */
@Composable
private fun rememberVisible(): Boolean {
    val dueno = LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(dueno.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(dueno) {
        val observador = LifecycleEventObserver { _, evento ->
            if (evento == Lifecycle.Event.ON_START) visible = true
            if (evento == Lifecycle.Event.ON_STOP) visible = false
        }
        dueno.lifecycle.addObserver(observador)
        onDispose { dueno.lifecycle.removeObserver(observador) }
    }
    return visible
}

// ---------------------------------------------------------------------------------------------------------------------
// Anillos
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Los anillos del HUD (escala de marcas, arcos segmentados que giran, arcos contrarios y un anillo que «late» con el sonido).
 * Son ADORNO que reacciona al estado de Julio y al nivel real de voz/micrófono; no muestran datos inventados.
 * Se dibujan en un cuadrado: el radio exterior es la mitad del lado.
 */
@Composable
fun HudAnillos(
    principal: Principal,
    alerta: Capa,
    nivelMic: () -> Float,
    nivelHabla: () -> Float,
    modifier: Modifier = Modifier,
) {
    val parametros = HudLogica.parametros(principal)
    val parametrosAct by rememberUpdatedState(parametros)
    val micAct by rememberUpdatedState(nivelMic)
    val hablaAct by rememberUpdatedState(nivelHabla)
    val visible = rememberVisible()
    val fase = remember { mutableFloatStateOf(0f) }
    val nivel = remember { mutableFloatStateOf(0f) }
    val brillo by animateFloatAsState(parametros.brillo, tween(600), label = "hudBrillo")
    val color = HudColores.deTono(HudLogica.tono(principal, alerta))

    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        var ultimo = SystemClock.uptimeMillis()
        while (isActive) {
            val ahora = SystemClock.uptimeMillis()
            val dt = (ahora - ultimo) / 1000f
            ultimo = ahora
            val p = parametrosAct
            fase.floatValue = (fase.floatValue + dt * p.velocidad) % 1000f
            val objetivo = if (p.reaccionaAlSonido) max(micAct(), hablaAct()) else 0f
            nivel.floatValue = HudLogica.suavizar(nivel.floatValue, objetivo)
            if (p.intervaloMs <= 0L) withFrameNanos { } else delay(p.intervaloMs)
        }
    }

    Canvas(modifier) {
        dibujarAnillos(fase.floatValue, brillo, nivel.floatValue, color, parametros.escaneo)
    }
}

private fun DrawScope.dibujarAnillos(fase: Float, brillo: Float, nivel: Float, color: Color, escaneo: Boolean) {
    val c = center
    val radio = size.minDimension / 2f
    val fino = 1.dp.toPx()

    // A: escala de marcas, giro muy lento.
    val rotA = fase * 36f
    for (i in 0 until 72) {
        val largo = if (i % 6 == 0) 9.dp.toPx() else 4.dp.toPx()
        val ang = Math.toRadians(i * 5.0 + rotA)
        val r1 = radio * 0.98f
        val r2 = r1 - largo
        val dx = cos(ang).toFloat()
        val dy = sin(ang).toFloat()
        drawLine(
            color.copy(alpha = brillo * (if (i % 6 == 0) 0.7f else 0.35f)),
            Offset(c.x + dx * r1, c.y + dy * r1),
            Offset(c.x + dx * r2, c.y + dy * r2),
            strokeWidth = fino,
        )
    }

    // B: seis arcos con brillo suave debajo.
    val rB = radio * 0.90f
    for (k in 0 until 6) {
        val ini = k * 60f + fase * 360f
        arco(color.copy(alpha = brillo * 0.12f), ini, 38f, rB, 8.dp.toPx())
        arco(color.copy(alpha = brillo * 0.9f), ini, 38f, rB, 3.dp.toPx())
    }

    // C: tres arcos largos que giran al revés y más rápido.
    val rC = radio * 0.84f
    for (k in 0 until 3) {
        arco(color.copy(alpha = brillo * 0.7f), k * 120f - fase * 576f, 70f, rC, 2.dp.toPx())
    }

    // Escaneo (Julio está procesando).
    if (escaneo) arco(color.copy(alpha = 0.95f), fase * 1440f, 28f, radio * 0.87f, 4.dp.toPx())

    // Anillo que late con el sonido.
    drawCircle(
        color.copy(alpha = brillo * (0.25f + 0.6f * nivel)),
        radius = radio * (0.80f + 0.05f * nivel),
        center = c,
        style = Stroke(1.5.dp.toPx()),
    )
}

private fun DrawScope.arco(color: Color, inicio: Float, barrido: Float, radio: Float, grosor: Float) {
    drawArc(
        color = color,
        startAngle = inicio,
        sweepAngle = barrido,
        useCenter = false,
        topLeft = Offset(center.x - radio, center.y - radio),
        size = Size(radio * 2f, radio * 2f),
        style = Stroke(grosor, cap = StrokeCap.Butt),
    )
}

/**
 * El orbe de Julio (su avatar animado) dentro de los anillos. El avatar queda dentro del anillo más interno, sin tocarlo.
 * [alToque] se pasa tal cual al avatar (tocarlo interrumpe a Julio si está hablando).
 */
@Composable
fun HudOrbe(
    vm: VozViewModel,
    principal: Principal,
    capa: EventoCapa,
    orbeColor: Boolean,
    alToque: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val alerta = rememberAlerta(capa)
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        HudAnillos(principal, alerta, { vm.nivel.value }, { vm.nivelHabla() }, Modifier.fillMaxSize())
        JulioAnimado(
            principal = principal,
            capa = capa,
            nivelMic = { vm.nivel.value },
            nivelHabla = { vm.nivelHabla() },
            palabras = { vm.palabras.value },
            alToque = alToque,
            colorPorEstado = orbeColor,
            modifier = Modifier.fillMaxWidth(0.46f),
        )
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Paneles
// ---------------------------------------------------------------------------------------------------------------------

/** Marco con esquinas recortadas (chaflán) y fondo oscuro translúcido. */
internal fun DrawScope.marco(color: Color) {
    val ch = 10.dp.toPx()
    val w = size.width
    val h = size.height
    val ruta = Path().apply {
        moveTo(ch, 0f)
        lineTo(w - ch, 0f)
        lineTo(w, ch)
        lineTo(w, h - ch)
        lineTo(w - ch, h)
        lineTo(ch, h)
        lineTo(0f, h - ch)
        lineTo(0f, ch)
        close()
    }
    drawPath(ruta, Color.Black.copy(alpha = 0.55f))
    drawPath(ruta, color.copy(alpha = 0.6f), style = Stroke(1.dp.toPx()))
}

@Composable
fun HudPanel(titulo: String, color: Color, modifier: Modifier = Modifier, contenido: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().drawBehind { marco(color) }.padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(titulo, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 3.sp)
        contenido()
    }
}

/** Panel SISTEMA: datos reales del teléfono y de Julio, con color por estado. */
@Composable
fun HudPanelSistema(filas: List<FilaSistema>, compacto: Boolean, modifier: Modifier = Modifier) {
    val (texto, nivel) = HudSistema.resumen(filas)
    val colorGeneral = HudColores.deNivel(nivel)
    HudPanel("SISTEMA · $texto", colorGeneral, modifier) {
        for (f in HudSistema.visibles(filas, if (compacto) 6 else 8)) {
            Row(Modifier.fillMaxWidth()) {
                Text(f.nombre, color = HudColores.Cian.copy(alpha = 0.55f), fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                Text(f.valor, color = HudColores.deNivel(f.nivel), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

/** Panel de ONDA con el nivel REAL: la voz de Julio cuando habla y el micrófono cuando escucha (plana si no hay sonido). */
@Composable
fun HudPanelOnda(principal: Principal, nivelMic: () -> Float, nivelHabla: () -> Float, color: Color, modifier: Modifier = Modifier) {
    val historial = remember { HistorialOnda(48) }
    val version = remember { mutableIntStateOf(0) }
    val micAct by rememberUpdatedState(nivelMic)
    val hablaAct by rememberUpdatedState(nivelHabla)
    val visible = rememberVisible()
    val hablando = principal == Principal.HABLANDO
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (isActive) {
            historial.agregar(max(micAct(), hablaAct()))
            version.intValue++
            delay(66L)
        }
    }
    HudPanel(if (hablando) "ONDA · VOZ DE JULIO" else "ONDA · MICRÓFONO", color, modifier) {
        Canvas(Modifier.fillMaxWidth().height(44.dp)) {
            version.intValue
            val valores = historial.valores()
            val paso = size.width / valores.size
            val medio = size.height / 2f
            for (i in valores.indices) {
                val alto = max(valores[i] * size.height, 2.dp.toPx())
                val x = paso * i + paso / 2f
                drawLine(color.copy(alpha = 0.35f + 0.65f * valores[i]), Offset(x, medio - alto / 2f), Offset(x, medio + alto / 2f), strokeWidth = paso * 0.6f)
            }
        }
    }
}

@Composable
fun HudPanelReloj(hora: String, fecha: String, color: Color, modifier: Modifier = Modifier) {
    HudPanel("HORA", color, modifier) {
        Text(
            hora,
            color = HudColores.Blanco,
            fontSize = 34.sp,
            fontWeight = FontWeight.Light,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(fecha, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Datos reales del sistema
// ---------------------------------------------------------------------------------------------------------------------

private data class LecturaSistema(val bateria: Int, val cargando: Boolean, val wifi: Boolean, val internet: Boolean, val microfono: Boolean)

private fun leerSistema(ctx: Context): LecturaSistema {
    val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val nivel = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val escala = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val estado = bat?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val porcentaje = if (nivel >= 0 && escala > 0) nivel * 100 / escala else 0
    val cargando = estado == BatteryManager.BATTERY_STATUS_CHARGING || estado == BatteryManager.BATTERY_STATUS_FULL
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
    return LecturaSistema(
        porcentaje,
        cargando,
        caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true,
        caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true,
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
    )
}

/** Junta lo que Julio ya sabe de sí mismo con lo que se lee del teléfono cada 5 segundos. */
@Composable
fun rememberDatosSistema(vm: VozViewModel): DatosSistema {
    val ctx = LocalContext.current
    val lectura by produceState(initialValue = leerSistema(ctx)) {
        while (true) {
            delay(5_000L)
            value = leerSistema(ctx)
        }
    }
    val escucha by vm.despertarActivo.collectAsStateWithLifecycle()
    val piper by PiperModelo.estado.collectAsStateWithLifecycle()
    val iaActiva by IaAjustes.activo.collectAsStateWithLifecycle()
    val iaClave by IaAjustes.clave.collectAsStateWithLifecycle()
    val avisosActivos by CuerpoAjustes.activo.collectAsStateWithLifecycle()
    val pendientes by CuerpoAvisos.pendientes.collectAsStateWithLifecycle()
    val rol by EnlaceAjustes.rol.collectAsStateWithLifecycle()
    val puerto by EnlaceAjustes.puertoLocal.collectAsStateWithLifecycle()
    return DatosSistema(
        bateria = lectura.bateria,
        cargando = lectura.cargando,
        wifi = lectura.wifi,
        internet = lectura.internet,
        microfono = lectura.microfono,
        escuchaJulio = escucha,
        voz = when (piper) {
            is EstadoPiper.Lista -> EstadoVozHud.LISTA
            is EstadoPiper.Descargando -> EstadoVozHud.DESCARGANDO
            else -> EstadoVozHud.SISTEMA
        },
        iaActiva = iaActiva,
        iaClave = iaClave.isNotBlank(),
        avisosActivos = avisosActivos,
        avisosPendientes = pendientes,
        enlace = if (rol == RolEnlace.CUERPO) {
            if (puerto > 0) EstadoEnlaceHud.ESCUCHANDO else EstadoEnlaceHud.CERRADO
        } else {
            EstadoEnlaceHud.NO_APLICA
        },
    )
}

// ---------------------------------------------------------------------------------------------------------------------
// Pantalla completa del modo escritorio
// ---------------------------------------------------------------------------------------------------------------------

/** Cuatro esquinas en «L» (adorno). */
internal fun DrawScope.esquinas(color: Color) {
    val m = 12.dp.toPx()
    val l = 28.dp.toPx()
    val g = 2.dp.toPx()
    val c = color.copy(alpha = 0.35f)
    val w = size.width
    val h = size.height
    drawLine(c, Offset(m, m), Offset(m + l, m), g); drawLine(c, Offset(m, m), Offset(m, m + l), g)
    drawLine(c, Offset(w - m, m), Offset(w - m - l, m), g); drawLine(c, Offset(w - m, m), Offset(w - m, m + l), g)
    drawLine(c, Offset(m, h - m), Offset(m + l, h - m), g); drawLine(c, Offset(m, h - m), Offset(m, h - m - l), g)
    drawLine(c, Offset(w - m, h - m), Offset(w - m - l, h - m), g); drawLine(c, Offset(w - m, h - m), Offset(w - m, h - m - l), g)
}

@Composable
private fun CentroHud(
    vm: VozViewModel,
    principal: Principal,
    capa: EventoCapa,
    alerta: Capa,
    orbeColor: Boolean,
    alToqueOrbe: () -> Unit,
    diametro: Dp,
    tono: Color,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        HudOrbe(vm, principal, capa, orbeColor, alToqueOrbe, Modifier.size(diametro))
        Text(
            "J.U.L.I.O.",
            style = TextStyle(
                color = HudColores.Blanco,
                fontSize = 26.sp,
                fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 6.sp,
                shadow = Shadow(tono.copy(alpha = 0.8f), Offset.Zero, 18f),
            ),
        )
        Text(
            HudLogica.etiqueta(principal, alerta),
            color = tono,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 4.sp,
        )
    }
}

/**
 * Modo escritorio con el tema Cyber (v44): orbe dentro de anillos, panel SISTEMA, onda real y reloj. En horizontal: sistema a la
 * izquierda, Julio al centro, onda y reloj a la derecha. En vertical: todo apilado. Todo se desplaza unos píxeles (anti quemado)
 * y en «dormido» los paneles se atenúan.
 */
@Composable
fun HudEscritorio(
    vm: VozViewModel,
    principal: Principal,
    capa: EventoCapa,
    orbeColor: Boolean,
    hora: String,
    fecha: String,
    alToqueOrbe: () -> Unit,
    ox: Dp,
    oy: Dp,
    modifier: Modifier = Modifier,
) {
    val alerta = rememberAlerta(capa)
    val tono = HudColores.deTono(HudLogica.tono(principal, alerta))
    val datos = rememberDatosSistema(vm)
    val filas = remember(datos) { HudSistema.filas(datos) }
    val tenue = if (principal == Principal.DORMIDO) 0.35f else 1f

    BoxWithConstraints(modifier.fillMaxSize()) {
        // «maxWidth» y «maxHeight» solo se pueden leer aquí, no dentro de las cajas anidadas (Row, Column, Box): se copian antes.
        val ancho = maxWidth
        val alto = maxHeight
        Canvas(Modifier.fillMaxSize()) { esquinas(tono) }
        val horizontal = ancho > alto
        if (horizontal) {
            Row(
                Modifier.fillMaxSize().offset(ox, oy).padding(horizontal = 28.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f).alpha(tenue), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    HudPanelSistema(filas, compacto = false)
                }
                Box(Modifier.weight(1.5f), contentAlignment = Alignment.Center) {
                    CentroHud(vm, principal, capa, alerta, orbeColor, alToqueOrbe, minOf(alto - 110.dp, ancho * 0.34f).coerceAtLeast(120.dp), tono)
                }
                Column(Modifier.weight(1f).alpha(tenue), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    HudPanelReloj(hora, fecha, tono)
                    HudPanelOnda(principal, { vm.nivel.value }, { vm.nivelHabla() }, tono)
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().offset(ox, oy).padding(horizontal = 20.dp, vertical = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CentroHud(vm, principal, capa, alerta, orbeColor, alToqueOrbe, minOf(ancho - 40.dp, alto * 0.38f).coerceAtLeast(120.dp), tono)
                Column(Modifier.alpha(tenue), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    HudPanelReloj(hora, fecha, tono)
                    HudPanelOnda(principal, { vm.nivel.value }, { vm.nivelHabla() }, tono)
                    HudPanelSistema(filas, compacto = true)
                }
            }
        }
    }
}
