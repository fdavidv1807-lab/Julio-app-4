package com.julio.asistente.ui.jarvis

import kotlin.math.abs

/** Las pantallas de la interfaz holográfica. JULIO = solo Julio; MANUAL = Julio con los dos botones; MI_DIA y CONFIG = Julio se desplazó. */
enum class Vista { JULIO, MANUAL, MI_DIA, CONFIG }

/** De qué lado queda Julio y de cuál el contenido. IZQUIERDA = Julio a la izquierda (se eligió el botón derecho). */
enum class LadoJulio { CENTRO, IZQUIERDA, DERECHA }

/**
 * Lógica pura (sin Compose ni Android) de la interfaz «Jarvis»: se prueba con JUnit.
 */
object JarvisLogica {
    /** Julio se desplaza hacia el lado donde NO se escogió el botón: Configuración (derecha) → Julio a la izquierda; Mi día (izquierda) → a la derecha. */
    fun ladoJulio(v: Vista): LadoJulio = when (v) {
        Vista.JULIO, Vista.MANUAL -> LadoJulio.CENTRO
        Vista.CONFIG -> LadoJulio.IZQUIERDA
        Vista.MI_DIA -> LadoJulio.DERECHA
    }

    /** Lo que hace «atrás» (o tocar a Julio) en cada pantalla. Un panel abierto se cierra primero. */
    fun atras(v: Vista, panelAbierto: Boolean): Pair<Vista, Boolean> = when {
        panelAbierto -> v to false
        v == Vista.MI_DIA || v == Vista.CONFIG -> Vista.MANUAL to false
        v == Vista.MANUAL -> Vista.JULIO to false
        else -> Vista.JULIO to false
    }

    /** Posición de un elemento del abanico: t va de -1 (arriba) a 1 (abajo); [empuje] 0..1 es cuánto se aleja del borde (0 en los extremos). */
    data class PosicionAbanico(val t: Float, val empuje: Float, val grados: Float)

    fun posicionAbanico(indice: Int, total: Int, gradosMax: Float = 7f): PosicionAbanico {
        if (total <= 1) return PosicionAbanico(0f, 1f, 0f)
        val medio = (total - 1) / 2f
        val t = (indice - medio) / medio
        return PosicionAbanico(t, 1f - t * t, t * gradosMax)
    }

    /** Alto de cada elemento del abanico (dp) para que quepan todos en la pantalla, entre 28 y 44. */
    fun altoElementoAbanico(altoDisponibleDp: Float, total: Int): Float {
        if (total <= 0) return 44f
        return ((altoDisponibleDp / total) * 0.82f).coerceIn(28f, 44f)
    }

    /** Cuántos segundos sin tocar antes de volver solo a «Julio» (el Cuerpo no debe quedarse en un menú). */
    fun segundosParaVolver(v: Vista): Int = when (v) {
        Vista.JULIO -> 0
        Vista.MANUAL -> 20
        Vista.MI_DIA, Vista.CONFIG -> 300
    }

    /** ¿Esta persona puede elegir el modo? Solo la primera vez: después es permanente (se cambia desinstalando). */
    fun puedeElegirModo(actual: ModoApp.Modo): Boolean = actual == ModoApp.Modo.SIN_ELEGIR

    /** ¿Dos valores están (casi) en el mismo lugar? Ayuda para las pruebas. */
    fun cerca(a: Float, b: Float, eps: Float = 1e-4f): Boolean = abs(a - b) < eps
}

/**
 * Cuenta toques sobre Julio: [necesarios] toques seguidos dentro de [ventanaMs] activan el modo manual.
 * Cada toque cuenta desde el primero que sigue vivo; tras activarse empieza de cero.
 */
class ContadorToques(private val necesarios: Int = 4, private val ventanaMs: Long = 2_500L) {
    private val tiempos = ArrayDeque<Long>()

    /** Registra un toque. Devuelve true si este toque completa la secuencia. */
    fun registrar(ahoraMs: Long): Boolean {
        while (tiempos.isNotEmpty() && ahoraMs - tiempos.first() > ventanaMs) tiempos.removeFirst()
        tiempos.addLast(ahoraMs)
        if (tiempos.size >= necesarios) {
            tiempos.clear()
            return true
        }
        return false
    }

    fun reiniciar() = tiempos.clear()
}
