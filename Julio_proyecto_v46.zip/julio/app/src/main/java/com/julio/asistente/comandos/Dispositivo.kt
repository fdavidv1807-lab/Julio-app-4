package com.julio.asistente.comandos

/**
 * Órdenes sobre el propio teléfono (Etapa 3 del Proyecto Cuerpo): volumen, brillo y abrir apps.
 * Lógica pura sobre texto ya normalizado ([Texto.normalizar] + [Texto.numeros]). No toca el sistema.
 */
object Dispositivo {
    private fun tiene(n: String, patron: String): Boolean = Regex(patron).containsMatchIn(n)

    /** Si la frase habla de otra cosa de Julio (alarmas, tareas...), esta lógica no interviene. */
    private val INTERNAS = Regex(
        "\\b(alarma|alarmas|tarea|tareas|pendiente|pendientes|horario|agenda|meta|metas|enfoque|estudio|examen|clase|clases|actividad|actividades|descanso)\\b",
    )
    private const val BAJA = "\\b(baja|bajar|bajale|baje|disminuye|disminuir|reduce|reducir|menos|bajo)\\b"
    private const val SUBE = "\\b(sube|subir|subele|suba|aumenta|aumentar|incrementa|incrementar|mas|alto)\\b"
    private const val MAXIMO = "\\b(maximo|maxima|al tope)\\b"
    private val VERBO_ABRIR = Regex("\\b(abre|abrir|abreme|abrime|lanza|lanzar|ejecuta|ejecutar)\\b")

    fun interpretar(n: String): Intencion? {
        if (INTERNAS.containsMatchIn(n)) return null
        return modoManual(n) ?: ayuda(n) ?: responder(n) ?: avisos(n) ?: volumen(n) ?: brillo(n) ?: musica(n) ?: abrir(n)
    }

    private fun nivel(n: String): Int? {
        val t = n.replace(Regex("\\bcien\\b"), "100")
        val m = Regex("(\\d{1,3})\\s*(%|por ciento)?").find(t) ?: return null
        return m.groupValues[1].toInt().coerceIn(0, 100)
    }

    private fun volumen(n: String): Intencion? {
        val habla = tiene(n, "\\b(volumen|sonido|audio)\\b")
        if ((habla && tiene(n, "\\b(activa|activar|reactiva|reactivar|restaura|restaurar|devuelve|devolver)\\b")) ||
            tiene(n, "\\bquita (el )?silencio\\b") || tiene(n, "\\bdesilencia\\b")
        ) return Intencion.AjustarVolumen(AccionNivel.ACTIVAR)
        if (tiene(n, "\\b(silencia|silenciar|mutea|mutear)\\b") ||
            tiene(n, "\\b(quita|quitale|apaga|sin) (el )?(sonido|volumen|audio)\\b")
        ) return Intencion.AjustarVolumen(AccionNivel.SILENCIAR)
        if (!habla) return null
        if (tiene(n, MAXIMO)) return Intencion.AjustarVolumen(AccionNivel.FIJAR, 100)
        nivel(n)?.let { return Intencion.AjustarVolumen(AccionNivel.FIJAR, it) }
        if (tiene(n, BAJA)) return Intencion.AjustarVolumen(AccionNivel.BAJAR)
        if (tiene(n, SUBE)) return Intencion.AjustarVolumen(AccionNivel.SUBIR)
        if (tiene(n, "\\b(como|cuanto|cual|que)\\b")) return Intencion.AjustarVolumen(AccionNivel.CONSULTAR)
        return null
    }

    private fun brillo(n: String): Intencion? {
        if (!tiene(n, "\\bbrillo\\b")) return null
        if (tiene(n, "\\b(automatico|automatica|normal|predeterminado)\\b|\\bpor defecto\\b")) return Intencion.AjustarBrillo(AccionNivel.AUTOMATICO)
        if (tiene(n, MAXIMO)) return Intencion.AjustarBrillo(AccionNivel.FIJAR, 100)
        if (tiene(n, "\\b(minimo|minima)\\b")) return Intencion.AjustarBrillo(AccionNivel.FIJAR, 5)
        nivel(n)?.let { return Intencion.AjustarBrillo(AccionNivel.FIJAR, it) }
        if (tiene(n, BAJA)) return Intencion.AjustarBrillo(AccionNivel.BAJAR)
        if (tiene(n, SUBE)) return Intencion.AjustarBrillo(AccionNivel.SUBIR)
        if (tiene(n, "\\b(como|cuanto|cual|que)\\b")) return Intencion.AjustarBrillo(AccionNivel.CONSULTAR)
        return null
    }

    private val MODO_MANUAL = Regex(
        "^(?:julio )?(?:(?:activa|activar|abre|abrir|pon|poner|entra a|entrar a|quiero|muestra|muestrame) )?(?:el )?modo manual$",
    )

    /** «Modo manual» / «Julio, activa el modo manual». */
    private fun modoManual(n: String): Intencion? = if (MODO_MANUAL.containsMatchIn(n.trim())) Intencion.ModoManual else null

    private val AYUDA = Regex(
        "\\b(que (puedes|sabes|podes) (hacer|decir)|que haces|para que sirves|que puedo (decirte|decirle|pedirte|pedirle)|" +
            "que comandos|que ordenes|como te uso|como se usa julio)\\b|^(julio )?ayuda$",
    )

    /** «¿Qué puedes hacer?». */
    private fun ayuda(n: String): Intencion? = if (AYUDA.containsMatchIn(n)) Intencion.Ayuda else null

    private val RESPONDER = Regex(
        "^(?:julio )?(?:quiero |puedes |podrias |vamos a )?(?:responde|responder|contesta|contestar|respondele|contestale|respondeme)" +
            "(?: (?:el|ese|este|al) (?:mensaje|chat|whatsapp))?(?: a (.+))?$",
    )

    /** «Responde» / «responde a Ana». El nombre queda normalizado (sin acentos). */
    private fun responder(n: String): Intencion? {
        val m = RESPONDER.find(n.trim()) ?: return null
        return Intencion.Responder(m.groupValues[1].trim().ifBlank { null })
    }

    private val AVISOS = Regex(
        "\\b(que|cuales|cuantas|cuantos) (notificaciones|notificacion|mensajes|mensaje)( nuevas| nuevos)? (tengo|hay|me llegaron|llegaron|me escribieron|me mandaron)\\b|" +
            "\\b(tengo|hay) (alguna |algun )?(notificacion|notificaciones|mensajes)( nuevas| nuevos)?\\b|" +
            "\\b(lee|leeme|leer|dime|resume|resumeme) (mis |las |los )?(notificaciones|mensajes)\\b|" +
            "\\bque me (llego|escribieron|mandaron)\\b",
    )

    /** «¿Qué notificaciones tengo?». */
    private fun avisos(n: String): Intencion? = if (AVISOS.containsMatchIn(n)) Intencion.ConsultarAvisos else null

    private const val NOMBRE_MUSICA = "\\b(cancion|canciones|musica|pista|rola)\\b"
    private val PON = Regex("\\b(pon|poner|ponme|reproduce|reproducir|toca|tocar|play|inicia|iniciar|empieza|empezar)\\b")

    /**
     * Música: exige la palabra «música/canción» (salvo «retrocede»), para no confundirse con «pausa el enfoque» u otras órdenes.
     * Funciona con la app de música que esté sonando.
     */
    private fun musica(n: String): Intencion? {
        if (tiene(n, "^(julio )?(retrocede|retroceder)$")) return Intencion.Musica(AccionMusica.ANTERIOR)
        if (!tiene(n, NOMBRE_MUSICA)) return null
        if (tiene(n, "\\b(siguiente|proxima|otra|cambia|cambiar|cambiala|salta|saltar|avanza|avanzar|pasa|pasar|adelanta)\\b"))
            return Intencion.Musica(AccionMusica.SIGUIENTE)
        if (tiene(n, "\\b(anterior|previa|retrocede|retroceder|regresa|regresar|devuelve|devolver|atras)\\b"))
            return Intencion.Musica(AccionMusica.ANTERIOR)
        if (tiene(n, "\\b(pausa|pausar|pausala|deten|detener|detenla)\\b") || (!PON.containsMatchIn(n) && tiene(n, "\\b(para|parar)\\b")))
            return Intencion.Musica(AccionMusica.PAUSAR)
        if (tiene(n, "\\b(reanuda|reanudar|continua|continuar|sigue|seguir|resume)\\b")) return Intencion.Musica(AccionMusica.SEGUIR)
        if (PON.containsMatchIn(n)) return Intencion.Musica(AccionMusica.PONER, consultaMusica(n))
        return null
    }

    private val RESTO_MUSICA = Regex("\\b(?:cancion|canciones|musica|rola|pista)\\s+(.+)$")
    private val SIN_PEDIR = Regex("^(aleatoria|aleatorio|cualquiera|al azar|lo que sea|alguna|algo|una|otra|buena|bonita)( .*)?$")

    /**
     * Lo que se quiere escuchar: «pon música de Bad Bunny» -> «bad bunny», «pon la canción Despacito» -> «despacito»,
     * «música para estudiar» -> «musica para estudiar». null = no pidió nada concreto (Julio elige algo al azar).
     */
    internal fun consultaMusica(n: String): String? {
        val m = RESTO_MUSICA.find(n) ?: return null
        var resto = m.groupValues[1].replace(Regex("\\b(por favor|julio|ahora|ya)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        resto = resto.replace(Regex("(^|\\s)(en|con|por) (youtube music|youtube|spotify)$"), "").trim()
        if (resto.startsWith("para ")) return "musica $resto"
        while (true) {
            val sin = resto.replace(Regex("^(de|del|la|el|los|las|un|una|unos|unas|estilo|tipo)\\s+"), "")
            if (sin == resto) break
            resto = sin
        }
        return if (resto.isBlank() || SIN_PEDIR.matches(resto)) null else resto
    }

    private fun abrir(n: String): Intencion? {
        if (!VERBO_ABRIR.containsMatchIn(n)) return null
        val nombre = Interprete.limpiar(n, listOf(VERBO_ABRIR.pattern, "\\b(aplicacion|aplicaciones|app|apps|programa)\\b", "\\bpor favor\\b"))
        return Intencion.AbrirApp(nombre.ifBlank { null })
    }
}
