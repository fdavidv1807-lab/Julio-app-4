package com.julio.asistente.ui.jarvis

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Modo de ESTE teléfono, elegido una sola vez: ESCRITORIO (el Cuerpo de Julio, fijo en el escritorio) o DIARIO (el que se lleva encima).
 * Es PERMANENTE: no hay ninguna función para cambiarlo. Para cambiarlo hay que desinstalar la app y volver a instalarla
 * (al desinstalar se borran las preferencias). Por eso solo existe [elegir], que no hace nada si ya se eligió.
 */
object ModoApp {
    enum class Modo { SIN_ELEGIR, ESCRITORIO, DIARIO }

    private const val ARCHIVO = "julio_modo_app"
    private val _modo = MutableStateFlow(Modo.SIN_ELEGIR)
    val modo: StateFlow<Modo> = _modo.asStateFlow()

    fun cargar(c: Context) {
        val app = c.applicationContext
        val guardado = app.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getString("modo", null)
        var m = runCatching { Modo.valueOf(guardado ?: "") }.getOrDefault(Modo.SIN_ELEGIR)
        // Quien venía de la v45 con el modo escritorio ya abierto sigue siendo el Cuerpo.
        if (m == Modo.SIN_ELEGIR && app.getSharedPreferences("julio_escritorio", Context.MODE_PRIVATE).getBoolean("activo", false)) {
            m = Modo.ESCRITORIO
            app.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putString("modo", m.name).apply()
        }
        _modo.value = m
    }

    /** Elige el modo. Solo funciona la primera vez; después se ignora. Devuelve si se guardó. */
    fun elegir(c: Context, nuevo: Modo): Boolean {
        if (nuevo == Modo.SIN_ELEGIR || !JarvisLogica.puedeElegirModo(_modo.value)) return false
        _modo.value = nuevo
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putString("modo", nuevo.name).apply()
        return true
    }
}

/** «Julio, modo manual» por voz: la orden de voz avisa a la pantalla con un contador (cada orden es un aviso nuevo). */
object ManualControl {
    private val _pedido = MutableStateFlow(0)
    val pedido: StateFlow<Int> = _pedido.asStateFlow()
    fun pedir() { _pedido.value = _pedido.value + 1 }
}
