package com.julio.asistente.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.escritorio.EscritorioControl
import com.julio.asistente.ui.jarvis.InterfazDiario
import com.julio.asistente.ui.jarvis.ModoApp
import com.julio.asistente.ui.jarvis.PantallaElegirModo
import com.julio.asistente.ui.screens.EscritorioScreen
import com.julio.asistente.ui.screens.PrepararEscritorio
import com.julio.asistente.ui.screens.PrepararEscritorioDialog
import com.julio.asistente.voz.VozViewModel

/**
 * Raíz de la app (v46, interfaz holográfica desde cero).
 * La primera vez se elige el modo de este teléfono y queda PERMANENTE (se cambia desinstalando y reinstalando):
 *  - ESCRITORIO: el Cuerpo de Julio (solo Julio; «modo manual» o 4 toques abren Mi día y Configuración).
 *  - DIARIO: Julio con Mi día, Configuración y Consola a la vista.
 * Se quitaron la navegación lateral, la barra superior y el panel derecho de las versiones anteriores.
 */
@Composable
fun JulioRoot() {
    val ctx = LocalContext.current
    // Un solo VozViewModel para toda la app (así hay un solo motor de voz).
    val vozVm: VozViewModel = viewModel()
    val modo by ModoApp.modo.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when (modo) {
            ModoApp.Modo.SIN_ELEGIR -> PantallaElegirModo { elegido -> ModoApp.elegir(ctx, elegido) }
            ModoApp.Modo.DIARIO -> InterfazDiario(vozVm)
            ModoApp.Modo.ESCRITORIO -> {
                // Preparación obligatoria (micrófono, notificaciones, acceso a notificaciones): se repite al abrir hasta que esté lista.
                var preparando by remember {
                    mutableStateOf(!(PrepararEscritorio.obligatoriosListos(ctx) && CuerpoAjustes.yaPreparado(ctx)))
                }
                EscritorioScreen(vozVm)
                if (preparando) PrepararEscritorioDialog(alCerrar = { preparando = false })
                LaunchedEffect(preparando) {
                    if (!preparando && !EscritorioControl.activo.value) EscritorioControl.entrar(ctx)
                }
            }
        }
    }
}
