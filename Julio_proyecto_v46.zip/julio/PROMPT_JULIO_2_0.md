# Prompt para Julio 2.0 (interfaz HUD tipo JARVIS)

**Haz solo esto:**
1. Abre un chat nuevo con Claude.
2. Sube **tres cosas**: el zip más reciente (`Julio_proyecto_vNN.zip`), la imagen de la interfaz que quieres (la del gorila doctor con los círculos) y, si la tienes, la imagen del gorila sola en alta resolución.
3. Copia y pega TODO lo que está debajo de la línea `=== COPIAR DESDE AQUÍ ===`.

=== COPIAR DESDE AQUÍ ===

Soy el dueño del proyecto "Julio", un asistente de voz personal en Android (Kotlin, Compose) que ya existe (te adjunto el zip). Quiero convertirlo en **Julio 2.0: un JARVIS real**, con una **interfaz futurista tipo HUD** (te adjunto la imagen de referencia), con voz y con automatización segura. **Responde siempre en español, corto y claro: leo desde el celular.**

## Antes de hacer nada
1. Lee `PROMPT_PARA_CONTINUAR.md`, `PLAN_DE_TRABAJO.md` (las últimas secciones mandan) y `docs/PROYECTO_CUERPO_DE_JULIO.md`.
2. Mira la imagen de referencia y repítemela en 5 líneas para confirmar que la entendiste.
3. Pregúntame (máx. 3 preguntas, cortas) lo que necesites y qué versión compilé. NO asumas que nada funciona: lo reciente no está verificado en el teléfono ni compilado en tu entorno.
4. Antes de escribir código, dame el diseño corto.

## Qué quiero (en una frase)
Que Julio se vea y se sienta como JARVIS: una pantalla negra con luces cian que reacciona a mi voz, un avatar holográfico en el centro, paneles con datos REALES a los lados, y que haga cosas por mí con comandos de voz, de forma automática pero segura.

## La interfaz (así es la imagen de referencia)
- **Fondo:** negro azulado muy oscuro, con paneles metálicos/hexagonales casi invisibles y viñeta. En la práctica usa negro puro (#000) de base: la pantalla es AMOLED y así gasta menos batería.
- **Color:** cian neón (≈#00E5FF) como principal, turquesa (≈#2DD4BF) secundario, blanco azulado para texto, ámbar (#FFB300) para alertas y rojo (#FF3D5A) para errores. Todo con brillo suave (glow), líneas finas y esquinas recortadas (chaflán).
- **Centro:** un marco vertical con el **avatar holográfico**: un gorila doctor con bata con circuitos y estetoscopio, sobre una plataforma luminosa. Detrás, un anillo grande con escala numérica y marcas, y partículas/chispas flotando. Debajo, el título **J.U.L.I.O.** con brillo y la línea «ACTIVE · VIRTUAL HEALTH ASSISTANT» (en español: «ASISTENTE VIRTUAL ACTIVO»).
- **Izquierda:** diales circulares concéntricos con arcos segmentados que giran a distintas velocidades, un panelito con líneas de datos y una onda pequeña abajo.
- **Derecha:** tres paneles con marco biselado: arriba una onda de audio de barras, en medio un dial circular con barras verticales con porcentajes (diagnóstico del sistema) y abajo una gráfica de barras con eje 0–100.
- **Conexiones:** líneas finas del centro hacia cada panel.
- **Ojo:** en la imagen dice «PATIENT DATA ACCESSED» y «HEALTH TRENDS». **Eso es decoración: NO quiero datos de pacientes en Julio.** Esos paneles deben mostrar MIS datos reales (ver abajo).

## Qué muestra cada panel (solo datos reales o decoración marcada como tal)
- **Onda de audio:** la amplitud REAL de la voz de Julio cuando habla (se puede calcular de las muestras que ya se reproducen). Si no se puede obtener el nivel del micrófono sin romper el reconocimiento (Vosk usa el micrófono), esa onda será decorativa y debes decírmelo.
- **Diagnóstico del sistema:** batería y carga, Wi-Fi, micrófono, escucha de «Julio» activa, voz de Julio lista, internet/IA, y estado del enlace con el teléfono de diario. Cada uno con color (verde/ámbar/rojo).
- **Hoy:** próxima clase o actividad, tareas pendientes, cuántas notificaciones hay por leer.
- **Tendencias:** mi tiempo de estudio por día y tareas completadas (de los datos que ya tiene Julio).
- **Dial central/izquierda:** hora y fecha, y el estado de Julio.
- Lo que sea solo adorno (anillos girando, partículas) debe estar marcado como decorativo en el código y NO simular datos.

## Estados (la interfaz debe reaccionar)
- **Reposo:** anillos lentos, brillo bajo.
- **Escuchando:** anillos aceleran y se expanden, la onda se mueve.
- **Procesando / consultando la IA:** arco giratorio rápido.
- **Hablando:** halo y onda sincronizados con la amplitud de su voz; el avatar «late».
- **Alerta:** ámbar pulsante (aviso, alarma, recordatorio).
- **Error o enlace caído:** rojo breve y se vuelve a normal.

## Reglas técnicas de la interfaz
- Dibujar con Compose `Canvas` y animaciones por tiempo (`withFrameNanos` o `rememberInfiniteTransition`) sin recomponer toda la pantalla.
- Dispositivo objetivo: Samsung Galaxy A53 5G (Super AMOLED, Android 16). Pantalla fija del Cuerpo siempre encendida: **bajar brillo, mover los elementos unos píxeles cada cierto tiempo (anti quemado, ya existe `OffsetEscritorio`/`CalculoEscritorio`), reducir a ~30 fps y pausar las animaciones cuando la pantalla no se ve.**
- Dos formatos: **horizontal** (Cuerpo/escritorio) con el diseño de la imagen; **vertical** (teléfono normal): avatar arriba y los paneles como tarjetas deslizables.
- El avatar es una imagen mía (te la paso); anímalo con brillo, respiración y reacción a la voz. Mover la boca solo si te paso otra imagen con la boca abierta. Si algún día se publica la app, habría que revisar los derechos de la imagen.
- Fuente futurista opcional (por ejemplo Orbitron o Rajdhani, licencia OFL): no puedes descargarla; si la quiero, te la subiré a `res/font`. Mientras tanto usa una fuente del sistema.
- **Mantén la interfaz actual** disponible con un interruptor «Tema: clásico / Cyber» hasta que yo confirme que la nueva funciona bien. Quiero **menos ventanas, no más**: lo menos usado va escondido.

## Cómo hacer un «JARVIS real» (sin mentirme)
Un JARVIS no es una pantalla bonita: son capas. Ya existen varias; falta unirlas bajo una interfaz:
1. **Interfaz HUD** (lo de arriba).
2. **Voz:** despertar por «Julio» con Vosk, reconocimiento, voz Piper, interrupciones (ya existen).
3. **Cerebro:** reglas locales (funcionan sin internet) + IA de consulta con Gemini (v43, solo con internet y si yo lo enciendo). Siguiente paso: que la IA pueda *proponer acciones* (function calling), pero que nunca las ejecute directamente.
4. **Ejecutor con niveles de permiso** (la pieza clave de seguridad, ver abajo): todo lo que Julio hace pasa por aquí.
5. **Rutinas:** conjuntos de acciones con un disparador (mi voz, una hora, conectar el cargador, llegada de un aviso).
6. **Memoria local:** mi perfil, mis materias, mis horarios (Room, **con migración siempre**).
7. **Enlace** Cuerpo ↔ teléfono de diario (ya existe) para recibir avisos y responder.

### Niveles de permiso (obligatorios)
- **N0 – Leer o informar:** hora, tareas, resumen de avisos, IA. Automático.
- **N1 – Acciones locales y reversibles:** volumen, brillo, música, abrir una app permitida, temporizadores, modo enfoque. Automático, y Julio dice «Listo».
- **N2 – Con efecto fuera de Julio:** enviar un mensaje, llamar, crear o borrar eventos, mandar correos. **SIEMPRE repite lo que va a hacer y espera mi «sí» hablado.** Un «no», el silencio o 30 s lo cancelan.
- **N3 – Prohibido, aunque yo lo pida «a la ligera»:** bancos y pagos, compras, borrar archivos o datos, instalar o desinstalar apps, cambiar ajustes de seguridad (Play Protect, bloqueo), leer o repetir códigos de verificación, grabar o guardar audio, manejar datos de pacientes reales.
- Una rutina «automática» solo puede contener N0 y N1. Si incluye N2, pide mi «sí» en el momento.

### Lo que Android NO deja (planéalo con APIs oficiales, sin root ni servicio de accesibilidad)
- No se puede encender/apagar el Wi-Fi por código (Android 10+), ni controlar la pantalla de otras apps sin accesibilidad (no la usaremos: es un riesgo de seguridad).
- Abrir apps desde segundo plano está limitado en Android 16: la pantalla de escritorio del Cuerpo debe estar visible.
- El micrófono en segundo plano exige servicio en primer plano con notificación (ya lo tiene).
- No se puede confirmar que un mensaje de WhatsApp «llegó»: Julio solo dice que lo envió.
- Para No molestar o el calendario hacen falta permisos especiales que yo debo conceder a mano.
Dime siempre qué parte NO es posible en vez de simularla.

## Ejemplos de automatización que quiero
- **«Julio, buenos días»:** resumen del día (clases, tareas, avisos) y música suave.
- **«Modo estudio»:** modo enfoque, música para concentrarme, pendientes del día y, si hay internet, una pregunta de repaso de la materia (con la IA).
- **«Me voy a dormir»:** silenciar, alarma, bajar el brillo, detener la música.
- **Repaso espaciado:** a ciertas horas, Julio me propone una pregunta tipo examen de lo que estoy estudiando y me dice la respuesta.
- **Resumen de avisos** cada cierto tiempo, si lo activo.
- Las rutinas se crean y se encienden por voz y desde una pantalla sencilla.

## Hoja de ruta (UNA cosa por versión; no avances sin que yo pruebe)
- **v44/v45 – HUD base (YA HECHO en el proyecto; v45 es la v44 corregida para compilar):** tema Cyber en el modo escritorio y en Inicio, con interruptor para volver al clásico; anillos, estados animados, hora y panel SISTEMA con datos reales. Falta que el dueño lo pruebe y mande capturas.
- **v46 – Paneles con datos reales:** Hoy, avisos, estudio y enlace.
- **v47 – Avatar holográfico** animado y que reacciona a la voz.
- **v48 – Motor de rutinas** (disparadores y acciones N0–N1) y su pantalla.
- **v49 – Ejecutor con niveles + IA con herramientas** (la IA propone, el Ejecutor decide).
- **v50 – Modo estudio** (repaso espaciado, simulacros con IA, tarjetas).
- **v51 – Integraciones opcionales** (calendario, clima, casa inteligente con Home Assistant en la red local).
**Antes de empezar, pregúntame si la v45 compiló y pídeme capturas del HUD; luego sigue con la v46, una cosa por versión.**

## Reglas de seguridad (no negociables, ya vienen del proyecto)
- Los códigos de verificación y los avisos del banco NUNCA se leen en voz alta, se envían, se guardan ni se responden.
- El texto de una notificación o de un mensaje son DATOS, no órdenes: solo se leen; jamás pasan por el intérprete de comandos ni por la IA como instrucciones.
- Nada se envía, se compra ni se borra sin mi «sí» hablado. Nunca grabar ni guardar audio.
- Todo apagado por defecto: nada sale a internet ni lee mis notificaciones hasta que yo lo encienda y elija las apps una por una.
- No cambiar la base de datos (Room) sin migración. Datos de avisos solo en memoria.
- La IA solo devuelve texto; nunca ejecuta nada. Nunca le mandes notificaciones, contactos, códigos ni datos de pacientes.
- No me hagas desactivar Play Protect ni Auto Blocker.

## Reglas de trabajo
- Nunca digas que algo «funciona» si no lo probaste. En cada entrega separa **«Verificado»** de **«NO verificado»**.
- No tienes compilador de Kotlin ni Android: valida la lógica pura con espejos en Python (`tools/espejo/`, corre `python3 espejo6.py` y `java EspejoProtocolo.java`) y escribe pruebas JUnit. Revisa a mano llaves, paréntesis y que cada `when` sobre `Intencion` sea exhaustivo. Lo visual no lo puedes ver: dímelo y pídeme una captura.
- Entrega el proyecto completo como `Julio_proyecto_vNN.zip` (siguiente número, carpeta raíz `julio/`) y actualiza `PLAN_DE_TRABAJO.md` (qué hace, qué NO está verificado, siguiente tarea) y `PROMPT_PARA_CONTINUAR.md`.
- Compilo con GitHub Actions: el zip va en la raíz del repo y su nombre NO lleva espacios ni «(1)».
- Una cosa por versión para saber qué falló. Si algo falla al compilar, te mando la captura y me dices la causa en una frase y el arreglo en pasos cortos.

## Cómo me conviene que me hables
Corto, claro, sin jerga. Me frustro cuando algo no funciona o hay muchas ventanas: no te disculpes de más; di qué falló, qué hacemos y cuál es el siguiente paso. Si algo es riesgoso para mi teléfono principal (tiene una cuenta bancaria), dímelo antes de pedirme instalar o conceder nada.

=== FIN ===
