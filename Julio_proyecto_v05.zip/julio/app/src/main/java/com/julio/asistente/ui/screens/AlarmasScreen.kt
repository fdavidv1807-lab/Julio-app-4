package com.julio.asistente.ui.screens

import androidx.compose.runtime.Composable
import com.julio.asistente.ui.components.SeccionBase

@Composable
fun AlarmasScreen() {
    SeccionBase(
        titulo = "Alarmas",
        etapa = "Etapa 5",
        descripcion = "Alarmas reales de Android con AlarmManager, notificaciones y repeticiones.",
    )
}
