package com.julio.asistente.ui.screens

import androidx.compose.runtime.Composable
import com.julio.asistente.ui.components.SeccionBase

@Composable
fun EnfoqueScreen() {
    SeccionBase(
        titulo = "Modo enfoque",
        etapa = "Etapa 6",
        descripcion = "Sesiones con duración personalizada, descansos y, si es viable, bloqueo de apps.",
    )
}
