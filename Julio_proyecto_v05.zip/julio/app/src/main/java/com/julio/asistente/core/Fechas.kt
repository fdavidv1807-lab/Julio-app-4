package com.julio.asistente.core

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * Las fechas "solo día" (p. ej. fecha límite de una tarea) se guardan como los milisegundos
 * de la medianoche UTC de ese día, que es lo que entrega el selector de fecha de Material.
 * Para mostrarlas hay que leerlas en UTC; así el día nunca se corre por la zona horaria.
 */
object Fechas {
    private val formato: DateTimeFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
    private val formatoLargo: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE d MMM yyyy")
    private val formatoHora: DateTimeFormatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)

    fun deMillisUtc(ms: Long): LocalDate =
        Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()

    fun texto(ms: Long): String = deMillisUtc(ms).format(formato)

    /** Vencida = el día límite ya pasó según la fecha local del teléfono. */
    fun estaVencida(ms: Long, hoy: LocalDate = LocalDate.now()): Boolean =
        deMillisUtc(ms).isBefore(hoy)

    /** Ejemplo: «Lunes 26 oct 2026» (según el idioma del teléfono). */
    fun textoLargo(d: LocalDate): String =
        d.format(formatoLargo).replaceFirstChar { it.uppercase() }

    fun textoHora(t: LocalTime): String = t.format(formatoHora)
}
