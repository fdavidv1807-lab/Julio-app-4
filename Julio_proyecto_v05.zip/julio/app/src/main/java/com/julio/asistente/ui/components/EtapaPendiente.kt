package com.julio.asistente.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Pantalla base de una sección: título + aviso honesto de que aún no está implementada. */
@Composable
fun SeccionBase(
    titulo: String,
    etapa: String,
    descripcion: String,
    modifier: Modifier = Modifier,
    contenidoExtra: @Composable () -> Unit = {},
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        contenidoExtra()
        Text(titulo, style = MaterialTheme.typography.headlineMedium)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Aún no implementado", style = MaterialTheme.typography.titleSmall)
                Text("Se construye en la $etapa.", style = MaterialTheme.typography.bodyMedium)
                Text(descripcion, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
