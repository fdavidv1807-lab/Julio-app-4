package com.julio.asistente.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.julio.asistente.ui.navigation.Destino
import com.julio.asistente.ui.screens.AlarmasScreen
import com.julio.asistente.ui.screens.EnfoqueScreen
import com.julio.asistente.ui.screens.HorarioScreen
import com.julio.asistente.ui.screens.TareasScreen
import com.julio.asistente.ui.screens.VozScreen

@Composable
fun JulioRoot() {
    val nav = rememberNavController()
    val entrada by nav.currentBackStackEntryAsState()
    val rutaActual = entrada?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                Destino.entries.forEach { d ->
                    NavigationBarItem(
                        selected = rutaActual == d.ruta,
                        onClick = {
                            nav.navigate(d.ruta) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(d.icono, contentDescription = d.titulo) },
                        label = { Text(d.titulo) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Destino.VOZ.ruta,
            modifier = Modifier.padding(padding),
        ) {
            composable(Destino.VOZ.ruta) { VozScreen() }
            composable(Destino.HORARIO.ruta) { HorarioScreen() }
            composable(Destino.TAREAS.ruta) { TareasScreen() }
            composable(Destino.ALARMAS.ruta) { AlarmasScreen() }
            composable(Destino.ENFOQUE.ruta) { EnfoqueScreen() }
        }
    }
}
