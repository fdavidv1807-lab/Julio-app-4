package com.julio.asistente.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.julio.asistente.R
import com.julio.asistente.ui.components.SeccionBase

@Composable
fun VozScreen() {
    SeccionBase(
        titulo = "Julio",
        etapa = "Etapa 3 (interfaz) y Etapa 8 (reconocimiento y síntesis de voz)",
        descripcion = "Aquí irán el botón para hablar, la transcripción, la respuesta, " +
            "la guía «¿Qué puedo decirle a Julio?» y Mis metas.",
    ) {
        Image(
            painter = painterResource(R.drawable.julio_mascota),
            contentDescription = "Julio, el gorila médico",
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 280.dp)
                .clip(RoundedCornerShape(28.dp)),
        )
    }
}
