package com.julio.asistente.tareas

enum class Prioridad(val valor: Int, val etiqueta: String) {
    BAJA(0, "Baja"),
    MEDIA(1, "Media"),
    ALTA(2, "Alta");

    companion object {
        fun de(valor: Int): Prioridad = entries.firstOrNull { it.valor == valor } ?: MEDIA
    }
}
