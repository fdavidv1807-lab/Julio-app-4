package com.julio.asistente

import android.app.Application
import com.julio.asistente.data.local.JulioDatabase

class JulioApp : Application() {
    /** Base de datos local única (Room). Se crea al primer uso. */
    val database: JulioDatabase by lazy { JulioDatabase.get(this) }
}
