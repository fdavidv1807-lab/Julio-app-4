package com.julio.asistente.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TareaEntity::class, ActividadEntity::class, AlarmaEntity::class, MetaEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class JulioDatabase : RoomDatabase() {
    abstract fun tareaDao(): TareaDao
    abstract fun actividadDao(): ActividadDao
    abstract fun alarmaDao(): AlarmaDao
    abstract fun metaDao(): MetaDao

    companion object {
        @Volatile private var instancia: JulioDatabase? = null

        fun get(context: Context): JulioDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    JulioDatabase::class.java,
                    "julio.db",
                ).build().also { instancia = it }
            }
    }
}
