package com.julio.asistente.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EsquemaOscuro = darkColorScheme(
    primary = AzulClaro,
    onPrimary = AzulProfundo,
    secondary = Cian,
    background = AzulProfundo,
    surface = SuperficieOscura,
    onBackground = Color(0xFFE6F1F8),
    onSurface = Color(0xFFE6F1F8),
)

private val EsquemaClaro = lightColorScheme(
    primary = AzulJulio,
    secondary = Color(0xFF00838F),
    background = Color(0xFFF4FAFE),
    surface = Color.White,
)

@Composable
fun JulioTheme(
    oscuro: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (oscuro) EsquemaOscuro else EsquemaClaro,
        content = content,
    )
}
