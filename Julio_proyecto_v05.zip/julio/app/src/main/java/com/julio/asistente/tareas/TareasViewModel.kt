package com.julio.asistente.tareas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.JulioApp
import com.julio.asistente.data.local.TareaEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TareasViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as JulioApp).database.tareaDao()

    /** null = todavía cargando desde la base de datos. La lista siempre refleja lo realmente guardado. */
    val tareas: StateFlow<List<TareaEntity>?> = dao.observarTodas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun guardar(t: TareaEntity) {
        viewModelScope.launch {
            if (t.id == 0L) dao.insertar(t) else dao.actualizar(t)
        }
    }

    fun alternarCompletada(t: TareaEntity) {
        viewModelScope.launch { dao.actualizar(t.copy(completada = !t.completada)) }
    }

    fun eliminar(t: TareaEntity) {
        viewModelScope.launch { dao.eliminar(t) }
    }
}
