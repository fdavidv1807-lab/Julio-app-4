package com.julio.asistente.ui.theme

import androidx.compose.ui.graphics.Color

val AzulJulio = Color(0xFF1E88E5)
val AzulClaro = Color(0xFF63C7F9)
val AzulProfundo = Color(0xFF0B1620)
val SuperficieOscura = Color(0xFF13222F)
val Cian = Color(0xFF4DD0E1)
