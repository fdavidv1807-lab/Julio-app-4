package com.julio.asistente.horario

enum class Recurrencia(val etiqueta: String) {
    NINGUNA("No se repite"),
    DIARIA("Cada día"),
    SEMANAL("Cada semana"),
    MENSUAL("Cada mes");

    companion object {
        fun de(valor: String): Recurrencia = entries.firstOrNull { it.name == valor } ?: NINGUNA
    }
}
