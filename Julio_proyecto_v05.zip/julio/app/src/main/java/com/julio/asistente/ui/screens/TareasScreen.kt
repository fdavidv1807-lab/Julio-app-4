package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.TareaEntity
import com.julio.asistente.tareas.Prioridad
import com.julio.asistente.tareas.TareasViewModel

private enum class FiltroTareas(val etiqueta: String) {
    PENDIENTES("Pendientes"),
    COMPLETADAS("Completadas"),
    TODAS("Todas"),
}

@Composable
fun TareasScreen(vm: TareasViewModel = viewModel()) {
    val lista by vm.tareas.collectAsStateWithLifecycle()
    var filtro by rememberSaveable { mutableStateOf(FiltroTareas.PENDIENTES) }
    var enEdicion by remember { mutableStateOf<TareaEntity?>(null) }
    var porEliminar by remember { mutableStateOf<TareaEntity?>(null) }

    val visibles = lista?.filter {
        when (filtro) {
            FiltroTareas.PENDIENTES -> !it.completada
            FiltroTareas.COMPLETADAS -> it.completada
            FiltroTareas.TODAS -> true
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Text(
                "Lista de tareas",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FiltroTareas.entries.forEach { f ->
                    FilterChip(
                        selected = filtro == f,
                        onClick = { filtro = f },
                        label = { Text(f.etiqueta) },
                    )
                }
            }
            Spacer(Modifier.height(12.dp))

            when {
                visibles == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                visibles.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        when (filtro) {
                            FiltroTareas.PENDIENTES -> "No tienes tareas pendientes."
                            FiltroTareas.COMPLETADAS -> "Aún no has completado ninguna tarea."
                            FiltroTareas.TODAS -> "No hay tareas. Toca «Nueva tarea» para crear la primera."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                else -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 96.dp),
                ) {
                    items(visibles, key = { it.id }) { t ->
                        TareaItem(
                            t = t,
                            onAlternar = { vm.alternarCompletada(t) },
                            onEditar = { enEdicion = t },
                            onEliminar = { porEliminar = t },
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { enEdicion = TareaEntity(titulo = "") },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Nueva tarea") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    enEdicion?.let { inicial ->
        DialogoTarea(
            inicial = inicial,
            onGuardar = { vm.guardar(it); enEdicion = null },
            onCancelar = { enEdicion = null },
        )
    }

    porEliminar?.let { t ->
        AlertDialog(
            onDismissRequest = { porEliminar = null },
            title = { Text("Eliminar tarea") },
            text = { Text("¿Eliminar «${t.titulo}»? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = { vm.eliminar(t); porEliminar = null }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { porEliminar = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun TareaItem(
    t: TareaEntity,
    onAlternar: () -> Unit,
    onEditar: () -> Unit,
    onEliminar: () -> Unit,
) {
    val vencida = !t.completada && t.fechaLimite?.let { Fechas.estaVencida(it) } == true
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(checked = t.completada, onCheckedChange = { onAlternar() })
            Column(Modifier.weight(1f)) {
                Text(
                    t.titulo,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (t.completada) TextDecoration.LineThrough else null,
                )
                if (t.descripcion.isNotBlank()) {
                    Text(
                        t.descripcion,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                val detalle = buildString {
                    append("Prioridad ${Prioridad.de(t.prioridad).etiqueta}")
                    t.fechaLimite?.let {
                        append(" · Límite ${Fechas.texto(it)}")
                        if (vencida) append(" (vencida)")
                    }
                }
                Text(
                    detalle,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (vencida) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(onClick = onEditar) { Icon(Icons.Filled.Edit, contentDescription = "Editar tarea") }
            IconButton(onClick = onEliminar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar tarea") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialogoTarea(
    inicial: TareaEntity,
    onGuardar: (TareaEntity) -> Unit,
    onCancelar: () -> Unit,
) {
    var titulo by remember { mutableStateOf(inicial.titulo) }
    var descripcion by remember { mutableStateOf(inicial.descripcion) }
    var prioridad by remember { mutableStateOf(Prioridad.de(inicial.prioridad)) }
    var fecha by remember { mutableStateOf(inicial.fechaLimite) }
    var selectorAbierto by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text(if (inicial.id == 0L) "Nueva tarea" else "Editar tarea") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it },
                    label = { Text("Título") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripción (opcional)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Prioridad", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Prioridad.entries.forEach { p ->
                        FilterChip(
                            selected = prioridad == p,
                            onClick = { prioridad = p },
                            label = { Text(p.etiqueta) },
                        )
                    }
                }
                OutlinedButton(onClick = { selectorAbierto = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(fecha?.let { "Fecha límite: ${Fechas.texto(it)}" } ?: "Añadir fecha límite")
                }
                if (fecha != null) {
                    TextButton(onClick = { fecha = null }) { Text("Quitar fecha límite") }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = titulo.isNotBlank(),
                onClick = {
                    onGuardar(
                        inicial.copy(
                            titulo = titulo.trim(),
                            descripcion = descripcion.trim(),
                            prioridad = prioridad.valor,
                            fechaLimite = fecha,
                        ),
                    )
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )

    if (selectorAbierto) {
        val estado = rememberDatePickerState(initialSelectedDateMillis = fecha)
        DatePickerDialog(
            onDismissRequest = { selectorAbierto = false },
            confirmButton = {
                TextButton(onClick = {
                    fecha = estado.selectedDateMillis
                    selectorAbierto = false
                }) { Text("Aceptar") }
            },
            dismissButton = { TextButton(onClick = { selectorAbierto = false }) { Text("Cancelar") } },
        ) { DatePicker(state = estado) }
    }
}
