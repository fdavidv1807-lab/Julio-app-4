package com.julio.asistente

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.julio.asistente.ui.JulioRoot
import com.julio.asistente.ui.theme.JulioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JulioTheme {
                JulioRoot()
            }
        }
    }
}
