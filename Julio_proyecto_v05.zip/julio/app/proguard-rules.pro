# Reglas R8 específicas del proyecto (se ampliarán si alguna librería lo requiere).
