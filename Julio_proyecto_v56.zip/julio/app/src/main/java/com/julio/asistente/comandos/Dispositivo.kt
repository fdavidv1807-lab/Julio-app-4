package com.julio.asistente.comandos

/**
 * Órdenes sobre el propio teléfono (Etapa 3 del Proyecto Cuerpo): volumen, brillo y abrir apps.
 * Lógica pura sobre texto ya normalizado ([Texto.normalizar] + [Texto.numeros]). No toca el sistema.
 */
object Dispositivo {
    private fun tiene(n: String, patron: String): Boolean = Regex(patron).containsMatchIn(n)

    /** Si la frase habla de otra cosa de Julio (alarmas, tareas...), esta lógica no interviene. */
    private val INTERNAS = Regex(
        "\\b(alarma|alarmas|tarea|tareas|pendiente|pendientes|horario|agenda|meta|metas|enfoque|estudio|examen|clase|clases|actividad|actividades|descanso)\\b",
    )
    private const val BAJA = "\\b(baja|bajar|bajale|baje|disminuye|disminuir|reduce|reducir|menos|bajo)\\b"
    private const val SUBE = "\\b(sube|subir|subele|suba|aumenta|aumentar|incrementa|incrementar|mas|alto)\\b"
    private const val MAXIMO = "\\b(maximo|maxima|al tope)\\b"
    private val VERBO_ABRIR = Regex("\\b(abre|abrir|abreme|abrime|lanza|lanzar|ejecuta|ejecutar)\\b")

    fun interpretar(n: String): Intencion? {
        // «Revisa mi actividad» lleva la palabra «actividad», que las órdenes internas (horario) reclaman: se mira antes.
        actividadTelefono(n)?.let { return it }
        repaso(n)?.let { return it }
        tarjetas(n)?.let { return it }
        if (INTERNAS.containsMatchIn(n)) return null
        return modoManual(n) ?: configuracion(n) ?: salirMenu(n) ?: ayuda(n) ?: conversacion(n) ?: diagnostico(n) ?: sincronizar(n) ?: reconectar(n) ?: llamar(n) ?: responder(n) ?: avisos(n) ?: volumen(n) ?: brillo(n) ?: musica(n) ?: abrir(n)
    }

    private fun nivel(n: String): Int? {
        val t = n.replace(Regex("\\bcien\\b"), "100")
        val m = Regex("(\\d{1,3})\\s*(%|por ciento)?").find(t) ?: return null
        return m.groupValues[1].toInt().coerceIn(0, 100)
    }

    private fun volumen(n: String): Intencion? {
        val habla = tiene(n, "\\b(volumen|sonido|audio)\\b")
        if ((habla && tiene(n, "\\b(activa|activar|reactiva|reactivar|restaura|restaurar|devuelve|devolver)\\b")) ||
            tiene(n, "\\bquita (el )?silencio\\b") || tiene(n, "\\bdesilencia\\b")
        ) return Intencion.AjustarVolumen(AccionNivel.ACTIVAR)
        if (tiene(n, "\\b(silencia|silenciar|mutea|mutear)\\b") ||
            tiene(n, "\\b(quita|quitale|apaga|sin) (el )?(sonido|volumen|audio)\\b")
        ) return Intencion.AjustarVolumen(AccionNivel.SILENCIAR)
        if (!habla) return null
        if (tiene(n, MAXIMO)) return Intencion.AjustarVolumen(AccionNivel.FIJAR, 100)
        nivel(n)?.let { return Intencion.AjustarVolumen(AccionNivel.FIJAR, it) }
        if (tiene(n, BAJA)) return Intencion.AjustarVolumen(AccionNivel.BAJAR)
        if (tiene(n, SUBE)) return Intencion.AjustarVolumen(AccionNivel.SUBIR)
        if (tiene(n, "\\b(como|cuanto|cual|que)\\b")) return Intencion.AjustarVolumen(AccionNivel.CONSULTAR)
        return null
    }

    private fun brillo(n: String): Intencion? {
        if (!tiene(n, "\\bbrillo\\b")) return null
        if (tiene(n, "\\b(automatico|automatica|normal|predeterminado)\\b|\\bpor defecto\\b")) return Intencion.AjustarBrillo(AccionNivel.AUTOMATICO)
        if (tiene(n, MAXIMO)) return Intencion.AjustarBrillo(AccionNivel.FIJAR, 100)
        if (tiene(n, "\\b(minimo|minima)\\b")) return Intencion.AjustarBrillo(AccionNivel.FIJAR, 5)
        nivel(n)?.let { return Intencion.AjustarBrillo(AccionNivel.FIJAR, it) }
        if (tiene(n, BAJA)) return Intencion.AjustarBrillo(AccionNivel.BAJAR)
        if (tiene(n, SUBE)) return Intencion.AjustarBrillo(AccionNivel.SUBIR)
        if (tiene(n, "\\b(como|cuanto|cual|que)\\b")) return Intencion.AjustarBrillo(AccionNivel.CONSULTAR)
        return null
    }

    private val MODO_MANUAL = Regex(
        "^(?:julio )?(?:(?:activa|activar|abre|abrir|pon|poner|entra a|entrar a|quiero|muestra|muestrame) )?(?:el )?modo manual$",
    )

    /** «Modo manual» / «Julio, activa el modo manual». */
    private fun modoManual(n: String): Intencion? = if (MODO_MANUAL.containsMatchIn(n.trim())) Intencion.ModoManual else null

    private val CONFIGURACION = Regex("^(?:julio )?(?:(?:abre|abrir|ve a|ir a|muestra|muestrame|ensename|quiero ver) )?(?:la |el )?(?:configuracion|ajustes|menu)$")

    /** «Julio, configuración»: muestra los botones ocultos (Mi día y Configuración), igual que el modo manual. */
    private fun configuracion(n: String): Intencion? = if (CONFIGURACION.containsMatchIn(n.trim())) Intencion.ModoManual else null

    /** «Julio, hablemos» / «termina la conversación». */
    private fun conversacion(n: String): Intencion? = when {
        ModoConversacion.pideIniciar(n) -> Intencion.IniciarConversacion
        ModoConversacion.pideTerminarExplicito(n) -> Intencion.TerminarConversacion
        else -> null
    }

    private val DIAGNOSTICO = Regex(
        "\\bdiagnostico (de |del |a )?(mis |los |las |el )?(avisos|aviso|notificaciones|alarmas)\\b|" +
            "\\bpor que no (me )?(avisas|avisa|avisaste|llegan|llega|suenan|suena|me llegan|me llega|me suenan)\\b|" +
            "\\b(no me )?(estas avisando|esta avisando|avisa) nada\\b",
    )

    /** «Diagnóstico de avisos», «¿por qué no me avisas?». */
    private fun diagnostico(n: String): Intencion? = if (DIAGNOSTICO.containsMatchIn(n)) Intencion.DiagnosticarAvisos else null

    private val SINCRONIZAR = Regex("^(?:julio )?(?:sincroniza|sincronizar|sincronizame|sincroniza todo)(?: ahora| los telefonos| mis telefonos| con el cuerpo| con el diario)?$")

    /** «Sincroniza». */
    private fun sincronizar(n: String): Intencion? = if (SINCRONIZAR.containsMatchIn(n.trim())) Intencion.SincronizarAhora else null

    private val ACTIVIDAD_TEL = Regex(
        "^(?:julio )?(?:revisa|revisar|muestra|muestrame|dime|ensename|como va|como voy con) (?:mi |el |mis )?(?:actividad|uso|tiempo de pantalla)" +
            "(?: del telefono| del celular| de mi telefono| de mi celular| de hoy| del movil)?$|" +
            "\\bcuanto (?:he |hemos )?usado (?:el |mi )?(?:telefono|celular|movil)\\b|\\b(?:tiempo|uso) de pantalla\\b|" +
            "^(?:julio )?cuanto tiempo (?:he |hemos )?(?:estado |pasado )?(?:en |con )(?:el |mi )?(?:telefono|celular|movil)\\b",
    )

    /** «Revisa mi actividad», «¿cuánto he usado el teléfono?». */
    private fun actividadTelefono(n: String): Intencion? = if (ACTIVIDAD_TEL.containsMatchIn(n.trim())) Intencion.RevisarActividad else null

    private val LLAMAR = Regex(
        "^(?:julio )?(?:(?:quiero|puedes|podrias|necesito|vamos) (?:que )?(?:me )?)?" +
            "(?:(?:llama|llamar|llamame|llamale)(?: por telefono)?(?: (?:a|al|a la|a mi))?(?: (.+))?|" +
            "(?:marca|marcar|marcale|telefonea) (?:a|al|a la|a mi) (.+))$",
    )

    /** «Llama a mamá». El nombre queda normalizado (sin acentos). «Marca» solo cuenta con «a …» (para no chocar con «marca como hecho»). */
    private fun llamar(n: String): Intencion? {
        val m = LLAMAR.find(n.trim()) ?: return null
        val crudo = m.groupValues[1].ifBlank { m.groupValues[2] }
        val nombre = crudo.trim().replace(Regex("^(?:a |al |a la |mi |mis )+"), "").trim()
        return Intencion.Llamar(nombre.ifBlank { null })
    }

    private val REPASAR = Regex(
        "^(?:julio )?(?:repasa|repasame|repasemos|repasar|hazme un repaso|hazme repaso|ponme un examen|ponme un quiz|ponme un repaso|examiname)" +
            "(?: (?:de|sobre|del|acerca de))?(?: (?:el |la |los |las )?(.+))?$",
    )
    private val REPASO_YA = Regex("^(?:julio )?ya repase (?:de |sobre |del |el |la |los |las )*(.+)$")
    private val REPASO_RESULTADO = Regex("^(?:julio )?me fue (bien|mal) (?:en|con|de|sobre) (?:el |la |los |las )*(.+)$")
    private val QUE_REPASAR = Regex("\\bque (?:debo|tengo que|me toca|toca|hay que) repasar\\b|\\bque repasos tengo\\b|^(?:julio )?mis repasos$")

    /** Repaso espaciado (v55): «repasa la mitosis», «ya repasé la mitosis», «me fue mal en la mitosis», «¿qué me toca repasar?». */
    private fun repaso(n: String): Intencion? {
        val t = n.trim()
        if (QUE_REPASAR.containsMatchIn(t)) return Intencion.ConsultarRepasos
        REPASO_YA.find(t)?.let { return Intencion.RepasoHecho(it.groupValues[1].trim(), true) }
        REPASO_RESULTADO.find(t)?.let { return Intencion.RepasoHecho(it.groupValues[2].trim(), it.groupValues[1] == "bien") }
        REPASAR.find(t)?.let {
            val tema = it.groupValues[1].trim()
            // «repasa mi horario» no es un repaso de estudio.
            if (Regex("^(?:mi|mis) (?:horario|tareas|agenda|alarmas|actividades|dia)").containsMatchIn(tema)) return null
            return Intencion.Repasar(tema.ifBlank { null })
        }
        return null
    }

    private val CREAR_TARJETAS = Regex(
        "^(?:julio )?(?:hazme|crea|crear|creame|genera|generame|dame|armame|arma|preparame) (?:unas |las |mis |unos |cinco |5 )*(?:tarjetas|flashcards)" +
            "(?: de estudio)?(?: (?:de|sobre|del|acerca de))?(?: (?:el |la |los |las )?(.+))?$",
    )
    private val QUE_TARJETAS = Regex("\\bcuantas tarjetas (?:tengo|me tocan|hay|debo repasar)\\b|\\bque tarjetas (?:tengo|me tocan|hay)\\b|^(?:julio )?mis tarjetas$")

    /** Tarjetas de estudio (v56): «hazme tarjetas de la mitosis», «¿cuántas tarjetas tengo pendientes?». */
    private fun tarjetas(n: String): Intencion? {
        val t = n.trim()
        if (QUE_TARJETAS.containsMatchIn(t)) return Intencion.ConsultarTarjetas
        CREAR_TARJETAS.find(t)?.let { return Intencion.CrearTarjetas(it.groupValues[1].trim().ifBlank { null }) }
        return null
    }

    private val RECONECTAR = Regex("^(?:julio )?(?:vincula|vincular|reconecta|reconectar|empareja|emparejar|enlaza|enlazar)(?: de nuevo| otra vez| los telefonos| mis telefonos| el enlace| con el cuerpo| con el diario)*$")

    /** «Vincula de nuevo», «reconecta». */
    private fun reconectar(n: String): Intencion? = if (RECONECTAR.containsMatchIn(n.trim())) Intencion.Reconectar else null

    private val SALIR_MENU = Regex(
        "^(?:julio )?(?:(?:sal|salir|salte|cierra|cerrar|quita|quitar|termina|terminar) (?:del |de |el )?(?:el )?(?:menu|modo manual|configuracion|horario)|" +
            "listo|ya esta|cierra|salir)$",
    )

    /** «Salir del menú» / «listo» / «cierra el menú». */
    private fun salirMenu(n: String): Intencion? = if (SALIR_MENU.containsMatchIn(n.trim())) Intencion.SalirMenu else null

    private val AYUDA = Regex(
        "\\b(que (puedes|sabes|podes) (hacer|decir)|que haces|para que sirves|que puedo (decirte|decirle|pedirte|pedirle)|" +
            "que comandos|que ordenes|como te uso|como se usa julio)\\b|^(julio )?ayuda$",
    )

    /** «¿Qué puedes hacer?». */
    private fun ayuda(n: String): Intencion? = if (AYUDA.containsMatchIn(n)) Intencion.Ayuda else null

    private val RESPONDER = Regex(
        "^(?:julio )?(?:quiero |puedes |podrias |vamos a )?(?:responde|responder|contesta|contestar|respondele|contestale|respondeme)" +
            "(?: (?:el|ese|este|al) (?:mensaje|chat|whatsapp))?(?: a (.+))?$",
    )

    /** «Responde» / «responde a Ana». El nombre queda normalizado (sin acentos). */
    private fun responder(n: String): Intencion? {
        val m = RESPONDER.find(n.trim()) ?: return null
        return Intencion.Responder(m.groupValues[1].trim().ifBlank { null })
    }

    private val AVISOS = Regex(
        "\\b(que|cuales|cuantas|cuantos) (notificaciones|notificacion|mensajes|mensaje)( nuevas| nuevos)? (tengo|hay|me llegaron|llegaron|me escribieron|me mandaron)\\b|" +
            "\\b(tengo|hay) (alguna |algun )?(notificacion|notificaciones|mensajes)( nuevas| nuevos)?\\b|" +
            "\\b(lee|leeme|leer|dime|resume|resumeme) (mis |las |los )?(notificaciones|mensajes)\\b|" +
            "\\bque me (llego|escribieron|mandaron)\\b",
    )

    /** «¿Qué notificaciones tengo?». */
    private fun avisos(n: String): Intencion? = if (AVISOS.containsMatchIn(n)) Intencion.ConsultarAvisos else null

    private const val NOMBRE_MUSICA = "\\b(cancion|canciones|musica|pista|rola)\\b"
    private val PON = Regex("\\b(pon|poner|ponme|reproduce|reproducir|toca|tocar|play|inicia|iniciar|empieza|empezar)\\b")

    /**
     * Música: exige la palabra «música/canción» (salvo «retrocede»), para no confundirse con «pausa el enfoque» u otras órdenes.
     * Funciona con la app de música que esté sonando.
     */
    private fun musica(n: String): Intencion? {
        if (tiene(n, "^(julio )?(retrocede|retroceder)$")) return Intencion.Musica(AccionMusica.ANTERIOR)
        if (!tiene(n, NOMBRE_MUSICA)) return null
        if (tiene(n, "\\b(siguiente|proxima|otra|cambia|cambiar|cambiala|salta|saltar|avanza|avanzar|pasa|pasar|adelanta)\\b"))
            return Intencion.Musica(AccionMusica.SIGUIENTE)
        if (tiene(n, "\\b(anterior|previa|retrocede|retroceder|regresa|regresar|devuelve|devolver|atras)\\b"))
            return Intencion.Musica(AccionMusica.ANTERIOR)
        if (tiene(n, "\\b(pausa|pausar|pausala|deten|detener|detenla)\\b") || (!PON.containsMatchIn(n) && tiene(n, "\\b(para|parar)\\b")))
            return Intencion.Musica(AccionMusica.PAUSAR)
        if (tiene(n, "\\b(reanuda|reanudar|continua|continuar|sigue|seguir|resume)\\b")) return Intencion.Musica(AccionMusica.SEGUIR)
        if (PON.containsMatchIn(n)) return Intencion.Musica(AccionMusica.PONER, consultaMusica(n))
        return null
    }

    private val RESTO_MUSICA = Regex("\\b(?:cancion|canciones|musica|rola|pista)\\s+(.+)$")
    private val SIN_PEDIR = Regex("^(aleatoria|aleatorio|cualquiera|al azar|lo que sea|alguna|algo|una|otra|buena|bonita)( .*)?$")

    /**
     * Lo que se quiere escuchar: «pon música de Bad Bunny» -> «bad bunny», «pon la canción Despacito» -> «despacito»,
     * «música para estudiar» -> «musica para estudiar». null = no pidió nada concreto (Julio elige algo al azar).
     */
    internal fun consultaMusica(n: String): String? {
        val m = RESTO_MUSICA.find(n) ?: return null
        var resto = m.groupValues[1].replace(Regex("\\b(por favor|julio|ahora|ya)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        resto = resto.replace(Regex("(^|\\s)(en|con|por) (youtube music|youtube|spotify)$"), "").trim()
        if (resto.startsWith("para ")) return "musica $resto"
        while (true) {
            val sin = resto.replace(Regex("^(de|del|la|el|los|las|un|una|unos|unas|estilo|tipo)\\s+"), "")
            if (sin == resto) break
            resto = sin
        }
        return if (resto.isBlank() || SIN_PEDIR.matches(resto)) null else resto
    }

    private fun abrir(n: String): Intencion? {
        if (!VERBO_ABRIR.containsMatchIn(n)) return null
        val nombre = Interprete.limpiar(n, listOf(VERBO_ABRIR.pattern, "\\b(aplicacion|aplicaciones|app|apps|programa)\\b", "\\bpor favor\\b"))
        return Intencion.AbrirApp(nombre.ifBlank { null })
    }
}
