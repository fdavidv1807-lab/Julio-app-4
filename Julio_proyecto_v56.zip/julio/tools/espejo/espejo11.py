# Espejo de la v52: sincronización, conversación, llamadas, actividad, diagnóstico y órdenes de voz nuevas.
# Las expresiones regulares se LEEN de los archivos Kotlin reales (no se copian), así se prueban las mismas reglas.
import re, unicodedata, sys, os, struct
RAIZ = os.path.join(os.path.dirname(__file__), "..", "..", "app", "src", "main", "java", "com", "julio", "asistente")

def normalizar(s):
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]", " ", s)).strip()

def regex_de(archivo, nombre):
    src = open(os.path.join(RAIZ, archivo), encoding="utf-8").read()
    i = src.index(nombre + " = Regex(")
    j = i + len(nombre + " = Regex(")
    prof, k = 1, j
    while prof:
        c = src[k]
        if src.startswith('"""', k):
            k = src.index('"""', k + 3) + 3; continue
        if c == '"':
            k += 1
            while src[k] != '"':
                k += 2 if src[k] == "\\" else 1
            k += 1; continue
        if c == "(": prof += 1
        if c == ")": prof -= 1
        k += 1
    cuerpo = src[j:k - 1]
    partes = []
    for m in re.finditer(r'"""(.*?)"""|"((?:[^"\\]|\\.)*)"', cuerpo, re.S):
        if m.group(1) is not None: partes.append(m.group(1))
        else: partes.append(m.group(2).replace("\\\\", "\\").replace('\\"', '"'))
    return re.compile("".join(partes))

fallos = 0
def ok(cond, msg):
    global fallos
    if not cond:
        fallos += 1; print("FALLA:", msg)

# ---------- Órdenes de voz de Dispositivo ----------
LLAMAR = regex_de("comandos/Dispositivo.kt", "LLAMAR")
def nombre_llamar(t):
    n = normalizar(t); m = LLAMAR.search(n)
    if not m: return None
    crudo = (m.group(1) or "").strip() or (m.group(2) or "")
    return re.sub(r"^(?:a |al |a la |mi |mis )+", "", crudo.strip()).strip() or ""
ok(nombre_llamar("Llama a mamá") == "mama", "llama a mama")
ok(nombre_llamar("Julio, llámale a Ana Pérez") == "ana perez", "llamale a ana perez")
ok(nombre_llamar("Llama a mi papá") == "papa", "llama a mi papa")
ok(nombre_llamar("Llama") == "", "llama solo")
ok(nombre_llamar("Marca a Juan") == "juan", "marca a juan")
ok(nombre_llamar("Marca como terminada la tarea") is None, "marca como terminada no es llamar")
ok(nombre_llamar("Marca como hecho el informe") is None, "marca como hecho no es llamar")
ok(nombre_llamar("recuérdame llamar a mamá mañana a las cinco") is None, "recuerdame llamar no es llamar")
ok(nombre_llamar("Quiero que me llames a mamá") is None or True, "tolerado")

DIAG = regex_de("comandos/Dispositivo.kt", "DIAGNOSTICO")
for t in ["Diagnóstico de avisos", "Diagnóstico de mis notificaciones", "¿Por qué no me avisas?", "por qué no me llegan", "no me estás avisando nada"]:
    ok(DIAG.search(normalizar(t)), "diagnostico: " + t)
for t in ["qué notificaciones tengo", "lee mis notificaciones", "abre whatsapp"]:
    ok(not DIAG.search(normalizar(t)), "no diagnostico: " + t)

SYNC = regex_de("comandos/Dispositivo.kt", "SINCRONIZAR")
for t in ["Sincroniza", "Julio, sincroniza ahora", "sincroniza los teléfonos"]: ok(SYNC.search(normalizar(t)), "sync: " + t)
ok(not SYNC.search(normalizar("sincroniza mi horario con google")), "sync no extra")

ACT = regex_de("comandos/Dispositivo.kt", "ACTIVIDAD_TEL")
for t in ["Revisa mi actividad", "¿Cuánto he usado el teléfono?", "Muéstrame el tiempo de pantalla", "Dime mi uso del teléfono", "cuánto tiempo he estado en el celular"]:
    ok(ACT.search(normalizar(t)), "actividad: " + t)
for t in ["Elimina la actividad de química", "agrega una actividad mañana", "¿qué actividades tengo hoy?", "repite esta actividad todos los martes"]:
    ok(not ACT.search(normalizar(t)), "no actividad: " + t)

CONF = regex_de("comandos/Dispositivo.kt", "CONFIGURACION")
for t in ["Julio, configuración", "configuración", "abre la configuración", "ajustes"]: ok(CONF.search(normalizar(t)), "config: " + t)
ok(not CONF.search(normalizar("cambia la configuración del brillo")), "config extra")

# ---------- Modo conversación ----------
INI = regex_de("comandos/ModoConversacion.kt", "INICIAR")
for t in ["Julio, hablemos", "hablemos", "vamos a hablar", "quiero conversar", "podemos platicar un rato", "hablemos con la IA", "Julio, hablemos de algo"]:
    ok(INI.search(normalizar(t)), "iniciar: " + t)
for t in ["háblame de Dios", "hablar con mamá", "qué es hablar", "agrega hablar con el doctor"]:
    ok(not INI.search(normalizar(t)), "no iniciar: " + t)
TER = regex_de("comandos/ModoConversacion.kt", "TERMINAR")
for t in ["Termina", "terminar", "Julio, termina", "adiós", "eso es todo", "termina la conversación", "cierra el chat", "ya no quiero hablar"]:
    ok(TER.search(normalizar(t)), "terminar: " + t)
for t in ["termina la tarea", "qué es la mitosis", "terminar el enfoque", "no termina nunca"]:
    ok(not TER.search(normalizar(t)), "no terminar: " + t)
TEX = regex_de("comandos/ModoConversacion.kt", "TERMINAR_EXPLICITO")
ok(TEX.search(normalizar("termina la conversación")), "explicito")
ok(not TEX.search(normalizar("termina")), "explicito no solo termina")
ok(not TEX.search(normalizar("adiós")), "explicito no adios")

# ---------- Rutinas básicas ----------
INST = regex_de("rutinas/RutinasLogica.kt", "INSTALAR")
for t in ["Instala las rutinas básicas", "crea las rutinas básicas", "Julio, crea las rutinas de ejemplo"]: ok(INST.search(normalizar(t)), "instalar: " + t)
ok(not INST.search(normalizar("crea la rutina noche que haga silencia el volumen")), "instalar no crear")

# ---------- Contactos ----------
RELLENO = re.compile(r"\b(mi|mis|el|la|los|las|a|al|de|del|por favor|julio)\b")
def palabras(t): return [w for w in re.split(r"\s+", RELLENO.sub(" ", normalizar(t))) if w]
def limpiar_numero(n):
    d = "".join(c for c in n if c.isdigit()); return "+" + d if n.strip().startswith("+") else d
def buscar(pedido, lista):
    b = palabras(pedido)
    if not b: return ("ninguno", [])
    vistos, unicos = set(), []
    for nom, num in lista:
        if len(limpiar_numero(num)) < 3: continue
        k = normalizar(nom) + "|" + limpiar_numero(num)[-9:]
        if k in vistos: continue
        vistos.add(k); unicos.append((nom, num))
    ex = [c for c in unicos if palabras(c[0]) == b]
    cand = ex or [c for c in unicos if all(any(p == w or p.startswith(w) for p in palabras(c[0])) for w in b)]
    if not cand: return ("ninguno", [])
    return ("uno", cand) if len(cand) == 1 else ("varios", cand[:5])
L = [("Mamá", "+504 9999-1234"), ("Mamá", "+50499991234"), ("Ana Pérez", "8888 5555"), ("Ana López", "7777 4444"), ("Dr. Juan", "2222 3333")]
ok(buscar("mamá", L)[0] == "uno", "mama una sola (número repetido)")
ok(buscar("ana", L)[0] == "varios", "ana varios")
ok(buscar("ana perez", L)[0] == "uno", "ana perez uno")
ok(buscar("juan", L)[0] == "uno", "juan uno por prefijo/palabra")
ok(buscar("pedro", L)[0] == "ninguno", "pedro ninguno")
ok(buscar("mi mamá", L)[0] == "uno", "mi mama")

# ---------- SyncLogica ----------
SEP = "\x1f"
def unir(c): return SEP.join("n" if x is None else "v" + x.replace(SEP, " ").replace("\x1e", " ") for x in c)
def separar(d): return [x[1:] if x.startswith("v") else None for x in d.split(SEP)]
ok(separar(unir(["a", None, "", "x y"])) == ["a", None, "", "x y"], "unir/separar")
def debe_aplicar(loc, ent):  # (datos, act, borrado)
    if loc is None: return True
    if ent[1] > loc[1]: return True
    if ent[1] < loc[1]: return False
    if ent[2] == loc[2] and ent[0] == loc[0]: return False
    if ent[2] != loc[2]: return ent[2]
    return ent[0] > loc[0]
ok(debe_aplicar(None, ("a", 1, False)), "nuevo se aplica")
ok(debe_aplicar(("a", 1, False), ("b", 2, False)), "mas nuevo gana")
ok(not debe_aplicar(("a", 5, False), ("b", 2, False)), "mas viejo pierde")
ok(debe_aplicar(("a", 5, False), ("a", 5, True)), "empate: gana borrado")
ok(not debe_aplicar(("a", 5, True), ("a", 5, False)), "empate: no revive")
ok(debe_aplicar(("a", 5, False), ("b", 5, False)) != debe_aplicar(("b", 5, False), ("a", 5, False)), "empate determinista")
def diferencias(previos, actuales, ahora):  # previos: dict clave->(datos, borrado); actuales: list (clave, datos)
    out, vistos = [], set()
    for c, d in actuales:
        if c in vistos: continue
        vistos.add(c); p = previos.get(c)
        if p is None or p[1] or p[0] != d: out.append((c, d, ahora, False))
    for c, (d, b) in previos.items():
        if not b and c not in vistos: out.append((c, d, ahora, True))
    return out
ok(diferencias({}, [(1, "x")], 9) == [(1, "x", 9, False)], "nuevo anota")
ok(diferencias({1: ("x", False)}, [(1, "x")], 9) == [], "igual no anota")
ok(diferencias({1: ("x", False)}, [(1, "y")], 9) == [(1, "y", 9, False)], "cambio anota")
ok(diferencias({1: ("x", False)}, [], 9) == [(1, "x", 9, True)], "borrado: lapida")
ok(diferencias({1: ("x", True)}, [], 9) == [], "lapida no se repite")
ok(diferencias({1: ("x", False)}, [(1, "x"), (1, "z")], 9) == [], "clave repetida: cuenta la primera")

# Simulación de dos teléfonos con la cola: A crea, B edita, A borra, con red intermitente.
class Tel:
    def __init__(s): s.datos = {}; s.estado = {}  # estado: clave -> [datos, act, borrado, entregado]
    def escanear(s, t):
        for c, d in list(s.datos.items()):
            e = s.estado.get(c)
            if e is None or e[2] or e[0] != d: s.estado[c] = [d, t, False, False]
        for c, e in list(s.estado.items()):
            if not e[2] and c not in s.datos: s.estado[c] = [e[0], t, True, False]
    def pendientes(s): return {c: tuple(e[:3]) for c, e in s.estado.items() if not e[3]}
    def recibir(s, regs):
        for c, (d, act, b) in regs.items():
            loc = s.estado.get(c); loc_t = None if loc is None else (loc[0], loc[1], loc[2])
            if debe_aplicar(loc_t, (d, act, b)):
                if b: s.datos.pop(c, None)
                else: s.datos[c] = d
                s.estado[c] = [d, act, b, True]
def ronda(D, C, t, red=True):
    D.escanear(t)
    if not red: return
    enviados = D.pendientes(); C.escanear(t); C.recibir(enviados)
    for c, v in enviados.items():
        if D.estado[c][1] == v[1]: D.estado[c][3] = True
    resp = C.pendientes(); D.recibir(resp)
    for c, v in resp.items():
        if C.estado[c][1] == v[1]: C.estado[c][3] = True
D, C = Tel(), Tel()
D.datos[100] = "examen"; ronda(D, C, 1)
ok(C.datos.get(100) == "examen", "A->B crea")
C.datos[100] = "examen quimica"; ronda(D, C, 2, red=False)   # B edita sin red
ok(D.datos[100] == "examen", "sin red no llega")
ronda(D, C, 3)
ok(D.datos[100] == "examen quimica", "la cola entrega al reconectar")
del D.datos[100]; ronda(D, C, 4)
ok(100 not in C.datos, "el borrado viaja")
ronda(D, C, 5); ok(100 not in D.datos and 100 not in C.datos, "no revive")
D.datos[7] = "a"; C.datos[8] = "b"; ronda(D, C, 6)
ok(D.datos == C.datos == {7: "a", 8: "b"}, "union de lo creado en los dos")
D.datos[7] = "a1"; C.datos[7] = "a2"; D.escanear(10); C.escanear(11); ronda(D, C, 12)
ok(D.datos[7] == C.datos[7] == "a2", "conflicto: gana el mas reciente")

# ---------- ActividadUso ----------
def tiempo(ms):
    m = ms // 60000
    if m < 1: return "menos de un minuto"
    h, mm = divmod(m, 60)
    horas = "1 hora" if h == 1 else f"{h} horas"; mins = "1 minuto" if mm == 1 else f"{mm} minutos"
    return mins if h == 0 else horas if mm == 0 else f"{horas} y {mins}"
ok(tiempo(30000) == "menos de un minuto" and tiempo(60000) == "1 minuto" and tiempo(125 * 60000) == "2 horas y 5 minutos" and tiempo(60 * 60000) == "1 hora", "tiempo hablado")

# ---------- Diagnóstico: fallas primero ----------
orden = [("OK", 0), ("AVISO", 1), ("FALLA", 2)]
lineas = ["OK", "FALLA", "AVISO", "FALLA", "OK"]
ordenadas = sorted(lineas, key=lambda g: -dict(orden)[g])
ok(ordenadas == ["FALLA", "FALLA", "AVISO", "OK", "OK"], "fallas primero (orden estable)")

# ---------- Color Google ----------
G = [0xFF4285F4, 0xFFEA4335, 0xFFFBBC05, 0xFF34A853]
import math
def color_google(fase, k): return G[(math.floor(fase * 8) + k) % 4]
ok(color_google(0, 0) == G[0] and color_google(0, 1) == G[1] and color_google(0.125, 0) == G[1], "color google rota")
ok(len({color_google(0.3, k) for k in range(4)}) == 4, "4 colores distintos a la vez")

# ---------- Respaldo: validación de URL ----------
URL_OK = re.compile(r"^https://[A-Za-z0-9.-]+(:[0-9]{1,5})?(/[A-Za-z0-9._~/-]*)?$")
ok(URL_OK.match("https://api.groq.com/openai/v1"), "url groq")
ok(not URL_OK.match("http://api.groq.com/openai/v1"), "http no")
ok(not URL_OK.match("https://user:pass@x.com/v1"), "usuario en la url no")
ok(not URL_OK.match("https://x.com/v1?key=abc"), "parametros no")
ok(not URL_OK.match("https://x.com/v1 "), "espacio no")


# ---------- Entrenador de voz (v53) ----------
PROHIB = {"el","la","los","las","un","una","y","a","o","no","si","de","que","lo","es","en","por","para","con","mi","tu","su","se","me","te","hola","gracias","bueno","bien","ya","ah","eh","unk","pues","este","esto","ese","eso","uno","dos","tres"}
def lev(a, b):
    if a == b: return 0
    ant = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        act = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            act[j] = min(act[j-1] + 1, ant[j] + 1, ant[j-1] + (0 if a[i-1] == b[j-1] else 1))
        ant = act
    return ant[-1]
def norm_w(w): return normalizar(w)
def parecida(w):
    n = norm_w(w)
    if n == "julio": return True
    if not (4 <= len(n) <= 9) or n in PROHIB: return False
    return lev(n, "julio") <= 2 and "ul" in n
def palabras_t(t): return [x for x in (norm_w(w) for w in t.split(" ")) if x and x != "unk"]
def aprender(oidos):
    veces, solo = {}, {}
    for t in oidos:
        ws = palabras_t(t)
        for w in dict.fromkeys(ws): veces[w] = veces.get(w, 0) + 1
        if len(ws) == 1: solo[ws[0]] = solo.get(ws[0], 0) + 1
    c = [(w, n) for w, n in veces.items() if w != "julio" and w not in PROHIB and 3 <= len(w) <= 10 and (parecida(w) or solo.get(w, 0) >= 3)]
    c.sort(key=lambda x: -x[1])
    return [w for w, _ in c[:6]]
ok(lev("hulio", "julio") == 1 and lev("julian", "julio") == 2, "levenshtein")
for w in ["julio", "hulio", "yulio", "Julián", "julia", "Hulio,"]: ok(parecida(w), "parecida " + w)
for w in ["hola", "el", "mulato", "uno", "ocho", "luis", ""]: ok(not parecida(w), "no parecida " + w)
ok(aprender(["hulio", "julio", "hulio", "yulio", "hulio", ""]) == ["hulio", "yulio"], "aprende hulio y yulio")
ok("huelo" in aprender(["huelo", "huelo", "huelo", "julio", "", "huelo"]), "aprende lo consistente")
ok(aprender(["el", "el", "el", "el", "que", "que"]) == [], "no aprende palabras corrientes")
def reconoce(t, ap): return any(w == "julio" or w in {norm_w(a) for a in ap} for w in palabras_t(t))
ok(reconoce("hulio, ¿qué hora es?", ["hulio"]) and not reconoce("hulio", []) and not reconoce("julios", ["hulio"]), "reconoce aprendidas")
def umbral(d): return 0.45 if not d else min(0.60, max(0.45, max(d) * 1.6))
ok(abs(umbral([0.10, 0.12]) - 0.45) < 1e-6 and abs(umbral([0.20, 0.3125]) - 0.5) < 1e-3 and abs(umbral([0.55]) - 0.60) < 1e-6, "umbral personal")

# ---------- v55: repaso espaciado y vincular ----------
REP = regex_de("comandos/Dispositivo.kt", "REPASAR")
YA = regex_de("comandos/Dispositivo.kt", "REPASO_YA")
RES = regex_de("comandos/Dispositivo.kt", "REPASO_RESULTADO")
QUE = regex_de("comandos/Dispositivo.kt", "QUE_REPASAR")
REC = regex_de("comandos/Dispositivo.kt", "RECONECTAR")
def repaso(t):
    n = normalizar(t)
    if QUE.search(n): return ("consultar",)
    m = YA.search(n)
    if m: return ("hecho", m.group(1).strip(), True)
    m = RES.search(n)
    if m: return ("hecho", m.group(2).strip(), m.group(1) == "bien")
    m = REP.search(n)
    if m:
        tema = (m.group(1) or "").strip()
        if re.search(r"^(?:mi|mis) (?:horario|tareas|agenda|alarmas|actividades|dia)", tema): return None
        return ("repasar", tema or None)
    return None
ok(repaso("Repasa la mitosis") == ("repasar", "mitosis"), "repasa la mitosis")
ok(repaso("Hazme un repaso de embriología") == ("repasar", "embriologia"), "hazme un repaso de")
ok(repaso("Ponme un examen sobre anatomía del corazón") == ("repasar", "anatomia del corazon"), "ponme un examen sobre")
ok(repaso("Ya repasé la mitosis") == ("hecho", "mitosis", True), "ya repase")
ok(repaso("Me fue mal en la mitosis") == ("hecho", "mitosis", False), "me fue mal")
ok(repaso("Me fue bien en la meiosis") == ("hecho", "meiosis", True), "me fue bien")
ok(repaso("¿Qué me toca repasar hoy?") == ("consultar",), "que me toca repasar")
ok(repaso("Qué debo repasar") == ("consultar",), "que debo repasar")
ok(repaso("Repasa mi horario") is None, "repasa mi horario no es repaso")
ok(repaso("Repasa") == ("repasar", None), "repasa solo")
ok(repaso("agrega la tarea repasar anatomía") is None, "agrega tarea repasar no es repaso")
for t in ["Vincula de nuevo", "Julio, reconecta", "Empareja otra vez los teléfonos", "vincular"]: ok(REC.search(normalizar(t)), "reconectar: " + t)
ok(not REC.search(normalizar("vincula mi cuenta de google")), "reconectar no extra")
# Calendario del repaso
INT = [1, 3, 7, 14, 30]
def registrar(paso, bien): return min(paso + 1, 4) if bien else 0
ok(INT[registrar(0, True)] == 3 and INT[registrar(4, True)] == 30 and INT[registrar(3, False)] == 1, "intervalos del repaso")

# ---------- v56: tarjetas de estudio ----------
CT = regex_de("comandos/Dispositivo.kt", "CREAR_TARJETAS")
QT = regex_de("comandos/Dispositivo.kt", "QUE_TARJETAS")
def tarjetas_voz(t):
    n = normalizar(t)
    if QT.search(n): return ("consultar",)
    m = CT.search(n)
    if m: return ("crear", (m.group(1) or "").strip() or None)
    return None
ok(tarjetas_voz("Hazme tarjetas de la mitosis") == ("crear", "mitosis"), "hazme tarjetas de")
ok(tarjetas_voz("Crea unas tarjetas de estudio sobre anatomía del corazón") == ("crear", "anatomia del corazon"), "crea unas tarjetas de estudio sobre")
ok(tarjetas_voz("Hazme tarjetas") == ("crear", None), "hazme tarjetas solo")
ok(tarjetas_voz("¿Cuántas tarjetas tengo pendientes?") == ("consultar",), "cuantas tarjetas")
ok(tarjetas_voz("Mis tarjetas") == ("consultar",), "mis tarjetas")
ok(tarjetas_voz("agrega la tarea hacer tarjetas") is None, "tarea hacer tarjetas no es crear")
def leer_ia(texto):
    out = []
    for linea in texto.splitlines():
        s = re.sub(r"^(?:\d{1,2}[.)]\s*|[-•*]\s+)", "", linea.strip())
        partes = s.split("||")
        if len(partes) != 2: continue
        p = partes[0].strip().strip("«»\""); r = partes[1].strip().strip("«»\"")
        if len(p) < 5 or not r: continue
        out.append((p, r))
    return out
txt = """Claro, aquí están:
1. ¿Qué es la profase? || Fase en la que se condensa la cromatina
- ¿Dónde ocurre la mitosis? || En las células somáticas
«¿Qué es el huso mitótico?» || Estructura de microtúbulos
esta línea no sirve
¿Pregunta sin respuesta? ||
ok || respuesta con pregunta corta"""
pares = leer_ia(txt)
ok(len(pares) == 3 and pares[0][0] == "¿Qué es la profase?" and pares[1][1] == "En las células somáticas" and pares[2][0] == "¿Qué es el huso mitótico?", "lee tarjetas de la IA")
def nota(a, t):
    if t <= 0: return "No hubo tarjetas en este simulacro."
    pct = int(100 * a / t + 0.5)
    return f"Sacaste {a} de {t} ({pct} %)."
ok(nota(9, 10).startswith("Sacaste 9 de 10 (90 %)") and nota(7, 10) == "Sacaste 7 de 10 (70 %).", "nota del simulacro")

print("espejo11:", "TODO BIEN" if fallos == 0 else f"{fallos} FALLOS")
sys.exit(1 if fallos else 0)
