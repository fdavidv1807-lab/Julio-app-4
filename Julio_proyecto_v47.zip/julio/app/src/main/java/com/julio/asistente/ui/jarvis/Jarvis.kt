package com.julio.asistente.ui.jarvis

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import com.julio.asistente.animacion.EventoCapa
import com.julio.asistente.animacion.JulioEstado
import com.julio.asistente.animacion.Principal
import com.julio.asistente.ui.hud.HudColores
import com.julio.asistente.ui.hud.HudLogica
import com.julio.asistente.ui.hud.HudOrbe
import com.julio.asistente.ui.hud.HudPanel
import com.julio.asistente.ui.hud.esquinas
import com.julio.asistente.ui.hud.marco
import com.julio.asistente.ui.hud.rememberAlerta
import com.julio.asistente.ui.screens.AlarmasScreen
import com.julio.asistente.ui.screens.ConfiguracionPanel
import com.julio.asistente.ui.screens.EnfoqueScreen
import com.julio.asistente.ui.screens.EstudioScreen
import com.julio.asistente.ui.screens.HorarioScreen
import com.julio.asistente.ui.screens.SECCIONES_CONFIGURACION
import com.julio.asistente.ui.screens.TareasScreen
import com.julio.asistente.ui.screens.VozScreen
import com.julio.asistente.voz.VozViewModel

/**
 * Interfaz holográfica (v47, tipo Jarvis). Una sola pieza para los dos modos:
 *  - Cuerpo (escritorio): normalmente solo Julio; con «modo manual» o 4 toques salen las dos burbujas, MI HORARIO (izquierda) y
 *    CONFIGURACIÓN (derecha), desde el interior de Julio. Todo lo demás (paneles de estado, hora, onda) se esconde.
 *  - Diario: Julio con las dos burbujas siempre a la vista, más el botón CONSOLA (hablar, escribir, conversación).
 * Al elegir una burbuja, esa burbuja desaparece y se convierte en un MENÚ EN CUARTO DE CÍRCULO, dividido en sectores, que se gira
 * con el dedo. Julio se desplaza hacia el lado de la burbuja que NO se eligió. La última opción es «Salir del menú»: todo se
 * esconde y Julio vuelve solo, al centro.
 */

private val ITEMS_MI_DIA = listOf("Horario", "Tareas", "Estudio", "Alarmas", "Enfoque")
private const val SALIR = "Salir del menú"
private const val PANEL_CONSOLA = "Consola"
private val MONO = FontFamily.Monospace

// ---------------------------------------------------------------------------------------------------------------------
// Elección del modo (solo la primera vez, permanente)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun PantallaElegirModo(alElegir: (ModoApp.Modo) -> Unit) {
    var pendiente by remember { mutableStateOf<ModoApp.Modo?>(null) }
    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Canvas(Modifier.fillMaxSize()) { esquinas(HudColores.Cian) }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        ) {
            TituloJulio(HudColores.Cian)
            Text("¿QUÉ SERÁ ESTE TELÉFONO?", color = HudColores.Blanco, fontSize = 14.sp, fontFamily = MONO, letterSpacing = 3.sp, textAlign = TextAlign.Center)
            HudPanel("ESCRITORIO", HudColores.Cian, Modifier.clickable { pendiente = ModoApp.Modo.ESCRITORIO }) {
                Text(
                    "El Cuerpo de Julio: fijo en tu escritorio, siempre enchufado. Escucha «Julio» y te lee los avisos.",
                    color = HudColores.Blanco, fontSize = 13.sp,
                )
            }
            HudPanel("DIARIO", HudColores.Turquesa, Modifier.clickable { pendiente = ModoApp.Modo.DIARIO }) {
                Text("El teléfono que llevas contigo todos los días.", color = HudColores.Blanco, fontSize = 13.sp)
            }
            Text(
                "La elección es PERMANENTE. Para cambiarla hay que desinstalar Julio y volver a instalarlo.",
                color = HudColores.Ambar, fontSize = 12.sp, fontFamily = MONO, textAlign = TextAlign.Center,
            )
        }
    }
    val m = pendiente
    if (m != null) {
        AlertDialog(
            onDismissRequest = { pendiente = null },
            title = { Text(if (m == ModoApp.Modo.ESCRITORIO) "¿Modo escritorio?" else "¿Modo diario?") },
            text = { Text("Es permanente: no se puede cambiar desde la app. Solo desinstalando Julio y volviéndolo a instalar.") },
            confirmButton = { Button(onClick = { pendiente = null; alElegir(m) }) { Text("Sí, elegir") } },
            dismissButton = { TextButton(onClick = { pendiente = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun TituloJulio(tono: Color) {
    Text(
        "J.U.L.I.O.",
        style = TextStyle(
            color = HudColores.Blanco,
            fontSize = 26.sp,
            fontWeight = FontWeight.Light,
            fontFamily = MONO,
            letterSpacing = 6.sp,
            shadow = Shadow(tono.copy(alpha = 0.8f), Offset.Zero, 18f),
        ),
    )
}

// ---------------------------------------------------------------------------------------------------------------------
// Teléfono de diario
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun InterfazDiario(vm: VozViewModel) {
    val principal by JulioEstado.principal.collectAsStateWithLifecycle()
    val capa by JulioEstado.capa.collectAsStateWithLifecycle()
    val orbeColor by vm.orbeColor.collectAsStateWithLifecycle()
    var vistaN by rememberSaveable { mutableStateOf(Vista.MANUAL.name) }
    var panel by rememberSaveable { mutableStateOf<String?>(null) }
    val vista = Vista.valueOf(vistaN)

    // «Atrás» cierra el panel, luego el abanico; en la pantalla principal deja salir de la app como siempre.
    BackHandler(enabled = panel != null || vista != Vista.MANUAL) {
        val (v, abierto) = JarvisLogica.atras(vista, panel != null)
        vistaN = (if (v == Vista.JULIO) Vista.MANUAL else v).name
        if (!abierto) panel = null
    }

    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        JarvisShell(
            vm = vm,
            principal = principal,
            capa = capa,
            orbeColor = orbeColor,
            vista = vista,
            panel = panel,
            alCambiarVista = { vistaN = it.name },
            alAbrirPanel = { panel = it },
            permanente = true,
        )
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// La pieza principal
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun JarvisShell(
    vm: VozViewModel,
    principal: Principal,
    capa: EventoCapa,
    orbeColor: Boolean,
    vista: Vista,
    panel: String?,
    alCambiarVista: (Vista) -> Unit,
    alAbrirPanel: (String?) -> Unit,
    permanente: Boolean,
    modifier: Modifier = Modifier,
) {
    val alerta = rememberAlerta(capa)
    val tono = HudColores.deTono(HudLogica.tono(principal, alerta))
    val lado = JarvisLogica.ladoJulio(vista)
    val suave = tween<Float>(700, easing = FastOutSlowInEasing)

    BoxWithConstraints(modifier.fillMaxSize()) {
        // «maxWidth» y «maxHeight» solo se pueden leer aquí (lección de la v44): se copian antes de usarlos en cajas anidadas.
        val ancho = maxWidth
        val alto = maxHeight
        val base = minOf(ancho.value, alto.value * 1.1f)
        val cyBase = if (permanente) 0.40f else 0.5f

        Canvas(Modifier.fillMaxSize()) { esquinas(tono) }

        // --- Julio: se desplaza y se achica ---
        val cxJ by animateFloatAsState(
            when (lado) { LadoJulio.CENTRO -> 0.5f; LadoJulio.IZQUIERDA -> 0.17f; LadoJulio.DERECHA -> 0.83f },
            suave, label = "cxJulio",
        )
        val cyJ by animateFloatAsState(if (lado == LadoJulio.CENTRO) cyBase else 0.5f, suave, label = "cyJulio")
        val diam by animateDpAsState(
            (base * (if (lado == LadoJulio.CENTRO) 0.36f else 0.28f)).dp,
            tween(700, easing = FastOutSlowInEasing), label = "diamJulio",
        )
        val toque: () -> Unit = {
            if (vista == Vista.MANUAL && !permanente) alCambiarVista(Vista.JULIO)
            else if (vista == Vista.MI_DIA || vista == Vista.CONFIG) alCambiarVista(Vista.MANUAL)
        }
        Box(Modifier.offset(x = ancho * cxJ - diam / 2, y = alto * cyJ - diam / 2).size(diam)) {
            HudOrbe(
                vm = vm,
                principal = principal,
                capa = capa,
                orbeColor = orbeColor,
                alToque = { vm.interrumpir(); toque() },
                modifier = Modifier.fillMaxSize(),
            )
        }

        // --- Título, estado y (en el diario) el botón de la consola, bajo Julio cuando está al centro ---
        val aCentro by animateFloatAsState(if (lado == LadoJulio.CENTRO) 1f else 0f, tween(400), label = "aCentro")
        if (aCentro > 0.01f) {
            Column(
                Modifier.offset(y = alto * cyJ + diam / 2 + 6.dp).fillMaxWidth().alpha(aCentro),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                TituloJulio(tono)
                Text(HudLogica.etiqueta(principal, alerta), color = tono, fontSize = 12.sp, fontFamily = MONO, letterSpacing = 4.sp)
                if (permanente) {
                    Spacer(Modifier.height(10.dp))
                    BotonHolo("CONSOLA", tono, Modifier.width(150.dp), enabled = vista == Vista.MANUAL) { alAbrirPanel(PANEL_CONSOLA) }
                }
            }
        }

        // --- Las dos burbujas: salen del interior de Julio; la elegida desaparece (el menú la reemplaza) y la otra se apaga ---
        var abrio by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { abrio = true }
        val dBurbuja = minOf(ancho.value * 0.27f, 108f).dp
        BurbujaAnimada(
            texto = "MI HORARIO", color = tono, ancho = ancho, alto = alto, diametro = dBurbuja,
            cxFinal = 0.17f, cy = cyBase, abrio = abrio,
            estado = when (vista) { Vista.MANUAL -> 1; Vista.MI_DIA -> 2; Vista.CONFIG -> 3; Vista.JULIO -> 0 },
            enabled = vista == Vista.MANUAL,
        ) { alCambiarVista(Vista.MI_DIA) }
        BurbujaAnimada(
            texto = "CONFIGURACIÓN", color = tono, ancho = ancho, alto = alto, diametro = dBurbuja,
            cxFinal = 0.83f, cy = cyBase, abrio = abrio,
            estado = when (vista) { Vista.MANUAL -> 1; Vista.CONFIG -> 2; Vista.MI_DIA -> 3; Vista.JULIO -> 0 },
            enabled = vista == Vista.MANUAL,
        ) { alCambiarVista(Vista.CONFIG) }

        // --- Menús en cuarto de círculo (cada uno aparece solo en su vista y mientras no haya un panel abierto) ---
        val salir = {
            alAbrirPanel(null)
            alCambiarVista(if (permanente) Vista.MANUAL else Vista.JULIO)
        }
        val alElegir: (String) -> Unit = { if (it == SALIR) salir() else alAbrirPanel(it) }
        MenuCuarto(
            titulo = "MI HORARIO",
            items = ITEMS_MI_DIA + SALIR,
            visible = vista == Vista.MI_DIA && panel == null,
            derecha = false,
            ancho = ancho, alto = alto, tono = tono,
            alElegir = alElegir,
        )
        MenuCuarto(
            titulo = "CONFIGURACIÓN",
            items = SECCIONES_CONFIGURACION + SALIR,
            visible = vista == Vista.CONFIG && panel == null,
            derecha = true,
            ancho = ancho, alto = alto, tono = tono,
            alElegir = alElegir,
        )

        // --- Panel abierto (pantalla completa, con «atrás») ---
        if (panel != null) {
            Column(
                Modifier.fillMaxSize()
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.98f))
                    .pointerInput(Unit) { detectTapGestures(onTap = { }) },
            ) {
                Row(Modifier.fillMaxWidth().drawBehind { marco(tono) }.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { alAbrirPanel(null) }) {
                        Text("‹ ATRÁS", color = tono, fontFamily = MONO, fontSize = 13.sp, letterSpacing = 2.sp)
                    }
                    Text(panel.uppercase(), color = HudColores.Blanco, fontFamily = MONO, fontSize = 13.sp, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    ContenidoPanel(vm, vista, panel) { alAbrirPanel(null) }
                }
            }
        }
    }
}

@Composable
private fun ContenidoPanel(vm: VozViewModel, vista: Vista, panel: String, cerrar: () -> Unit) {
    when {
        panel == PANEL_CONSOLA -> VozScreen(vm)
        vista == Vista.CONFIG -> ConfiguracionPanel(
            vm = vm,
            alCerrar = null,
            alProbarEjemplo = { vm.enviarTexto(it); cerrar() },
            modifier = Modifier.fillMaxSize(),
            seccionUnica = panel,
        )
        panel == "Horario" -> HorarioScreen()
        panel == "Tareas" -> TareasScreen()
        panel == "Estudio" -> EstudioScreen()
        panel == "Alarmas" -> AlarmasScreen()
        panel == "Enfoque" -> EnfoqueScreen()
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Botones y abanico
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun BotonHolo(texto: String, color: Color, modifier: Modifier, enabled: Boolean = true, alPulsar: () -> Unit) {
    Box(
        modifier.height(44.dp).drawBehind { marco(color) }.clickable(enabled = enabled, onClick = alPulsar).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            texto,
            color = HudColores.Blanco,
            fontSize = 11.sp,
            fontFamily = MONO,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Clip,
        )
    }
}

/**
 * Una burbuja del modo manual. [estado]: 0 = oculta, 1 = visible, 2 = elegida (crece con un destello y desaparece: el menú la
 * reemplaza), 3 = descartada (se encoge y se apaga). Al abrirse sale del centro (donde está Julio) hacia su lugar.
 */
@Composable
private fun BurbujaAnimada(
    texto: String,
    color: Color,
    ancho: Dp,
    alto: Dp,
    diametro: Dp,
    cxFinal: Float,
    cy: Float,
    abrio: Boolean,
    estado: Int,
    enabled: Boolean,
    alPulsar: () -> Unit,
) {
    val visible = abrio && estado == 1
    val cx by animateFloatAsState(if (abrio) cxFinal else 0.5f, tween(600, easing = FastOutSlowInEasing), label = "cxBurbuja")
    val alfa by animateFloatAsState(if (visible) 1f else 0f, tween(if (estado == 2) 500 else 450), label = "alfaBurbuja")
    val escala by animateFloatAsState(
        when {
            !abrio -> 0.2f
            estado == 2 -> 1.8f
            estado == 3 -> 0.6f
            estado == 0 -> 0.2f
            else -> 1f
        },
        tween(600, easing = FastOutSlowInEasing), label = "escalaBurbuja",
    )
    if (alfa < 0.01f) return
    Box(
        Modifier
            .offset(x = ancho * cx - diametro / 2, y = alto * cy - diametro / 2)
            .size(diametro)
            .graphicsLayer { this.alpha = alfa; scaleX = escala; scaleY = escala },
    ) {
        BurbujaHolo(texto, color, diametro, enabled, alPulsar)
    }
}

@Composable
private fun BurbujaHolo(texto: String, color: Color, diametro: Dp, enabled: Boolean, alPulsar: () -> Unit) {
    Box(
        Modifier
            .size(diametro)
            .drawBehind {
                val r = size.minDimension / 2f
                // Resplandor, fondo, borde y un segundo anillo fino (adorno).
                drawCircle(
                    Brush.radialGradient(0f to color.copy(alpha = 0.30f), 0.7f to color.copy(alpha = 0.10f), 1f to Color.Transparent, center = center, radius = r * 1.35f),
                    radius = r * 1.35f,
                )
                drawCircle(Color.Black.copy(alpha = 0.62f), radius = r)
                drawCircle(color.copy(alpha = 0.95f), radius = r, style = Stroke(1.5.dp.toPx()))
                drawCircle(color.copy(alpha = 0.35f), radius = r - 6.dp.toPx(), style = Stroke(1.dp.toPx()))
            }
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = alPulsar),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            texto,
            color = HudColores.Blanco,
            fontSize = 10.sp,
            fontFamily = MONO,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Clip,
        )
    }
}

/**
 * Menú en cuarto de círculo (la matemática está en [MenuSector]). El centro queda en la esquina de abajo del lado [derecha]
 * (o izquierda), el cuarto se divide en un sector por opción y se GIRA con el dedo (al soltar se acomoda en una opción).
 * Los toques solo se reciben dentro del cuadrado del cuarto, así que Julio y lo demás siguen tocables.
 */
@Composable
private fun MenuCuarto(
    titulo: String,
    items: List<String>,
    visible: Boolean,
    derecha: Boolean,
    ancho: Dp,
    alto: Dp,
    tono: Color,
    alElegir: (String) -> Unit,
) {
    val n = items.size
    var giro by remember(items) { mutableFloatStateOf(0f) }
    var arrastrando by remember { mutableStateOf(false) }
    val giroAnim by animateFloatAsState(giro, if (arrastrando) snap() else tween(220), label = "giroMenu")
    val giroAct by rememberUpdatedState(giro)
    val derechaAct by rememberUpdatedState(derecha)
    val p by animateFloatAsState(if (visible) 1f else 0f, tween(500, delayMillis = if (visible) 250 else 0), label = "menuCuarto")
    if (p < 0.01f) return

    val radio = MenuSector.radioExterior(ancho.value, alto.value)
    val radioIn = MenuSector.radioInterior(radio)

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .align(if (derecha) Alignment.BottomEnd else Alignment.BottomStart)
                .size(radio.dp)
                .graphicsLayer {
                    alpha = p
                    scaleX = 0.55f + 0.45f * p
                    scaleY = 0.55f + 0.45f * p
                    transformOrigin = TransformOrigin(if (derecha) 1f else 0f, 1f)
                }
                // Tocar una opción.
                .pointerInput(visible, n) {
                    detectTapGestures { pos ->
                        if (!visible) return@detectTapGestures
                        val lado = size.width.toFloat()
                        val dx = if (derechaAct) lado - pos.x else pos.x
                        val dy = lado - pos.y
                        val r = hypot(dx, dy)
                        if (r < lado * radioIn / radio || r > lado) return@detectTapGestures
                        val opcion = MenuSector.opcionEn(MenuSector.anguloDePunto(dx, dy), giroAct, n)
                        if (opcion != null) alElegir(items[opcion])
                    }
                }
                // Girarlo con el dedo.
                .pointerInput(visible, n) {
                    if (!visible) return@pointerInput
                    val lado = size.width.toFloat()
                    fun angulo(pos: Offset): Float {
                        val dx = max(if (derechaAct) lado - pos.x else pos.x, 0.001f)
                        val dy = max(lado - pos.y, 0.001f)
                        return MenuSector.anguloDePunto(dx, dy)
                    }
                    detectDragGestures(
                        onDragStart = { arrastrando = true },
                        onDragEnd = { arrastrando = false; giro = MenuSector.acomodar(giro, n) },
                        onDragCancel = { arrastrando = false; giro = MenuSector.acomodar(giro, n) },
                    ) { cambio, _ ->
                        cambio.consume()
                        giro = MenuSector.limitar(giro + (angulo(cambio.position) - angulo(cambio.previousPosition)), n)
                    }
                },
        ) {
            val mostrado = if (arrastrando) giro else giroAnim
            Canvas(Modifier.fillMaxSize()) { dibujarSectores(items, mostrado, derecha, tono) }

            // Los textos, uno por sector, girados a lo largo del radio.
            val rMedio = (radio + radioIn) / 2f
            val anchoTexto = (radio - radioIn) * 0.86f
            val altoTexto = 24f
            items.forEachIndexed { i, texto ->
                if (!MenuSector.textoVisible(i, mostrado)) return@forEachIndexed
                val phi = MenuSector.anguloCentro(i, mostrado)
                val rad = Math.toRadians(phi.toDouble())
                val cxp = if (derecha) radio - rMedio * cos(rad).toFloat() else rMedio * cos(rad).toFloat()
                val cyp = radio - rMedio * sin(rad).toFloat()
                Box(
                    Modifier
                        .offset(x = (cxp - anchoTexto / 2f).dp, y = (cyp - altoTexto / 2f).dp)
                        .size(anchoTexto.dp, altoTexto.dp)
                        .graphicsLayer { rotationZ = if (derecha) phi else -phi },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        texto.uppercase(),
                        color = if (texto == SALIR) HudColores.Ambar else HudColores.Blanco,
                        fontSize = 11.sp,
                        fontFamily = MONO,
                        letterSpacing = 1.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            // Título en el hueco de la esquina.
            Text(
                titulo,
                color = tono,
                fontSize = 9.sp,
                fontFamily = MONO,
                letterSpacing = 1.sp,
                modifier = Modifier.align(if (derecha) Alignment.BottomEnd else Alignment.BottomStart).padding(10.dp),
            )
        }
    }
}

/** Dibuja los sectores del cuarto (fondo, borde y arcos de adorno). El centro está en la esquina de abajo del lado elegido. */
private fun DrawScope.dibujarSectores(items: List<String>, giro: Float, derecha: Boolean, tono: Color) {
    val lado = size.width
    val rOut = lado
    val rIn = MenuSector.radioInterior(rOut)
    val pivote = Offset(if (derecha) lado else 0f, lado)
    val hueco = 0.8f // grados de separación entre sectores
    items.forEachIndexed { i, texto ->
        val alto = 90f - i * MenuSector.PASO + giro
        val bajo = alto - MenuSector.PASO
        if (alto <= 0f || bajo >= 90f) return@forEachIndexed
        val lo = max(bajo, 0f) + hueco
        val hi = min(alto, 90f) - hueco
        if (hi <= lo) return@forEachIndexed
        val color = if (texto == SALIR) HudColores.Ambar else tono
        val ruta = rutaSector(pivote, rIn, rOut, lo, hi, derecha)
        drawPath(ruta, color.copy(alpha = 0.10f))
        drawPath(ruta, Color.Black.copy(alpha = 0.40f))
        drawPath(ruta, color.copy(alpha = 0.70f), style = Stroke(1.dp.toPx()))
    }
    // Arcos de adorno (no son datos).
    for (k in 0 until 3) {
        val r = rIn * 0.55f + k * rIn * 0.12f
        val inicio = if (derecha) -180f else -90f
        drawArc(
            color = tono.copy(alpha = 0.25f - 0.06f * k),
            startAngle = inicio,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(pivote.x - r, pivote.y - r),
            size = Size(r * 2f, r * 2f),
            style = Stroke(1.dp.toPx()),
        )
    }
}

/** Un sector anular entre los ángulos φ [lo] y [hi] (φ = 0 es el borde de abajo, φ = 90 el borde del lado). */
private fun rutaSector(pivote: Offset, rIn: Float, rOut: Float, lo: Float, hi: Float, derecha: Boolean): Path {
    val inicio = if (derecha) lo - 180f else -hi
    val barrido = hi - lo
    val exterior = Rect(pivote.x - rOut, pivote.y - rOut, pivote.x + rOut, pivote.y + rOut)
    val interior = Rect(pivote.x - rIn, pivote.y - rIn, pivote.x + rIn, pivote.y + rIn)
    return Path().apply {
        arcTo(exterior, inicio, barrido, true)
        arcTo(interior, inicio + barrido, -barrido, false)
        close()
    }
}
