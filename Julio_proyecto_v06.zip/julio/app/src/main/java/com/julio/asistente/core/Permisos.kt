package com.julio.asistente.core

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

object Permisos {
    /** Android 13+ exige aceptar el permiso de notificaciones; antes de eso siempre está concedido. */
    fun notificaciones(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    /** Android 14+ puede revocar la pantalla completa de alarma; antes de eso siempre está concedida. */
    fun pantallaCompleta(c: Context): Boolean =
        Build.VERSION.SDK_INT < 34 ||
            c.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    fun ajustesNotificaciones(c: Context): Intent =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)

    fun ajustesPantallaCompleta(c: Context): Intent =
        if (Build.VERSION.SDK_INT >= 34) {
            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${c.packageName}"))
        } else {
            ajustesNotificaciones(c)
        }
}
