package com.julio.asistente.alarmas

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.julio.asistente.MainActivity
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.data.local.JulioDatabase
import java.time.ZonedDateTime

/**
 * Programa alarmas reales en el sistema con AlarmManager.setAlarmClock():
 * suenan con la app cerrada, atraviesan el modo Doze y muestran el icono de alarma en la barra.
 */
object AlarmaProgramador {
    const val ACCION_SONAR = "com.julio.asistente.ALARMA_SONAR"
    const val EXTRA_ID = "alarma_id"
    const val EXTRA_POSPUESTA = "alarma_pospuesta"
    private const val OFFSET_POSPUESTA = 1_000_000

    private fun alarmManager(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pendiente(c: Context, id: Long, pospuesta: Boolean, flags: Int): PendingIntent? {
        val intent = Intent(c, AlarmaReceiver::class.java).apply {
            action = ACCION_SONAR
            data = Uri.parse("julio://alarma/$id/${if (pospuesta) "p" else "n"}")
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_POSPUESTA, pospuesta)
        }
        val codigo = id.toInt() + if (pospuesta) OFFSET_POSPUESTA else 0
        return PendingIntent.getBroadcast(c, codigo, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun abrirApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    /**
     * Programa la próxima vez que suena [a]. Devuelve el momento programado,
     * o null si no se programó nada (alarma desactivada, fecha pasada o error del sistema).
     */
    fun programar(c: Context, a: AlarmaEntity, ahora: ZonedDateTime = ZonedDateTime.now()): ZonedDateTime? {
        if (!a.activa) {
            cancelar(c, a.id)
            return null
        }
        val proxima = CalculoAlarma.proxima(a, ahora) ?: return null
        return try {
            val operacion = pendiente(c, a.id, false, PendingIntent.FLAG_UPDATE_CURRENT) ?: return null
            val info = AlarmManager.AlarmClockInfo(proxima.toInstant().toEpochMilli(), abrirApp(c))
            alarmManager(c).setAlarmClock(info, operacion)
            proxima
        } catch (e: Exception) {
            null
        }
    }

    fun posponer(c: Context, id: Long, minutos: Int): Boolean {
        if (id < 0) return false
        return try {
            val operacion = pendiente(c, id, true, PendingIntent.FLAG_UPDATE_CURRENT) ?: return false
            val momento = System.currentTimeMillis() + minutos * 60_000L
            alarmManager(c).setAlarmClock(AlarmManager.AlarmClockInfo(momento, abrirApp(c)), operacion)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun cancelar(c: Context, id: Long) {
        for (pospuesta in listOf(false, true)) {
            pendiente(c, id, pospuesta, PendingIntent.FLAG_NO_CREATE)?.let {
                alarmManager(c).cancel(it)
                it.cancel()
            }
        }
    }

    /** Tras reiniciar el teléfono, cambiar la hora o actualizar la app, el sistema olvida las alarmas. */
    suspend fun reprogramarTodas(c: Context) {
        val dao = JulioDatabase.get(c).alarmaDao()
        dao.activas().forEach { a ->
            if (programar(c, a) == null) dao.actualizar(a.copy(activa = false))
        }
    }
}
