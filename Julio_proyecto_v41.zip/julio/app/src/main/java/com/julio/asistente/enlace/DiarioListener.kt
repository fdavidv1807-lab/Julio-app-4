package com.julio.asistente.enlace

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.julio.asistente.cuerpo.ConversorAvisos

/**
 * Teléfono de diario: ve las notificaciones nuevas (permiso «Acceso a notificaciones», que se concede en Ajustes), deja solo las
 * de las apps elegidas, quita el contenido de códigos y bancos ANTES de enviar y las manda cifradas al Cuerpo por la Wi-Fi.
 * Si el teléfono no está en el rol «diario», no hace nada.
 */
class DiarioListener : NotificationListenerService() {
    private lateinit var conversor: ConversorAvisos

    override fun onCreate() {
        super.onCreate()
        EnlaceAjustes.cargar(applicationContext)
        conversor = ConversorAvisos(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (EnlaceAjustes.rol.value != RolEnlace.DIARIO) return
            val aviso = conversor.convertir(sbn, EnlaceAjustes.permitidas.value) ?: return
            EnlaceDiario.enviar(applicationContext, aviso)
        } catch (e: Exception) {
            // Un aviso raro nunca debe tumbar el servicio.
        }
    }

    /** Samsung y otros matan estos servicios: se pide al sistema que lo vuelva a conectar. */
    override fun onListenerDisconnected() {
        try {
            NotificationListenerService.requestRebind(ComponentName(this, DiarioListener::class.java))
        } catch (e: Exception) { }
    }
}
