package com.julio.asistente.enlace

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.cuerpo.CuerpoAvisos
import com.julio.asistente.cuerpo.Origen
import com.julio.asistente.cuerpo.Sensibles
import com.julio.asistente.escritorio.EscritorioControl
import java.io.IOException
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Lado «Cuerpo de Julio»: escucha en la Wi-Fi de casa, se anuncia por NSD/mDNS («Julio-xxxxxx») y recibe avisos cifrados.
 * Solo acepta mensajes que vengan con el código de emparejamiento. Corre mientras viva [com.julio.asistente.escritorio.JulioServicio].
 */
object EnlaceCuerpo {
    @Volatile private var servidor: ServerSocket? = null
    private var nsd: NsdManager? = null
    private var registro: NsdManager.RegistrationListener? = null
    private var verificador = Verificador()
    private val horaFmt get() = SimpleDateFormat("HH:mm", Locale.getDefault())

    // Abrir y cerrar sockets se hace fuera del hilo principal, en orden (un solo hilo de control).
    private val control = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "julio-enlace-control").also { it.isDaemon = true } }

    fun iniciar(c: Context) {
        val app = c.applicationContext
        control.execute { iniciarAhora(app) }
    }

    fun detener() {
        control.execute { detenerAhora() }
    }

    /** Se llama al cambiar de rol o de código: apaga y, si corresponde, vuelve a encender. */
    fun reiniciar(c: Context) {
        val app = c.applicationContext
        control.execute {
            detenerAhora()
            if (EnlaceAjustes.rol.value == RolEnlace.CUERPO && EscritorioControl.activo.value) iniciarAhora(app)
        }
    }

    private fun iniciarAhora(c: Context) {
        if (servidor != null) return
        val app = c.applicationContext
        EnlaceAjustes.cargar(app)
        if (EnlaceAjustes.rol.value != RolEnlace.CUERPO) return
        val secreto = EnlaceAjustes.secreto()
        if (secreto == null) {
            EnlaceAjustes.ponerEstado("Falta el código de emparejamiento (Configuración > Enlace).")
            return
        }
        val clave = Protocolo.claveDe(secreto)
        val ss = abrirPuerto()
        if (ss == null) {
            EnlaceAjustes.ponerEstado("No pude abrir el puerto de la red para recibir avisos.")
            return
        }
        servidor = ss
        verificador = Verificador()
        EnlaceAjustes.ponerPuertoLocal(ss.localPort)
        anunciar(app, ss.localPort, Protocolo.idPublico(secreto))
        val hilo = Thread({ atender(ss, clave) }, "julio-enlace-cuerpo")
        hilo.isDaemon = true
        hilo.start()
        EnlaceAjustes.ponerEstado("Esperando avisos del teléfono de diario.")
    }

    private fun detenerAhora() {
        try { servidor?.close() } catch (e: IOException) { }
        servidor = null
        EnlaceAjustes.ponerPuertoLocal(0)
        try {
            val m = nsd
            val r = registro
            if (m != null && r != null) m.unregisterService(r)
        } catch (e: Exception) { }
        nsd = null
        registro = null
        CuerpoAvisos.vaciar()
    }

    private fun abrirPuerto(): ServerSocket? {
        for (puerto in listOf(Protocolo.PUERTO, 0)) {
            try {
                val s = ServerSocket()
                s.reuseAddress = true
                s.bind(InetSocketAddress(puerto))
                return s
            } catch (e: IOException) { /* se prueba el siguiente */ }
        }
        return null
    }

    private fun anunciar(app: Context, puerto: Int, id: String) {
        try {
            val info = NsdServiceInfo().apply {
                serviceName = "Julio-$id"
                serviceType = Protocolo.TIPO_SERVICIO
                port = puerto
            }
            val m = app.getSystemService(Context.NSD_SERVICE) as NsdManager
            val oyente = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, codigo: Int) {
                    EnlaceAjustes.ponerEstado("No pude anunciarme en la red (código $codigo). En el teléfono de diario escribe mi IP a mano.")
                }
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, codigo: Int) {}
            }
            m.registerService(info, NsdManager.PROTOCOL_DNS_SD, oyente)
            nsd = m
            registro = oyente
        } catch (e: Exception) {
            EnlaceAjustes.ponerEstado("No pude anunciarme en la red: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun atender(ss: ServerSocket, clave: ByteArray) {
        while (!ss.isClosed) {
            try {
                ss.accept().use { s ->
                    s.soTimeout = 5_000
                    manejar(s, clave)
                }
            } catch (e: IOException) {
                if (ss.isClosed) return
            } catch (e: Exception) {
                // Una conexión rara no tumba el servidor.
            }
        }
    }

    private fun manejar(s: Socket, clave: ByteArray) {
        val trama = Protocolo.leerTrama(s.getInputStream())
        val aviso = Protocolo.decodificar(trama, clave)
        val ack = if (aviso == null) {
            EnlaceAjustes.ponerEstado("Un teléfono sin el código correcto intentó enviar un aviso (rechazado).")
            Protocolo.ACK_NO_AUTORIZADO
        } else {
            val r = verificador.revisar(aviso, System.currentTimeMillis())
            if (r == Protocolo.ACK_OK) {
                if (CuerpoAjustes.activo.value) {
                    CuerpoAvisos.recibir(Sensibles.sanear(aviso), Origen.DIARIO)
                    EnlaceAjustes.ponerEstado("Último aviso del diario a las ${horaFmt.format(Date())}.")
                } else {
                    EnlaceAjustes.ponerEstado("Llegó un aviso del diario, pero la lectura de avisos está apagada (Configuración > Avisos del Cuerpo).")
                }
            } else if (r == Protocolo.ACK_HORA) {
                EnlaceAjustes.ponerEstado("Rechacé un aviso: la hora de los dos teléfonos difiere más de 10 minutos.")
            }
            r
        }
        s.getOutputStream().write(ack)
        s.getOutputStream().flush()
    }

    /** IP de este teléfono en la Wi-Fi (para escribirla a mano en el teléfono de diario si hace falta). */
    fun ipLocal(): String? = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { it.isUp && !it.isLoopback }
            .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { it.isSiteLocalAddress }
            ?.hostAddress
    } catch (e: Exception) {
        null
    }
}
