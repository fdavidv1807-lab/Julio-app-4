package com.julio.asistente.comandos

import com.julio.asistente.horario.Recurrencia
import java.time.LocalDate
import java.time.LocalTime

/** Lo que Julio le preguntó al usuario y está esperando que responda (conversación de varios turnos). */
sealed class Esperando {
    object TituloTarea : Esperando()
    object TituloMeta : Esperando()
    data class TipoEntrada(val texto: String) : Esperando()
    data class DatosActividad(
        val titulo: String?, val fecha: LocalDate?, val hora: LocalTime?, val recurrencia: Recurrencia,
        val diasMascara: Int = 0, val intervaloSemanas: Int = 1, val horaFin: LocalTime? = null,
    ) : Esperando()
    data class FrecuenciaActividad(val id: Long) : Esperando()
    data class DatosExamen(val materia: String?, val fecha: LocalDate?, val temas: List<String>) : Esperando()
    data class DatosAlarma(val hora: LocalTime?, val fecha: LocalDate?, val dias: Int) : Esperando()
    data class MetaParaProgreso(val porcentaje: Int?) : Esperando()
    data class PorcentajeMeta(val metaId: Long) : Esperando()
    data class ConfirmarEliminar(val elemento: Elemento, val id: Long, val nombre: String) : Esperando()
    data class ElementoParaEliminar(val elemento: Elemento) : Esperando()
    data class NuevoHorarioActividad(val id: Long) : Esperando()
    data class NuevoNombreTarea(val id: Long) : Esperando()
    data class NuevaHoraAlarma(val id: Long) : Esperando()
    data class ConfirmarEstricto(val minutos: Int) : Esperando()
    /** «Responde»: Julio preguntó qué decir y espera el mensaje dictado (caduca a los 30 s). */
    data class TextoRespuesta(val chat: String, val desde: Long) : Esperando()
    /** Julio repitió el mensaje y espera «sí» para enviarlo (caduca a los 30 s). */
    data class ConfirmarRespuesta(val chat: String, val texto: String, val desde: Long) : Esperando()
    /** «Abre…» sin decir qué app. */
    object NombreApp : Esperando()
    /** Varias apps se parecen al nombre dicho: se espera que elija una. */
    data class ElegirApp(val opciones: List<AppInfo>) : Esperando()
}
