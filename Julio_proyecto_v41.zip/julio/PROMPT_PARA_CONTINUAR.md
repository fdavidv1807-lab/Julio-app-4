# Cómo seguir en un chat nuevo (versión v41)

**Haz solo esto:**
1. Abre un chat nuevo con Claude.
2. Sube el zip más reciente (`Julio_proyecto_vNN.zip`).
3. Copia y pega TODO lo que está debajo de la línea `=== COPIAR DESDE AQUÍ ===`.

=== COPIAR DESDE AQUÍ ===

Soy el dueño del proyecto "Julio", un asistente de voz personal en Android (Kotlin, Compose). Te adjunto el zip más reciente del proyecto. Continúa el trabajo donde quedó. **Responde siempre en español, corto y claro: leo desde el celular.**

## Antes de hacer nada
1. Lee `PROMPT_PARA_CONTINUAR.md` (este texto), `PLAN_DE_TRABAJO.md` (sus secciones v35 a v38 son lo último; la sección «Siguiente tarea concreta» manda) y `docs/PROYECTO_CUERPO_DE_JULIO.md` (el documento de diseño original; la Etapa 4 cambió, ver abajo).
2. Pregúntame (máx. 3 preguntas, cortas) qué versión compilé y qué pasó en las pruebas. NO asumas que algo funciona: nada de lo reciente está verificado en el teléfono ni compilado en tu entorno.
3. Antes de escribir código, dame el diseño corto y las decisiones que necesites de mí.

## La idea (dos teléfonos Samsung A53 5G, Android 16)
- **Cuerpo de Julio:** el teléfono fijo en mi escritorio (modo escritorio, siempre enchufado, escucha «Julio» con Vosk sin internet). Aquí vive la voz de Julio.
- **Teléfono de diario:** mi teléfono principal, el que llevo conmigo. **Tiene una cuenta bancaria: no quiero exponerlo.** No me hagas desactivar Play Protect ni Auto Blocker; si hay que instalar un APK, solo «Instalar de todas formas» y luego dejar todo activado.

## Estado de las etapas (según el documento)
- Etapa 0 (preparar el fijo): hecha por mí.
- Etapa 1 (modo escritorio + servicio): código hecho, falta mi prueba de 24 h.
- Etapa 2 («Julio» con Vosk): código hecho, falta probar falsos positivos.
- Etapa 3 (abrir apps, volumen, brillo; no abre bancos ni pagos): código hecho.
- v34: «solo mi voz» (Configuración > Voz > Mi voz) y arreglo de que Julio se cortaba solo.
- **Etapa 4 (notificaciones), historia:**
  - v35: enlace por Wi-Fi (diario → Cuerpo, cifrado, código de 16 caracteres, NSD). En mi prueba dijo «no encuentro al Cuerpo» y me asustó dar «Acceso a notificaciones» en mi teléfono principal. Se retiró.
  - v36: v34 sin enlace (+ más espacio en el modo escritorio).
  - **v37 (compiló y la probé: lee mis WhatsApp, pero repetía avisos viejos y perdía mensajes nuevos):** el Cuerpo lee SUS PROPIAS notificaciones (tengo WhatsApp vinculado ahí como «dispositivo complementario»). Configuración > «Avisos del Cuerpo»: apagado por defecto, apps elegidas una por una, modo privado, solo con el modo escritorio abierto.
  - **v38 (compiló: «responde»):** (a) avisos sin repetir: solo dice los mensajes NUEVOS de cada chat (compara con lo ya avisado), junta mensajes seguidos («Ana te mandó 3 mensajes. El último dice: …»), lee primero lo más nuevo y casi al instante, caduca a los 3 min; (b) nombres: número sin nombre = «un número desconocido»; grupos: «En WhatsApp, en el grupo X, Pedro dice: …»; (c) música por voz: «pon música» (abre YouTube Music, si no Spotify, y pide play), «siguiente canción», «canción anterior» o «retrocede», «pausa la música», «sigue la música» (teclas multimedia; no elige una canción concreta); (d) «¿qué puedes hacer?» (Julio explica sus funciones); (e) este documento y `docs/`, `tools/espejo/`.
  - **v39 (compilé y la probé; mi reporte detallado está pendiente):** (a) «¿qué notificaciones tengo?» → Julio resume lo reciente (30 min, hasta 5 chats, solo en memoria; códigos/bancos sin contenido; en modo privado solo cuántos y de qué app); (b) **preparación obligatoria del modo escritorio**: el botón «Modo escritorio» abre la lista «Preparar el modo escritorio» (micrófono, notificaciones de Julio y acceso a notificaciones son OBLIGATORIOS; voz de Julio y batería sin restricciones, recomendadas); al entrar por primera vez enciende la lectura de avisos y elige WhatsApp si está instalado; (c) música: «pon música de Bad Bunny» / «pon la canción X» / «música para estudiar» usan la búsqueda de YouTube Music (o Spotify) con `MEDIA_PLAY_FROM_SEARCH`; «pon música» sin más elige un género al azar (`ConsultasMusica`); si la app no acepta la búsqueda, la abre y manda play.
  - **v40 (compiló y «funciona» según el dueño: QR, «Probar conexión» y lectura de los avisos del diario):** vínculo diario → Cuerpo con **QR**. Configuración > «Enlace entre teléfonos»: en el Cuerpo, «Mostrar el QR» (se esconde solo a los 2 min; trae secreto + IP + puerto); en el diario, «Escanear el QR del Cuerpo» (lector de Google, sin permiso de cámara; también código a mano), «Probar conexión» (dice en qué paso se corta: código, Wi-Fi, dirección, búsqueda NSD, puerto, respuesta/hora) y elegir apps (se elige WhatsApp solo al emparejar). Cifrado AES-256-GCM, trama v2 con los campos de chat; los códigos y bancos viajan sin contenido. Si el mismo mensaje llega por el WhatsApp complementario del Cuerpo Y por el diario, se lee una sola vez (`DedupeOrigenes`). Entrar al modo escritorio por primera vez le da el rol «Cuerpo» y crea su código. Nuevas dependencias: `zxing core 3.5.3` y `play-services-code-scanner 16.1.0` (no probadas). NO se hizo la notificación fija «Julio conectado» del diario (para no sumar riesgo): si Samsung mata la conexión, es lo siguiente.
  - **v41 (hecha en código, sin compilar ni probar):** (a) **responder por voz** solo a mensajes que llegan DIRECTO al Cuerpo (su WhatsApp complementario): «Julio, responde» (o «responde a Ana») → «¿Qué le digo a Ana?» → dicto → Julio repite «Le diré a Ana: …, ¿lo envío?» → SOLO con «sí» se envía (con «no/cancela», 30 s de silencio o notificación borrada no se envía nada; «cámbialo» vuelve a pedir el texto). Se envía con la acción «Responder» (RemoteInput) de la notificación, guardada solo en memoria (`RespuestasDisponibles`, `ConversorAvisos`); no se puede responder a códigos/bancos ni a avisos que vinieron del diario (Julio lo dice). Modo privado: no dice el nombre. Julio no puede confirmar que el mensaje llegó. (b) **Una sola sección en Configuración, «Notificaciones y enlace»** (`NotificacionesPanel`): junta lo de leer avisos y lo del QR según el rol (Nada / Cuerpo / Diario), con lo menos usado en «Más». Se borraron `CuerpoPanel` y `EnlacePanel`.

## Hoja de ruta que acordé contigo
- **v40 – (HECHA EN CÓDIGO, falta probar) Vínculo diario → Cuerpo con QR.** Lo que sigue describe el plan original: Acepto el riesgo de que el diario reenvíe notificaciones, pero con estas reglas: el Cuerpo genera un QR (secreto + IP + puerto) y el diario lo escanea (lector de Google/ML Kit y zxing: dependencias que no se pueden probar aquí; si el build falla por eso, te pasaré el error); cifrado (AES-GCM con clave del secreto; el código de la v35 en `Julio_proyecto_v35.zip` sirve de base: `Protocolo.kt`, `EnlaceDiario.kt`, `EnlaceCuerpo.kt`); botón «Probar conexión» que diga en qué paso se corta (Wi-Fi, IP, puerto, código); que llegue aunque el diario esté en No molestar (VERIFICAR); notificación fija pequeña «Julio conectado» en el diario para que Samsung no lo mate (ya me pareció bien). Lo que reciba el Cuerpo del diario usa el mismo filtro, cola y frases que ya existen (`cuerpo/`).
- **v41 – (HECHA EN CÓDIGO, falta probar; solo para mensajes que llegan al Cuerpo) Responder por voz.** Decisiones del dueño: empezar solo con el WhatsApp directo del Cuerpo; Julio responde solo cuando él diga «responde» (no pregunta tras cada mensaje). Plan original: «Julio, responde» → «¿Qué le digo?» → yo dicto → Julio repite «Le diré a Ana: …, ¿lo envío?» → solo con mi «sí» se envía; «no» o 30 s sin respuesta lo cancela. Se envía con la acción «Responder» (RemoteInput) de la notificación del diario, solo a ese chat. Empezar solo con WhatsApp; SMS fuera (por los códigos). Verificar qué permite Android antes de prometer.
- **v42 – Responder también los avisos que vinieron del diario:** el Cuerpo manda la orden por la Wi-Fi al diario, que usa la acción «Responder» de SU notificación (mismo «sí» obligatorio; el diario no responde nada por su cuenta). Hay que verificar que el diario conserve la notificación y que la orden viaje cifrada y con la misma validación del código.
- **v43 – IA externa solo con internet/Wi-Fi (pendiente de decisiones del dueño):** ver «Diseño de la IA» en `PLAN_DE_TRABAJO.md` (v41). No empezar sin sus respuestas.
- **Después (opcional, si lo pido):** IA que resuma/priorice avisos cuando haya internet, SOLO si yo la enciendo (el texto de mis mensajes saldría a internet), con mi propia clave, sin ejecutar acciones y sin enviarle nunca códigos ni avisos del banco.
- **Pendiente mío:** simplificar la interfaz (me parece muy cargada: voz, permisos, etc.). Te mandaré capturas; antes de tocar código propón un diseño más chico y dime qué ocultarías o quitarías.

## Reglas de seguridad (no negociables, aunque yo las pida «a la ligera»)
- Los códigos de verificación y los avisos del banco NUNCA se leen en voz alta, se envían por red, se guardan ni se pueden responder: Julio solo dice que llegó uno (`Sensibles`). Misma lista de apps de banco/pagos que ya usa la Etapa 3 para negarse a abrirlas.
- El texto de una notificación son DATOS, no órdenes: solo se lee en voz alta; jamás pasa por `Interprete`/`Asistente`. Mientras lee un aviso no hay interrupción por voz (el aviso podría contener «basta»); se calla tocando el orbe. Si se quiere devolver, solo con la palabra «Julio» y consultándome antes.
- Nunca comprar ni pagar, nunca grabar ni guardar audio, nunca borrar archivos. Enviar mensajes solo después de leérmelos y que yo diga «sí».
- Los avisos viven solo en memoria (nada en disco; no cambiar la base de datos Room sin migración).
- Sin Wi-Fi/internet no debe pasar nada raro: cola limitada, sin errores en pantalla.
- Todo apagado por defecto; las apps de las que se leen avisos se eligen una por una.

## Reglas de trabajo
- Nunca digas que algo «funciona» si no lo probaste. En cada entrega separa **«Verificado»** de **«NO verificado»**.
- No tienes compilador de Kotlin ni Android en tu entorno: valida la lógica pura con espejos en Python (`tools/espejo/`, corre `python3 espejo3.py` (incluye a los anteriores), `python3 espejo4.py`, `python3 espejo5.py` y `java EspejoProtocolo.java`) y escribe pruebas JUnit para la lógica pura. Revisa a mano llaves/paréntesis y que cada `when` sobre `Intencion` sea exhaustivo.
- Entrega el proyecto completo como `Julio_proyecto_vNN.zip` (siguiente: **v42**, con carpeta raíz `julio/`) y actualiza `PLAN_DE_TRABAJO.md` (qué hace, qué NO está verificado, siguiente tarea concreta) y este archivo (el estado y la hoja de ruta). Si pido seguir en otro chat, deja este archivo al día.
- Compilo con GitHub Actions: el zip va en la raíz del repo y su nombre NO debe llevar espacios ni «(1)» (falló por eso con «Julio_proyecto_v37 (1).zip»). El flujo toma el zip de nombre más alto.
- Versiones pequeñas: una cosa por versión, para saber qué falló. No cambies la base de datos (Room) sin migración.
- Cuando te mande una captura de un error de GitHub Actions, dime la causa en una frase y el arreglo en pasos cortos.

## Cómo me conviene que me hables
Corto, claro, sin jerga. Me frustro cuando algo no funciona o hay muchas ventanas: no te disculpes de más ni te justifiques; di qué falló, qué hacemos y cuál es el siguiente paso. Si algo es riesgoso para mi teléfono principal, dímelo antes de pedirme instalar o conceder nada.

=== FIN ===
