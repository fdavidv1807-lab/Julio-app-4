package com.julio.asistente.comandos

import kotlin.random.Random

/**
 * Respuestas especiales de Julio. Sin pantalla ni opciones: solo se activan cuando lo que dices NO es una orden que
 * Julio entienda (así no estorban a ninguna función) y suenan con su voz como cualquier respuesta.
 *  - «Háblame de Dios», «dame un versículo»  -> un versículo con su cita.
 *  - Algo grave sobre tu vida                -> Julio habla en serio y te pide buscar a una persona o emergencias.
 * Los versículos están parafraseados con palabras sencillas (no son el texto de una versión) y las citas van escritas
 * con palabras para que la voz las lea bien.
 */
object HuevosDePascua {
    enum class Tipo { CRISIS, DIOS }

    private val CRISIS = Regex(
        "\\b(quiero morir|quiero morirme|me quiero morir|no quiero vivir|ya no quiero vivir|quitarme la vida|matarme|" +
            "suicid\\w*|hacerme dano|lastimarme|acabar con mi vida|mejor muerto|mejor muerta)\\b",
    )
    private val DIOS = Regex(
        "\\b(hablame de dios|habla de dios|hablame sobre dios|dime algo de dios|cuentame de dios|" +
            "una palabra de dios|dame una palabra de dios|dame un versiculo|dime un versiculo|un versiculo|versiculo biblico)\\b",
    )

    /** ¿Qué tipo de frase es? null = no es de las especiales. */
    fun clasificar(texto: String): Tipo? {
        val n = Texto.normalizar(texto)
        if (n.isBlank()) return null
        if (CRISIS.containsMatchIn(n)) return Tipo.CRISIS
        if (DIOS.containsMatchIn(n)) return Tipo.DIOS
        return null
    }

    /** Solo lo grave: se revisa antes que cualquier otra cosa. */
    fun crisis(texto: String): String? = if (clasificar(texto) == Tipo.CRISIS) MENSAJE_CRISIS else null

    fun responder(texto: String, azar: Random = Random.Default): String? =
        when (clasificar(texto)) {
            Tipo.CRISIS -> MENSAJE_CRISIS
            Tipo.DIOS -> versiculo(azar)
            null -> null
        }

    private var ultimo = -1

    /** Un versículo al azar, sin repetir el mismo dos veces seguidas. */
    @Synchronized
    fun versiculo(azar: Random): String {
        var i = azar.nextInt(VERSICULOS.size)
        if (i == ultimo) i = (i + 1) % VERSICULOS.size
        ultimo = i
        val (texto, cita) = VERSICULOS[i]
        return INTROS[azar.nextInt(INTROS.size)] + texto + " " + cita + "."
    }

    const val MENSAJE_CRISIS =
        "Oye, esto es importante y te lo digo en serio. Lo que me dices me preocupa mucho. No tienes que cargar con esto tú solo. " +
            "Ahora mismo busca a una persona de confianza y dile cómo te sientes, o llama a emergencias de tu país. " +
            "Si estás en peligro, no esperes. Yo sigo aquí, pero alguien a tu lado puede ayudarte mucho más que yo."

    val INTROS: List<String> = listOf(
        "Esto es para ti hoy. ",
        "Escucha esta palabra. ",
        "Dios no se ha olvidado de ti. ",
        "Respira y escucha. ",
    )

    /** Cada par es (versículo parafraseado, cita escrita con palabras). */
    val VERSICULOS: List<Pair<String, String>> = listOf(
        "Todo lo puedo gracias a Cristo, que me da las fuerzas." to "Filipenses, cuatro, trece",
        "Sé fuerte y valiente. No tengas miedo ni te desanimes, porque el Señor tu Dios está contigo dondequiera que vayas." to "Josué, uno, nueve",
        "No temas, porque yo estoy contigo. No te angusties, porque yo soy tu Dios: te daré fuerzas y te ayudaré." to "Isaías, cuarenta y uno, diez",
        "El Señor es mi pastor, nada me falta." to "Salmo veintitrés, uno",
        "Dios es nuestro refugio y nuestra fuerza, una ayuda siempre presente en los problemas." to "Salmo cuarenta y seis, uno",
        "Confía en el Señor con todo tu corazón y no te apoyes en tu propia inteligencia. Reconócelo en todo y él enderezará tus caminos." to "Proverbios, tres, cinco y seis",
        "Yo sé los planes que tengo para ustedes, dice el Señor: planes de bienestar, para darles un futuro y una esperanza." to "Jeremías, veintinueve, once",
        "Vengan a mí los que están cansados y cargados, y yo los haré descansar." to "Mateo, once, veintiocho",
        "Dios hace que todas las cosas ayuden para bien a los que lo aman." to "Romanos, ocho, veintiocho",
        "No nos cansemos de hacer el bien, porque a su tiempo cosecharemos si no nos damos por vencidos." to "Gálatas, seis, nueve",
        "Dios no nos dio un espíritu de miedo, sino de poder, de amor y de dominio propio." to "Segunda de Timoteo, uno, siete",
        "Levanto mis ojos a los montes y me pregunto de dónde vendrá mi ayuda. Mi ayuda viene del Señor, que hizo el cielo y la tierra." to "Salmo ciento veintiuno, uno y dos",
        "Los que confían en el Señor recuperan las fuerzas: vuelan como águilas, corren sin cansarse y caminan sin fatigarse." to "Isaías, cuarenta, treinta y uno",
        "Si a alguien le falta sabiduría, que se la pida a Dios, que da a todos con generosidad." to "Santiago, uno, cinco",
        "Pon tus proyectos en manos del Señor y tus planes se cumplirán." to "Proverbios, dieciséis, tres",
        "Todo lo que hagan, háganlo de corazón, como para el Señor y no para las personas." to "Colosenses, tres, veintitrés",
        "El Señor está cerca de los que tienen el corazón roto y rescata a los que están abatidos." to "Salmo treinta y cuatro, dieciocho",
        "Pongan en manos de Dios toda su ansiedad, porque él cuida de ustedes." to "Primera de Pedro, cinco, siete",
        "La paz les dejo, mi paz les doy. No se angustien ni tengan miedo." to "Juan, catorce, veintisiete",
        "Sean fuertes y valientes, no tengan miedo, porque el Señor tu Dios va contigo y nunca te dejará ni te abandonará." to "Deuteronomio, treinta y uno, seis",
        "Tu palabra es una lámpara para mis pasos y una luz en mi camino." to "Salmo ciento diecinueve, ciento cinco",
        "La fe es la seguridad de lo que se espera y la certeza de lo que no se ve." to "Hebreos, once, uno",
        "Busquen primero el reino de Dios y lo que es justo, y todo lo demás vendrá por añadidura." to "Mateo, seis, treinta y tres",
        "El amor del Señor nunca se acaba y su compasión no tiene fin. Cada mañana se renuevan. Grande es su fidelidad." to "Lamentaciones, tres, veintidós y veintitrés",
        "Entrega tu camino al Señor, confía en él y él actuará." to "Salmo treinta y siete, cinco",
    )
}
