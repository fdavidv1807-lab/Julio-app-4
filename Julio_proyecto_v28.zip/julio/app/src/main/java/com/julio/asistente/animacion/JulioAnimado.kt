package com.julio.asistente.animacion

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp as mezclarColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.julio.asistente.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

// Un color por estado.
private val AZUL = Color(0xFF3B82F6)
private val CIAN = Color(0xFF22D3EE)
private val VIOLETA = Color(0xFF8B5CF6)
private val VERDE = Color(0xFF22C55E)
private val INDIGO = Color(0xFF3730A3)
private val AMBAR = Color(0xFFF59E0B)
private val ROJO = Color(0xFFEF4444)

// Imágenes que se usan (las 5 PNG se usan tal cual; no se pinta nada encima de ellas).
private const val IMG_ORIGINAL = 0 // boca abierta
private const val IMG_MEDIA = 1 // boca a medio abrir
private const val IMG_CERRADA = 2 // boca cerrada
private const val IMG_OJOS_CERRADA = 3 // ojos a medio cerrar, boca cerrada

private val DOS_PI = (2.0 * PI).toFloat()
private val UN_PI = PI.toFloat()

/** Sin tocar ni hablar durante este rato (con Julio en reposo y la pantalla abierta), Julio se duerme. */
private const val DORMIR_MS = 10 * 60_000L

/**
 * Calcula, cuadro por cuadro, cómo se ve Julio. No dibuja: solo deja listos los números que usa el Canvas.
 * Un solo bucle de animación, sin partículas.
 */
private class Animador {
    // ----- Lo que se dibuja -----
    var color: Color = AZUL
    var orbeEscala = 1f
    var orbeSx = 1f
    var orbeSy = 1f
    var orbeAlfa = 0.5f
    var imagen = IMG_CERRADA
    var gorilaEscala = 1f
    var dx = 0f // temblor horizontal (fracción del ancho)
    var dy = 0f // saltito (fracción del ancho; negativo = hacia arriba)

    /** Cuánto esperar para el próximo cuadro: 0 = al ritmo de la pantalla; si no, milisegundos. */
    var esperaMs = 100L

    // ----- Memoria interna -----
    private var ultimo = 0L
    private var principalPrevio: Principal? = null
    private var capaVista = -1
    private var capaTipo = Capa.NINGUNA
    private var capaInicio = 0L
    private var nivelMic = 0f
    private var nivelVoz = 0f
    private var boca = 0 // 0 cerrada, 1 media, 2 abierta
    private var palabrasVistas = 0
    private var impulsoInicio = -10_000L
    private var proximoParpadeo = 0L
    private var parpadeoHasta = 0L

    private fun intervaloParpadeo(p: Principal): Long =
        if (p == Principal.ENFOCADO) Random.nextLong(14_000L, 24_000L) else Random.nextLong(3_000L, 6_000L)

    /**
     * @param mic nivel del micrófono (0 a 1).
     * @param habla nivel real de la voz de Julio (0 a 1), o -1 si no hay dato real (voz del teléfono):
     *              entonces la boca sigue el ritmo de las palabras.
     */
    fun actualizar(
        ahora: Long, p: Principal, ev: EventoCapa,
        mic: Float, habla: Float, palabras: Int, colorPorEstado: Boolean,
    ) {
        val dt = if (ultimo == 0L) 16L else (ahora - ultimo).coerceIn(1L, 500L)
        ultimo = ahora
        val t = ahora / 1000f

        // ----- Capa (aviso / error) -----
        if (capaVista == -1) capaVista = ev.id // un aviso viejo no se vuelve a animar al abrir la pantalla
        if (ev.id != capaVista) {
            capaVista = ev.id
            capaTipo = ev.capa
            capaInicio = ahora
        }
        val capaDur = when (capaTipo) {
            Capa.AVISO -> if (p == Principal.ENFOCADO) 900L else 1400L
            Capa.ERROR -> 800L
            Capa.NINGUNA -> 0L
        }
        val capaT = ahora - capaInicio
        val capaViva = capaTipo != Capa.NINGUNA && capaT < capaDur
        val x = if (capaViva) capaT.toFloat() / capaDur.toFloat() else 1f

        // Un impulso por cada palabra (solo se usa si no hay nivel real de la voz).
        if (palabras != palabrasVistas) {
            palabrasVistas = palabras
            impulsoInicio = ahora
        }

        // ----- Estado principal -----
        var colorObjetivo: Color
        var escala: Float
        var alfa: Float
        var respira = 0f
        var sx = 1f
        var sy = 1f
        when (p) {
            Principal.REPOSO -> {
                // Azul tenue, respiración lenta (5 s).
                colorObjetivo = AZUL
                alfa = 0.55f
                val r = sin(t * DOS_PI / 5f)
                escala = 0.95f + 0.03f * r
                respira = 0.012f * r
            }
            Principal.DORMIDO -> {
                // Orbe casi apagado, brillo bajo, respiración muy lenta.
                colorObjetivo = AZUL
                alfa = 0.14f
                val r = sin(t * DOS_PI / 7f)
                escala = 0.86f + 0.01f * r
                respira = 0.006f * r
            }
            Principal.ESCUCHANDO -> {
                // Cian brillante: se agranda un poco y pulsa con el volumen de tu voz.
                colorObjetivo = CIAN
                alfa = 0.9f
                nivelMic += (mic - nivelMic) * (if (mic > nivelMic) 0.6f else 0.15f)
                escala = 1.06f + 0.16f * nivelMic
                respira = 0.008f * nivelMic
            }
            Principal.PENSANDO -> {
                // Violeta: respira más rápido y se deforma levemente.
                colorObjetivo = VIOLETA
                alfa = 0.8f
                val r = sin(t * DOS_PI / 1.1f)
                escala = 1.02f + 0.05f * r
                sx = 1f + 0.05f * sin(t * DOS_PI / 1.7f)
                sy = 1f + 0.05f * sin(t * DOS_PI / 1.3f + 1f)
                respira = 0.01f * r
            }
            Principal.HABLANDO -> {
                // Verde: pulsa con el volumen de su propia voz.
                colorObjetivo = VERDE
                alfa = 0.9f
                val objetivo = if (habla >= 0f) habla else max(0f, 1f - (ahora - impulsoInicio) / 200f)
                nivelVoz += (objetivo - nivelVoz) * (if (objetivo > nivelVoz) 0.7f else 0.35f)
                escala = 1.04f + 0.16f * nivelVoz
                respira = 0.008f * nivelVoz
            }
            Principal.ENFOCADO -> {
                // Índigo oscuro, más pequeño, firme y casi inmóvil.
                colorObjetivo = INDIGO
                alfa = 0.6f
                val r = sin(t * DOS_PI / 8f)
                escala = 0.78f + 0.004f * r
                respira = 0.003f * r
            }
        }
        if (p != Principal.ESCUCHANDO) nivelMic = 0f
        if (p != Principal.HABLANDO) nivelVoz = 0f
        if (!colorPorEstado) colorObjetivo = CIAN

        // ----- Efectos de la capa -----
        var salto = 0f
        var temblor = 0f
        if (capaViva) {
            when (capaTipo) {
                Capa.AVISO -> {
                    if (p == Principal.ENFOCADO) {
                        // En enfoque: solo un pulso suave.
                        escala += 0.05f * sin(UN_PI * x)
                        colorObjetivo = mezclarColor(colorObjetivo, AMBAR, 0.6f)
                    } else {
                        // 3 pulsos rápidos y un saltito pequeño de la imagen completa; luego se calma.
                        escala += 0.20f * abs(sin(3f * UN_PI * x)) * (1f - 0.4f * x)
                        colorObjetivo = AMBAR
                        if (capaT < 450L) salto = -0.02f * sin(UN_PI * capaT.toFloat() / 450f)
                    }
                }
                Capa.ERROR -> {
                    // Temblor corto de la imagen completa y el orbe se encoge; luego vuelve a respirar normal.
                    colorObjetivo = ROJO
                    val f = 1f - x
                    escala *= 1f - 0.30f * f * f
                    if (capaT < 450L) temblor = 0.014f * sin(capaT.toFloat() * 0.085f) * (1f - capaT.toFloat() / 450f)
                }
                Capa.NINGUNA -> {}
            }
            alfa = max(alfa, 0.75f)
        }

        // ----- Color: cambia suave, salvo al interrumpir (verde a cian al instante) -----
        val interrupcion = principalPrevio == Principal.HABLANDO && p == Principal.ESCUCHANDO
        principalPrevio = p
        color = if (interrupcion) colorObjetivo else mezclarColor(color, colorObjetivo, 1f - exp(-dt / 120f))

        // ----- Parpadeo (solo en reposo y, muy raro, en enfoque; nunca mientras habla) -----
        val puedeParpadear = p == Principal.REPOSO || p == Principal.ENFOCADO
        if (puedeParpadear) {
            if (proximoParpadeo == 0L) proximoParpadeo = ahora + intervaloParpadeo(p)
            if (ahora >= proximoParpadeo) {
                parpadeoHasta = ahora + 135L
                proximoParpadeo = ahora + intervaloParpadeo(p)
            }
        }

        // ----- Boca al hablar: según el volumen, con histéresis para que no parpadee entre imágenes -----
        if (p == Principal.HABLANDO) {
            boca = when (boca) {
                0 -> if (nivelVoz > 0.42f) 2 else if (nivelVoz > 0.14f) 1 else 0
                1 -> if (nivelVoz > 0.42f) 2 else if (nivelVoz < 0.09f) 0 else 1
                else -> if (nivelVoz < 0.09f) 0 else if (nivelVoz < 0.32f) 1 else 2
            }
        } else {
            boca = 0
        }

        imagen = when (p) {
            Principal.DORMIDO -> IMG_OJOS_CERRADA
            Principal.HABLANDO -> when (boca) {
                0 -> IMG_CERRADA
                1 -> IMG_MEDIA
                else -> IMG_ORIGINAL
            }
            else -> if (puedeParpadear && ahora < parpadeoHasta) IMG_OJOS_CERRADA else IMG_CERRADA
        }

        // ----- Resultado para dibujar -----
        orbeEscala = escala
        orbeSx = sx
        orbeSy = sy
        orbeAlfa = alfa
        gorilaEscala = 1f + respira
        dx = temblor
        dy = salto

        // ----- Batería: movimiento en vivo solo si hay actividad; en reposo casi quieto -----
        val vivo = capaViva || p == Principal.ESCUCHANDO || p == Principal.PENSANDO || p == Principal.HABLANDO
        esperaMs = when {
            vivo -> 0L
            ahora < parpadeoHasta || (puedeParpadear && proximoParpadeo - ahora < 150L) -> 33L
            p == Principal.ENFOCADO -> 150L
            p == Principal.DORMIDO -> 250L
            else -> 100L
        }
    }
}

/**
 * Julio animado: un orbe (esfera que respira y pulsa) detrás del gorila médico.
 *
 * REGLA DE ORO: las imágenes del gorila no se modifican, ni se redibujan, ni se recolorean ni se deforman.
 * Solo se cambia entre ellas, se mueve o escala la imagen COMPLETA y hay efectos detrás (el orbe).
 *
 * @param nivelMic nivel del micrófono (0 a 1) mientras escucha.
 * @param nivelHabla nivel real de la voz de Julio (0 a 1), o -1 si no hay dato real.
 * @param palabras contador de palabras dichas (respaldo para la boca con la voz del teléfono).
 * @param alToque tocar el orbe (si Julio está hablando, lo interrumpe).
 */
@Composable
fun JulioAnimado(
    principal: Principal,
    capa: EventoCapa,
    nivelMic: () -> Float,
    nivelHabla: () -> Float,
    palabras: () -> Int,
    alToque: () -> Unit,
    modifier: Modifier = Modifier,
    colorPorEstado: Boolean = true,
) {
    val original = ImageBitmap.imageResource(R.drawable.julio_original)
    val media = ImageBitmap.imageResource(R.drawable.julio_boca_media)
    val cerrada = ImageBitmap.imageResource(R.drawable.julio_boca_cerrada)
    val ojosCerrada = ImageBitmap.imageResource(R.drawable.julio_ojos_medio_boca_cerrada)
    val imagenes = remember(original, media, cerrada, ojosCerrada) { arrayOf(original, media, cerrada, ojosCerrada) }

    val animador = remember { Animador() }
    var tick by remember { mutableLongStateOf(0L) }
    var toques by remember { mutableIntStateOf(0) }

    val principalAct by rememberUpdatedState(principal)
    val capaAct by rememberUpdatedState(capa)
    val micAct by rememberUpdatedState(nivelMic)
    val hablaAct by rememberUpdatedState(nivelHabla)
    val palabrasAct by rememberUpdatedState(palabras)
    val colorAct by rememberUpdatedState(colorPorEstado)
    val toqueAct by rememberUpdatedState(alToque)

    // Pausar todo cuando la app no está visible.
    val dueno = LocalLifecycleOwner.current
    var visible by remember { mutableStateOf(dueno.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(dueno) {
        val observador = LifecycleEventObserver { _, evento ->
            if (evento == Lifecycle.Event.ON_START) visible = true
            if (evento == Lifecycle.Event.ON_STOP) visible = false
        }
        dueno.lifecycle.addObserver(observador)
        onDispose { dueno.lifecycle.removeObserver(observador) }
    }

    // Un solo bucle de animación.
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        while (isActive) {
            animador.actualizar(
                ahora = SystemClock.uptimeMillis(),
                p = principalAct,
                ev = capaAct,
                mic = micAct(),
                habla = hablaAct(),
                palabras = palabrasAct(),
                colorPorEstado = colorAct,
            )
            tick++
            if (animador.esperaMs == 0L) withFrameNanos { } else delay(animador.esperaMs)
        }
    }

    // Dormido: tras mucho rato en reposo sin que nadie hable ni toque.
    LaunchedEffect(principal, capa.id, toques, visible) {
        if (principal == Principal.REPOSO && visible) {
            delay(DORMIR_MS)
            JulioEstado.dormir()
        }
    }

    Canvas(
        modifier
            .aspectRatio(0.8f)
            .pointerInput(Unit) {
                detectTapGestures(onTap = {
                    toques++
                    JulioEstado.despertar()
                    toqueAct()
                })
            },
    ) {
        if (tick < 0L) return@Canvas // leer «tick» hace que se redibuje en cada cuadro

        val w = size.width
        val h = size.height
        val gw = w * 0.80f
        val gh = gw * 1200f / 896f
        val gx = (w - gw) / 2f
        val gy = (h - gh) / 2f
        val centro = Offset(w / 2f, gy + gh * 0.48f)

        // Orbe detrás del gorila.
        val radio = w * 0.50f * animador.orbeEscala
        val c = animador.color
        val a = animador.orbeAlfa
        withTransform({ scale(animador.orbeSx, animador.orbeSy, centro) }) {
            drawCircle(
                brush = Brush.radialGradient(
                    0f to c.copy(alpha = a),
                    0.7f to c.copy(alpha = a * 0.45f),
                    1f to Color.Transparent,
                    center = centro,
                    radius = radio,
                ),
                radius = radio,
                center = centro,
            )
            drawCircle(
                color = c.copy(alpha = a * 0.7f),
                radius = radio * 0.8f,
                center = centro,
                style = Stroke(width = 2.dp.toPx()),
            )
        }

        // Gorila: la imagen completa, sin tocarla.
        val pivote = Offset(w / 2f, gy + gh)
        withTransform({
            translate(animador.dx * w, animador.dy * w)
            scale(animador.gorilaEscala, animador.gorilaEscala, pivote)
        }) {
            drawImage(
                image = imagenes[animador.imagen],
                dstOffset = IntOffset(gx.roundToInt(), gy.roundToInt()),
                dstSize = IntSize(gw.roundToInt(), gh.roundToInt()),
                filterQuality = FilterQuality.Medium,
            )
        }
    }
}
