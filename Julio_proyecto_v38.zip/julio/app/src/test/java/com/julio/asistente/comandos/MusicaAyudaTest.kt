package com.julio.asistente.comandos

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

/** Música por voz y «¿qué puedes hacer?» (v38). Sin Android. */
class MusicaAyudaTest {
    private val hoy = LocalDate.of(2026, 11, 7)
    private val ahora = LocalTime.of(9, 0)
    private fun i(t: String) = Interprete.interpretar(t, hoy, ahora)

    @Test fun siguienteCancion() {
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Siguiente canción"))
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Cambia de música"))
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Julio, pon otra canción"))
        assertEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Salta esta canción"))
    }

    @Test fun cancionAnterior() {
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Canción anterior"))
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Retrocede la canción"))
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Retrocede"))
        assertEquals(Intencion.Musica(AccionMusica.ANTERIOR), i("Regresa a la canción anterior"))
    }

    @Test fun pausaYSigue() {
        assertEquals(Intencion.Musica(AccionMusica.PAUSAR), i("Pausa la música"))
        assertEquals(Intencion.Musica(AccionMusica.PAUSAR), i("Para la música"))
        assertEquals(Intencion.Musica(AccionMusica.SEGUIR), i("Sigue la música"))
        assertEquals(Intencion.Musica(AccionMusica.SEGUIR), i("Reanuda la canción"))
    }

    @Test fun ponMusica() {
        assertEquals(Intencion.Musica(AccionMusica.PONER), i("Pon música"))
        assertEquals(Intencion.Musica(AccionMusica.PONER), i("Reproduce música para estudiar"))
    }

    @Test fun noSeConfundeConOtrasOrdenes() {
        assertNotEquals(Intencion.Musica(AccionMusica.PAUSAR), i("Pausa el enfoque"))
        assertNotEquals(Intencion.Musica(AccionMusica.SIGUIENTE), i("Cambia de tema"))
        assertEquals(Intencion.AjustarVolumen(AccionNivel.SUBIR), i("Sube el volumen de la música"))
        assertEquals(Intencion.AbrirApp("spotify"), i("Abre Spotify"))
    }

    @Test fun queSePuedeHacer() {
        assertEquals(Intencion.Ayuda, i("¿Qué puedes hacer?"))
        assertEquals(Intencion.Ayuda, i("Julio, qué sabes hacer"))
        assertEquals(Intencion.Ayuda, i("Ayuda"))
        assertEquals(Intencion.Ayuda, i("¿Qué puedo decirte?"))
    }
}
