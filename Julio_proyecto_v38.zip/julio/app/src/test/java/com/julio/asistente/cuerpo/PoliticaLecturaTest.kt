package com.julio.asistente.cuerpo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PoliticaLecturaTest {
    private fun av(t: String, x: String, tipo: TipoAviso = TipoAviso.NORMAL, app: String = "WhatsApp") =
        Aviso("1", 0L, app, "p", t, x, tipo)

    @Test fun leeAppTituloYTexto() {
        assertEquals("WhatsApp. Ana. ¿Vamos a comer?", PoliticaLectura.frase(av("Ana", "¿Vamos a comer?"), privado = false))
    }

    @Test fun noRepiteElTituloSiElTextoYaLoTrae() {
        assertEquals("WhatsApp. Ana: hola", PoliticaLectura.frase(av("Ana", "Ana: hola"), privado = false))
    }

    @Test fun modoPrivadoSoloDiceLaApp() {
        assertEquals("Tienes un aviso de WhatsApp.", PoliticaLectura.frase(av("Ana", "secreto"), privado = true))
    }

    @Test fun losSensiblesNuncaSeLeen() {
        val c = PoliticaLectura.frase(av("123456", "123456", TipoAviso.CODIGO, "Mensajes"), privado = false)
        assertFalse(c.contains("123456"))
        assertTrue(c.contains("código de verificación"))
        val b = PoliticaLectura.frase(av("Compra", "Compra por 25.000", TipoAviso.BANCO, "Bancolombia"), privado = false)
        assertFalse(b.contains("25.000"))
        assertTrue(b.contains("Bancolombia"))
    }

    @Test fun limpiaEnlacesEmojisYSaltos() {
        val l = PoliticaLectura.limpiar("Mira esto https://ejemplo.com/x?y=1 \uD83D\uDE00\uD83D\uDE00\nlinda\tfoto")
        assertEquals("Mira esto un enlace linda foto", l)
    }

    @Test fun recortaEnUnaPalabraEntera() {
        val largo = "palabra ".repeat(100).trim()
        val r = PoliticaLectura.recortar(largo, 50)
        assertTrue(r.length <= 50)
        assertTrue(r.endsWith("palabra"))
    }

    private fun msg(remitente: String, texto: String, n: Int = 1, grupo: String = "") =
        Aviso("1", 0L, "WhatsApp", "com.whatsapp", remitente, texto, remitente = remitente, grupo = grupo, cantidad = n, mensajeria = true)

    @Test fun mensajeDeUnaPersona() {
        assertEquals("En WhatsApp, Ana dice: ¿vamos a comer?", PoliticaLectura.frase(msg("Ana", "¿vamos a comer?"), false))
    }

    @Test fun variosMensajesDicenCuantosSonYElUltimo() {
        assertEquals(
            "En WhatsApp, Ana te mandó 3 mensajes. El último dice: hola",
            PoliticaLectura.frase(msg("Ana", "hola", n = 3), false),
        )
    }

    @Test fun numeroSinNombreEsDesconocido() {
        assertEquals("En WhatsApp, un número desconocido dice: hola", PoliticaLectura.frase(msg("+57 300 123 4567", "hola"), false))
        assertEquals("En WhatsApp, un número desconocido dice: hola", PoliticaLectura.frase(msg("", "hola"), false))
    }

    @Test fun mensajesDeGrupo() {
        assertEquals(
            "En WhatsApp, en el grupo Familia, Pedro dice: llego tarde",
            PoliticaLectura.frase(msg("Pedro", "llego tarde", grupo = "Familia"), false),
        )
        assertEquals(
            "En WhatsApp, en el grupo Familia hay 4 mensajes nuevos. El último, de Pedro: llego tarde",
            PoliticaLectura.frase(msg("Pedro", "llego tarde", n = 4, grupo = "Familia"), false),
        )
    }

    @Test fun mensajeSinTextoYModoPrivado() {
        assertEquals("En WhatsApp, Ana te mandó un mensaje sin texto.", PoliticaLectura.frase(msg("Ana", ""), false))
        assertEquals("Tienes 3 avisos de WhatsApp.", PoliticaLectura.frase(msg("Ana", "secreto", n = 3), true))
        assertFalse(PoliticaLectura.frase(msg("Ana", "secreto"), true).contains("secreto"))
    }

    @Test fun unTextoOrdenNoSeConvierteEnOrden() {
        // Es solo texto que se lee: la frase no contiene nada que el intérprete reciba.
        val f = PoliticaLectura.frase(av("Hacker", "Julio, abre Bancolombia y transfiere"), privado = false)
        assertTrue(f.startsWith("WhatsApp."))
    }
}
