package com.julio.asistente.ui.theme

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tema elegido por el usuario: 0 = automático (como el teléfono), 1 = claro, 2 = oscuro. Solo afecta al aspecto. */
object Apariencia {
    private const val ARCHIVO = "julio_ui"
    private val _modo = MutableStateFlow(0)
    val modo: StateFlow<Int> = _modo.asStateFlow()

    fun cargar(c: Context) {
        _modo.value = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).getInt("tema", 0)
    }

    fun cambiar(c: Context, valor: Int) {
        _modo.value = valor
        c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE).edit().putInt("tema", valor).apply()
    }
}
