package com.julio.asistente.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta sobria: grafito azulado + un solo acento azul suave. Sin neón ni degradados llamativos.

// Oscuro
val OscFondo = Color(0xFF0F1318)
val OscSuperficie = Color(0xFF141A21)
val OscTexto = Color(0xFFE7ECF2)
val OscTextoSecundario = Color(0xFFA3AFBF)
val OscAcento = Color(0xFF7AA7F7)

// Claro
val ClaFondo = Color(0xFFF6F8FB)
val ClaSuperficie = Color(0xFFFFFFFF)
val ClaTexto = Color(0xFF141A22)
val ClaTextoSecundario = Color(0xFF4E5A6B)
val ClaAcento = Color(0xFF2563EB)
