package com.julio.asistente.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.julio.asistente.R
import com.julio.asistente.voz.EstadoVoz
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private val DOS_PI = (2.0 * PI).toFloat()

/**
 * Avatar de Julio. Mismo tamaño y mismos movimientos de siempre (respira, se inclina al escuchar, abre la
 * quijada al ritmo de cada palabra, ondas y barras con la voz); solo cambia el estilo: un disco liso, líneas finas
 * del color del tema y nada de brillos ni luces.
 * El movimiento de la boca sigue el ritmo de las palabras que reporta el motor de voz; no es sincronía exacta.
 */
@Composable
fun Orbe(
    estado: EstadoVoz,
    nivel: Float,
    palabras: Int,
    modifier: Modifier = Modifier,
    colorPorEstado: Boolean = true,
) {
    val gorila: ImageBitmap = ImageBitmap.imageResource(R.drawable.julio_orbe)
    val esquema = MaterialTheme.colorScheme
    // Acento del tema; al pensar y al responder cambia a otro tono suave del tema (transición gradual).
    val colorObjetivo = if (!colorPorEstado) esquema.primary else when (estado) {
        EstadoVoz.PROCESANDO -> esquema.secondary
        EstadoVoz.RESPONDIENDO -> esquema.tertiary
        else -> esquema.primary
    }
    val acento by animateColorAsState(colorObjetivo, tween(450), label = "acento")
    val colorDisco = esquema.surfaceContainerHigh

    val transicion = rememberInfiniteTransition(label = "avatar")
    val fase by transicion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart),
        label = "fase",
    )
    val inclinacion by animateFloatAsState(
        targetValue = if (estado == EstadoVoz.ESCUCHANDO) -4f else 0f,
        animationSpec = tween(500),
        label = "inclinacion",
    )

    // Un impulso por cada palabra que el motor de voz empieza a decir.
    val impulso = remember { Animatable(0f) }
    LaunchedEffect(palabras) {
        if (estado == EstadoVoz.RESPONDIENDO && palabras > 0) {
            impulso.snapTo(1f)
            impulso.animateTo(0f, tween(200))
        }
    }

    // Velocidades enteras: el bucle de 6 s se repite sin saltos.
    val velocidad = when (estado) {
        EstadoVoz.REPOSO -> 1
        EstadoVoz.ESCUCHANDO -> 2
        EstadoVoz.RESPONDIENDO -> 2
        EstadoVoz.PROCESANDO -> 6
    }

    Canvas(modifier.aspectRatio(1f)) {
        val lado = size.minDimension
        val c = Offset(size.width / 2f, lado * 0.48f)
        val f = fase
        val habla = estado == EstadoVoz.RESPONDIENDO
        val vaiven = if (habla) 0.35f * abs(sin(f * DOS_PI * 12f)) else 0f
        val apertura = if (habla) max(impulso.value, vaiven) else 0f
        val energia = when (estado) {
            EstadoVoz.REPOSO -> 0.06f
            EstadoVoz.ESCUCHANDO -> 0.15f + 0.85f * nivel
            EstadoVoz.PROCESANDO -> 0.45f
            EstadoVoz.RESPONDIENDO -> 0.2f + 0.8f * apertura
        }
        val intensidad = if (estado == EstadoVoz.REPOSO) 0.7f else 1f
        val respiracion = 1f + 0.012f * sin(f * DOS_PI)

        // Disco liso detrás del avatar y un anillo fino
        val centroDisco = Offset(c.x, lado * 0.47f)
        val radioDisco = lado * 0.40f
        drawCircle(color = colorDisco, radius = radioDisco, center = centroDisco)
        drawCircle(
            color = acento.copy(alpha = 0.40f * intensidad), radius = radioDisco, center = centroDisco,
            style = Stroke(width = lado * 0.004f),
        )

        // Ondas que se expanden (escuchando y respondiendo)
        if (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.RESPONDIENDO) {
            for (k in 0 until 3) {
                val p = ((f * velocidad + k / 3f) % 1f)
                drawCircle(
                    color = acento.copy(alpha = (1f - p) * 0.28f * (0.4f + energia)),
                    radius = radioDisco * (1f + 0.22f * p), center = centroDisco,
                    style = Stroke(width = lado * 0.004f),
                )
            }
        }
        // Arco que gira (escuchando y pensando)
        if (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.PROCESANDO) {
            val d = radioDisco * 2f
            drawArc(
                color = acento, startAngle = f * 360f * velocidad, sweepAngle = 70f, useCenter = false,
                topLeft = Offset(centroDisco.x - radioDisco, centroDisco.y - radioDisco), size = Size(d, d),
                style = Stroke(width = lado * 0.008f, cap = StrokeCap.Round),
            )
        }

        // Barras que reaccionan a la voz, sobre una elipse fina en la base
        val yBase = lado * 0.87f
        val rx = lado * 0.34f
        val ry = lado * 0.05f
        drawOval(
            color = acento.copy(alpha = 0.45f * intensidad),
            topLeft = Offset(c.x - rx, yBase - ry), size = Size(rx * 2f, ry * 2f),
            style = Stroke(width = lado * 0.003f),
        )
        val barras = 48
        for (i in 0 until barras) {
            val ang = DOS_PI * i / barras + f * DOS_PI * 0.5f * (if (velocidad >= 6) 2f else 1f)
            val osc = abs(sin(f * DOS_PI * velocidad + i * 0.55f))
            val altura = lado * 0.006f + lado * 0.075f * energia * (0.25f + 0.75f * osc)
            val bx = c.x + rx * cos(ang)
            val by = yBase + ry * sin(ang)
            drawLine(
                color = acento.copy(alpha = (if (sin(ang) > 0f) 0.8f else 0.4f) * intensidad),
                start = Offset(bx, by), end = Offset(bx, by - altura),
                strokeWidth = lado * 0.005f, cap = StrokeCap.Round,
            )
        }

        // Gorila (en su propia capa para desvanecer los bordes del recorte)
        val ancho = gorila.width
        val alto = gorila.height
        val corte = (ancho * 0.528f).roundToInt()     // borde superior de la boca
        val banda = (ancho * 0.30f).roundToInt()      // mandíbula y mentón: se estiran al hablar
        val k = 1f + 0.10f * apertura
        val escalaLatido = respiracion + 0.02f * apertura + (if (estado == EstadoVoz.ESCUCHANDO) 0.025f * nivel else 0f)
        val gw = lado * 0.58f * escalaLatido
        val factor = gw / ancho
        val gh = alto * factor
        val gx = c.x - gw / 2f
        val gy = lado * 0.115f - lado * 0.004f * apertura

        drawIntoCanvas { it.saveLayer(Rect(0f, 0f, size.width, size.height), Paint()) }
        withTransform({
            rotate(inclinacion, pivot = Offset(c.x, gy + gh))
            translate(gx, gy)
            scale(factor, factor, pivot = Offset.Zero)
        }) {
            // resto del cuerpo: sigue a la barbilla
            withTransform({ translate(0f, corte + banda * k) }) {
                drawImage(
                    image = gorila,
                    srcOffset = IntOffset(0, corte + banda),
                    srcSize = IntSize(ancho, alto - corte - banda),
                    dstOffset = IntOffset.Zero,
                    dstSize = IntSize(ancho, alto - corte - banda),
                    filterQuality = FilterQuality.High,
                )
            }
            // mandíbula: se estira
            withTransform({
                translate(0f, corte.toFloat())
                scale(1f, k, pivot = Offset.Zero)
            }) {
                drawImage(
                    image = gorila,
                    srcOffset = IntOffset(0, corte),
                    srcSize = IntSize(ancho, banda),
                    dstOffset = IntOffset.Zero,
                    dstSize = IntSize(ancho, banda),
                    filterQuality = FilterQuality.High,
                )
            }
            // cabeza (ojos y nariz): quieta
            drawImage(
                image = gorila,
                srcOffset = IntOffset.Zero,
                srcSize = IntSize(ancho, corte),
                dstOffset = IntOffset.Zero,
                dstSize = IntSize(ancho, corte),
                filterQuality = FilterQuality.High,
            )
        }
        // bordes que se desvanecen: el gorila se funde con el disco sin recuadro
        drawRect(
            brush = Brush.radialGradient(
                0f to Color.Transparent,
                0.74f to Color.Transparent,
                1f to Color.Black,
                center = Offset(c.x, gy + gh * 0.42f), radius = gw * 0.62f,
            ),
            blendMode = BlendMode.DstOut,
        )
        drawIntoCanvas { it.restore() }
    }
}
