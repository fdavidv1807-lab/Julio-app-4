package com.julio.asistente.enfoque

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** AlarmManager avisa aquí cuando termina la sesión de enfoque o el descanso. */
class EnfoqueReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        EnfoqueControl.terminar(context.applicationContext)
    }
}
