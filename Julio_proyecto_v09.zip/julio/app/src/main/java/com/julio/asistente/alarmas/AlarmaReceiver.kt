package com.julio.asistente.alarmas

import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.julio.asistente.R
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.AlarmaEntity
import com.julio.asistente.data.local.JulioDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.time.ZonedDateTime

/** El sistema avisa aquí a la hora exacta de una alarma (o de una alarma pospuesta). */
class AlarmaReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmaProgramador.EXTRA_ID, -1L)
        if (id < 0) return
        val pospuesta = intent.getBooleanExtra(AlarmaProgramador.EXTRA_POSPUESTA, false)
        val app = context.applicationContext
        val pendiente = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = JulioDatabase.get(app).alarmaDao()
                val alarma = dao.porId(id)
                if (alarma != null && (alarma.activa || pospuesta)) {
                    if (!pospuesta) {
                        if (alarma.diasMascara != 0) {
                            // Repetitiva: programar la siguiente (margen de 1 min para no repetir esta).
                            AlarmaProgramador.programar(app, alarma, ZonedDateTime.now().plusSeconds(60))
                        } else {
                            // De una sola vez: ya cumplió su trabajo.
                            dao.actualizar(alarma.copy(activa = false))
                        }
                    }
                    sonar(app, alarma)
                }
            } finally {
                pendiente.finish()
            }
        }
    }

    private fun sonar(app: Context, a: AlarmaEntity) {
        val hora = Fechas.textoHora(LocalTime.of(a.hora, a.minuto))
        val servicio = Intent(app, AlarmaService::class.java).apply {
            action = AlarmaService.ACCION_SONAR
            putExtra(AlarmaProgramador.EXTRA_ID, a.id)
            putExtra(AlarmaService.EXTRA_NOMBRE, a.nombre)
            putExtra(AlarmaService.EXTRA_HORA, hora)
            putExtra(AlarmaService.EXTRA_SONIDO, a.sonidoUri)
        }
        try {
            ContextCompat.startForegroundService(app, servicio)
        } catch (e: Exception) {
            respaldo(app, a, hora)
        }
    }

    /** Si el sistema no deja iniciar el servicio, al menos una notificación que suena y vibra. */
    private fun respaldo(app: Context, a: AlarmaEntity, hora: String) {
        val pantalla = PendingIntent.getActivity(
            app, 20,
            Intent(app, AlarmaActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(AlarmaService.EXTRA_NOMBRE, a.nombre)
                putExtra(AlarmaService.EXTRA_HORA, hora)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notificacion = NotificationCompat.Builder(app, Canales.RESPALDO)
            .setSmallIcon(R.drawable.ic_alarma)
            .setContentTitle(a.nombre.ifBlank { "Alarma" })
            .setContentText(hora)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pantalla)
            .build()
        notificacion.flags = notificacion.flags or Notification.FLAG_INSISTENT
        try {
            NotificationManagerCompat.from(app).notify(4002, notificacion)
        } catch (e: SecurityException) {
            // Sin permiso de notificaciones no hay más que hacer; la pantalla de Alarmas lo advierte.
        }
    }
}
