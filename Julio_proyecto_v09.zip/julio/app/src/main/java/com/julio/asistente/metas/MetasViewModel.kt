package com.julio.asistente.metas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.JulioApp
import com.julio.asistente.data.local.MetaEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MetasViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as JulioApp).database.metaDao()

    /** null = cargando. La lista siempre refleja lo realmente guardado. */
    val metas: StateFlow<List<MetaEntity>?> = dao.observarTodas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun guardar(m: MetaEntity) {
        viewModelScope.launch {
            if (m.id == 0L) dao.insertar(m) else dao.actualizar(m)
        }
    }

    /** 100 % = completada; si se baja de 100, la meta vuelve a estar en curso. */
    fun actualizarProgreso(m: MetaEntity, progreso: Int) {
        val p = progreso.coerceIn(0, 100)
        viewModelScope.launch { dao.actualizar(m.copy(progreso = p, completada = p == 100)) }
    }

    fun completar(m: MetaEntity) = actualizarProgreso(m, 100)

    fun eliminar(m: MetaEntity) {
        viewModelScope.launch { dao.eliminar(m) }
    }
}
