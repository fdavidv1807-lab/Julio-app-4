package com.julio.asistente.alarmas

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.julio.asistente.R
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Servicio en primer plano que hace sonar y vibrar la alarma hasta que el usuario
 * la detiene, la pospone, o pasan [DURACION_MAXIMA_MS].
 */
class AlarmaService : Service() {

    companion object {
        const val ACCION_SONAR = "com.julio.asistente.SERVICIO_SONAR"
        const val ACCION_DETENER = "com.julio.asistente.SERVICIO_DETENER"
        const val ACCION_POSPONER = "com.julio.asistente.SERVICIO_POSPONER"
        const val EXTRA_NOMBRE = "nombre"
        const val EXTRA_HORA = "hora"
        const val EXTRA_SONIDO = "sonido"
        const val MINUTOS_POSPONER = 10
        const val DURACION_MAXIMA_MS = 5 * 60_000L
        private const val ID_NOTIFICACION = 4001

        /** true mientras una alarma está sonando. La pantalla de alarma lo observa para cerrarse. */
        val sonando = MutableStateFlow(false)
    }

    private var player: MediaPlayer? = null
    private var alarmaId = -1L
    private val handler = Handler(Looper.getMainLooper())
    private val corteAutomatico = Runnable { detener() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACCION_DETENER -> detener()
            ACCION_POSPONER -> posponer()
            ACCION_SONAR -> iniciar(intent)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun iniciar(intent: Intent) {
        // Si ya sonaba otra alarma, se reemplaza por esta.
        pararSonido()
        alarmaId = intent.getLongExtra(AlarmaProgramador.EXTRA_ID, -1L)
        val nombre = intent.getStringExtra(EXTRA_NOMBRE).orEmpty()
        val hora = intent.getStringExtra(EXTRA_HORA).orEmpty()
        val sonido = intent.getStringExtra(EXTRA_SONIDO)

        sonando.value = true
        ServiceCompat.startForeground(
            this,
            ID_NOTIFICACION,
            construirNotificacion(nombre, hora),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
        )
        reproducir(sonido)
        vibrar()
        handler.removeCallbacks(corteAutomatico)
        handler.postDelayed(corteAutomatico, DURACION_MAXIMA_MS)
    }

    private fun construirNotificacion(nombre: String, hora: String): android.app.Notification {
        val pantalla = PendingIntent.getActivity(
            this, 10,
            Intent(this, AlarmaActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(EXTRA_NOMBRE, nombre)
                putExtra(EXTRA_HORA, hora)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, Canales.ALARMAS)
            .setSmallIcon(R.drawable.ic_alarma)
            .setContentTitle(nombre.ifBlank { "Alarma" })
            .setContentText(hora)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setFullScreenIntent(pantalla, true)
            .setContentIntent(pantalla)
            .addAction(0, "Posponer $MINUTOS_POSPONER min", accion(ACCION_POSPONER, 11))
            .addAction(0, "Detener", accion(ACCION_DETENER, 12))
            .build()
    }

    private fun accion(accion: String, codigo: Int): PendingIntent =
        PendingIntent.getService(
            this, codigo,
            Intent(this, AlarmaService::class.java).setAction(accion),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun reproducir(sonido: String?) {
        val candidatos = listOfNotNull(
            sonido?.let { Uri.parse(it) },
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
        )
        for (uri in candidatos) {
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                mp.setDataSource(this, uri)
                mp.isLooping = true
                mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (e: Exception) {
                // Probar el siguiente sonido disponible.
            }
        }
    }

    private fun vibrar() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
    }

    private fun pararSonido() {
        handler.removeCallbacks(corteAutomatico)
        try {
            player?.stop()
        } catch (e: Exception) {
            // El reproductor pudo no haber arrancado.
        }
        player?.release()
        player = null
        (getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.cancel()
    }

    private fun posponer() {
        AlarmaProgramador.posponer(this, alarmaId, MINUTOS_POSPONER)
        detener()
    }

    private fun detener() {
        pararSonido()
        sonando.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        pararSonido()
        sonando.value = false
        super.onDestroy()
    }
}
