package com.julio.asistente.alarmas

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.JulioApp
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.AlarmaEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.ZonedDateTime

class AlarmasViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as JulioApp).database.alarmaDao()

    /** null = cargando. */
    val alarmas: StateFlow<List<AlarmaEntity>?> = dao.observarTodas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _aviso = MutableStateFlow<String?>(null)
    /** Resultado real de la última operación (nunca se confirma algo que no se programó). */
    val aviso: StateFlow<String?> = _aviso

    fun limpiarAviso() { _aviso.value = null }

    fun guardar(a: AlarmaEntity) {
        viewModelScope.launch { persistir(a) }
    }

    fun alternar(a: AlarmaEntity) {
        viewModelScope.launch {
            if (a.activa) {
                persistir(a.copy(activa = false))
            } else {
                persistir(rearmarSiVencida(a).copy(activa = true))
            }
        }
    }

    fun eliminar(a: AlarmaEntity) {
        viewModelScope.launch {
            AlarmaProgramador.cancelar(getApplication<Application>(), a.id)
            dao.eliminar(a)
        }
    }

    /** Una alarma de una sola vez cuya fecha ya pasó se vuelve a armar para la próxima vez que llegue esa hora. */
    private fun rearmarSiVencida(a: AlarmaEntity): AlarmaEntity {
        val ahora = ZonedDateTime.now()
        if (a.diasMascara == 0 && CalculoAlarma.proxima(a, ahora) == null) {
            val siguiente = CalculoAlarma.proxima(a.copy(fechaEpochDay = null), ahora)
            if (siguiente != null) return a.copy(fechaEpochDay = siguiente.toLocalDate().toEpochDay())
        }
        return a
    }

    private suspend fun persistir(original: AlarmaEntity) {
        val app = getApplication<Application>()
        val ahora = ZonedDateTime.now()
        var alarma = original
        var aviso: String? = null

        // Una sola vez y sin fecha: fijar ya la fecha concreta en que sonará.
        if (alarma.activa && alarma.diasMascara == 0 && alarma.fechaEpochDay == null) {
            val proxima = CalculoAlarma.proxima(alarma, ahora)
            if (proxima != null) alarma = alarma.copy(fechaEpochDay = proxima.toLocalDate().toEpochDay())
        }
        // Fecha y hora ya pasadas: se guarda desactivada y se dice.
        if (alarma.activa && CalculoAlarma.proxima(alarma, ahora) == null) {
            alarma = alarma.copy(activa = false)
            aviso = "Esa fecha y hora ya pasaron. La alarma se guardó desactivada."
        }

        val id = if (alarma.id == 0L) {
            dao.insertar(alarma)
        } else {
            dao.actualizar(alarma)
            alarma.id
        }
        val guardada = alarma.copy(id = id)

        if (guardada.activa) {
            val programada = AlarmaProgramador.programar(app, guardada)
            if (programada == null) {
                dao.actualizar(guardada.copy(activa = false))
                aviso = "No se pudo programar la alarma en el sistema. Quedó desactivada." +
                    (AlarmaProgramador.ultimoError?.let { "\n\nDetalle: $it" } ?: "")
            } else {
                aviso = "Sonará el ${Fechas.textoLargo(programada.toLocalDate())} a las " +
                    "${Fechas.textoHora(programada.toLocalTime())}."
            }
        } else {
            AlarmaProgramador.cancelar(app, id)
        }
        _aviso.value = aviso
    }
}
