package com.julio.asistente.enfoque

enum class Fase { ENFOQUE, DESCANSO }

enum class EstadoSesion { INACTIVA, CORRIENDO, PAUSADA, TERMINADA }

data class Sesion(
    val estado: EstadoSesion = EstadoSesion.INACTIVA,
    val fase: Fase = Fase.ENFOQUE,
    val duracionMs: Long = 0L,
    /** Solo si CORRIENDO: instante (epoch ms) en que termina. */
    val finMs: Long = 0L,
    /** Solo si PAUSADA: tiempo que faltaba. */
    val restanteMs: Long = 0L,
)

data class Preferencias(
    val enfoqueMin: Int = 25,
    val descansoMin: Int = 5,
)
