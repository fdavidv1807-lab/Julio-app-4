package com.julio.asistente.alarmas

import com.julio.asistente.data.local.AlarmaEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime

/** Lógica pura (sin Android): ¿cuándo debe sonar una alarma? */
object CalculoAlarma {

    /** Lunes = bit 0 ... domingo = bit 6. */
    fun bit(d: DayOfWeek): Int = 1 shl (d.value - 1)

    /**
     * Próximo momento (estrictamente posterior a [ahora]) en que debe sonar, o null si
     * ya no sonará nunca (alarma de una sola vez con fecha pasada).
     */
    fun proxima(a: AlarmaEntity, ahora: ZonedDateTime): ZonedDateTime? {
        val zona = ahora.zone
        val hora = LocalTime.of(a.hora, a.minuto)

        if (a.diasMascara != 0) {
            for (i in 0..7) {
                val dia = ahora.toLocalDate().plusDays(i.toLong())
                if ((a.diasMascara and bit(dia.dayOfWeek)) == 0) continue
                val candidato = ZonedDateTime.of(dia, hora, zona)
                if (candidato.isAfter(ahora)) return candidato
            }
            return null
        }

        val fecha = a.fechaEpochDay
        if (fecha != null) {
            val candidato = ZonedDateTime.of(LocalDate.ofEpochDay(fecha), hora, zona)
            return if (candidato.isAfter(ahora)) candidato else null
        }

        // Sin fecha ni días: la próxima vez que llegue esa hora.
        val hoy = ZonedDateTime.of(ahora.toLocalDate(), hora, zona)
        return if (hoy.isAfter(ahora)) hoy else hoy.plusDays(1)
    }
}
