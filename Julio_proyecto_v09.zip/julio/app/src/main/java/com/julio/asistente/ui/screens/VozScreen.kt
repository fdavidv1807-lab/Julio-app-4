package com.julio.asistente.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.julio.asistente.R

@Composable
fun VozScreen() {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Image(
            painter = painterResource(R.drawable.julio_mascota),
            contentDescription = "Julio, el gorila médico",
            modifier = Modifier.widthIn(max = 240.dp).clip(RoundedCornerShape(28.dp)),
        )
        Text("Julio", style = MaterialTheme.typography.headlineMedium)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Voz: aún no implementada", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Hablar con Julio, el orbe animado y la guía «¿Qué puedo decirle a Julio?» " +
                        "se construyen en la etapa de voz. Mientras tanto, tus metas ya funcionan aquí abajo.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }

        MetasSection()
    }
}
