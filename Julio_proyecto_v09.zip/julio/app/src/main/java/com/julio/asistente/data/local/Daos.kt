package com.julio.asistente.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TareaDao {
    @Query("SELECT * FROM tareas ORDER BY completada ASC, fechaLimite IS NULL, fechaLimite ASC, prioridad DESC")
    fun observarTodas(): Flow<List<TareaEntity>>

    @Insert suspend fun insertar(t: TareaEntity): Long
    @Update suspend fun actualizar(t: TareaEntity)
    @Delete suspend fun eliminar(t: TareaEntity)
}

@Dao
interface ActividadDao {
    @Query("SELECT * FROM actividades ORDER BY inicio ASC")
    fun observarTodas(): Flow<List<ActividadEntity>>

    @Query("SELECT * FROM actividades WHERE inicio BETWEEN :desde AND :hasta ORDER BY inicio ASC")
    suspend fun entre(desde: Long, hasta: Long): List<ActividadEntity>

    @Insert suspend fun insertar(a: ActividadEntity): Long
    @Update suspend fun actualizar(a: ActividadEntity)
    @Delete suspend fun eliminar(a: ActividadEntity)
}

@Dao
interface AlarmaDao {
    @Query("SELECT * FROM alarmas ORDER BY hora ASC, minuto ASC")
    fun observarTodas(): Flow<List<AlarmaEntity>>

    @Query("SELECT * FROM alarmas WHERE id = :id")
    suspend fun porId(id: Long): AlarmaEntity?

    @Query("SELECT * FROM alarmas WHERE activa = 1")
    suspend fun activas(): List<AlarmaEntity>

    @Insert suspend fun insertar(a: AlarmaEntity): Long
    @Update suspend fun actualizar(a: AlarmaEntity)
    @Delete suspend fun eliminar(a: AlarmaEntity)
}

@Dao
interface MetaDao {
    @Query("SELECT * FROM metas ORDER BY completada ASC, creadaEn DESC")
    fun observarTodas(): Flow<List<MetaEntity>>

    @Insert suspend fun insertar(m: MetaEntity): Long
    @Update suspend fun actualizar(m: MetaEntity)
    @Delete suspend fun eliminar(m: MetaEntity)
}
