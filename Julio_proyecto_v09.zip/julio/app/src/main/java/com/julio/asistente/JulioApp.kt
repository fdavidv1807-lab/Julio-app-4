package com.julio.asistente

import android.app.Application
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.enfoque.EnfoqueControl

class JulioApp : Application() {
    /** Base de datos local única (Room). Se crea al primer uso. */
    val database: JulioDatabase by lazy { JulioDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        Canales.crear(this)
        EnfoqueControl.cargar(this)
    }
}
