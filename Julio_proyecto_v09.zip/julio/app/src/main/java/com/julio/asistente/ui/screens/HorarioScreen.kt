package com.julio.asistente.ui.screens

import android.text.format.DateFormat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.core.Fechas
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.horario.HorarioViewModel
import com.julio.asistente.horario.Ocurrencia
import com.julio.asistente.horario.Ocurrencias
import com.julio.asistente.horario.Recurrencia
import com.julio.asistente.ui.components.SelectorFecha
import com.julio.asistente.ui.components.SelectorHora
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZoneOffset

private enum class VistaHorario(val etiqueta: String) {
    DIA("Día"),
    PROXIMAS("Próximas"),
}

@Composable
fun HorarioScreen(vm: HorarioViewModel = viewModel()) {
    val lista by vm.actividades.collectAsStateWithLifecycle()
    val actividades = lista
    val zona = ZoneId.systemDefault()

    var vista by rememberSaveable { mutableStateOf(VistaHorario.DIA) }
    var diaEpoch by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }
    val dia = LocalDate.ofEpochDay(diaEpoch)

    var dialogoAbierto by remember { mutableStateOf(false) }
    var enEdicion by remember { mutableStateOf<ActividadEntity?>(null) }
    var porEliminar by remember { mutableStateOf<ActividadEntity?>(null) }
    var selectorDiaAbierto by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Text(
                "Horario",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VistaHorario.entries.forEach { v ->
                    FilterChip(
                        selected = vista == v,
                        onClick = { vista = v },
                        label = { Text(v.etiqueta) },
                    )
                }
            }

            if (vista == VistaHorario.DIA) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { diaEpoch -= 1 }) {
                        Icon(Icons.Filled.ChevronLeft, contentDescription = "Día anterior")
                    }
                    TextButton(
                        onClick = { selectorDiaAbierto = true },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            Fechas.textoLargo(dia),
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center,
                        )
                    }
                    IconButton(onClick = { diaEpoch += 1 }) {
                        Icon(Icons.Filled.ChevronRight, contentDescription = "Día siguiente")
                    }
                }
                if (dia != LocalDate.now()) {
                    TextButton(onClick = { diaEpoch = LocalDate.now().toEpochDay() }) {
                        Text("Volver a hoy")
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            if (actividades == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                val ocurrencias = if (vista == VistaHorario.DIA) {
                    Ocurrencias.entre(actividades, dia, dia, zona)
                } else {
                    Ocurrencias.proximas(actividades, LocalDateTime.now(), 14, zona)
                }
                if (ocurrencias.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            if (vista == VistaHorario.DIA) "No hay actividades este día."
                            else "No tienes actividades en los próximos 14 días.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 96.dp),
                    ) {
                        ocurrencias.groupBy { it.fecha }.forEach { (fecha, delDia) ->
                            if (vista == VistaHorario.PROXIMAS) {
                                item(key = "cab-${fecha.toEpochDay()}") {
                                    Text(
                                        etiquetaDia(fecha),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(top = 8.dp),
                                    )
                                }
                            }
                            items(
                                delDia,
                                key = { "${it.actividad.id}-${it.fecha.toEpochDay()}" },
                            ) { o ->
                                OcurrenciaItem(
                                    o = o,
                                    onEditar = { enEdicion = o.actividad; dialogoAbierto = true },
                                    onEliminar = { porEliminar = o.actividad },
                                )
                            }
                        }
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { enEdicion = null; dialogoAbierto = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Nueva actividad") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    if (dialogoAbierto) {
        DialogoActividad(
            inicial = enEdicion,
            diaPorDefecto = dia,
            zona = zona,
            onGuardar = { vm.guardar(it); dialogoAbierto = false },
            onCancelar = { dialogoAbierto = false },
        )
    }

    if (selectorDiaAbierto) {
        SelectorFecha(
            inicial = dia,
            onAceptar = { diaEpoch = it.toEpochDay(); selectorDiaAbierto = false },
            onCancelar = { selectorDiaAbierto = false },
        )
    }

    porEliminar?.let { a ->
        val repite = Recurrencia.de(a.recurrencia) != Recurrencia.NINGUNA
        AlertDialog(
            onDismissRequest = { porEliminar = null },
            title = { Text("Eliminar actividad") },
            text = {
                Text(
                    "¿Eliminar «${a.titulo}»?" +
                        if (repite) " Se eliminarán todas sus repeticiones." else "",
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.eliminar(a); porEliminar = null }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { porEliminar = null }) { Text("Cancelar") } },
        )
    }
}

private fun etiquetaDia(f: LocalDate): String {
    val hoy = LocalDate.now()
    return when (f) {
        hoy -> "Hoy · ${Fechas.textoLargo(f)}"
        hoy.plusDays(1) -> "Mañana · ${Fechas.textoLargo(f)}"
        else -> Fechas.textoLargo(f)
    }
}

@Composable
private fun OcurrenciaItem(o: Ocurrencia, onEditar: () -> Unit, onEliminar: () -> Unit) {
    val a = o.actividad
    val rec = Recurrencia.de(a.recurrencia)
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                val horas = o.horaFin?.let { "${Fechas.textoHora(o.horaInicio)} – ${Fechas.textoHora(it)}" }
                    ?: Fechas.textoHora(o.horaInicio)
                Text(horas, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Text(a.titulo, style = MaterialTheme.typography.titleMedium)
                if (a.descripcion.isNotBlank()) {
                    Text(
                        a.descripcion,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (rec != Recurrencia.NINGUNA) {
                    Text(
                        "Se repite: ${rec.etiqueta.lowercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            IconButton(onClick = onEditar) { Icon(Icons.Filled.Edit, contentDescription = "Editar actividad") }
            IconButton(onClick = onEliminar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar actividad") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun DialogoActividad(
    inicial: ActividadEntity?,
    diaPorDefecto: LocalDate,
    zona: ZoneId,
    onGuardar: (ActividadEntity) -> Unit,
    onCancelar: () -> Unit,
) {
    val inicioZ = inicial?.let { Instant.ofEpochMilli(it.inicio).atZone(zona) }
    var titulo by remember { mutableStateOf(inicial?.titulo ?: "") }
    var descripcion by remember { mutableStateOf(inicial?.descripcion ?: "") }
    var fecha by remember { mutableStateOf(inicioZ?.toLocalDate() ?: diaPorDefecto) }
    var hora by remember {
        mutableStateOf<LocalTime?>(inicioZ?.toLocalTime()?.withSecond(0)?.withNano(0))
    }
    var horaFin by remember {
        mutableStateOf<LocalTime?>(
            inicial?.fin?.let { Instant.ofEpochMilli(it).atZone(zona).toLocalTime().withSecond(0).withNano(0) },
        )
    }
    var recurrencia by remember { mutableStateOf(Recurrencia.de(inicial?.recurrencia ?: "NINGUNA")) }
    var selectorFecha by remember { mutableStateOf(false) }
    var selectorHora by remember { mutableStateOf(false) }
    var selectorHoraFin by remember { mutableStateOf(false) }

    val h = hora
    val hf = horaFin
    val finInvalido = h != null && hf != null && !hf.isAfter(h)

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text(if (inicial == null) "Nueva actividad" else "Editar actividad") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it },
                    label = { Text("Título") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripción (opcional)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { selectorFecha = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Fecha: ${Fechas.textoLargo(fecha)}")
                }
                OutlinedButton(onClick = { selectorHora = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(h?.let { "Hora de inicio: ${Fechas.textoHora(it)}" } ?: "Elegir hora de inicio")
                }
                OutlinedButton(onClick = { selectorHoraFin = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(hf?.let { "Hora de fin: ${Fechas.textoHora(it)}" } ?: "Añadir hora de fin (opcional)")
                }
                if (hf != null) {
                    TextButton(onClick = { horaFin = null }) { Text("Quitar hora de fin") }
                }
                if (finInvalido) {
                    Text(
                        "La hora de fin debe ser posterior a la de inicio.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                } else if (h == null) {
                    Text(
                        "Elige la hora de inicio para poder guardar.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Text("Repetición", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Recurrencia.entries.forEach { r ->
                        FilterChip(
                            selected = recurrencia == r,
                            onClick = { recurrencia = r },
                            label = { Text(r.etiqueta) },
                        )
                    }
                }
                if (inicial != null && recurrencia != Recurrencia.NINGUNA) {
                    Text(
                        "Los cambios se aplican a todas las repeticiones.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = titulo.isNotBlank() && h != null && !finInvalido,
                onClick = {
                    if (h != null) {
                        val inicioMs = LocalDateTime.of(fecha, h).atZone(zona).toInstant().toEpochMilli()
                        val finMs = hf?.let { LocalDateTime.of(fecha, it).atZone(zona).toInstant().toEpochMilli() }
                        val base = inicial ?: ActividadEntity(titulo = "", inicio = inicioMs)
                        onGuardar(
                            base.copy(
                                titulo = titulo.trim(),
                                descripcion = descripcion.trim(),
                                inicio = inicioMs,
                                fin = finMs,
                                recurrencia = recurrencia.name,
                            ),
                        )
                    }
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )

    if (selectorFecha) {
        SelectorFecha(
            inicial = fecha,
            onAceptar = { fecha = it; selectorFecha = false },
            onCancelar = { selectorFecha = false },
        )
    }
    if (selectorHora) {
        SelectorHora(
            titulo = "Hora de inicio",
            inicial = h ?: LocalTime.of(8, 0),
            onAceptar = { hora = it; selectorHora = false },
            onCancelar = { selectorHora = false },
        )
    }
    if (selectorHoraFin) {
        SelectorHora(
            titulo = "Hora de fin",
            inicial = hf ?: (h?.plusHours(1) ?: LocalTime.of(9, 0)),
            onAceptar = { horaFin = it; selectorHoraFin = false },
            onCancelar = { selectorHoraFin = false },
        )
    }
}
