package com.julio.asistente.alarmas

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.ui.theme.JulioTheme

/** Pantalla que aparece (incluso con el teléfono bloqueado) cuando suena una alarma. */
class AlarmaActivity : ComponentActivity() {

    private var nombre by mutableStateOf("")
    private var hora by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        leerDatos(intent)

        setContent {
            JulioTheme {
                val sonando by AlarmaService.sonando.collectAsStateWithLifecycle()
                LaunchedEffect(sonando) { if (!sonando) finish() }
                PantallaAlarma(
                    nombre = nombre,
                    hora = hora,
                    onDetener = { enviar(AlarmaService.ACCION_DETENER) },
                    onPosponer = { enviar(AlarmaService.ACCION_POSPONER) },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        leerDatos(intent)
    }

    private fun leerDatos(i: Intent) {
        nombre = i.getStringExtra(AlarmaService.EXTRA_NOMBRE).orEmpty()
        hora = i.getStringExtra(AlarmaService.EXTRA_HORA).orEmpty()
    }

    private fun enviar(accion: String) {
        startService(Intent(this, AlarmaService::class.java).setAction(accion))
    }
}

@Composable
private fun PantallaAlarma(nombre: String, hora: String, onDetener: () -> Unit, onPosponer: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Filled.Alarm, contentDescription = null, modifier = Modifier.size(72.dp))
            Spacer(Modifier.height(16.dp))
            Text(hora, style = MaterialTheme.typography.displayLarge)
            if (nombre.isNotBlank()) {
                Text(nombre, style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.height(48.dp))
            Button(onClick = onDetener, modifier = Modifier.fillMaxWidth().height(64.dp)) {
                Text("Detener", style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onPosponer, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                Text("Posponer ${AlarmaService.MINUTOS_POSPONER} min")
            }
        }
    }
}
