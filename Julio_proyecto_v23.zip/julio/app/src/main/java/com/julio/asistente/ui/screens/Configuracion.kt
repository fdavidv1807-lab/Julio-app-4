package com.julio.asistente.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.bloqueo.BloqueoControl
import com.julio.asistente.core.Permisos
import com.julio.asistente.ui.components.PanelJulio
import com.julio.asistente.ui.components.RespaldoPanel
import com.julio.asistente.ui.theme.Apariencia
import com.julio.asistente.voz.EstadoPiper
import com.julio.asistente.voz.PiperModelo
import com.julio.asistente.voz.VozViewModel

/**
 * Panel de configuración (a la derecha): apariencia, permisos, voz, guía de comandos y copia de seguridad.
 * Reúne controles que ya existían; no cambia ninguna lógica.
 */
@Composable
fun ConfiguracionPanel(
    vm: VozViewModel,
    alCerrar: (() -> Unit)?,
    alProbarEjemplo: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val modo by Apariencia.modo.collectAsStateWithLifecycle()
    val orbeColor by vm.orbeColor.collectAsStateWithLifecycle()

    Column(
        modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Configuración", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            if (alCerrar != null) {
                IconButton(onClick = alCerrar) { Icon(Icons.Filled.Close, contentDescription = "Cerrar la configuración") }
            }
        }

        Seccion("Apariencia", abiertaAlInicio = true) {
            PanelJulio(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tema", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Automático" to 0, "Claro" to 1, "Oscuro" to 2).forEach { (titulo, valor) ->
                            FilterChip(
                                selected = modo == valor,
                                onClick = { Apariencia.cambiar(ctx, valor) },
                                label = { Text(titulo) },
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("El orbe cambia de color", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = orbeColor, onCheckedChange = { vm.alternarOrbeColor() })
                    }
                }
            }
        }

        Seccion("Permisos") { PermisosLista() }

        Seccion("Voz") {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                PiperPanel(vm)
                AjustesVozPanel(vm = vm, alAbrirSistema = { abrirAjustesDeVoz(ctx) })
            }
        }

        Seccion("Guía de comandos") { GuiaComandos(alProbarEjemplo) }

        Seccion("Copia de seguridad") { RespaldoPanel() }
    }
}

/** Sección que se abre y se cierra tocando su título. */
@Composable
private fun Seccion(titulo: String, abiertaAlInicio: Boolean = false, contenido: @Composable () -> Unit) {
    var abierta by rememberSaveable(titulo) { mutableStateOf(abiertaAlInicio) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            Modifier.fillMaxWidth().clickable { abierta = !abierta }.padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(titulo, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Icon(
                if (abierta) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (abierta) "Ocultar $titulo" else "Mostrar $titulo",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        AnimatedVisibility(visible = abierta) { Box { contenido() } }
    }
}

/** Voz neuronal «Dave» (Piper, español de España): se instala una vez y después funciona sin internet. */
@Composable
private fun PiperPanel(vm: VozViewModel) {
    val estado by vm.piperEstado.collectAsStateWithLifecycle()
    val usar by vm.usarPiper.collectAsStateWithLifecycle()
    val fallo by vm.errorPiper.collectAsStateWithLifecycle()
    val selector = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { archivos ->
        if (archivos.isNotEmpty()) vm.instalarPiperDesdeArchivos(archivos)
    }
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Voz neuronal sin internet", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Voz «Dave» en español de España (Piper). Elige sus dos archivos, es_ES-davefx-medium.onnx y su .json, " +
                    "o descárgala (unos ${PiperModelo.TAMANO_APROX_MB} MB, mejor con Wi‑Fi). Se instala una sola vez y después " +
                    "Julio habla con ella sin conexión. Si algo falla, usa la voz del teléfono. " +
                    "El tono y la velocidad de abajo también la afectan.",
                style = MaterialTheme.typography.bodySmall,
            )
            if (!vm.piperDisponible) {
                Text(
                    "Esta compilación de Julio no incluyó el motor neuronal (no se pudo descargar al compilar). " +
                        "Vuelve a compilar con internet y aparecerá.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            when (val e = estado) {
                EstadoPiper.NoDescargada -> {
                    Button(
                        onClick = { selector.launch(arrayOf("*/*")) },
                        enabled = vm.piperDisponible,
                        shape = MaterialTheme.shapes.small,
                    ) { Text("Instalar con mis archivos de Dave") }
                    TextButton(onClick = { vm.descargarPiper() }, enabled = vm.piperDisponible) { Text("Descargar Dave (sin archivos)") }
                }
                is EstadoPiper.Descargando -> {
                    if (e.progreso >= 0f) LinearProgressIndicator(progress = { e.progreso }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("${e.etapa}… ${e.mb} MB", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { vm.cancelarDescargaPiper() }) { Text("Cancelar") }
                }
                EstadoPiper.Lista -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Usar la voz neuronal Dave", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Switch(checked = usar, onCheckedChange = { vm.alternarPiper(it) })
                    }
                    TextButton(onClick = { vm.eliminarPiper() }) { Text("Eliminar voz instalada") }
                }
                is EstadoPiper.Error -> {
                    Text(e.mensaje, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    Button(onClick = { vm.reintentarPiper() }, shape = MaterialTheme.shapes.small) { Text("Reintentar") }
                    TextButton(onClick = { selector.launch(arrayOf("*/*")) }, enabled = vm.piperDisponible) { Text("Elegir otros archivos") }
                }
            }
            fallo?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        }
    }
}

private class FilaPermiso(val nombre: String, val detalle: String, val concedido: Boolean, val abrir: () -> Intent)

/** Estado de los permisos (solo lectura); «Abrir» lleva a los mismos ajustes del sistema que ya usa la app. */
@Composable
private fun PermisosLista() {
    val ctx = LocalContext.current
    var version by remember { mutableStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { version++ }
    val filas = remember(version) {
        val bloqueo = BloqueoControl.permisos(ctx)
        listOf(
            FilaPermiso(
                "Micrófono", "Para hablar con Julio",
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            ) { Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")) },
            FilaPermiso("Notificaciones", "Para avisos y recordatorios", Permisos.notificaciones(ctx)) { Permisos.ajustesNotificaciones(ctx) },
            FilaPermiso("Alarmas exactas", "Para que las alarmas suenen a su hora", Permisos.alarmasExactas(ctx)) { Permisos.ajustesAlarmasExactas(ctx) },
            FilaPermiso("Alarma en pantalla completa", "Para mostrar la alarma con el teléfono bloqueado", Permisos.pantallaCompleta(ctx)) { Permisos.ajustesPantallaCompleta(ctx) },
            FilaPermiso("Acceso de uso", "Solo para el bloqueo de apps", bloqueo.acceso) { BloqueoControl.ajustesAcceso(ctx) },
            FilaPermiso("Mostrar sobre otras apps", "Solo para el bloqueo de apps", bloqueo.superposicion) { BloqueoControl.ajustesSuperposicion(ctx) },
        )
    }
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            filas.forEach { f ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(f.nombre, style = MaterialTheme.typography.bodyMedium)
                        Text(f.detalle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (f.concedido) {
                        Text("Concedido", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    } else {
                        TextButton(onClick = {
                            try {
                                ctx.startActivity(f.abrir().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) {
                                // Si el teléfono no tiene esa pantalla de ajustes, no pasa nada.
                            }
                        }) { Text("Abrir") }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuiaComandos(alProbarEjemplo: (String) -> Unit) {
    var categoria by rememberSaveable { mutableStateOf(-1) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            GUIA.forEachIndexed { indice, cat ->
                FilterChip(
                    selected = categoria == indice,
                    onClick = { categoria = if (categoria == indice) -1 else indice },
                    label = { Text(cat.titulo) },
                )
            }
        }
        val abierta = GUIA.getOrNull(categoria)
        AnimatedVisibility(visible = abierta != null) {
            if (abierta != null) {
                PanelJulio(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "Puedes decirle a Julio:",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        abierta.ejemplos.forEach { ejemplo ->
                            Text(
                                "«$ejemplo»",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { alProbarEjemplo(ejemplo) }
                                    .padding(vertical = 8.dp),
                            )
                        }
                        Text("Toca un ejemplo para probarlo.", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

private class CategoriaGuia(val titulo: String, val ejemplos: List<String>)

/** Solo ejemplos que el intérprete realmente entiende hoy (verificados con pruebas de la lógica). */
private val GUIA = listOf(
    CategoriaGuia("Horario", listOf(
        "¿Qué tengo programado hoy?",
        "Agrega laboratorio de química mañana a las dos de la tarde",
        "Agrega clase de anatomía mañana de 8 a 10",
        "Programa clases de lunes a viernes a las siete de la mañana",
        "Agrega estudio de medicina los lunes, miércoles y viernes a las cuatro de la tarde",
        "Programa gimnasio todos los días a las dos de la tarde",
        "Repite esta actividad todos los martes y jueves",
        "¿Qué clases tengo el lunes?",
        "Mueve el laboratorio de química para el viernes a las cuatro de la tarde",
        "Elimina la clase de anatomía",
    )),
    CategoriaGuia("Lista de tareas", listOf(
        "Agrega estudiar anatomía a mis tareas",
        "¿Qué tareas tengo pendientes?",
        "Marca como terminada la tarea del informe",
        "Cambia el nombre de la tarea informe por informe final",
        "Elimina la tarea del informe",
    )),
    CategoriaGuia("Estudio", listOf(
        "Tengo examen de anatomía el 5 de noviembre con los temas huesos, músculos y nervios",
        "¿Qué me toca estudiar hoy?",
        "Empieza mi sesión de estudio",
        "Ya estudié",
        "¿Cómo va mi racha?",
    )),
    CategoriaGuia("Alarmas", listOf(
        "Pon una alarma para mañana a las seis de la mañana",
        "Desactiva la alarma del domingo",
        "Cambia la alarma de las seis a las siete",
        "Elimina la alarma de las seis",
    )),
    CategoriaGuia("Modo enfoque", listOf(
        "Inicia una sesión de enfoque de 35 minutos",
        "Quiero estudiar durante una hora y veinte minutos",
        "Configura un descanso de diez minutos",
    )),
    CategoriaGuia("Mis metas", listOf(
        "Muéstrame mis metas",
        "Quiero agregar una meta nueva",
        "Actualiza el progreso de mi meta",
        "Elimina la meta de leer",
    )),
)

private fun abrirAjustesDeVoz(ctx: Context) {
    try {
        ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

@Composable
private fun AjustesVozPanel(vm: VozViewModel, alAbrirSistema: () -> Unit) {
    val ajustes by vm.ajustesVoz.collectAsStateWithLifecycle()
    var voces by remember { mutableStateOf(vm.vocesDisponibles()) }
    var menu by remember { mutableStateOf(false) }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Voz de Julio", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Si Dave está instalado y activado arriba, Julio habla con él. Si no, usa las voces de tu teléfono " +
                    "(las del motor de voz predeterminado de Android); este selector elige esa voz. " +
                    "Si la quieres más grave, baja el tono.",
                style = MaterialTheme.typography.bodySmall,
            )
            val actual = voces.firstOrNull { it.nombre == ajustes.voz }?.etiqueta ?: "Automática"
            Box {
                OutlinedButton(
                    onClick = { voces = vm.vocesDisponibles(); menu = true },
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(actual, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Automática") },
                        onClick = { vm.elegirVoz(null); menu = false },
                    )
                    voces.forEach { v ->
                        DropdownMenuItem(
                            text = { Text(v.etiqueta) },
                            onClick = { vm.elegirVoz(v.nombre); menu = false },
                        )
                    }
                }
            }
            if (voces.isEmpty()) {
                Text(
                    "Todavía no se cargó la lista de voces. Toca el selector otra vez en unos segundos.",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Text("Tono (más grave ← → más agudo)", style = MaterialTheme.typography.labelMedium)
            Slider(value = ajustes.tono, onValueChange = { vm.cambiarTono(it) }, valueRange = 0.5f..1.4f)
            Text("Velocidad (más lenta ← → más rápida)", style = MaterialTheme.typography.labelMedium)
            Slider(value = ajustes.velocidad, onValueChange = { vm.cambiarVelocidad(it) }, valueRange = 0.6f..1.3f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.probarVoz() }, shape = MaterialTheme.shapes.small) { Text("Probar voz") }
                TextButton(onClick = alAbrirSistema) { Text("Más voces (Ajustes)") }
            }
        }
    }
}
