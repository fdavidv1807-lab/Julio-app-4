import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URI

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// --- Voz neuronal (Piper «Dave») con sherpa-onnx ---
// El motor se baja al compilar. Se prueban varias versiones por si alguna no tiene el archivo .aar publicado.
// Si no hay red o ninguna descarga funciona, la app se compila igual SIN voz neuronal
// (Julio avisa en Configuración > Voz y usa la voz del teléfono).
val versionesSherpa = listOf("1.13.7", "1.13.8", "1.13.6", "1.13.5")
val carpetaLibs: File = layout.projectDirectory.dir("libs").asFile
var aarEncontrado: File? = carpetaLibs.listFiles()
    ?.firstOrNull { it.name.startsWith("sherpa-onnx-") && it.name.endsWith(".aar") && it.length() > 1_000_000L }
if (aarEncontrado == null) {
    for (v in versionesSherpa) {
        val destino = File(carpetaLibs, "sherpa-onnx-$v.aar")
        try {
            carpetaLibs.mkdirs()
            val direccion = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v$v/sherpa-onnx-$v.aar"
            val conexion = URI(direccion).toURL().openConnection() as HttpURLConnection
            conexion.instanceFollowRedirects = true
            conexion.connectTimeout = 30_000
            conexion.readTimeout = 120_000
            if (conexion.responseCode !in 200..299) throw IOException("el servidor respondió ${conexion.responseCode}")
            conexion.inputStream.use { entrada: InputStream ->
                destino.outputStream().use { salida: OutputStream -> entrada.copyTo(salida) }
            }
            if (destino.length() > 1_000_000L) {
                aarEncontrado = destino
                logger.lifecycle("Julio: sherpa-onnx $v descargado (${destino.length() / 1_000_000} MB)")
                break
            }
            destino.delete()
        } catch (e: Exception) {
            logger.warn("Julio: no pude bajar sherpa-onnx $v ($e)")
            destino.delete()
        }
    }
    if (aarEncontrado == null) logger.warn("Julio: no se pudo descargar sherpa-onnx. Se compila sin voz neuronal.")
}
val sherpaAar: File? = aarEncontrado

android {
    namespace = "com.julio.asistente"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.julio.asistente"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        // Solo las arquitecturas de teléfonos reales (reduce el tamaño del APK).
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // La firma de release se configura en la Etapa 9 (keystore propio, nunca en el repositorio).
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.kotlinx.coroutines.android)

    // Para descomprimir la voz (.tar.bz2) descargada
    implementation("org.apache.commons:commons-compress:1.27.1")
    // Motor de voz neuronal (solo si se pudo descargar)
    sherpaAar?.let { implementation(files(it)) }

    testImplementation(libs.junit)
}
