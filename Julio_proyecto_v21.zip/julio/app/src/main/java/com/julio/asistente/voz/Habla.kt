package com.julio.asistente.voz

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/** Una voz instalada en el teléfono, lista para mostrarse en el selector. */
data class VozInfo(val nombre: String, val etiqueta: String)

/** Lo que el usuario eligió para la voz de Julio (se guarda en el teléfono). */
data class AjustesVoz(val voz: String?, val tono: Float, val velocidad: Float)

/**
 * Voz de Julio con el motor de síntesis de Android (funciona sin internet con las voces locales).
 * Android no permite garantizar que la voz sea masculina ni grave: depende de las voces instaladas.
 * Por eso hay selector de voz y controles de tono y velocidad.
 */
class Habla(context: Context) {
    private companion object {
        const val VOZ_PREFERIDA = "davefx"
    }

    private val appContext = context.applicationContext
    private val piper = MotorPiper(context.applicationContext)

    /** ¿Esta compilación trae el motor neuronal? */
    val piperDisponible: Boolean get() = piper.libreriaDisponible

    private val _usarPiper = MutableStateFlow(false)
    /** Si está activada y descargada, Julio habla con la voz neuronal; si no, con la del teléfono. */
    val usarPiper: StateFlow<Boolean> = _usarPiper.asStateFlow()

    private val _errorPiper = MutableStateFlow<String?>(null)
    /** Último motivo por el que la voz neuronal falló (y Julio usó la del teléfono). */
    val errorPiper: StateFlow<String?> = _errorPiper.asStateFlow()

    fun activarPiper(activar: Boolean) {
        _usarPiper.value = activar
        prefs.edit().putBoolean("usarPiper", activar).apply()
        if (activar) _errorPiper.value = null
    }

    /** Libera de la memoria la voz neuronal (al borrarla). */
    fun olvidarPiper() { piper.olvidar() }

    private var tts: TextToSpeech? = null
    private var inicializado = false
    private var listo = false
    private var idioma: Locale? = null
    private var alTerminar: (() -> Unit)? = null
    private var pendiente: Pair<String, () -> Unit>? = null
    private val principal = Handler(Looper.getMainLooper())
    private val prefs = context.applicationContext.getSharedPreferences("julio_voz", Context.MODE_PRIVATE)

    private val _ajustes = MutableStateFlow(
        AjustesVoz(
            voz = prefs.getString("voz", null),
            tono = prefs.getFloat("tono", 0.85f),
            velocidad = prefs.getFloat("velocidad", 0.95f),
        ),
    )
    val ajustes: StateFlow<AjustesVoz> = _ajustes.asStateFlow()

    private val _palabras = MutableStateFlow(0)
    /** Sube en 1 cada vez que el motor empieza una palabra: sirve para animar la boca del gorila. */
    val palabras: StateFlow<Int> = _palabras.asStateFlow()

    init {
        PiperModelo.iniciar(appContext)
        _usarPiper.value = prefs.getBoolean("usarPiper", false)
        tts = TextToSpeech(context.applicationContext) { estado ->
            inicializado = true
            if (estado == TextToSpeech.SUCCESS) configurar()
            val p = pendiente
            pendiente = null
            if (p != null) hablar(p.first, p.second)
        }
    }

    private fun configurar() {
        val t = tts ?: return
        val candidatos = listOf(Locale("es", "MX"), Locale("es", "US"), Locale("es", "ES"), Locale("es"))
        val elegido = candidatos.firstOrNull { t.isLanguageAvailable(it) >= TextToSpeech.LANG_AVAILABLE }
        if (elegido == null) {
            listo = false
            return
        }
        idioma = elegido
        t.setLanguage(elegido)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                _palabras.value = _palabras.value + 1
            }
            override fun onDone(utteranceId: String?) { terminar() }
            @Deprecated("Requerido por la API")
            override fun onError(utteranceId: String?) { terminar() }
        })
        listo = true
        aplicar()
    }

    /** Aplica tono, velocidad y voz guardados. */
    private fun aplicar() {
        val t = tts ?: return
        val a = _ajustes.value
        t.setPitch(a.tono)
        t.setSpeechRate(a.velocidad)
        val nombre = a.voz
        if (nombre != null) {
            val v = try { t.voices?.firstOrNull { it.name == nombre } } catch (e: Exception) { null }
            if (v != null) t.setVoice(v)
        } else {
            // Sin voz elegida: si hay una voz Piper «davefx» (por ejemplo desde SherpaTTS) se usa esa; si no, la de siempre.
            val preferida = try { t.voices?.firstOrNull { it.name.contains(VOZ_PREFERIDA, ignoreCase = true) } } catch (e: Exception) { null }
            if (preferida != null) t.setVoice(preferida) else idioma?.let { t.setLanguage(it) }
        }
    }

    // ---------- selector de voz ----------

    val vocesListas: Boolean get() = listo

    /** Voces en español instaladas: primero las que funcionan sin internet. */
    fun voces(): List<VozInfo> {
        val t = tts ?: return emptyList()
        if (!listo) return emptyList()
        val todas = try { t.voices?.toList().orEmpty() } catch (e: Exception) { emptyList() }
        val es = todas
            .filter { it.locale.language == "es" }
            .sortedWith(compareBy({ it.isNetworkConnectionRequired }, { it.locale.country }, { it.name }))
        return es.mapIndexed { i, v ->
            val pais = v.locale.getDisplayCountry(Locale("es")).ifBlank { "Español" }
            val red = if (v.isNetworkConnectionRequired) "necesita internet" else "sin internet"
            VozInfo(v.name, "Voz ${i + 1} · $pais · ${v.name} · $red")
        }
    }

    fun elegirVoz(nombre: String?) {
        _ajustes.value = _ajustes.value.copy(voz = nombre)
        prefs.edit().apply { if (nombre == null) remove("voz") else putString("voz", nombre) }.apply()
        aplicar()
    }

    fun cambiarTono(tono: Float) {
        _ajustes.value = _ajustes.value.copy(tono = tono)
        prefs.edit().putFloat("tono", tono).apply()
        tts?.setPitch(tono)
    }

    fun cambiarVelocidad(velocidad: Float) {
        _ajustes.value = _ajustes.value.copy(velocidad = velocidad)
        prefs.edit().putFloat("velocidad", velocidad).apply()
        tts?.setSpeechRate(velocidad)
    }

    private fun terminar() {
        principal.post {
            val cb = alTerminar
            alTerminar = null
            cb?.invoke()
        }
    }

    /**
     * Habla con la voz neuronal si está activada y descargada; si falla, usa la voz del teléfono.
     * Si ninguna está disponible, llama a [alTerminar] enseguida: la respuesta igual se ve en pantalla.
     */
    fun hablar(texto: String, alTerminar: () -> Unit) {
        if (_usarPiper.value && piper.listo()) {
            this.alTerminar = alTerminar
            val a = _ajustes.value
            piper.hablar(
                texto, a.tono, a.velocidad,
                alPalabra = { _palabras.value = _palabras.value + 1 },
                alTerminar = { terminar() },
                alFallar = { motivo ->
                    _errorPiper.value = "La voz neuronal falló ($motivo); usé la voz del teléfono."
                    hablarConSistema(texto, alTerminar)
                },
            )
            return
        }
        hablarConSistema(texto, alTerminar)
    }

    private fun hablarConSistema(texto: String, alTerminar: () -> Unit) {
        val t = tts
        if (t == null) { alTerminar(); return }
        if (!inicializado) { pendiente = texto to alTerminar; return }
        if (!listo) { alTerminar(); return }
        this.alTerminar = alTerminar
        val r = t.speak(texto, TextToSpeech.QUEUE_FLUSH, null, "julio")
        if (r == TextToSpeech.ERROR) {
            this.alTerminar = null
            alTerminar()
        }
    }

    fun detener() {
        alTerminar = null
        pendiente = null
        piper.detener()
        tts?.stop()
    }

    val disponible: Boolean get() = (_usarPiper.value && piper.listo()) || !inicializado || listo

    fun cerrar() {
        piper.cerrar()
        detener()
        tts?.shutdown()
        tts = null
    }
}
