package com.julio.asistente.voz

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

sealed class EstadoPiper {
    object NoDescargada : EstadoPiper()
    data class Descargando(val progreso: Float, val mb: Long) : EstadoPiper()
    object Lista : EstadoPiper()
    data class Error(val mensaje: String) : EstadoPiper()
}

/**
 * La voz neuronal «es_MX-claude-high» (Piper, español de México, licencia Apache-2.0 según su ficha).
 * Pesa unos 67 MB, así que no va dentro del APK: se descarga UNA vez (con internet) y después se usa sin conexión.
 * El paquete trae el modelo, `tokens.txt` y `espeak-ng-data` (los datos de pronunciación que Piper necesita).
 */
object PiperModelo {
    const val ID = "es_MX-claude-high"
    const val TAMANO_APROX_MB = 67
    private val URLS = listOf(
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-es_MX-claude-high.tar.bz2",
        "https://huggingface.co/streamkit/piper-models/resolve/main/vits-piper-es_MX-claude-high.tar.bz2",
    )

    class Rutas(val modelo: String, val tokens: String, val datos: String)

    private val _estado = MutableStateFlow<EstadoPiper>(EstadoPiper.NoDescargada)
    val estado: StateFlow<EstadoPiper> = _estado.asStateFlow()

    private val alcance = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var cancelado = false

    private fun carpeta(c: Context) = File(c.applicationContext.filesDir, "piper/$ID")

    /** Busca los tres archivos que necesita el motor dentro de una carpeta. null = faltan. */
    private fun localizar(raiz: File): Rutas? {
        if (!raiz.isDirectory) return null
        val onnx = raiz.walkTopDown().firstOrNull { it.isFile && it.name.endsWith(".onnx") } ?: return null
        val base = onnx.parentFile ?: return null
        val tokens = File(base, "tokens.txt")
        val datos = File(base, "espeak-ng-data")
        if (!tokens.isFile || !datos.isDirectory || datos.listFiles().isNullOrEmpty()) return null
        return Rutas(onnx.absolutePath, tokens.absolutePath, datos.absolutePath)
    }

    fun rutas(c: Context): Rutas? = localizar(carpeta(c))

    /** Al abrir la app: ¿ya está descargada? */
    fun iniciar(c: Context) {
        if (_estado.value is EstadoPiper.Descargando) return
        _estado.value = if (rutas(c) != null) EstadoPiper.Lista else EstadoPiper.NoDescargada
    }

    fun descargar(c: Context) {
        if (_estado.value is EstadoPiper.Descargando) return
        val app = c.applicationContext
        cancelado = false
        _estado.value = EstadoPiper.Descargando(0f, 0)
        alcance.launch {
            val temporal = File(app.filesDir, "piper/.descarga_$ID")
            try {
                var ultimo: Exception? = null
                var bajada = false
                for (url in URLS) {
                    temporal.deleteRecursively()
                    temporal.mkdirs()
                    try {
                        bajarYExtraer(url, temporal)
                        bajada = true
                        break
                    } catch (e: Exception) {
                        if (cancelado) throw e
                        ultimo = e
                    }
                }
                if (!bajada) throw ultimo ?: IOException("No se pudo descargar")
                if (localizar(temporal) == null) throw IOException("El paquete descargado no trae todos los archivos de la voz")
                val destino = carpeta(app)
                destino.deleteRecursively()
                destino.parentFile?.mkdirs()
                if (!temporal.renameTo(destino)) throw IOException("No pude guardar la voz en la memoria de Julio")
                _estado.value = if (localizar(destino) != null) EstadoPiper.Lista else EstadoPiper.Error("La voz no quedó completa")
            } catch (e: Exception) {
                temporal.deleteRecursively()
                _estado.value = if (cancelado) EstadoPiper.NoDescargada
                else EstadoPiper.Error("No pude descargar la voz: ${e.message ?: e.javaClass.simpleName}. Revisa tu conexión e inténtalo otra vez.")
            }
        }
    }

    fun cancelar() { cancelado = true }

    fun eliminar(c: Context) {
        cancelado = true
        carpeta(c).deleteRecursively()
        _estado.value = EstadoPiper.NoDescargada
    }

    private class Contador(entrada: InputStream, private val alLeer: (Long) -> Unit) : FilterInputStream(entrada) {
        private var total = 0L
        override fun read(): Int {
            val b = super.read()
            if (b >= 0) { total++; alLeer(total) }
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { total += n; alLeer(total) }
            return n
        }
    }

    /** Baja el .tar.bz2 y lo va descomprimiendo al vuelo (no hace falta espacio extra para el archivo comprimido). */
    private fun bajarYExtraer(url: String, destino: File) {
        val conexion = URL(url).openConnection() as HttpURLConnection
        conexion.connectTimeout = 20_000
        conexion.readTimeout = 30_000
        conexion.instanceFollowRedirects = true
        try {
            if (conexion.responseCode !in 200..299) throw IOException("el servidor respondió ${conexion.responseCode}")
            val total = conexion.contentLengthLong
            var porcentajePublicado = -1
            val contado = Contador(conexion.inputStream) { leidos ->
                if (cancelado) throw IOException("Descarga cancelada")
                val p = if (total > 0) (leidos * 100 / total).toInt() else -1
                if (p != porcentajePublicado) {
                    porcentajePublicado = p
                    _estado.value = EstadoPiper.Descargando(if (total > 0) leidos.toFloat() / total else -1f, leidos / 1_000_000)
                }
            }
            val raiz = destino.canonicalFile
            TarArchiveInputStream(BZip2CompressorInputStream(BufferedInputStream(contado))).use { tar ->
                var entrada = tar.nextEntry
                while (entrada != null) {
                    val salida = File(raiz, entrada.name).canonicalFile
                    if (!salida.path.startsWith(raiz.path + File.separator)) throw IOException("Archivo con ruta no válida")
                    if (entrada.isDirectory) {
                        salida.mkdirs()
                    } else {
                        salida.parentFile?.mkdirs()
                        salida.outputStream().use { fuera -> tar.copyTo(fuera) }
                    }
                    entrada = tar.nextEntry
                }
            }
        } finally {
            conexion.disconnect()
        }
    }
}
