# PLAN DE TRABAJO — Proyecto Julio

> Fuente principal de continuidad. Léelo primero; no releas todo el documento de requisitos.
> Última actualización: Tareas verificada; Horario y Alarmas compilan (alarmas: corregido permiso exacto en v07/v08, pendiente de confirmar); Enfoque y Metas escritos (sin compilar).

## 1. Decisiones técnicas
| Tema | Decisión | Motivo |
|---|---|---|
| Lenguaje / UI | **Kotlin nativo + Jetpack Compose (Material 3)** | Alarmas exactas, servicios en segundo plano, AccessibilityService/UsageStats y SpeechRecognizer/TextToSpeech son APIs nativas de Android; sin capa intermedia. |
| minSdk / target | 26 (Android 8.0) / 35 | Iconos adaptativos y canales de notificación sin parches. |
| Almacenamiento | **Room (SQLite)** 2.6.1 vía KSP; DataStore para preferencias (Etapa 5+) | Persistencia local, consultas por fecha, sin servidor. |
| Arquitectura | UI (Compose) → ViewModel → repositorio → DAO. Interpretación de comandos separada de UI y datos. | Requisito 3 y 11. |
| Build | Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01 | Combinación compatible conocida. |
| Paquete | `com.julio.asistente` | |

## 2. Estructura
```
app/src/main/java/com/julio/asistente/
  JulioApp.kt, MainActivity.kt
  ui/ (JulioRoot, navigation/, theme/, components/, screens/)
  data/local/ (Entidades, Daos, JulioDatabase)
  voz/ comandos/ horario/ tareas/ alarmas/ metas/ enfoque/ core/   <- reservados (LEEME.txt)
```

## 3. Limitaciones de Android a abordar
- **Voz**: `SpeechRecognizer` necesita permiso RECORD_AUDIO; el reconocimiento offline depende del paquete de idioma y del dispositivo. `TextToSpeech` usará la mejor voz masculina en español instalada (la disponibilidad varía por fabricante). Servicio externo de voz/IA: solo con aviso de datos enviados, coste y clave guardada fuera del repositorio.
- **Conversación real**: requiere un modelo de lenguaje externo (API con clave del usuario). Sin ella, solo comandos estructurados; no se simulará con respuestas fijas.
- **Alarmas**: `AlarmManager.setAlarmClock()` / exactas (`SCHEDULE_EXACT_ALARM` en Android 12+, `POST_NOTIFICATIONS` en 13+), reprogramar tras reinicio (`BOOT_COMPLETED`). Restricciones de batería por fabricante: se documentarán.
- **Bloqueo de apps**: solo viable con `PACKAGE_USAGE_STATS` + superposición o `AccessibilityService`, con consentimiento explícito. Se entrega primero el temporizador funcional.

## 3b. Referencia visual de la pantalla Voz (pedida por el usuario)
Imagen: `docs/referencia_voz_orbe.jpg`. Muestra a Julio dentro de un orbe azul neón con anillos y una onda de audio debajo, el título «JULIO» arriba y el estado «Escuchando...» abajo.
Decisiones para la Etapa 3b/8:
- El orbe se dibuja en Compose (anillos y barras de onda animados) alrededor del gorila original; la imagen de referencia tiene el texto «Escuchando...» fijo, así que no se usa tal cual.
- El texto de estado cambia según el estado real: Escuchando / Procesando / Respondiendo / En reposo.
- La animación solo se activa cuando el reconocimiento de voz esté realmente escuchando (nunca decorativa).
- El gorila debe seguir siendo la imagen original del usuario.

## 4. Estado de las etapas
| Etapa | Estado |
|---|---|
| 1 Planificación | ✅ Hecha (este documento) |
| 2 Base (proyecto, navegación, tema, Room) | ✅ Compila en GitHub Actions; abre en el teléfono, las 5 pestañas navegan |
| 3 Identidad visual | ✅ Icono real y mascota; pantalla Voz con orbe animado (sin probar en teléfono) |
| 4 Horario y Tareas | 🟡 Tareas ✅ (el usuario confirmó que funciona); Horario escrito, **sin compilar ni probar** |
| 5 Alarmas y recordatorios | 🟡 Escritas (AlarmManager.setAlarmClock + servicio + pantalla de alarma), **sin compilar ni probar**. Recordatorios de Horario/Tareas: pendientes (requieren migración de BD v1→v2) |
| 6 Modo enfoque | 🟡 Temporizador real + bloqueo de apps con consentimiento escritos (sin compilar/probar) |
| 7 Mis metas | 🟡 CRUD + progreso escrito dentro de Voz (sin compilar/probar) |
| 8 Voz e inteligencia | 🟡 Voz (SpeechRecognizer + TextToSpeech), orbe, guía e intérprete local escritos (sin compilar/probar). IA externa para conversación general: PENDIENTE |
| 9 Integración, pruebas, APK de producción | ⬜ |

## 5. Qué se verificó y qué NO
**Verificado en teléfono real (APK debug de la Etapa 2)**: la app abre, las 5 pestañas navegan, la mascota se ve completa en Voz.
**Sin confirmar**: que el icono aparezca en el lanzador (el usuario aún no lo reportó).
**Tareas**: compilada por Actions y probada por el usuario en su teléfono (funciona).
**Horario** y **Alarmas**: código escrito sin SDK; **no compilados ni probados**. Se verificarán con el siguiente build y en el teléfono. Las alarmas **solo pueden validarse en un dispositivo real**.
**No hay APK de producción** (solo debug).
Pruebas automatizadas: ninguna todavía.

## 6. Cómo compilar
- **Android Studio** (recomendado): abrir la carpeta, dejar sincronizar Gradle, `Build > Build APK(s)`. Ruta: `app/build/outputs/apk/debug/app-debug.apk`.
- **GitHub Actions**: `.github/workflows/build.yml` compila en cada push a `desarrollo-julio` y sube la APK como artefacto.
- El wrapper (`gradlew`) no está incluido; Android Studio lo genera, o `gradle wrapper --gradle-version 8.9`.
- APK de producción: requiere keystore propio (Etapa 9). Nunca subirlo al repositorio.

## 7. Errores conocidos / pendientes
- Enfoque es un aviso «Aún no implementado».
- Horario: repeticiones calculadas (diaria/semanal/mensual); editar/eliminar afecta a toda la serie; hora de fin opcional, mismo día.
- **Alarmas (Etapa 5, sin probar)**:
  - Mecanismo: `AlarmManager.setAlarmClock()` (atraviesa Doze). **Corrección**: en la v06 se creyó que no necesitaba permiso de alarmas exactas; en Android 12+ SÍ lo necesita (falló en el teléfono real: «No se pudo programar»). Desde la v07 se declaran USE_EXACT_ALARM (13+) y SCHEDULE_EXACT_ALARM (31-32), y la pantalla muestra el motivo técnico real si falla. `AlarmaReceiver` → `AlarmaService` (primer plano, mediaPlayback) → `AlarmaActivity` (sobre pantalla bloqueada). Respaldo: notificación con sonido si el sistema bloquea el servicio.
  - Permisos: USE_EXACT_ALARM, SCHEDULE_EXACT_ALARM (≤32), POST_NOTIFICATIONS (se pide en pantalla Alarmas), USE_FULL_SCREEN_INTENT (Android 14+ puede revocarlo; la pantalla lo avisa), FOREGROUND_SERVICE(+_MEDIA_PLAYBACK), RECEIVE_BOOT_COMPLETED, VIBRATE, WAKE_LOCK.
  - Una sola vez: se fija la fecha concreta al guardar; tras sonar se desactiva. Repetitivas: se reprograma la siguiente al sonar. Posponer = 10 min (constante `MINUTOS_POSPONER`, aún no configurable). Se detiene sola a los 5 min.
  - Se reprograman tras reinicio, actualización de la APK y cambio de hora/zona (`ArranqueReceiver`). Una alarma que vence con el teléfono apagado NO suena después.
  - Dudas a verificar en teléfono real: inicio del servicio desde el receptor (Android 12+), sonido con volumen de alarma, pantalla sobre bloqueo, restricciones de batería/autoarranque del fabricante (Xiaomi, Samsung, etc.: puede requerir permitir «inicio automático» y «sin restricciones de batería»).
  - Sonido: selector del sistema (TYPE_ALARM); si el sonido elegido falla, cae al predeterminado.
- **Enfoque (Etapa 6, sin probar)**: estado en SharedPreferences (`enfoque/EnfoqueControl.kt`), fin avisado por `AlarmManager.setExactAndAllowWhileIdle` (cae a inexacta si falta permiso) → `EnfoqueReceiver`. Notificación con cuenta regresiva (cronómetro) mientras corre; aviso con sonido al terminar. Duraciones personalizadas (1 min–12 h enfoque, 1 min–4 h descanso), presets 25/35/50/70/80 y 5/10/15/20. Pausar/reanudar/finalizar y encadenar descanso. Se reprograma tras reinicio/actualización (`ArranqueReceiver`).
- **Bloqueo de apps (sin probar; es lo más dependiente del fabricante)**: apagado por defecto. En Enfoque, tarjeta «Bloqueo de aplicaciones» con interruptor → diálogo de consentimiento (qué hace, qué permisos, qué nunca bloquea, cómo salir) → el usuario concede en Ajustes: **Acceso de uso** (`PACKAGE_USAGE_STATS`) y **Mostrar sobre otras apps** (`SYSTEM_ALERT_WINDOW`), y elige las apps (lista de apps con icono de lanzador vía `<queries>`). Solo bloquea durante un ENFOQUE en marcha (no pausa ni descanso). Mecanismo: `bloqueo/BloqueoService` (primer plano `specialUse`) consulta `UsageStatsManager.queryEvents` cada 600 ms y, si la app en primer plano está elegida, dibuja una ventana `TYPE_APPLICATION_OVERLAY` con «Ir al inicio» y «Finalizar sesión de enfoque» (2 toques). Nunca bloquea: Julio, marcador/llamadas (`TelecomManager.defaultDialerPackage` + lista fija), emergencias, Ajustes, SystemUI ni el launcher (`BloqueoControl.protegidas`). Se detiene si se apaga el interruptor, se revoca un permiso o termina/pausa el enfoque. No lee contenido de apps ni envía datos.
  - Limitaciones conocidas: el arranque tras reinicio/actualización puede ser bloqueado por Android al iniciar un servicio en primer plano desde segundo plano (se captura el error en `BloqueoControl.ultimoError`); Xiaomi/HyperOS, Samsung, etc. pueden exigir «inicio automático» y batería «sin restricciones»; un usuario puede salirse apagando permisos en Ajustes (por diseño: no se eludirá la protección del sistema).
- **Voz (Etapa 3b/8, sin probar)**:
  - Reconocimiento: `SpeechRecognizer` del teléfono (en muchos equipos necesita internet; el error de red se muestra claro). Permiso RECORD_AUDIO se pide al tocar «Hablar con Julio». Respuesta hablada: `TextToSpeech` en español, tono 0.85 / velocidad 0.95. **No se puede garantizar voz masculina**: depende de las voces instaladas; pendiente un selector de voz.
  - Orbe v13 (`ui/components/Orbe.kt`), pedido del usuario: sin caja, flota sobre el fondo de la app (disco con borde suave), anillos con halo, arcos giratorios, ondas hacia afuera, barras radiales (ecualizador circular) y el gorila (`drawable-nodpi/julio_orbe.png`, MISMO dibujo original sin el fondo azul de la baldosa; el icono de la app no cambia). Al responder, la quijada se estira (división en la línea de la boca, 52.8 % de la imagen, hasta +9 %) al ritmo de cada palabra (`Habla.palabras` ← `onRangeStart`) con un vaivén de respaldo; no es sincronía exacta de labios. En reposo respira muy despacio (animación mínima mientras la pestaña Voz está visible). Referencia original: `docs/referencia_voz_orbe.jpg`. El usuario recuerda un orbe de «las primeras versiones»: esa versión NO estaba disponible para el asistente; pedir captura si se quiere igualar.
  - Guía de comandos en pestañas (chips): Horario, Lista de tareas, Alarmas, Modo enfoque, Mis metas; al tocar una se despliega «Puedes decirle a Julio:» con ejemplos tocables; tocar de nuevo la cierra.
  - Intérprete local (`comandos/`): `Texto` (números, horas, fechas, duraciones) + `Interprete` (frases -> `Intencion`) + `Asistente` (ejecuta contra la BD y **verifica antes de confirmar**). Conversación de varios turnos con `Esperando`. Probado en lógica con un espejo en Python (todas las frases de la guía) y con `InterpreteTest.kt` (ejecutar `gradle testDebugUnitTest` en Android Studio; CI no corre tests).
  - Heurística de hora sin «mañana/tarde»: horario 1–6 = tarde, 7–11 = mañana; alarma 1–11 = mañana. Siempre se repite la hora resuelta al confirmar.
  - Historial de conversación: solo en memoria (no persiste), por diseño de esta versión.
  - Lo que NO hace aún: conversación general («¿cómo funciona X?»). Responde honestamente que no lo entendió como orden. Falta IA externa opcional (clave guardada cifrada, aviso de qué datos se envían y coste).
  - Limitaciones del intérprete: hora de fin («de 8 a 10») no soportada; no edita actividades por voz; eliminar por voz no soportado.
- **Metas (Etapa 7, sin probar)**: `ui/screens/MetasSection.kt` dentro de `VozScreen`: crear, editar (título/descripción/fecha objetivo), actualizar progreso (slider 0–100 %, 100 % = completada), marcar completada, eliminar con confirmación. Voz de metas («Muéstrame mis metas») llega con la etapa de voz.
- **Recordatorios (sin probar)**: Horario → aviso 0/5/10/15/30/60 min antes (columna `actividades.recordatorioMin`, se rearma tras cada aviso si es repetitiva); Tareas → aviso a una hora elegida el día de la fecha límite (`tareas.recordatorioMinutoDia`; se cancela al completar). Mecanismo: `recordatorios/` (AlarmManager exacta + `RecordatorioReceiver` + canal «Recordatorios»); se reprograman tras reinicio/actualización. **Base de datos v2**: migración 1→2 con `ALTER TABLE ... ADD COLUMN` (columnas anulables, no borra datos). Si la app se cierra al abrir tras actualizar, sospechar de esta migración.
- Fecha límite de tareas = medianoche UTC del día elegido (`core/Fechas.kt`).
- Flujo de subida del usuario (celular): sube `Julio_proyecto_vNN.zip` a la raíz del repo; el workflow descomprime el zip de nombre más alto (etapa2, etapa4, v05, v06...).

## 8. Siguiente tarea concreta
0. (v12) Probar Voz: permiso de micrófono, orbe, «Hablar con Julio», comandos de la guía, escribir comandos, respuesta hablada.
1. Compilar y probar en el teléfono: Alarmas (con permiso exacto), Enfoque y Metas.
2. Pantalla Voz con orbe (ver §3b), guía «¿Qué puedo decirle a Julio?» y luego Etapa 8 (voz + intérprete de comandos + IA externa opcional).
4. Etapa 9: pruebas finales y APK de producción firmada.

## 9. Prompt para continuar en otro chat
> Continúa el proyecto Julio (app Android, Kotlin + Compose). Lee primero `PLAN_DE_TRABAJO.md`. No reinicies ni reescribas lo hecho. Estado: Etapas 1-2 escritas (sin compilar), icono listo. Empieza por la «Siguiente tarea concreta». Archivos a revisar: `PLAN_DE_TRABAJO.md`, `app/build.gradle.kts`, `gradle/libs.versions.toml`, `data/local/*`, `ui/JulioRoot.kt`, `ui/screens/*`. Trabaja por etapas, sé honesto sobre lo verificado y actualiza el plan al final.


## v14 — Cabina futurista + saludo + editar/eliminar por voz + selector de voz (entrega combinada 1+2+3-parcial)

Confirmado por el usuario antes de v14: alarmas, recordatorios y diferenciación horario/tareas funcionan perfecto.

- **Diseño «cabina»** (todo el app): tema SIEMPRE oscuro (neón cian/azul, esquinas cortadas, tipografía con letra espaciada), fondo con cuadrícula y resplandor, encabezado con hora y fecha, barra inferior con línea de neón, `PanelJulio` (tarjeta con borde de neón) reemplaza a `Card` en todas las pantallas. Archivos: `ui/theme/*`, `ui/components/Hud.kt`, `ui/JulioRoot.kt`. Barras del sistema forzadas a iconos claros (MainActivity y AlarmaActivity).
- **Orbe holográfico** (`ui/components/Orbe.kt`): gorila protagonista (mismo dibujo recortado, `drawable-nodpi/julio_orbe.png` 568×665), bordes desvanecidos + líneas de holograma + barrido de luz, anillos 3D que giran (mitad detrás/mitad delante), partículas orbitando, plataforma de proyección con ecualizador. Estados: reposo (respira), escuchando (inclina la cabeza, reacciona al micrófono), procesando (anillos rápidos, ojos brillan), respondiendo (quijada se abre al ritmo de cada palabra vía `onRangeStart` + vaivén de respaldo). OJO: nunca compilado/visto en teléfono real al escribir esto; si se ve raro, ajustar proporciones en `Orbe.kt` (gw 0.58, gy 0.115, plataforma 0.87, vignette 0.74).
- **Saludo al abrir** (`Asistente.saludo()` + `VozViewModel`): resumen real de actividades que quedan hoy y tareas pendientes/vencidas; como máximo uno cada 30 min; se puede apagar (switch «Saludo al abrir la app»).
- **Eliminar, mover y renombrar por voz** (`Interprete` + `Asistente` + `Esperando`): eliminar tarea/actividad/alarma/meta SIEMPRE con confirmación sí/no (si hay varias coincidencias, lista y pide cuál); mover actividad («para el viernes a las cuatro»); renombrar tarea; cambiar hora de una alarma («de las seis a las siete»). Se arregló además que «de las seis» (en vez de «a las seis») no se leía como hora al desactivar/activar alarmas. Validado con espejo en Python (`/home/claude/test/nuevas.py`, 38 frases incl. regresiones) + 8 pruebas unitarias nuevas en `InterpreteTest.kt`.
- **Selector de voz** (`voz/Habla.kt`): lista las voces en español instaladas (primero las que no requieren internet), tono 0.5–1.4, velocidad 0.6–1.3, botón «Probar voz», acceso a Ajustes de Android > Texto a voz para instalar más voces. Se guarda en SharedPreferences `julio_voz`.
- **NO incluido todavía**: voz neuronal local tipo Piper (necesita descargar modelos/bibliotecas; el entorno del asistente no tiene red — habría que decidir cómo agregarlos al repo), plan de estudio diario (entrega 4), modo estudio con racha (5), extras: personalidad/clima/copias de seguridad (6), APK de producción firmado (7).
- **Siguiente tarea concreta**: confirmar con el usuario cómo se ve/siente v14 (orbe, estilo, saludo, borrar con confirmación). Luego entrega 4: plan de estudio diario (examen + temas → sesiones de enfoque repartidas por día, aviso diario, «¿cómo te fue?»).


## v15 — Legibilidad desde el origen + horarios de varios días (pedido del usuario)

Prioridad del usuario tras v14: (1) arreglar textos negros/ilegibles, (2) horarios para varios días de la semana. «Olvida lo de la voz» = olvidar la voz neuronal (Piper); los comandos de voz para horarios SÍ se hicieron. El prompt que pasó el usuario hablaba de Flutter/Dart, pero Julio es Kotlin + Compose: se aplicó a este código.

- **Causa del texto negro (error introducido en v14):** `Scaffold(containerColor = Transparent)` dejó el color de contenido por defecto (negro). Arreglo en el origen: `JulioTheme` ahora fija `LocalContentColor` claro para toda la app, y el Scaffold de `JulioRoot` usa `contentColor = onBackground`. Además `onSurfaceVariant` y `outline` más claros. Contrastes medidos (WCAG): texto principal 14–17:1, secundario 10–12:1, botón 13:1, chip 9:1, borde de campos 6:1 (mínimo AA = 4,5:1). Los textos deshabilitados de Material siguen siendo tenues a propósito.
- **Modelo:** `ActividadEntity` +3 columnas anulables (`diasMascara`, `intervaloSemanas`, `excluidas`); Room v3 con `MIGRACION_2_3` (solo ALTER TABLE ADD COLUMN: las actividades existentes no cambian). `Recurrencia.DIAS` nueva; DIARIA/SEMANAL/MENSUAL siguen como antes.
- **Lógica:** `horario/DiasSemana.kt` (máscaras, `primerDia`, `describir`), `Ocurrencias` entiende DIAS (máscara + cada N semanas) y días excluidos. Las repeticiones se calculan, no se duplican.
- **Formulario (HorarioScreen):** sección «Repetir» con: Una sola vez, Todos los días, Lunes a viernes, Fin de semana, Días elegidos (chips Lun..Dom), Cada varias semanas (2/3/4), Cada mes; resumen «Se repetirá de lunes a viernes». Hora de inicio y de fin ya existían. Al editar/eliminar una actividad que se repite se pregunta: solo ese día (se excluye de la serie y, al editar, se crea una actividad suelta) o toda la serie.
- **Voz:** `Interprete.extraerRepeticion` (de lunes a viernes; los lunes, miércoles y viernes; martes y jueves; todos los días; fines de semana; entre semana; cada dos semanas; cada semana/mes) + `RepetirActividad` («repite esta actividad todos los martes y jueves», usa la última actividad agregada). `Asistente.agregarHorario` pregunta lo que falta (nombre, hora, días), guarda, VUELVE A LEER de la base y comprueba tipo de repetición, hora y que el primer día realmente ocurra; solo entonces confirma («He programado «Clases» de lunes a viernes a las 7:00 a. m.»); si no cuadra, borra lo guardado y avisa. Mover una serie por días con una fecha nueva no se permite por voz (se explica cómo cambiar los días).
- **Pruebas:** espejo en Python (`/home/claude/test/rep.py`, 31 frases) + `InterpreteTest` (+9) y `OcurrenciasTest` (nuevo, 10 pruebas). NO se ejecutaron con Gradle (sin toolchain en el entorno del asistente); el CI no corre tests: `gradle testDebugUnitTest`.
- **Aparcado:** borrador del plan de estudio diario en `docs/pendiente_estudio/*.kt.txt` (no compila, no forma parte de la app).
- **Siguiente tarea concreta:** confirmar con el usuario (a) texto legible en todas las pantallas, (b) horarios de varios días por formulario y por voz. Luego retomar plan de estudio (entregas 4+5).
