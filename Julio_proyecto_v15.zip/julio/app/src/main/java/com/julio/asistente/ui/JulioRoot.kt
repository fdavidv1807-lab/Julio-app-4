package com.julio.asistente.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.julio.asistente.ui.components.EncabezadoHud
import com.julio.asistente.ui.components.FondoHud
import com.julio.asistente.ui.navigation.Destino
import com.julio.asistente.ui.screens.AlarmasScreen
import com.julio.asistente.ui.screens.EnfoqueScreen
import com.julio.asistente.ui.screens.HorarioScreen
import com.julio.asistente.ui.screens.TareasScreen
import com.julio.asistente.ui.screens.VozScreen
import com.julio.asistente.ui.theme.NeonCian

@Composable
fun JulioRoot() {
    val nav = rememberNavController()
    val entrada by nav.currentBackStackEntryAsState()
    val rutaActual = entrada?.destination?.route

    FondoHud {
        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            topBar = { EncabezadoHud() },
            bottomBar = {
                NavigationBar(
                    containerColor = Color(0xF0060F22),
                    tonalElevation = 0.dp,
                    modifier = Modifier.drawBehind {
                        drawLine(NeonCian.copy(alpha = 0.45f), Offset(0f, 0f), Offset(size.width, 0f), 1.5f)
                    },
                ) {
                    Destino.entries.forEach { d ->
                        NavigationBarItem(
                            selected = rutaActual == d.ruta,
                            onClick = {
                                nav.navigate(d.ruta) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(d.icono, contentDescription = d.titulo) },
                            label = { Text(d.titulo) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonCian,
                                selectedTextColor = NeonCian,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            ),
                        )
                    }
                }
            },
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Destino.VOZ.ruta,
                modifier = Modifier.padding(padding),
            ) {
                composable(Destino.VOZ.ruta) { VozScreen() }
                composable(Destino.HORARIO.ruta) { HorarioScreen() }
                composable(Destino.TAREAS.ruta) { TareasScreen() }
                composable(Destino.ALARMAS.ruta) { AlarmasScreen() }
                composable(Destino.ENFOQUE.ruta) { EnfoqueScreen() }
            }
        }
    }
}
