package com.julio.asistente.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.ui.components.Orbe
import com.julio.asistente.ui.components.PanelJulio
import com.julio.asistente.voz.EstadoVoz
import com.julio.asistente.voz.VozViewModel

private class CategoriaGuia(val titulo: String, val ejemplos: List<String>)

/** Solo ejemplos que el intérprete realmente entiende hoy (verificados con pruebas de la lógica). */
private val GUIA = listOf(
    CategoriaGuia("Horario", listOf(
        "¿Qué tengo programado hoy?",
        "Agrega laboratorio de química mañana a las dos de la tarde",
        "Programa clases de lunes a viernes a las siete de la mañana",
        "Agrega estudio de medicina los lunes, miércoles y viernes a las cuatro de la tarde",
        "Programa gimnasio todos los días a las dos de la tarde",
        "Repite esta actividad todos los martes y jueves",
        "¿Qué clases tengo el lunes?",
        "Mueve el laboratorio de química para el viernes a las cuatro de la tarde",
        "Elimina la clase de anatomía",
    )),
    CategoriaGuia("Lista de tareas", listOf(
        "Agrega estudiar anatomía a mis tareas",
        "¿Qué tareas tengo pendientes?",
        "Marca como terminada la tarea del informe",
        "Cambia el nombre de la tarea informe por informe final",
        "Elimina la tarea del informe",
    )),
    CategoriaGuia("Alarmas", listOf(
        "Pon una alarma para mañana a las seis de la mañana",
        "Desactiva la alarma del domingo",
        "Cambia la alarma de las seis a las siete",
        "Elimina la alarma de las seis",
    )),
    CategoriaGuia("Modo enfoque", listOf(
        "Inicia una sesión de enfoque de 35 minutos",
        "Quiero estudiar durante una hora y veinte minutos",
        "Configura un descanso de diez minutos",
    )),
    CategoriaGuia("Mis metas", listOf(
        "Muéstrame mis metas",
        "Quiero agregar una meta nueva",
        "Actualiza el progreso de mi meta",
        "Elimina la meta de leer",
    )),
)

private fun abrirAjustesDeVoz(ctx: Context) {
    try {
        ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

@Composable
fun VozScreen(vm: VozViewModel = viewModel()) {
    val ctx = LocalContext.current
    val estado by vm.estado.collectAsStateWithLifecycle()
    val transcripcion by vm.transcripcion.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val historial by vm.historial.collectAsStateWithLifecycle()
    val nivel by vm.nivel.collectAsStateWithLifecycle()
    val palabras by vm.palabras.collectAsStateWithLifecycle()
    val hablar by vm.hablarRespuestas.collectAsStateWithLifecycle()
    val saludo by vm.saludoActivo.collectAsStateWithLifecycle()
    var categoria by rememberSaveable { mutableStateOf(-1) }
    var ajustesAbiertos by rememberSaveable { mutableStateOf(false) }
    var texto by remember { mutableStateOf("") }

    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { concedido ->
        if (concedido) vm.escuchar() else vm.reportarPermisoDenegado()
    }

    fun enviar() {
        vm.enviarTexto(texto)
        texto = ""
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Orbe(
            estado = estado,
            nivel = nivel,
            palabras = palabras,
            modifier = Modifier.fillMaxWidth().widthIn(max = 400.dp).align(Alignment.CenterHorizontally),
        )
        Text(
            when (estado) {
                EstadoVoz.REPOSO -> "LISTO"
                EstadoVoz.ESCUCHANDO -> "ESCUCHANDO..."
                EstadoVoz.PROCESANDO -> "PROCESANDO..."
                EstadoVoz.RESPONDIENDO -> "RESPONDIENDO..."
            },
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )

        // Controles principales
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val ocupado = estado == EstadoVoz.PROCESANDO
            Button(
                enabled = !ocupado && estado != EstadoVoz.ESCUCHANDO,
                onClick = {
                    if (vm.permisoMicrofono()) vm.escuchar() else pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO)
                },
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.height(56.dp),
            ) {
                Icon(Icons.Filled.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Hablar con Julio")
            }
            if (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.RESPONDIENDO) {
                OutlinedButton(
                    onClick = { vm.detener() },
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.height(56.dp),
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Detener")
                }
            }
        }

        // Transcripción en vivo
        if (transcripcion.isNotBlank() && (estado == EstadoVoz.ESCUCHANDO || estado == EstadoVoz.PROCESANDO)) {
            Text("Dijiste: $transcripcion", style = MaterialTheme.typography.bodyMedium)
        }

        // Errores claros
        error?.let { mensaje ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(mensaje, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    Row {
                        if (!vm.permisoMicrofono()) {
                            TextButton(onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")),
                                )
                            }) { Text("Abrir ajustes de la app") }
                        }
                        TextButton(onClick = { vm.limpiarError() }) { Text("Cerrar") }
                    }
                }
            }
        }

        // Escribir en vez de hablar
        OutlinedTextField(
            value = texto,
            onValueChange = { texto = it },
            label = { Text("O escríbele a Julio") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { enviar() }),
            trailingIcon = {
                IconButton(enabled = texto.isNotBlank(), onClick = { enviar() }) {
                    Icon(Icons.Filled.Send, contentDescription = "Enviar")
                }
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Respuestas habladas", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = hablar, onCheckedChange = { vm.alternarHablar() })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Saludo al abrir la app", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Switch(checked = saludo, onCheckedChange = { vm.alternarSaludo() })
        }

        // Voz de Julio
        OutlinedButton(onClick = { ajustesAbiertos = !ajustesAbiertos }, shape = MaterialTheme.shapes.small) {
            Text(if (ajustesAbiertos) "Ocultar ajustes de voz" else "Ajustes de voz")
        }
        AnimatedVisibility(visible = ajustesAbiertos) {
            AjustesVozPanel(vm = vm, alAbrirSistema = { abrirAjustesDeVoz(ctx) })
        }

        // Conversación (solo de esta sesión)
        if (historial.isNotEmpty()) {
            Text("Conversación", style = MaterialTheme.typography.titleMedium)
            historial.takeLast(8).forEach { m ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (m.deUsuario) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            if (m.deUsuario) "TÚ" else "JULIO",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Text(m.texto, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            Text(
                "La conversación no se guarda: se borra al cerrar la app. Tus tareas, horario, alarmas y metas sí se guardan.",
                style = MaterialTheme.typography.labelSmall,
            )
        }

        // Guía de comandos en pestañas: ocupa espacio solo cuando abres una
        Text("¿Qué puedo decirle a Julio?", style = MaterialTheme.typography.titleLarge)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            GUIA.forEachIndexed { indice, cat ->
                FilterChip(
                    selected = categoria == indice,
                    onClick = { categoria = if (categoria == indice) -1 else indice },
                    label = { Text(cat.titulo) },
                )
            }
        }
        val abierta = GUIA.getOrNull(categoria)
        AnimatedVisibility(visible = abierta != null) {
            if (abierta != null) {
                PanelJulio(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "Puedes decirle a Julio:",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        abierta.ejemplos.forEach { ejemplo ->
                            Text(
                                "«$ejemplo»",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { vm.enviarTexto(ejemplo) }
                                    .padding(vertical = 8.dp),
                            )
                        }
                        Text("Toca un ejemplo para probarlo.", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        MetasSection()
    }
}

@Composable
private fun AjustesVozPanel(vm: VozViewModel, alAbrirSistema: () -> Unit) {
    val ajustes by vm.ajustesVoz.collectAsStateWithLifecycle()
    var voces by remember { mutableStateOf(vm.vocesDisponibles()) }
    var menu by remember { mutableStateOf(false) }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Voz de Julio", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(
                "Julio habla con las voces instaladas en tu teléfono (funcionan sin internet). " +
                    "No puedo garantizar que alguna sea grave o masculina: eso depende de las voces que tengas. " +
                    "Prueba con el tono más grave, o instala más voces en español desde los ajustes de Android.",
                style = MaterialTheme.typography.bodySmall,
            )
            val actual = voces.firstOrNull { it.nombre == ajustes.voz }?.etiqueta ?: "Predeterminada del teléfono"
            Box {
                OutlinedButton(
                    onClick = { voces = vm.vocesDisponibles(); menu = true },
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(actual, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Predeterminada del teléfono") },
                        onClick = { vm.elegirVoz(null); menu = false },
                    )
                    voces.forEach { v ->
                        DropdownMenuItem(
                            text = { Text(v.etiqueta) },
                            onClick = { vm.elegirVoz(v.nombre); menu = false },
                        )
                    }
                }
            }
            if (voces.isEmpty()) {
                Text(
                    "Todavía no se cargó la lista de voces. Toca el selector otra vez en unos segundos.",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Text("Tono (más grave ← → más agudo)", style = MaterialTheme.typography.labelMedium)
            Slider(value = ajustes.tono, onValueChange = { vm.cambiarTono(it) }, valueRange = 0.5f..1.4f)
            Text("Velocidad (más lenta ← → más rápida)", style = MaterialTheme.typography.labelMedium)
            Slider(value = ajustes.velocidad, onValueChange = { vm.cambiarVelocidad(it) }, valueRange = 0.6f..1.3f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.probarVoz() }, shape = MaterialTheme.shapes.small) { Text("Probar voz") }
                TextButton(onClick = alAbrirSistema) { Text("Más voces (Ajustes)") }
            }
        }
    }
}
