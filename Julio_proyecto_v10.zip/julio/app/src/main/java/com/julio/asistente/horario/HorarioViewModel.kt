package com.julio.asistente.horario

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.JulioApp
import com.julio.asistente.data.local.ActividadEntity
import com.julio.asistente.recordatorios.RecordatorioProgramador
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HorarioViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as JulioApp).database.actividadDao()

    /** null = cargando. La lista siempre refleja lo realmente guardado en la base de datos. */
    val actividades: StateFlow<List<ActividadEntity>?> = dao.observarTodas()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun guardar(a: ActividadEntity) {
        viewModelScope.launch {
            val id = if (a.id == 0L) dao.insertar(a) else {
                dao.actualizar(a)
                a.id
            }
            RecordatorioProgramador.programarActividad(getApplication(), a.copy(id = id))
        }
    }

    fun eliminar(a: ActividadEntity) {
        viewModelScope.launch {
            RecordatorioProgramador.cancelar(getApplication(), RecordatorioProgramador.TIPO_ACTIVIDAD, a.id)
            dao.eliminar(a)
        }
    }
}
