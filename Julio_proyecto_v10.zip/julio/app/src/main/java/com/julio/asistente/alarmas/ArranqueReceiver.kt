package com.julio.asistente.alarmas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.recordatorios.RecordatorioProgramador
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Reprograma las alarmas tras reiniciar, actualizar la app o cambiar la hora/zona horaria. */
class ArranqueReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pendiente = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AlarmaProgramador.reprogramarTodas(app)
                EnfoqueControl.reprogramar(app)
                RecordatorioProgramador.reprogramarTodos(app)
            } finally {
                pendiente.finish()
            }
        }
    }
}
