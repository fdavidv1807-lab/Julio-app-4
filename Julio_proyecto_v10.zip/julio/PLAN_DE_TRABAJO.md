# PLAN DE TRABAJO — Proyecto Julio

> Fuente principal de continuidad. Léelo primero; no releas todo el documento de requisitos.
> Última actualización: Tareas verificada; Horario y Alarmas compilan (alarmas: corregido permiso exacto en v07/v08, pendiente de confirmar); Enfoque y Metas escritos (sin compilar).

## 1. Decisiones técnicas
| Tema | Decisión | Motivo |
|---|---|---|
| Lenguaje / UI | **Kotlin nativo + Jetpack Compose (Material 3)** | Alarmas exactas, servicios en segundo plano, AccessibilityService/UsageStats y SpeechRecognizer/TextToSpeech son APIs nativas de Android; sin capa intermedia. |
| minSdk / target | 26 (Android 8.0) / 35 | Iconos adaptativos y canales de notificación sin parches. |
| Almacenamiento | **Room (SQLite)** 2.6.1 vía KSP; DataStore para preferencias (Etapa 5+) | Persistencia local, consultas por fecha, sin servidor. |
| Arquitectura | UI (Compose) → ViewModel → repositorio → DAO. Interpretación de comandos separada de UI y datos. | Requisito 3 y 11. |
| Build | Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01 | Combinación compatible conocida. |
| Paquete | `com.julio.asistente` | |

## 2. Estructura
```
app/src/main/java/com/julio/asistente/
  JulioApp.kt, MainActivity.kt
  ui/ (JulioRoot, navigation/, theme/, components/, screens/)
  data/local/ (Entidades, Daos, JulioDatabase)
  voz/ comandos/ horario/ tareas/ alarmas/ metas/ enfoque/ core/   <- reservados (LEEME.txt)
```

## 3. Limitaciones de Android a abordar
- **Voz**: `SpeechRecognizer` necesita permiso RECORD_AUDIO; el reconocimiento offline depende del paquete de idioma y del dispositivo. `TextToSpeech` usará la mejor voz masculina en español instalada (la disponibilidad varía por fabricante). Servicio externo de voz/IA: solo con aviso de datos enviados, coste y clave guardada fuera del repositorio.
- **Conversación real**: requiere un modelo de lenguaje externo (API con clave del usuario). Sin ella, solo comandos estructurados; no se simulará con respuestas fijas.
- **Alarmas**: `AlarmManager.setAlarmClock()` / exactas (`SCHEDULE_EXACT_ALARM` en Android 12+, `POST_NOTIFICATIONS` en 13+), reprogramar tras reinicio (`BOOT_COMPLETED`). Restricciones de batería por fabricante: se documentarán.
- **Bloqueo de apps**: solo viable con `PACKAGE_USAGE_STATS` + superposición o `AccessibilityService`, con consentimiento explícito. Se entrega primero el temporizador funcional.

## 3b. Referencia visual de la pantalla Voz (pedida por el usuario)
Imagen: `docs/referencia_voz_orbe.jpg`. Muestra a Julio dentro de un orbe azul neón con anillos y una onda de audio debajo, el título «JULIO» arriba y el estado «Escuchando...» abajo.
Decisiones para la Etapa 3b/8:
- El orbe se dibuja en Compose (anillos y barras de onda animados) alrededor del gorila original; la imagen de referencia tiene el texto «Escuchando...» fijo, así que no se usa tal cual.
- El texto de estado cambia según el estado real: Escuchando / Procesando / Respondiendo / En reposo.
- La animación solo se activa cuando el reconocimiento de voz esté realmente escuchando (nunca decorativa).
- El gorila debe seguir siendo la imagen original del usuario.

## 4. Estado de las etapas
| Etapa | Estado |
|---|---|
| 1 Planificación | ✅ Hecha (este documento) |
| 2 Base (proyecto, navegación, tema, Room) | ✅ Compila en GitHub Actions; abre en el teléfono, las 5 pestañas navegan |
| 3 Identidad visual | 🟡 Icono real (mipmaps + adaptativo) y mascota añadidos; falta pantalla Voz real |
| 4 Horario y Tareas | 🟡 Tareas ✅ (el usuario confirmó que funciona); Horario escrito, **sin compilar ni probar** |
| 5 Alarmas y recordatorios | 🟡 Escritas (AlarmManager.setAlarmClock + servicio + pantalla de alarma), **sin compilar ni probar**. Recordatorios de Horario/Tareas: pendientes (requieren migración de BD v1→v2) |
| 6 Modo enfoque | 🟡 Temporizador real escrito (sin compilar/probar). Bloqueo de apps: NO implementado (ver §7) |
| 7 Mis metas | 🟡 CRUD + progreso escrito dentro de Voz (sin compilar/probar) |
| 8 Voz e inteligencia | ⬜ |
| 9 Integración, pruebas, APK de producción | ⬜ |

## 5. Qué se verificó y qué NO
**Verificado en teléfono real (APK debug de la Etapa 2)**: la app abre, las 5 pestañas navegan, la mascota se ve completa en Voz.
**Sin confirmar**: que el icono aparezca en el lanzador (el usuario aún no lo reportó).
**Tareas**: compilada por Actions y probada por el usuario en su teléfono (funciona).
**Horario** y **Alarmas**: código escrito sin SDK; **no compilados ni probados**. Se verificarán con el siguiente build y en el teléfono. Las alarmas **solo pueden validarse en un dispositivo real**.
**No hay APK de producción** (solo debug).
Pruebas automatizadas: ninguna todavía.

## 6. Cómo compilar
- **Android Studio** (recomendado): abrir la carpeta, dejar sincronizar Gradle, `Build > Build APK(s)`. Ruta: `app/build/outputs/apk/debug/app-debug.apk`.
- **GitHub Actions**: `.github/workflows/build.yml` compila en cada push a `desarrollo-julio` y sube la APK como artefacto.
- El wrapper (`gradlew`) no está incluido; Android Studio lo genera, o `gradle wrapper --gradle-version 8.9`.
- APK de producción: requiere keystore propio (Etapa 9). Nunca subirlo al repositorio.

## 7. Errores conocidos / pendientes
- Enfoque es un aviso «Aún no implementado».
- Horario: repeticiones calculadas (diaria/semanal/mensual); editar/eliminar afecta a toda la serie; hora de fin opcional, mismo día.
- **Alarmas (Etapa 5, sin probar)**:
  - Mecanismo: `AlarmManager.setAlarmClock()` (atraviesa Doze). **Corrección**: en la v06 se creyó que no necesitaba permiso de alarmas exactas; en Android 12+ SÍ lo necesita (falló en el teléfono real: «No se pudo programar»). Desde la v07 se declaran USE_EXACT_ALARM (13+) y SCHEDULE_EXACT_ALARM (31-32), y la pantalla muestra el motivo técnico real si falla. `AlarmaReceiver` → `AlarmaService` (primer plano, mediaPlayback) → `AlarmaActivity` (sobre pantalla bloqueada). Respaldo: notificación con sonido si el sistema bloquea el servicio.
  - Permisos: USE_EXACT_ALARM, SCHEDULE_EXACT_ALARM (≤32), POST_NOTIFICATIONS (se pide en pantalla Alarmas), USE_FULL_SCREEN_INTENT (Android 14+ puede revocarlo; la pantalla lo avisa), FOREGROUND_SERVICE(+_MEDIA_PLAYBACK), RECEIVE_BOOT_COMPLETED, VIBRATE, WAKE_LOCK.
  - Una sola vez: se fija la fecha concreta al guardar; tras sonar se desactiva. Repetitivas: se reprograma la siguiente al sonar. Posponer = 10 min (constante `MINUTOS_POSPONER`, aún no configurable). Se detiene sola a los 5 min.
  - Se reprograman tras reinicio, actualización de la APK y cambio de hora/zona (`ArranqueReceiver`). Una alarma que vence con el teléfono apagado NO suena después.
  - Dudas a verificar en teléfono real: inicio del servicio desde el receptor (Android 12+), sonido con volumen de alarma, pantalla sobre bloqueo, restricciones de batería/autoarranque del fabricante (Xiaomi, Samsung, etc.: puede requerir permitir «inicio automático» y «sin restricciones de batería»).
  - Sonido: selector del sistema (TYPE_ALARM); si el sonido elegido falla, cae al predeterminado.
- **Enfoque (Etapa 6, sin probar)**: estado en SharedPreferences (`enfoque/EnfoqueControl.kt`), fin avisado por `AlarmManager.setExactAndAllowWhileIdle` (cae a inexacta si falta permiso) → `EnfoqueReceiver`. Notificación con cuenta regresiva (cronómetro) mientras corre; aviso con sonido al terminar. Duraciones personalizadas (1 min–12 h enfoque, 1 min–4 h descanso), presets 25/35/50/70/80 y 5/10/15/20. Pausar/reanudar/finalizar y encadenar descanso. Se reprograma tras reinicio/actualización (`ArranqueReceiver`).
- **Bloqueo de apps: NO implementado.** Para hacerlo de forma real haría falta: (a) permiso «Acceso de uso» (`PACKAGE_USAGE_STATS`) para detectar qué app está en primer plano + permiso de superposición (`SYSTEM_ALERT_WINDOW`) para mostrar una pantalla de bloqueo, o (b) un `AccessibilityService` (más fiable pero con consentimiento explícito y política de Play estricta). Requiere lista de apps elegidas por el usuario, salida segura (botón/fin de sesión), y nunca bloquear llamadas de emergencia ni el teléfono/ajustes. Decisión pendiente del usuario.
- **Metas (Etapa 7, sin probar)**: `ui/screens/MetasSection.kt` dentro de `VozScreen`: crear, editar (título/descripción/fecha objetivo), actualizar progreso (slider 0–100 %, 100 % = completada), marcar completada, eliminar con confirmación. Voz de metas («Muéstrame mis metas») llega con la etapa de voz.
- **Recordatorios (sin probar)**: Horario → aviso 0/5/10/15/30/60 min antes (columna `actividades.recordatorioMin`, se rearma tras cada aviso si es repetitiva); Tareas → aviso a una hora elegida el día de la fecha límite (`tareas.recordatorioMinutoDia`; se cancela al completar). Mecanismo: `recordatorios/` (AlarmManager exacta + `RecordatorioReceiver` + canal «Recordatorios»); se reprograman tras reinicio/actualización. **Base de datos v2**: migración 1→2 con `ALTER TABLE ... ADD COLUMN` (columnas anulables, no borra datos). Si la app se cierra al abrir tras actualizar, sospechar de esta migración.
- Fecha límite de tareas = medianoche UTC del día elegido (`core/Fechas.kt`).
- Flujo de subida del usuario (celular): sube `Julio_proyecto_vNN.zip` a la raíz del repo; el workflow descomprime el zip de nombre más alto (etapa2, etapa4, v05, v06...).

## 8. Siguiente tarea concreta
1. Compilar y probar en el teléfono: Alarmas (con permiso exacto), Enfoque y Metas.
2. Pantalla Voz con orbe (ver §3b), guía «¿Qué puedo decirle a Julio?» y luego Etapa 8 (voz + intérprete de comandos + IA externa opcional).
4. Etapa 9: pruebas finales y APK de producción firmada.

## 9. Prompt para continuar en otro chat
> Continúa el proyecto Julio (app Android, Kotlin + Compose). Lee primero `PLAN_DE_TRABAJO.md`. No reinicies ni reescribas lo hecho. Estado: Etapas 1-2 escritas (sin compilar), icono listo. Empieza por la «Siguiente tarea concreta». Archivos a revisar: `PLAN_DE_TRABAJO.md`, `app/build.gradle.kts`, `gradle/libs.versions.toml`, `data/local/*`, `ui/JulioRoot.kt`, `ui/screens/*`. Trabaja por etapas, sé honesto sobre lo verificado y actualiza el plan al final.
