package com.julio.asistente.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.core.Permisos
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.enfoque.Fase
import com.julio.asistente.enfoque.Preferencias
import com.julio.asistente.enfoque.Sesion
import kotlinx.coroutines.delay

private fun etiquetaMin(min: Int): String = when {
    min < 60 -> "$min min"
    min % 60 == 0 -> "${min / 60} h"
    else -> "${min / 60} h ${min % 60} min"
}

private fun formatoReloj(ms: Long): String {
    val total = (ms + 999) / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

@Composable
fun EnfoqueScreen() {
    val ctx = LocalContext.current
    val sesion by EnfoqueControl.sesion.collectAsStateWithLifecycle()
    val prefs by EnfoqueControl.preferencias.collectAsStateWithLifecycle()

    var ahora by remember { mutableStateOf(System.currentTimeMillis()) }
    var confirmarFin by remember { mutableStateOf(false) }
    var permisoNotif by remember { mutableStateOf(Permisos.notificaciones(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        permisoNotif = Permisos.notificaciones(ctx)
        ahora = System.currentTimeMillis()
        EnfoqueControl.reprogramar(ctx)
    }
    val pedirNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permisoNotif = Permisos.notificaciones(ctx)
    }

    // Reloj de la pantalla: solo refresca lo que se ve; el fin real lo avisa AlarmManager.
    LaunchedEffect(sesion.estado, sesion.finMs) {
        while (sesion.estado == EstadoSesion.CORRIENDO) {
            ahora = System.currentTimeMillis()
            if (ahora >= sesion.finMs) {
                EnfoqueControl.terminar(ctx)
                break
            }
            delay(250)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Modo enfoque", style = MaterialTheme.typography.headlineMedium)

        if (!permisoNotif) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        "Sin el permiso de notificaciones no verás el tiempo restante fuera de la app " +
                            "ni el aviso al terminar.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Row {
                        TextButton(onClick = {
                            pedirNotif.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }) { Text("Dar permiso") }
                        TextButton(onClick = { ctx.startActivity(Permisos.ajustesNotificaciones(ctx)) }) {
                            Text("Abrir ajustes")
                        }
                    }
                }
            }
        }

        when (sesion.estado) {
            EstadoSesion.INACTIVA -> Configuracion(prefs)
            EstadoSesion.CORRIENDO, EstadoSesion.PAUSADA ->
                SesionActiva(sesion, ahora, onFinalizar = { confirmarFin = true })
            EstadoSesion.TERMINADA -> SesionTerminada(sesion, prefs)
        }

        TarjetaBloqueo()
    }

    if (confirmarFin) {
        AlertDialog(
            onDismissRequest = { confirmarFin = false },
            title = { Text("Finalizar sesión") },
            text = { Text("¿Terminar ahora? Se perderá el tiempo que falta.") },
            confirmButton = {
                TextButton(onClick = { EnfoqueControl.finalizar(ctx); confirmarFin = false }) { Text("Finalizar") }
            },
            dismissButton = { TextButton(onClick = { confirmarFin = false }) { Text("Seguir") } },
        )
    }
}

@Composable
private fun Configuracion(prefs: Preferencias) {
    val ctx = LocalContext.current
    var enfoqueMin by remember(prefs) { mutableStateOf(prefs.enfoqueMin) }
    var descansoMin by remember(prefs) { mutableStateOf(prefs.descansoMin) }
    val valido = enfoqueMin in 1..720 && descansoMin in 1..240

    SelectorDuracion("Duración del enfoque", listOf(25, 35, 50, 70, 80), enfoqueMin) { enfoqueMin = it }
    SelectorDuracion("Duración del descanso", listOf(5, 10, 15, 20), descansoMin) { descansoMin = it }

    if (!valido) {
        Text(
            "El enfoque puede durar de 1 min a 12 h, y el descanso de 1 min a 4 h.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
        )
    }
    Button(
        enabled = valido,
        modifier = Modifier.fillMaxWidth(),
        onClick = {
            EnfoqueControl.guardarPreferencias(ctx, Preferencias(enfoqueMin, descansoMin))
            EnfoqueControl.iniciar(ctx, Fase.ENFOQUE, enfoqueMin * 60_000L)
        },
    ) { Text(if (valido) "Iniciar enfoque de ${etiquetaMin(enfoqueMin)}" else "Iniciar enfoque") }
    OutlinedButton(
        enabled = valido,
        modifier = Modifier.fillMaxWidth(),
        onClick = {
            EnfoqueControl.guardarPreferencias(ctx, Preferencias(enfoqueMin, descansoMin))
            EnfoqueControl.iniciar(ctx, Fase.DESCANSO, descansoMin * 60_000L)
        },
    ) { Text(if (valido) "Solo un descanso de ${etiquetaMin(descansoMin)}" else "Solo un descanso") }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SelectorDuracion(titulo: String, presets: List<Int>, minutos: Int, onCambio: (Int) -> Unit) {
    var h by remember { mutableStateOf((minutos / 60).toString()) }
    var m by remember { mutableStateOf((minutos % 60).toString()) }

    fun aplicar(nuevaH: String, nuevaM: String) {
        h = nuevaH
        m = nuevaM
        onCambio((nuevaH.toIntOrNull() ?: 0) * 60 + (nuevaM.toIntOrNull() ?: 0))
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(titulo, style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEach { p ->
                    FilterChip(
                        selected = minutos == p,
                        onClick = { aplicar((p / 60).toString(), (p % 60).toString()) },
                        label = { Text(etiquetaMin(p)) },
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = h,
                    onValueChange = { aplicar(it.filter(Char::isDigit).take(2), m) },
                    label = { Text("Horas") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = m,
                    onValueChange = { aplicar(h, it.filter(Char::isDigit).take(3)) },
                    label = { Text("Minutos") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
            }
            Text("Total: ${etiquetaMin(minutos)}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SesionActiva(sesion: Sesion, ahora: Long, onFinalizar: () -> Unit) {
    val ctx = LocalContext.current
    val corriendo = sesion.estado == EstadoSesion.CORRIENDO
    val restante = if (corriendo) (sesion.finMs - ahora).coerceAtLeast(0L) else sesion.restanteMs
    val progreso = if (sesion.duracionMs > 0) 1f - restante.toFloat() / sesion.duracionMs else 0f

    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(24.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                if (sesion.fase == Fase.ENFOQUE) "Enfoque" else "Descanso",
                style = MaterialTheme.typography.titleMedium,
            )
            Text(formatoReloj(restante), style = MaterialTheme.typography.displayLarge)
            LinearProgressIndicator(progress = { progreso.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            Text(
                if (corriendo) "En curso · ${etiquetaMin((sesion.duracionMs / 60_000L).toInt())} en total"
                else "En pausa",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (corriendo) {
                    Button(onClick = { EnfoqueControl.pausar(ctx) }) { Text("Pausar") }
                } else {
                    Button(onClick = { EnfoqueControl.reanudar(ctx) }) { Text("Reanudar") }
                }
                OutlinedButton(onClick = onFinalizar) { Text("Finalizar") }
            }
        }
    }
}

@Composable
private fun SesionTerminada(sesion: Sesion, prefs: Preferencias) {
    val ctx = LocalContext.current
    val eraEnfoque = sesion.fase == Fase.ENFOQUE
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                if (eraEnfoque) "¡Enfoque terminado!" else "¡Descanso terminado!",
                style = MaterialTheme.typography.headlineSmall,
            )
            if (eraEnfoque) {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { EnfoqueControl.iniciar(ctx, Fase.DESCANSO, prefs.descansoMin * 60_000L) },
                ) { Text("Iniciar descanso de ${etiquetaMin(prefs.descansoMin)}") }
            } else {
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { EnfoqueControl.iniciar(ctx, Fase.ENFOQUE, prefs.enfoqueMin * 60_000L) },
                ) { Text("Iniciar otro enfoque de ${etiquetaMin(prefs.enfoqueMin)}") }
            }
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { EnfoqueControl.finalizar(ctx) }) {
                Text("Cerrar")
            }
        }
    }
}
