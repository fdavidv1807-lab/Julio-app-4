package com.julio.asistente.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.bloqueo.BloqueoConfig
import com.julio.asistente.bloqueo.BloqueoControl
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private class AppInfo(val paquete: String, val nombre: String, val icono: ImageBitmap?)

private fun abrirAjustes(c: Context, principal: Intent, alternativa: Intent? = null) {
    try {
        c.startActivity(principal)
    } catch (e: ActivityNotFoundException) {
        if (alternativa != null) {
            try { c.startActivity(alternativa) } catch (e2: ActivityNotFoundException) { /* sin pantalla disponible */ }
        }
    }
}

private fun cargarApps(c: Context): List<AppInfo> {
    val pm = c.packageManager
    val lanzador = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val protegidas = BloqueoControl.protegidas(c)
    @Suppress("DEPRECATION")
    val resueltas = pm.queryIntentActivities(lanzador, 0)
    return resueltas
        .filter { it.activityInfo.packageName !in protegidas }
        .map { ri ->
            AppInfo(
                paquete = ri.activityInfo.packageName,
                nombre = ri.loadLabel(pm).toString(),
                icono = runCatching { ri.loadIcon(pm).toBitmap(72, 72).asImageBitmap() }.getOrNull(),
            )
        }
        .distinctBy { it.paquete }
        .sortedBy { it.nombre.lowercase() }
}

/** Tarjeta de «Bloqueo de aplicaciones»: aquí el usuario decide si lo quiere y concede los permisos. */
@Composable
fun TarjetaBloqueo() {
    val ctx = LocalContext.current
    val activo by BloqueoConfig.activo.collectAsStateWithLifecycle()
    val paquetes by BloqueoConfig.paquetes.collectAsStateWithLifecycle()
    var permisos by remember { mutableStateOf(BloqueoControl.permisos(ctx)) }
    var consentimiento by remember { mutableStateOf(false) }
    var elegirApps by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        permisos = BloqueoControl.permisos(ctx)
        BloqueoControl.sincronizar(ctx)
    }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Bloqueo de aplicaciones",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f),
                )
                Switch(
                    checked = activo,
                    onCheckedChange = { quiere ->
                        if (quiere) consentimiento = true else BloqueoConfig.activar(ctx, false)
                    },
                )
            }
            if (!activo) {
                Text(
                    "Apagado. Si lo activas, durante tus enfoques Julio cubrirá con una pantalla las apps " +
                        "que elijas. Te explicaré qué permisos necesita antes de encenderlo.",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                FilaPermiso(
                    titulo = "Acceso de uso",
                    detalle = "Para saber qué app está abierta.",
                    concedido = permisos.acceso,
                    onConceder = { abrirAjustes(ctx, BloqueoControl.ajustesAcceso(ctx), BloqueoControl.ajustesAccesoGeneral()) },
                )
                FilaPermiso(
                    titulo = "Mostrar sobre otras apps",
                    detalle = "Para poner la pantalla de bloqueo encima.",
                    concedido = permisos.superposicion,
                    onConceder = { abrirAjustes(ctx, BloqueoControl.ajustesSuperposicion(ctx)) },
                )
                OutlinedButton(onClick = { elegirApps = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Elegir apps a bloquear (${paquetes.size})")
                }
                val estado = when {
                    !permisos.ok -> "Todavía NO bloquea nada: faltan permisos."
                    paquetes.isEmpty() -> "Todavía NO bloquea nada: elige al menos una app."
                    else -> "Listo: durante cada enfoque se bloquearán ${paquetes.size} app(s). No se bloquea en descansos ni en pausa."
                }
                Text(
                    estado,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (permisos.ok && paquetes.isNotEmpty()) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.error,
                )
                Text(
                    "En Xiaomi/Redmi/POCO, Samsung y otras marcas, si no funciona en segundo plano, permite " +
                        "a Julio «inicio automático» y batería «sin restricciones» en los ajustes de la app.",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }

    if (consentimiento) {
        AlertDialog(
            onDismissRequest = { consentimiento = false },
            title = { Text("¿Activar el bloqueo de apps?") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Qué hará", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Mientras dure un enfoque (no en pausas ni descansos), si abres una app de las que " +
                            "elijas, Julio mostrará una pantalla encima que te invita a volver al inicio.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text("Qué permisos pide", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "1. Acceso de uso: solo para saber qué app está en primer plano. Julio no lee su " +
                            "contenido, no guarda ese dato y no lo envía a ningún lado.\n" +
                            "2. Mostrar sobre otras apps: para poner la pantalla de bloqueo.\n" +
                            "Los concedes tú en los ajustes de Android y puedes quitarlos cuando quieras.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text("Qué nunca bloquea", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Llamadas y emergencias, el teléfono, los ajustes, la pantalla de inicio ni Julio.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Text("Cómo salir siempre", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Con el botón «Finalizar sesión de enfoque» de la pantalla de bloqueo, terminando " +
                            "la sesión en Julio, o apagando este interruptor.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    BloqueoConfig.activar(ctx, true)
                    consentimiento = false
                    if (!BloqueoControl.permisos(ctx).acceso) {
                        abrirAjustes(ctx, BloqueoControl.ajustesAcceso(ctx), BloqueoControl.ajustesAccesoGeneral())
                    } else if (!BloqueoControl.permisos(ctx).superposicion) {
                        abrirAjustes(ctx, BloqueoControl.ajustesSuperposicion(ctx))
                    }
                }) { Text("Sí, activar") }
            },
            dismissButton = { TextButton(onClick = { consentimiento = false }) { Text("Ahora no") } },
        )
    }

    if (elegirApps) {
        DialogoApps(
            seleccion = paquetes,
            onGuardar = { BloqueoConfig.guardarPaquetes(ctx, it); elegirApps = false },
            onCancelar = { elegirApps = false },
        )
    }
}

@Composable
private fun FilaPermiso(titulo: String, detalle: String, concedido: Boolean, onConceder: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(titulo, style = MaterialTheme.typography.labelLarge)
            Text(
                if (concedido) "Concedido" else detalle,
                style = MaterialTheme.typography.bodySmall,
                color = if (concedido) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!concedido) TextButton(onClick = onConceder) { Text("Conceder") }
    }
}

@Composable
private fun DialogoApps(seleccion: Set<String>, onGuardar: (Set<String>) -> Unit, onCancelar: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>?>(null) }
    var marcadas by remember { mutableStateOf(seleccion) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { cargarApps(ctx) } }

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text("Apps a bloquear") },
        text = {
            val lista = apps
            if (lista == null) {
                CircularProgressIndicator()
            } else if (lista.isEmpty()) {
                Text("No se encontraron apps para bloquear.")
            } else {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(lista, key = { it.paquete }) { app ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                marcadas = if (app.paquete in marcadas) marcadas - app.paquete else marcadas + app.paquete
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            app.icono?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(36.dp)) }
                            Spacer(Modifier.width(12.dp))
                            Text(app.nombre, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Checkbox(checked = app.paquete in marcadas, onCheckedChange = null)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onGuardar(marcadas) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )
}
