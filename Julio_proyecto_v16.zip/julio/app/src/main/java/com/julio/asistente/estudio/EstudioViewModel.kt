package com.julio.asistente.estudio

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.julio.asistente.JulioApp
import com.julio.asistente.bloqueo.BloqueoConfig
import com.julio.asistente.data.local.TareaEntity
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.enfoque.Fase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class EstudioViewModel(app: Application) : AndroidViewModel(app) {
    init {
        EstudioRepo.cargar(app)
        EnfoqueControl.cargar(app)
    }

    val examenes: StateFlow<List<Examen>> = EstudioRepo.examenes
    val ajustes: StateFlow<AjustesEstudio> = EstudioRepo.ajustes
    val pendienteNota: StateFlow<PendienteNota?> = EstudioRepo.pendienteNota

    /** Las 3 tareas pendientes más urgentes (por fecha límite y prioridad). */
    val tareasPendientes: StateFlow<List<TareaEntity>> = (app as JulioApp).database.tareaDao().observarTodas()
        .map { lista ->
            lista.filter { !it.completada }
                .sortedWith(compareBy<TareaEntity>({ it.fechaLimite ?: Long.MAX_VALUE }, { -it.prioridad }))
                .take(3)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _mensaje = MutableStateFlow<String?>(null)
    val mensaje: StateFlow<String?> = _mensaje.asStateFlow()
    fun cerrarMensaje() { _mensaje.value = null }

    private fun app() = getApplication<Application>()

    fun crearExamen(materia: String, fecha: LocalDate, temas: List<String>, minutos: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val e = EstudioRepo.crear(app(), materia, fecha, temas, minutos)
            if (e == null) {
                _mensaje.value = "No pude crear el plan de estudio. Revisa que la fecha sea posterior a hoy e inténtalo de nuevo."
            } else {
                EstudioAviso.programar(app())
                val primera = LocalDate.ofEpochDay(e.sesiones.first().fecha)
                _mensaje.value = "Listo. Armé ${e.sesiones.size} sesiones para «${e.materia}», empezando el " +
                    "${com.julio.asistente.core.Fechas.textoLargo(primera).lowercase()}."
            }
        }
    }

    fun eliminarExamen(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = EstudioRepo.eliminar(app(), id)
            EstudioAviso.programar(app())
            _mensaje.value = if (ok) "Plan eliminado." else "No pude eliminar el plan."
        }
    }

    fun marcarHecha(examenId: Long, sesionId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = EstudioRepo.marcarHecha(app(), examenId, sesionId)
            _mensaje.value = if (ok) "Sesión marcada como hecha." else "No pude guardar el cambio."
        }
    }

    fun moverAHoy(examenId: Long, sesionId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = EstudioRepo.moverAHoy(app(), examenId, sesionId)
            _mensaje.value = if (ok) "Pasé la sesión a hoy." else "No pude guardar el cambio."
        }
    }

    /** Empieza una sesión de enfoque con la duración planeada. El bloqueo de apps (si lo activaste) actúa solo. */
    fun empezarSesion(examen: Examen, sesion: SesionEstudio) {
        viewModelScope.launch(Dispatchers.IO) {
            val c = app()
            val estado = EnfoqueControl.sesion.value.estado
            if (estado == EstadoSesion.CORRIENDO || estado == EstadoSesion.PAUSADA) {
                _mensaje.value = "Ya hay una sesión de enfoque en curso. Termínala o cancélala en la pestaña Enfoque primero."
                return@launch
            }
            if (estado == EstadoSesion.TERMINADA) EnfoqueControl.finalizar(c)
            EnfoqueControl.iniciar(c, Fase.ENFOQUE, sesion.minutos * 60_000L)
            if (EnfoqueControl.sesion.value.estado == EstadoSesion.CORRIENDO) {
                EstudioRepo.marcarEnCurso(c, examen.id, sesion.id)
                val bloqueo = if (BloqueoConfig.activo.value) " El bloqueo de apps está activado."
                else " El bloqueo de apps está apagado (puedes activarlo en Enfoque)."
                _mensaje.value = "Sesión de estudio iniciada: ${sesion.minutos} minutos. Te aviso al terminar.$bloqueo"
            } else {
                _mensaje.value = "No pude iniciar la sesión de enfoque."
            }
        }
    }

    fun calificar(nota: Int) {
        val p = pendienteNota.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val texto = EstudioRepo.calificar(app(), p.examenId, p.sesionId, nota)
            _mensaje.value = texto ?: "No pude guardar tu respuesta."
        }
    }

    fun omitirNota() {
        viewModelScope.launch(Dispatchers.IO) { EstudioRepo.limpiarPendiente(app()) }
    }

    fun guardarAviso(activo: Boolean, minutos: Int) {
        viewModelScope.launch(Dispatchers.IO) { EstudioRepo.guardarAviso(app(), activo, minutos) }
    }
}
