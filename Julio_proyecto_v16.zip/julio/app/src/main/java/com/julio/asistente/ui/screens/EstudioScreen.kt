package com.julio.asistente.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.julio.asistente.bloqueo.BloqueoConfig
import com.julio.asistente.core.Fechas
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.enfoque.EstadoSesion
import com.julio.asistente.estudio.Agenda
import com.julio.asistente.estudio.Examen
import com.julio.asistente.estudio.EstudioViewModel
import com.julio.asistente.estudio.Planificador
import com.julio.asistente.estudio.Rachas
import com.julio.asistente.estudio.SesionEstudio
import com.julio.asistente.ui.components.PanelJulio
import com.julio.asistente.ui.components.SelectorFecha
import com.julio.asistente.ui.components.SelectorHora
import com.julio.asistente.ui.theme.NeonCian
import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit

@Composable
fun EstudioScreen(vm: EstudioViewModel = viewModel()) {
    val examenes by vm.examenes.collectAsStateWithLifecycle()
    val ajustes by vm.ajustes.collectAsStateWithLifecycle()
    val pendienteNota by vm.pendienteNota.collectAsStateWithLifecycle()
    val mensaje by vm.mensaje.collectAsStateWithLifecycle()
    val tareas by vm.tareasPendientes.collectAsStateWithLifecycle()
    val enfoque by EnfoqueControl.sesion.collectAsStateWithLifecycle()
    val bloqueoActivo by BloqueoConfig.activo.collectAsStateWithLifecycle()

    var hoy by remember { mutableStateOf(LocalDate.now()) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { hoy = LocalDate.now() }
    var dialogoNuevo by remember { mutableStateOf(false) }
    var porBorrar by remember { mutableStateOf<Examen?>(null) }
    var selectorHora by remember { mutableStateOf(false) }

    val deHoy = remember(examenes, hoy) { Agenda.deHoy(examenes, hoy) }
    val atrasadas = remember(examenes, hoy) { Agenda.atrasadas(examenes, hoy) }
    val proxima = remember(examenes, hoy) { Agenda.proxima(examenes, hoy) }
    val hechos = remember(examenes) { Agenda.diasHechos(examenes) }
    val racha = Rachas.actual(hechos, hoy.toEpochDay())
    val mejor = Rachas.mejor(hechos)
    val hayEnfoque = enfoque.estado == EstadoSesion.CORRIENDO || enfoque.estado == EstadoSesion.PAUSADA

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Racha
        PanelJulio(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = NeonCian)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (racha == 1) "Racha: 1 día seguido" else "Racha: $racha días seguidos",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        if (hechos.isEmpty()) "Termina una sesión de estudio para empezar tu racha."
                        else "Tu mejor racha: $mejor ${if (mejor == 1) "día" else "días"}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        mensaje?.let { texto ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(texto, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.cerrarMensaje() }) { Text("Cerrar") }
                }
            }
        }

        // Hoy toca
        Text("Hoy toca", style = MaterialTheme.typography.titleLarge)
        if (examenes.isEmpty()) {
            PanelJulio(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Todavía no tienes un plan de estudio.", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Dile a Julio la fecha de tu examen y los temas, y reparte el repaso por días para que no se junte todo la víspera. " +
                            "También puedes decirle: «tengo examen de anatomía el 5 de noviembre con los temas huesos y músculos».",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        } else if (deHoy.isEmpty()) {
            PanelJulio(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("No tienes sesiones pendientes para hoy.", style = MaterialTheme.typography.bodyMedium)
                    proxima?.let { (e, s) ->
                        Text(
                            "La próxima es el ${Fechas.textoLargo(LocalDate.ofEpochDay(s.fecha)).lowercase()}: ${e.materia}, ${s.titulo}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        } else {
            deHoy.forEach { (e, s) ->
                SesionTarjeta(
                    examen = e, sesion = s, fecha = null, ocupado = hayEnfoque,
                    onEmpezar = { vm.empezarSesion(e, s) },
                    onHecha = { vm.marcarHecha(e.id, s.id) },
                    onHoy = null,
                )
            }
        }
        if (hayEnfoque) {
            Text(
                "Hay una sesión de enfoque en curso: mira el tiempo en la pestaña Enfoque.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        if (atrasadas.isNotEmpty()) {
            Text("Atrasadas", style = MaterialTheme.typography.titleLarge)
            atrasadas.forEach { (e, s) ->
                SesionTarjeta(
                    examen = e, sesion = s, fecha = LocalDate.ofEpochDay(s.fecha), ocupado = hayEnfoque,
                    onEmpezar = null,
                    onHecha = { vm.marcarHecha(e.id, s.id) },
                    onHoy = { vm.moverAHoy(e.id, s.id) },
                )
            }
        }

        // Exámenes
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Mis exámenes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Button(onClick = { dialogoNuevo = true }, shape = MaterialTheme.shapes.small) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(4.dp))
                Text("Nuevo examen")
            }
        }
        examenes.sortedBy { it.fecha }.forEach { e ->
            ExamenTarjeta(e, hoy, onBorrar = { porBorrar = e })
        }

        // Tareas pendientes
        if (tareas.isNotEmpty()) {
            Text("Tareas pendientes", style = MaterialTheme.typography.titleLarge)
            PanelJulio(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    tareas.forEach { t ->
                        val limite = t.fechaLimite?.let { " · límite ${Fechas.textoLargo(Fechas.deMillisUtc(it)).lowercase()}" } ?: ""
                        Text("• ${t.titulo}$limite", style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(
                        "Se completan en la pestaña Tareas.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // Bloqueo de apps y aviso diario
        PanelJulio(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Para concentrarte", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text(
                    if (bloqueoActivo) "El bloqueo de apps está activado: durante tus sesiones de estudio te bloquea las apps que elegiste."
                    else "El bloqueo de apps está apagado. Si quieres que bloquee distracciones durante el estudio, actívalo en la pestaña Enfoque.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Aviso diario de estudio", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = ajustes.avisoActivo, onCheckedChange = { vm.guardarAviso(it, ajustes.avisoMin) })
                }
                if (ajustes.avisoActivo) {
                    OutlinedButton(onClick = { selectorHora = true }, shape = MaterialTheme.shapes.small) {
                        Text("Avisarme a las ${Fechas.textoHora(LocalTime.of(ajustes.avisoMin / 60, ajustes.avisoMin % 60))}")
                    }
                    Text(
                        "Si el aviso no llega, revisa que las notificaciones de Julio estén permitidas en los ajustes del teléfono.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }

    if (dialogoNuevo) {
        DialogoExamen(
            hoy = hoy,
            onCrear = { materia, fecha, temas, minutos ->
                vm.crearExamen(materia, fecha, temas, minutos)
                dialogoNuevo = false
            },
            onCancelar = { dialogoNuevo = false },
        )
    }

    if (selectorHora) {
        SelectorHora(
            titulo = "Hora del aviso diario",
            inicial = LocalTime.of(ajustes.avisoMin / 60, ajustes.avisoMin % 60),
            onAceptar = { vm.guardarAviso(true, it.hour * 60 + it.minute); selectorHora = false },
            onCancelar = { selectorHora = false },
        )
    }

    porBorrar?.let { e ->
        AlertDialog(
            onDismissRequest = { porBorrar = null },
            title = { Text("Eliminar plan") },
            text = { Text("¿Eliminar el plan de estudio de «${e.materia}» y todas sus sesiones?") },
            confirmButton = { TextButton(onClick = { vm.eliminarExamen(e.id); porBorrar = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { porBorrar = null }) { Text("Cancelar") } },
        )
    }

    // «¿Cómo te fue?» después de terminar una sesión de estudio
    pendienteNota?.let { p ->
        val examen = examenes.firstOrNull { it.id == p.examenId }
        val sesion = examen?.sesiones?.firstOrNull { it.id == p.sesionId }
        if (examen != null && sesion != null) {
            AlertDialog(
                onDismissRequest = { vm.omitirNota() },
                title = { Text("¿Cómo te fue?") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Terminaste: ${examen.materia}, ${sesion.titulo}. La sesión ya cuenta para tu racha.")
                        Text(
                            "Si te fue regular o mal, Julio agrega un repaso de refuerzo para mañana.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.calificar(3) }, shape = MaterialTheme.shapes.small) { Text("Bien") }
                            OutlinedButton(onClick = { vm.calificar(2) }, shape = MaterialTheme.shapes.small) { Text("Regular") }
                            OutlinedButton(onClick = { vm.calificar(1) }, shape = MaterialTheme.shapes.small) { Text("Mal") }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { vm.omitirNota() }) { Text("Omitir") } },
            )
        }
    }
}

@Composable
private fun SesionTarjeta(
    examen: Examen,
    sesion: SesionEstudio,
    fecha: LocalDate?,
    ocupado: Boolean,
    onEmpezar: (() -> Unit)?,
    onHecha: () -> Unit,
    onHoy: (() -> Unit)?,
) {
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(examen.materia, style = MaterialTheme.typography.titleMedium)
            Text(sesion.titulo, style = MaterialTheme.typography.bodyMedium)
            Text(
                buildString {
                    append("${sesion.minutos} min")
                    if (fecha != null) append(" · era para el ${Fechas.textoLargo(fecha).lowercase()}")
                    if (sesion.refuerzo) append(" · refuerzo")
                },
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onEmpezar != null) {
                    Button(onClick = onEmpezar, enabled = !ocupado, shape = MaterialTheme.shapes.small) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Empezar")
                    }
                }
                if (onHoy != null) {
                    Button(onClick = onHoy, shape = MaterialTheme.shapes.small) { Text("Hacerla hoy") }
                }
                OutlinedButton(onClick = onHecha, shape = MaterialTheme.shapes.small) {
                    Icon(Icons.Filled.Check, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Ya la hice")
                }
            }
        }
    }
}

@Composable
private fun ExamenTarjeta(e: Examen, hoy: LocalDate, onBorrar: () -> Unit) {
    var abierto by rememberSaveable(e.id) { mutableStateOf(false) }
    val fecha = LocalDate.ofEpochDay(e.fecha)
    val faltan = ChronoUnit.DAYS.between(hoy, fecha)
    val hechas = e.sesiones.count { it.hecha }
    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp, end = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(e.materia, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Examen: ${Fechas.textoLargo(fecha)} · " + when {
                            faltan > 1 -> "faltan $faltan días"
                            faltan == 1L -> "es mañana"
                            faltan == 0L -> "es hoy"
                            else -> "ya pasó"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onBorrar) { Icon(Icons.Filled.Delete, contentDescription = "Eliminar plan") }
            }
            Text("Sesiones hechas: $hechas de ${e.sesiones.size}", style = MaterialTheme.typography.bodyMedium)
            if (e.temas.isNotEmpty()) {
                Text(
                    "Temas: " + e.temas.joinToString(", "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = { abierto = !abierto }) { Text(if (abierto) "Ocultar plan" else "Ver plan día por día") }
            if (abierto) {
                e.sesiones.forEach { s ->
                    val marca = if (s.hecha) "✓" else "•"
                    Text(
                        "$marca ${Fechas.textoLargo(LocalDate.ofEpochDay(s.fecha))}: ${s.titulo} (${s.minutos} min)",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (s.hecha) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DialogoExamen(
    hoy: LocalDate,
    onCrear: (String, LocalDate, List<String>, Int) -> Unit,
    onCancelar: () -> Unit,
) {
    var materia by remember { mutableStateOf("") }
    var fecha by remember { mutableStateOf<LocalDate?>(null) }
    var temasTexto by remember { mutableStateOf("") }
    var minutos by remember { mutableStateOf(45) }
    var selectorFecha by remember { mutableStateOf(false) }

    val temas = remember(temasTexto) {
        temasTexto.split(Regex("[,;\n]")).map { it.trim() }.filter { it.isNotEmpty() }
    }
    val f = fecha
    val fechaValida = f != null && f.isAfter(hoy)
    val sesiones = if (f != null && fechaValida) Planificador.generar(materia.ifBlank { "Examen" }, temas, f, hoy, minutos) else emptyList()
    val valido = materia.isNotBlank() && fechaValida && temas.isNotEmpty()

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text("Nuevo examen") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = materia,
                    onValueChange = { materia = it },
                    label = { Text("Materia") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { selectorFecha = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(f?.let { "Fecha del examen: ${Fechas.textoLargo(it)}" } ?: "Elegir fecha del examen")
                }
                if (f != null && !fechaValida) {
                    Text(
                        "La fecha debe ser posterior a hoy para que haya días de estudio.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                OutlinedTextField(
                    value = temasTexto,
                    onValueChange = { temasTexto = it },
                    label = { Text("Temas") },
                    supportingText = { Text("Sepáralos con comas o uno por línea") },
                    minLines = 3,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Tiempo por bloque de estudio", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(25, 35, 45, 60).forEach { m ->
                        FilterChip(selected = minutos == m, onClick = { minutos = m }, label = { Text("$m min") })
                    }
                }
                if (valido && sesiones.isNotEmpty()) {
                    val inicio = LocalDate.ofEpochDay(sesiones.first().fecha)
                    val fin = LocalDate.ofEpochDay(sesiones.last().fecha)
                    Text(
                        "Julio armará ${sesiones.size} ${if (sesiones.size == 1) "sesión" else "sesiones"}, del " +
                            "${Fechas.textoLargo(inicio).lowercase()} al ${Fechas.textoLargo(fin).lowercase()}.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                } else if (materia.isNotBlank() && fechaValida && temas.isEmpty()) {
                    Text("Agrega al menos un tema.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valido, onClick = { if (f != null) onCrear(materia.trim(), f, temas, minutos) }) { Text("Crear plan") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } },
    )

    if (selectorFecha) {
        SelectorFecha(
            inicial = f ?: hoy.plusDays(7),
            onAceptar = { fecha = it; selectorFecha = false },
            onCancelar = { selectorFecha = false },
        )
    }
}
