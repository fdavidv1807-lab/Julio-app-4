package com.julio.asistente.sync

import android.content.Context
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.Protocolo
import com.julio.asistente.enlace.Verificador
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.io.InputStream
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Lado «Cuerpo» de la sincronización (v52): atiende una ronda que llegó del Diario. Primero aplica lo del Diario y SOLO DESPUÉS contesta «OK»
 * con sus propios cambios; así el Diario nunca saca de su cola algo que el Cuerpo no guardó. Se llama desde el servidor del enlace.
 */
object SyncCuerpo {
    private val verificador = Verificador()
    private val horaFmt get() = SimpleDateFormat("HH:mm", Locale.getDefault())

    private fun ack(s: Socket, codigo: Int) {
        s.getOutputStream().write(codigo)
        s.getOutputStream().flush()
    }

    /** [entrada] es el flujo con la trama todavía sin leer (el servidor ya miró los dos primeros bytes). */
    fun atender(app: Context, s: Socket, entrada: InputStream, clave: ByteArray) {
        val trama = Protocolo.leerTramaSync(entrada)
        val carga = Protocolo.decodificarSync(trama, clave)
        if (carga == null) {
            EnlaceAjustes.ponerEstado("Un teléfono sin el código correcto intentó sincronizar (rechazado).")
            ack(s, Protocolo.ACK_NO_AUTORIZADO); return
        }
        val lote = SyncLogica.decodificarLote(carga)
        if (lote == null) { ack(s, Protocolo.ACK_MALFORMADO); return }
        val r = verificador.revisarId(lote.id, lote.tiempo, System.currentTimeMillis())
        if (r != Protocolo.ACK_OK) { ack(s, r); return }
        if (!SyncAjustes.activo.value) { ack(s, Protocolo.ACK_SIN_PERMISO); return }
        val respuesta = try {
            runBlocking(Dispatchers.IO) {
                val recibidos = Sincronizador.recibir(app, lote)
                val pend = Sincronizador.prepararLote(app)
                LoteSync(UUID.randomUUID().toString(), System.currentTimeMillis(), pend.hayMas, pend.registros, recibidos)
            }
        } catch (e: Exception) {
            ack(s, Protocolo.ACK_NO_DISPONIBLE); return
        }
        s.getOutputStream().write(Protocolo.ACK_OK)
        s.getOutputStream().write(Protocolo.codificarSync(SyncLogica.codificarLote(respuesta), clave))
        s.getOutputStream().flush()
        SyncAjustes.ponerEstado("Sincronizado con el Diario a las ${horaFmt.format(Date())}.")
    }
}
