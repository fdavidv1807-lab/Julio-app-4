package com.julio.asistente.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.actividad.ActividadAndroid
import com.julio.asistente.actividad.ActividadUso
import com.julio.asistente.actividad.ResumenUso
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.sync.TipoSync
import com.julio.asistente.ui.components.PanelJulio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Configuración > Actividad del teléfono (v52): cuánto se usó hoy el teléfono, por categoría y por app, con barras.
 * En el teléfono de diario lo mide el propio teléfono (Acceso de uso); en el Cuerpo se muestra lo que el diario sincronizó.
 * Los nombres de las apps nunca salen de tu Wi-Fi ni van a la IA.
 */
@Composable
fun ActividadPanel() {
    val ctx = LocalContext.current
    val rol by EnlaceAjustes.rol.collectAsStateWithLifecycle()
    var version by remember { mutableStateOf(0) }
    var resumen by remember { mutableStateOf<ResumenUso?>(null) }
    var mensaje by remember { mutableStateOf("Midiendo…") }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { version++ }

    LaunchedEffect(version, rol) {
        val dia = LocalDate.now().toEpochDay()
        val r = withContext(Dispatchers.IO) {
            if (rol == RolEnlace.CUERPO) {
                JulioDatabase.get(ctx).syncDao().uno(TipoSync.USO, dia)?.takeIf { !it.borrado }?.let { ActividadUso.leer(dia, it.datos) }
            } else {
                ActividadAndroid.resumenDelDia(ctx, dia)
            }
        }
        resumen = r
        mensaje = when {
            r != null -> ""
            rol == RolEnlace.CUERPO -> "Todavía no llegó el uso del teléfono de diario. Ese teléfono necesita el acceso de uso y estar en tu Wi-Fi con la sincronización encendida."
            !ActividadAndroid.hayPermiso(ctx) -> "Falta el acceso de uso: dalo en Permisos, «Acceso de uso»."
            else -> "No pude leer el uso del teléfono."
        }
    }

    PanelJulio(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val r = resumen
            if (r == null) {
                Text(mensaje, style = MaterialTheme.typography.bodySmall)
            } else if (r.apps.isEmpty()) {
                Text("Todavía no hay uso registrado hoy.", style = MaterialTheme.typography.bodySmall)
            } else {
                Text(
                    (if (rol == RolEnlace.CUERPO) "Hoy, en el teléfono de diario: " else "Hoy: ") + ActividadUso.tiempoHablado(r.totalMs),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text("Por tipo de app", style = MaterialTheme.typography.labelMedium)
                val cats = r.porCategoria()
                cats.forEach { (nombre, ms) -> Barra(nombre, ms, cats.first().second) }
                Text("Apps con más tiempo", style = MaterialTheme.typography.labelMedium)
                val top = r.top(8)
                top.forEach { Barra(it.nombre, it.ms, top.first().ms) }
            }
        }
    }
}

@Composable
private fun Barra(etiqueta: String, ms: Long, maxMs: Long) {
    val fraccion = if (maxMs <= 0L) 0f else (ms.toFloat() / maxMs.toFloat()).coerceIn(0.02f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row {
            Text(etiqueta, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text(ActividadUso.tiempoHablado(ms), style = MaterialTheme.typography.bodySmall)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))) {
            Box(Modifier.fillMaxWidth(fraccion).height(8.dp).background(MaterialTheme.colorScheme.primary))
        }
    }
}
