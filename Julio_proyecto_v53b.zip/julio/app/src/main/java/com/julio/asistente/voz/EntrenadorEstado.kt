package com.julio.asistente.voz

/** Lo que muestra la pantalla del entrenador de voz (v53). */
sealed class FaseEntrenador {
    object Inactivo : FaseEntrenador()

    /** Repetición [i] de [total]. [oyo] = lo último que entendió el reconocedor (null = aún escuchando). */
    data class Repitiendo(val i: Int, val total: Int, val consigna: String, val oyo: String?, val aciertos: Int, val escuchando: Boolean) : FaseEntrenador()

    data class Listo(val aciertos: Int, val total: Int, val aprendidas: List<String>, val mensaje: String) : FaseEntrenador()
    data class Error(val mensaje: String) : FaseEntrenador()
}
