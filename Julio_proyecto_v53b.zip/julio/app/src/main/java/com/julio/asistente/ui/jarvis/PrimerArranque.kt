package com.julio.asistente.ui.jarvis

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.julio.asistente.bloqueo.BloqueoControl
import com.julio.asistente.core.Permisos
import com.julio.asistente.cuerpo.AvisosListener
import com.julio.asistente.cuerpo.CuerpoAjustes
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.ui.hud.HudColores
import com.julio.asistente.ui.hud.HudPanel
import com.julio.asistente.ui.hud.esquinas
import com.julio.asistente.ui.screens.PiperPanel
import com.julio.asistente.ui.screens.VoskPanel
import com.julio.asistente.ui.screens.VozDuenoPanel
import com.julio.asistente.voz.EstadoPiper
import com.julio.asistente.voz.EstadoVosk
import com.julio.asistente.voz.VozViewModel

/** Dónde va el primer arranque (se guarda para seguir en el mismo paso si la app se cierra al ir a los ajustes del teléfono). */
object PrimerArranque {
    private const val ARCHIVO = "julio_arranque"
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(ARCHIVO, Context.MODE_PRIVATE)

    fun terminado(c: Context): Boolean = sp(c).getBoolean("terminado", false)

    fun paso(c: Context): PasoArranque =
        runCatching { PasoArranque.valueOf(sp(c).getString("paso", PasoArranque.VOZ.name) ?: "") }.getOrDefault(PasoArranque.VOZ)

    fun guardarPaso(c: Context, p: PasoArranque) { sp(c).edit().putString("paso", p.name).apply() }

    /** Termina el primer arranque. En el Cuerpo deja listo el modo escritorio (lectura de avisos, rol y código de emparejamiento). */
    fun terminar(c: Context) {
        sp(c).edit().putBoolean("terminado", true).apply()
        if (ModoApp.modo.value == ModoApp.Modo.ESCRITORIO) {
            CuerpoAjustes.prepararPorDefecto(c)
            if (EnlaceAjustes.rol.value == RolEnlace.NINGUNO) {
                EnlaceAjustes.fijarRol(c, RolEnlace.CUERPO)
                if (EnlaceAjustes.codigo.value == null) EnlaceAjustes.nuevoCodigo(c)
            }
        }
    }
}

private val MONO = FontFamily.Monospace

/** Abre una pantalla de ajustes; si el teléfono no la tiene, prueba la siguiente y, si ninguna existe, no hace nada. */
private fun abrir(ctx: Context, vararg opciones: Intent) {
    for (i in opciones) {
        try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: ActivityNotFoundException) {
        } catch (e: SecurityException) {
        }
    }
}

/** Android 11+: abre DIRECTO la página de «Acceso a notificaciones» de Julio (no la lista larga de apps). */
private fun detalleListener(ctx: Context): Intent? =
    if (Build.VERSION.SDK_INT >= 30) {
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
            ComponentName(ctx, AvisosListener::class.java).flattenToString(),
        )
    } else {
        null
    }

private fun infoDeLaApp(ctx: Context) = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))

/** Pantallas del administrador del teléfono para «inicio automático» (NO verificadas: dependen de la versión de Honor/MagicOS). */
private fun inicioAutomaticoHonor(): List<Intent> = listOf(
    ComponentName("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
    ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
    ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
).map { Intent().setComponent(it) }

/**
 * Primer arranque, en este orden: voz → entrenar voz → modo (Cuerpo/Diario) → permisos → batería (solo Cuerpo) → IA.
 * El modo se pregunta DESPUÉS de dejar bien a Julio. Lo obligatorio no deja avanzar; lo recomendado se puede omitir.
 */
@Composable
fun PantallaPrimerArranque(vm: VozViewModel, alTerminar: () -> Unit) {
    val ctx = LocalContext.current
    val modo by ModoApp.modo.collectAsStateWithLifecycle()
    var paso by remember {
        mutableStateOf(ArranqueLogica.normalizar(PrimerArranque.paso(ctx), ModoApp.modo.value) ?: PasoArranque.IA)
    }
    fun avanzar() {
        val sig = ArranqueLogica.siguiente(paso, ModoApp.modo.value)
        if (sig == null) {
            PrimerArranque.terminar(ctx)
            alTerminar()
        } else {
            paso = sig
            PrimerArranque.guardarPaso(ctx, sig)
        }
    }

    // El modo se elige con su propia pantalla (la de siempre), pero solo después de configurar a Julio.
    if (paso == PasoArranque.MODO) {
        PantallaElegirModo { elegido ->
            if (ModoApp.elegir(ctx, elegido)) avanzar()
        }
        return
    }

    val (n, total) = ArranqueLogica.posicion(paso, modo)
    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Canvas(Modifier.fillMaxSize()) { esquinas(HudColores.Cian) }
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("J.U.L.I.O.", color = HudColores.Blanco, fontSize = 22.sp, fontFamily = MONO, letterSpacing = 6.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Text(
                "PASO $n DE $total · " + when (paso) {
                    PasoArranque.VOZ -> "VOZ"
                    PasoArranque.ENTRENAR -> "ENTRENAR TU VOZ"
                    PasoArranque.MODO -> "MODO"
                    PasoArranque.PERMISOS -> "PERMISOS"
                    PasoArranque.BATERIA -> "BATERÍA (CUERPO)"
                    PasoArranque.IA -> "INTELIGENCIA ARTIFICIAL"
                },
                color = HudColores.Cian, fontSize = 12.sp, fontFamily = MONO, letterSpacing = 2.sp,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
            )
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when (paso) {
                    PasoArranque.VOZ -> PasoVoz(vm) { avanzar() }
                    PasoArranque.ENTRENAR -> PasoEntrenar(vm, alAvanzar = { avanzar() })
                    PasoArranque.PERMISOS -> PasoPermisos(modo) { avanzar() }
                    PasoArranque.BATERIA -> PasoBateria { avanzar() }
                    PasoArranque.IA -> PasoIa { avanzar() }
                    PasoArranque.MODO -> {}
                }
            }
        }
    }
}

@Composable
private fun Siguiente(texto: String, habilitado: Boolean, alPulsar: () -> Unit) {
    Button(onClick = alPulsar, enabled = habilitado, modifier = Modifier.fillMaxWidth()) { Text(texto) }
}

@Composable
private fun Omitir(texto: String = "Omitir por ahora", alPulsar: () -> Unit) {
    TextButton(onClick = alPulsar, modifier = Modifier.fillMaxWidth()) { Text(texto) }
}

// ---------------------------------------------------------------------------------------------------------------------
// 1. Voz: el reconocedor y la voz neuronal (obligatorios)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun PasoVoz(vm: VozViewModel, alAvanzar: () -> Unit) {
    val vosk by vm.voskEstado.collectAsStateWithLifecycle()
    val piper by vm.piperEstado.collectAsStateWithLifecycle()
    val listo = ArranqueLogica.vozLista(vosk is EstadoVosk.Listo, piper is EstadoPiper.Lista, vm.piperDisponible)
    Text(
        "Primero hay que dejar bien a Julio: necesita dos cosas para oírte y para hablarte. Descárgalas con Wi‑Fi (unos minutos). " +
            "Son obligatorias y quedan guardadas: después funcionan sin internet.",
        color = HudColores.Blanco, fontSize = 13.sp,
    )
    HudPanel(if (vosk is EstadoVosk.Listo) "1 · RECONOCEDOR DE VOZ  ✓" else "1 · RECONOCEDOR DE VOZ", HudColores.Cian) { VoskPanel(vm) }
    HudPanel(if (piper is EstadoPiper.Lista) "2 · VOZ NEURONAL DE JULIO  ✓" else "2 · VOZ NEURONAL DE JULIO", HudColores.Turquesa) { PiperPanel(vm) }
    Siguiente(if (listo) "Siguiente" else "Faltan las dos descargas", listo, alAvanzar)
}

// ---------------------------------------------------------------------------------------------------------------------
// 2. Entrenar la voz
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun PasoEntrenar(vm: VozViewModel, alAvanzar: () -> Unit) {
    val huella by vm.duenoHuella.collectAsStateWithLifecycle()
    Text(
        "Dos pasos. 1) El entrenador: dices «Julio» seis veces y Julio aprende cómo suena TU «Julio». " +
            "2) Tu perfil: aprende SOLO tu voz para no hacerle caso a otras personas (tres muestras más). Solo se guardan datos numéricos, nunca audio.",
        color = HudColores.Blanco, fontSize = 13.sp,
    )
    val aprendidas by vm.duenoAprendidas.collectAsStateWithLifecycle()
    val hecho = huella || aprendidas.isNotEmpty()
    HudPanel(if (hecho) "ENTRENADOR DE VOZ  ✓" else "ENTRENADOR DE VOZ", HudColores.Cian) { com.julio.asistente.ui.screens.EntrenadorVozPanel(vm) }
    HudPanel(if (huella) "MI VOZ  ✓" else "MI VOZ", HudColores.Cian) { VozDuenoPanel(vm) }
    Siguiente(if (hecho) "Siguiente" else "Entrena tu voz para seguir", hecho, alAvanzar)
    if (!hecho) Omitir("Omitir (Julio obedecerá a cualquier voz)", alAvanzar)
}

// ---------------------------------------------------------------------------------------------------------------------
// 4. Permisos (después de elegir el modo)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun PasoPermisos(modo: ModoApp.Modo, alAvanzar: () -> Unit) {
    val ctx = LocalContext.current
    val marca = remember { MarcaTelefono.deFabricante(Build.MANUFACTURER ?: "", Build.BRAND ?: "") }
    var version by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { version++ }
    val pedirMicrofono = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { version++ }
    val pedirNotificaciones = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { version++ }

    // «version» solo sirve para volver a leer los permisos al volver de los ajustes del teléfono.
    val microfono = version >= 0 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val notificaciones = version >= 0 && Permisos.notificaciones(ctx)
    val acceso = version >= 0 && CuerpoAjustes.accesoANotificaciones(ctx)
    val uso = version >= 0 && BloqueoControl.permisos(ctx).acceso
    val listo = ArranqueLogica.permisosListos(microfono, notificaciones, acceso, uso, modo)

    Text(
        "Julio es una app que pide permisos especiales: el teléfono los bloquea hasta que tú los das. Cada botón te lleva directo a la " +
            "pantalla correcta y, al volver, se marca solo. Lo marcado con * es obligatorio. " +
            "(La batería sin restricciones se pide después, solo si este teléfono es el Cuerpo.)",
        color = HudColores.Blanco, fontSize = 13.sp,
    )
    FilaPermiso("* Micrófono", "Para oír «Julio».", microfono, "Permitir") { pedirMicrofono.launch(Manifest.permission.RECORD_AUDIO) }
    FilaPermiso("* Notificaciones de Julio", "Para avisarte y mostrar que está activo.", notificaciones, "Permitir") {
        if (Build.VERSION.SDK_INT >= 33) pedirNotificaciones.launch(Manifest.permission.POST_NOTIFICATIONS)
        else abrir(ctx, Permisos.ajustesNotificaciones(ctx))
    }
    FilaPermiso(
        "* Acceso a notificaciones",
        "Para que Julio lea tus avisos (WhatsApp, etc.). " + MarcaTelefono.ajustesRestringidos(marca),
        acceso, "Abrir ajustes",
        extra = "Abrir información de la app",
        alExtra = { abrir(ctx, infoDeLaApp(ctx)) },
    ) {
        abrir(ctx, *listOfNotNull(detalleListener(ctx), Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)).toTypedArray())
    }
    FilaPermiso(
        if (modo == ModoApp.Modo.DIARIO) "* Acceso de uso" else "Acceso de uso (recomendado)",
        "Para medir cuánto tiempo usas cada app. En la lista busca Julio y activa «Permitir acceso de uso». " + MarcaTelefono.accesoUso(marca),
        uso, "Abrir ajustes",
    ) { abrir(ctx, BloqueoControl.ajustesAcceso(ctx), BloqueoControl.ajustesAccesoGeneral()) }
    Siguiente(if (listo) "Siguiente" else "Faltan los marcados con *", listo, alAvanzar)
}

@Composable
private fun FilaPermiso(
    titulo: String,
    detalle: String,
    listo: Boolean,
    boton: String,
    extra: String? = null,
    alExtra: () -> Unit = {},
    alPulsar: () -> Unit,
) {
    HudPanel(if (listo) "$titulo  ✓" else titulo, if (listo) HudColores.Turquesa else HudColores.Cian) {
        Text(detalle, color = HudColores.Blanco, fontSize = 12.sp)
        if (!listo) {
            OutlinedButton(onClick = alPulsar, modifier = Modifier.fillMaxWidth()) { Text(boton) }
            if (extra != null) TextButton(onClick = alExtra, modifier = Modifier.fillMaxWidth()) { Text(extra) }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// 5. Batería (solo el Cuerpo)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun PasoBateria(alAvanzar: () -> Unit) {
    val ctx = LocalContext.current
    val marca = remember { MarcaTelefono.deFabricante(Build.MANUFACTURER ?: "", Build.BRAND ?: "") }
    var version by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { version++ }
    val bateria = version >= 0 && ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    Text(
        "Este teléfono será el Cuerpo de Julio: tiene que estar siempre escuchando. Para que el teléfono no lo cierre:",
        color = HudColores.Blanco, fontSize = 13.sp,
    )
    HudPanel(if (bateria) "BATERÍA SIN RESTRICCIONES  ✓" else "BATERÍA SIN RESTRICCIONES", if (bateria) HudColores.Turquesa else HudColores.Cian) {
        Text(MarcaTelefono.bateria(marca), color = HudColores.Blanco, fontSize = 12.sp)
        if (!bateria) {
            OutlinedButton(
                onClick = { abrir(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), infoDeLaApp(ctx)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Abrir ajustes de batería") }
        }
        if (marca == Marca.HONOR) {
            TextButton(
                onClick = { abrir(ctx, *inicioAutomaticoHonor().toTypedArray(), infoDeLaApp(ctx)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Abrir inicio de aplicaciones (Honor)") }
        }
    }
    Siguiente(if (bateria) "Siguiente" else "Siguiente (sin esto el teléfono puede cerrar a Julio)", true, alAvanzar)
}

// ---------------------------------------------------------------------------------------------------------------------
// 6. IA (opcional)
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun PasoIa(alTerminar: () -> Unit) {
    val ctx = LocalContext.current
    Text(
        "Si quieres hablar con la inteligencia artificial, haz esto:",
        color = HudColores.Blanco, fontSize = 14.sp,
    )
    HudPanel("CLAVE GRATIS DE GEMINI", HudColores.Cian) {
        Text(
            "Toca el botón: se abre Google AI Studio. Entra con TU cuenta de Google y crea la clave gratis. " +
                "Julio no puede sacarla solo. Después la pegas a mano en Configuración > «IA de consulta».",
            color = HudColores.Blanco, fontSize = 12.sp,
        )
        OutlinedButton(
            onClick = { abrir(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Ir a Google AI Studio") }
    }
    Siguiente("Terminar", true, alTerminar)
    Omitir("Omitir (lo hago después)", alTerminar)
}
