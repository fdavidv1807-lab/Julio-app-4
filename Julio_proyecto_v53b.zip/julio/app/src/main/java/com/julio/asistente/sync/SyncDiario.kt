package com.julio.asistente.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.julio.asistente.enlace.EnlaceAjustes
import com.julio.asistente.enlace.EnlaceDiario
import com.julio.asistente.enlace.Protocolo
import com.julio.asistente.enlace.RolEnlace
import com.julio.asistente.enlace.Verificador
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Lado «teléfono de diario» de la sincronización (v52). El Diario es siempre quien llama: cada 2 minutos (y al conectarse a la Wi-Fi o al pedirlo)
 * anota sus cambios, se los manda al Cuerpo y recibe los del Cuerpo en la misma conversación. Si el Cuerpo no está al alcance, los cambios
 * esperan en la cola (tabla sync_estado) y se entregan solos al reconectar, sin errores en pantalla.
 * Solo por Wi-Fi local; el relé para fuera de casa es una versión aparte.
 */
object SyncDiario {
    private const val PERIODO_MS = 120_000L
    private const val MAX_RONDAS = 10
    private val iniciado = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val unaVez = Mutex()
    private val verificador = Verificador()
    private val horaFmt get() = SimpleDateFormat("HH:mm", Locale.getDefault())
    @Volatile private var ultimaBusqueda = 0L

    private enum class Resultado { OK, SIN_CAMINO, RECHAZADO, FALLO }

    /** Arranca el ciclo (una sola vez por proceso). Seguro llamarlo varias veces. */
    fun iniciar(c: Context) {
        val app = c.applicationContext
        if (!iniciado.compareAndSet(false, true)) return
        scope.launch {
            while (isActive) {
                try { ciclo(app) } catch (e: Exception) { /* una vuelta mala no apaga el ciclo */ }
                delay(PERIODO_MS)
            }
        }
    }

    /** Sincroniza ahora (botón o voz). */
    fun sincronizarYa(c: Context) {
        val app = c.applicationContext
        iniciar(app)
        scope.launch { try { ciclo(app) } catch (e: Exception) { } }
    }

    private suspend fun ciclo(app: Context) {
        if (!unaVez.tryLock()) return
        try {
            if (EnlaceAjustes.rol.value != RolEnlace.DIARIO || !SyncAjustes.activo.value) return
            val secreto = EnlaceAjustes.secreto() ?: return
            val clave = Protocolo.claveDe(secreto)
            Sincronizador.escanear(app) // anota los cambios aunque no haya red: así quedan en la cola con su hora
            val pendientes = Sincronizador.prepararLote(app)
            if (!hayWifi(app)) {
                SyncAjustes.ponerEstado(if (pendientes.registros.isEmpty()) "Sin Wi-Fi. Se sincronizará al volver a casa." else "Sin Wi-Fi: ${pendientes.registros.size}${if (pendientes.hayMas) "+" else ""} cambios esperan en la cola.")
                return
            }
            var resultado = Resultado.SIN_CAMINO
            for ((host, puerto) in EnlaceAjustes.destinos()) {
                resultado = conversar(app, host, puerto, clave)
                if (resultado != Resultado.SIN_CAMINO) break
            }
            if (resultado == Resultado.SIN_CAMINO && System.currentTimeMillis() - ultimaBusqueda > 60_000L) {
                ultimaBusqueda = System.currentTimeMillis()
                val hallado = EnlaceDiario.Descubridor.buscar(app, Protocolo.idPublico(secreto), 6_000L)
                if (hallado != null) {
                    EnlaceAjustes.guardarDestino(app, hallado.first, hallado.second)
                    resultado = conversar(app, hallado.first, hallado.second, clave)
                }
            }
            when (resultado) {
                Resultado.OK -> SyncAjustes.ponerEstado("Sincronizado con el Cuerpo a las ${horaFmt.format(Date())}.")
                Resultado.SIN_CAMINO -> SyncAjustes.ponerEstado("No encuentro al Cuerpo: los cambios esperan en la cola.")
                Resultado.RECHAZADO -> SyncAjustes.ponerEstado("El Cuerpo rechazó la sincronización (código distinto, hora diferente o sincronización apagada allí). Vuelve a emparejar.")
                Resultado.FALLO -> SyncAjustes.ponerEstado("La sincronización se cortó a medias. Se reintenta sola.")
            }
        } finally {
            unaVez.unlock()
        }
    }

    private class Ronda(val ack: Int, val lote: LoteSync?)

    /** Varias rondas hasta que no quede nada por mandar ni por recibir. */
    private suspend fun conversar(app: Context, host: String, puerto: Int, clave: ByteArray): Resultado {
        var confirmar: List<Confirmacion> = emptyList()
        for (n in 1..MAX_RONDAS) {
            val pend = Sincronizador.prepararLote(app)
            val salida = LoteSync(UUID.randomUUID().toString(), System.currentTimeMillis(), pend.hayMas, pend.registros, confirmar)
            val r = ronda(host, puerto, clave, salida)
            when (r.ack) {
                -1 -> return if (n == 1) Resultado.SIN_CAMINO else Resultado.FALLO
                Protocolo.ACK_OK -> Unit
                Protocolo.ACK_NO_AUTORIZADO, Protocolo.ACK_HORA, Protocolo.ACK_SIN_PERMISO -> return Resultado.RECHAZADO
                else -> return Resultado.FALLO
            }
            val respuesta = r.lote ?: return Resultado.FALLO
            if (verificador.revisarId(respuesta.id, respuesta.tiempo, System.currentTimeMillis()) != Protocolo.ACK_OK) return Resultado.FALLO
            // El Cuerpo contestó OK DESPUÉS de aplicar lo nuestro: sale de la cola.
            Sincronizador.marcarEnviados(app, pend.registros)
            confirmar = Sincronizador.recibir(app, respuesta)
            if (!pend.hayMas && !respuesta.hayMas && confirmar.isEmpty()) return Resultado.OK
        }
        return Resultado.OK
    }

    /** Una vuelta: manda el lote y lee la respuesta. Bloquea (se llama en el hilo de IO). */
    private fun ronda(host: String, puerto: Int, clave: ByteArray, lote: LoteSync): Ronda {
        val s = Socket()
        try {
            s.connect(InetSocketAddress(host, puerto), 2_500)
            s.soTimeout = 8_000
            s.getOutputStream().write(Protocolo.codificarSync(SyncLogica.codificarLote(lote), clave))
            s.getOutputStream().flush()
            val ack = s.getInputStream().read()
            if (ack != Protocolo.ACK_OK) return Ronda(ack, null)
            val trama = Protocolo.leerTramaSync(s.getInputStream())
            val carga = Protocolo.decodificarSync(trama, clave) ?: return Ronda(Protocolo.ACK_NO_AUTORIZADO, null)
            val respuesta = SyncLogica.decodificarLote(carga) ?: return Ronda(Protocolo.ACK_MALFORMADO, null)
            return Ronda(ack, respuesta)
        } catch (e: IOException) {
            return Ronda(-1, null)
        } finally {
            try { s.close() } catch (e: IOException) { }
        }
    }

    private fun hayWifi(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }
}
