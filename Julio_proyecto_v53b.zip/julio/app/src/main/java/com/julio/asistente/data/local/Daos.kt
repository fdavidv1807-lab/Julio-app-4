package com.julio.asistente.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TareaDao {
    @Query("SELECT * FROM tareas ORDER BY completada ASC, fechaLimite IS NULL, fechaLimite ASC, prioridad DESC")
    fun observarTodas(): Flow<List<TareaEntity>>

    @Query("SELECT * FROM tareas WHERE id = :id")
    suspend fun porId(id: Long): TareaEntity?

    @Query("SELECT * FROM tareas WHERE creadaEn = :creadaEn LIMIT 1")
    suspend fun porCreadaEn(creadaEn: Long): TareaEntity?

    @Query("SELECT * FROM tareas WHERE completada = 0 AND recordatorioMinutoDia IS NOT NULL")
    suspend fun conRecordatorio(): List<TareaEntity>

    @Insert suspend fun insertar(t: TareaEntity): Long
    @Query("DELETE FROM tareas") suspend fun borrarTodo()
    @Update suspend fun actualizar(t: TareaEntity)
    @Delete suspend fun eliminar(t: TareaEntity)
}

@Dao
interface ActividadDao {
    @Query("SELECT * FROM actividades ORDER BY inicio ASC")
    fun observarTodas(): Flow<List<ActividadEntity>>

    @Query("SELECT * FROM actividades WHERE inicio BETWEEN :desde AND :hasta ORDER BY inicio ASC")
    suspend fun entre(desde: Long, hasta: Long): List<ActividadEntity>

    @Query("SELECT * FROM actividades WHERE id = :id")
    suspend fun porId(id: Long): ActividadEntity?

    @Query("SELECT * FROM actividades WHERE creadaEn = :creadaEn LIMIT 1")
    suspend fun porCreadaEn(creadaEn: Long): ActividadEntity?

    @Query("SELECT * FROM actividades WHERE recordatorioMin IS NOT NULL")
    suspend fun conRecordatorio(): List<ActividadEntity>

    @Insert suspend fun insertar(a: ActividadEntity): Long
    @Query("DELETE FROM actividades") suspend fun borrarTodo()
    @Update suspend fun actualizar(a: ActividadEntity)
    @Delete suspend fun eliminar(a: ActividadEntity)
}

@Dao
interface AlarmaDao {
    @Query("SELECT * FROM alarmas ORDER BY hora ASC, minuto ASC")
    fun observarTodas(): Flow<List<AlarmaEntity>>

    @Query("SELECT * FROM alarmas WHERE id = :id")
    suspend fun porId(id: Long): AlarmaEntity?

    @Query("SELECT * FROM alarmas WHERE creadaEn = :creadaEn LIMIT 1")
    suspend fun porCreadaEn(creadaEn: Long): AlarmaEntity?

    @Query("SELECT * FROM alarmas WHERE activa = 1")
    suspend fun activas(): List<AlarmaEntity>

    @Insert suspend fun insertar(a: AlarmaEntity): Long
    @Query("DELETE FROM alarmas") suspend fun borrarTodo()
    @Update suspend fun actualizar(a: AlarmaEntity)
    @Delete suspend fun eliminar(a: AlarmaEntity)
}

@Dao
interface MetaDao {
    @Query("SELECT * FROM metas ORDER BY completada ASC, creadaEn DESC")
    fun observarTodas(): Flow<List<MetaEntity>>

    @Query("SELECT * FROM metas WHERE id = :id")
    suspend fun porId(id: Long): MetaEntity?

    @Insert suspend fun insertar(m: MetaEntity): Long
    @Query("DELETE FROM metas") suspend fun borrarTodo()
    @Update suspend fun actualizar(m: MetaEntity)
    @Delete suspend fun eliminar(m: MetaEntity)
}

@Dao
interface RutinaDao {
    @Query("SELECT * FROM rutinas ORDER BY activa DESC, nombre ASC")
    fun observarTodas(): Flow<List<RutinaEntity>>

    @Query("SELECT * FROM rutinas ORDER BY nombre ASC")
    suspend fun todas(): List<RutinaEntity>

    @Query("SELECT * FROM rutinas WHERE id = :id")
    suspend fun porId(id: Long): RutinaEntity?

    @Query("SELECT * FROM rutinas WHERE activa = 1 AND disparador = :disparador")
    suspend fun activasPor(disparador: String): List<RutinaEntity>

    @Query("UPDATE rutinas SET ultimaEjecucion = :ms WHERE id = :id")
    suspend fun marcarEjecutada(id: Long, ms: Long)

    @Insert suspend fun insertar(r: RutinaEntity): Long
    @Update suspend fun actualizar(r: RutinaEntity)
    @Delete suspend fun eliminar(r: RutinaEntity)
}

@Dao
interface SyncDao {
    @Query("SELECT * FROM sync_estado WHERE tipo = :tipo")
    suspend fun deTipo(tipo: String): List<SyncEstadoEntity>

    @Query("SELECT * FROM sync_estado WHERE tipo = :tipo AND clave = :clave")
    suspend fun uno(tipo: String, clave: Long): SyncEstadoEntity?

    /** Cambios que el otro teléfono todavía no confirmó (la «cola»): los más viejos primero. */
    @Query("SELECT * FROM sync_estado WHERE entregado = 0 ORDER BY actualizadoEn ASC LIMIT :n")
    suspend fun pendientes(n: Int): List<SyncEstadoEntity>

    @Query("SELECT COUNT(*) FROM sync_estado WHERE entregado = 0")
    suspend fun cuantosPendientes(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun poner(e: SyncEstadoEntity)

    /** Solo marca si el elemento no cambió desde que se mandó (misma hora de cambio). */
    @Query("UPDATE sync_estado SET entregado = 1 WHERE tipo = :tipo AND clave = :clave AND actualizadoEn = :actualizadoEn")
    suspend fun marcarEntregado(tipo: String, clave: Long, actualizadoEn: Long)

    /** Las lápidas ya entregadas se olvidan pasado un tiempo. */
    @Query("DELETE FROM sync_estado WHERE borrado = 1 AND entregado = 1 AND actualizadoEn < :antes")
    suspend fun limpiarLapidas(antes: Long)
}
