package com.julio.asistente.sync

import android.content.Context
import com.julio.asistente.alarmas.AlarmaProgramador
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.data.local.SyncEstadoEntity
import com.julio.asistente.recordatorios.RecordatorioProgramador
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Motor de la sincronización (v52). Funciona por COMPARACIÓN: en cada vuelta mira lo que hay en las tablas de tareas, horario y alarmas,
 * lo compara con lo que tenía anotado en «sync_estado» y anota solo lo que cambió (con su hora) o desapareció (lápida).
 * Así no hace falta tocar cada lugar de la app donde se crea, edita o borra algo.
 * Lo que anota y el otro teléfono no ha confirmado es la COLA: sigue ahí hasta que se entregue (como un mensaje de WhatsApp).
 */
object Sincronizador {
    private val candado = Mutex()
    private const val VIDA_LAPIDA_MS = 30L * 24 * 60 * 60 * 1000

    private fun SyncEstadoEntity.aRegistro() = RegistroSync(tipo, clave, datos, actualizadoEn, borrado)

    /** Anota los cambios locales. Es barato; se puede llamar cuando se quiera. */
    suspend fun escanear(c: Context) = candado.withLock { escanearSinCandado(c.applicationContext) }

    private suspend fun escanearSinCandado(c: Context) {
        val db = JulioDatabase.get(c)
        val dao = db.syncDao()
        val ahora = System.currentTimeMillis()
        val actuales = mapOf(
            TipoSync.TAREA to db.tareaDao().observarTodas().first().map { Instantanea(TipoSync.TAREA, it.creadaEn, SerializadorSync.datosTarea(it)) },
            TipoSync.ACTIVIDAD to db.actividadDao().observarTodas().first().map { Instantanea(TipoSync.ACTIVIDAD, it.creadaEn, SerializadorSync.datosActividad(it)) },
            TipoSync.ALARMA to db.alarmaDao().observarTodas().first().map { Instantanea(TipoSync.ALARMA, it.creadaEn, SerializadorSync.datosAlarma(it)) },
        )
        // v52: uso del teléfono. Lo mide solo el Diario (hoy y ayer); los días anteriores se arrastran tal cual (14 días) para no borrarse.
        val hoy = java.time.LocalDate.now().toEpochDay()
        val uso = dao.deTipo(TipoSync.USO).filter { !it.borrado && it.clave >= hoy - 14 }.associate { it.clave to it.datos }.toMutableMap()
        if (com.julio.asistente.enlace.EnlaceAjustes.rol.value == com.julio.asistente.enlace.RolEnlace.DIARIO) {
            for (dia in listOf(hoy - 1, hoy)) {
                val r = com.julio.asistente.actividad.ActividadAndroid.resumenDelDia(c, dia) ?: continue
                uso[dia] = com.julio.asistente.actividad.ActividadUso.serializar(r)
            }
        }
        val todos = actuales + (TipoSync.USO to uso.map { Instantanea(TipoSync.USO, it.key, it.value) })
        for ((tipo, lista) in todos) {
            val previos = dao.deTipo(tipo).map { it.aRegistro() }
            for (d in SyncLogica.diferencias(previos, lista, ahora)) {
                dao.poner(SyncEstadoEntity(d.tipo, d.clave, d.datos, d.actualizadoEn, d.borrado, entregado = false))
            }
        }
        dao.limpiarLapidas(ahora - VIDA_LAPIDA_MS)
    }

    class Pendientes(val registros: List<RegistroSync>, val hayMas: Boolean)

    /** Anota lo nuevo y devuelve hasta [SyncLogica.MAX_LOTE] cambios de la cola. */
    suspend fun prepararLote(c: Context): Pendientes = candado.withLock {
        val app = c.applicationContext
        escanearSinCandado(app)
        val dao = JulioDatabase.get(app).syncDao()
        val lista = dao.pendientes(SyncLogica.MAX_LOTE + 1)
        SyncAjustes.ponerPendientes(dao.cuantosPendientes())
        Pendientes(lista.take(SyncLogica.MAX_LOTE).map { it.aRegistro() }, lista.size > SyncLogica.MAX_LOTE)
    }

    /** El otro teléfono aceptó estos cambios: salen de la cola (solo si no cambiaron mientras tanto). */
    suspend fun marcarEnviados(c: Context, registros: List<RegistroSync>) = candado.withLock {
        val dao = JulioDatabase.get(c.applicationContext).syncDao()
        for (r in registros) dao.marcarEntregado(r.tipo, r.clave, r.actualizadoEn)
        SyncAjustes.ponerPendientes(dao.cuantosPendientes())
    }

    /**
     * Aplica los cambios que llegaron del otro teléfono (gana el más reciente) y procesa sus confirmaciones.
     * Devuelve lo que recibimos, para que el otro lo marque como entregado.
     */
    suspend fun recibir(c: Context, lote: LoteSync): List<Confirmacion> = candado.withLock {
        val app = c.applicationContext
        val dao = JulioDatabase.get(app).syncDao()
        escanearSinCandado(app)
        val recibidos = ArrayList<Confirmacion>()
        for (r in lote.registros) {
            val local = dao.uno(r.tipo, r.clave)?.aRegistro()
            if (SyncLogica.debeAplicar(local, r)) {
                if (aplicar(app, r)) dao.poner(SyncEstadoEntity(r.tipo, r.clave, r.datos, r.actualizadoEn, r.borrado, entregado = true))
                else continue
            }
            recibidos += Confirmacion(r.tipo, r.clave, r.actualizadoEn)
        }
        for (cf in lote.confirmaciones) dao.marcarEntregado(cf.tipo, cf.clave, cf.actualizadoEn)
        SyncAjustes.ponerPendientes(dao.cuantosPendientes())
        recibidos
    }

    /** Escribe el cambio en la tabla real y reprograma sus alarmas o avisos. false = no se pudo (datos raros). */
    private suspend fun aplicar(c: Context, r: RegistroSync): Boolean {
        val db = JulioDatabase.get(c)
        return try {
            when (r.tipo) {
                TipoSync.TAREA -> {
                    val dao = db.tareaDao()
                    val local = dao.porCreadaEn(r.clave)
                    if (r.borrado) {
                        local?.let { RecordatorioProgramador.cancelar(c, RecordatorioProgramador.TIPO_TAREA, it.id); dao.eliminar(it) }
                    } else {
                        val nueva = SerializadorSync.tareaDe(r.datos, r.clave, local?.id ?: 0L) ?: return false
                        val guardada = if (local == null) nueva.copy(id = dao.insertar(nueva)) else nueva.also { dao.actualizar(it) }
                        if (guardada.completada) RecordatorioProgramador.cancelar(c, RecordatorioProgramador.TIPO_TAREA, guardada.id)
                        else RecordatorioProgramador.programarTarea(c, guardada)
                    }
                }
                TipoSync.ACTIVIDAD -> {
                    val dao = db.actividadDao()
                    val local = dao.porCreadaEn(r.clave)
                    if (r.borrado) {
                        local?.let { RecordatorioProgramador.cancelar(c, RecordatorioProgramador.TIPO_ACTIVIDAD, it.id); dao.eliminar(it) }
                    } else {
                        val nueva = SerializadorSync.actividadDe(r.datos, r.clave, local?.id ?: 0L) ?: return false
                        val guardada = if (local == null) nueva.copy(id = dao.insertar(nueva)) else nueva.also { dao.actualizar(it) }
                        RecordatorioProgramador.programarActividad(c, guardada)
                    }
                }
                TipoSync.ALARMA -> {
                    val dao = db.alarmaDao()
                    val local = dao.porCreadaEn(r.clave)
                    if (r.borrado) {
                        local?.let { AlarmaProgramador.cancelar(c, it.id); dao.eliminar(it) }
                    } else {
                        val nueva = SerializadorSync.alarmaDe(r.datos, r.clave, local?.id ?: 0L, local?.sonidoUri) ?: return false
                        val guardada = if (local == null) nueva.copy(id = dao.insertar(nueva)) else nueva.also { dao.actualizar(it) }
                        AlarmaProgramador.programar(c, guardada)
                    }
                }
                // El uso del teléfono solo se guarda en sync_estado (lo hace quien llama); no hay tabla real que escribir.
                TipoSync.USO -> Unit
                else -> return false
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
