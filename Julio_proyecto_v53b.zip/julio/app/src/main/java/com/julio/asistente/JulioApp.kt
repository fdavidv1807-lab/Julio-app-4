package com.julio.asistente

import android.app.Application
import com.julio.asistente.alarmas.Canales
import com.julio.asistente.avisos.AvisosAjustes
import com.julio.asistente.avisos.AvisosProgramador
import com.julio.asistente.bloqueo.BloqueoConfig
import com.julio.asistente.data.local.JulioDatabase
import com.julio.asistente.enfoque.EnfoqueControl
import com.julio.asistente.estudio.EstudioAviso
import com.julio.asistente.estudio.EstudioRepo

class JulioApp : Application() {
    /** Base de datos local única (Room). Se crea al primer uso. */
    val database: JulioDatabase by lazy { JulioDatabase.get(this) }

    override fun onCreate() {
        super.onCreate()
        Canales.crear(this)
        BloqueoConfig.cargar(this)
        com.julio.asistente.ui.theme.Apariencia.cargar(this)
        com.julio.asistente.ui.jarvis.ModoApp.cargar(this)
        EnfoqueControl.cargar(this)
        com.julio.asistente.escritorio.EscritorioControl.cargar(this)
        EstudioRepo.cargar(this)
        EstudioAviso.programar(this)
        AvisosAjustes.cargar(this)
        com.julio.asistente.cuerpo.CuerpoAjustes.cargar(this)
        com.julio.asistente.enlace.EnlaceAjustes.cargar(this)
        com.julio.asistente.ia.IaAjustes.cargar(this)
        com.julio.asistente.sync.SyncAjustes.cargar(this)
        // v52: el teléfono de diario sincroniza horario, tareas y alarmas con el Cuerpo (solo si ya está emparejado).
        if (com.julio.asistente.enlace.EnlaceAjustes.rol.value == com.julio.asistente.enlace.RolEnlace.DIARIO) {
            com.julio.asistente.sync.SyncDiario.iniciar(this)
        }
        AvisosProgramador.programar(this)
    }
}
