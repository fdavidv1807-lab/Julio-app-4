package com.julio.asistente.voz

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Entrenador de voz (v53): aprende cómo oye el reconocedor TU «Julio». Lógica pura. */
class EntrenadorLogicaTest {
    @Test fun distanciaDeEdicion() {
        assertEquals(0, EntrenadorLogica.distancia("julio", "julio"))
        assertEquals(1, EntrenadorLogica.distancia("hulio", "julio"))
        assertEquals(2, EntrenadorLogica.distancia("julian", "julio"))
    }

    @Test fun sonidosParecidosAJulio() {
        for (w in listOf("julio", "hulio", "yulio", "Julián", "julia", "Hulio,")) assertTrue(w, EntrenadorLogica.parecidaAJulio(w))
        for (w in listOf("hola", "el", "mulato", "uno", "ocho", "luis", "")) assertFalse(w, EntrenadorLogica.parecidaAJulio(w))
    }

    @Test fun aprendeLasFormasQueOyeConTuVoz() {
        val oidos = listOf("hulio", "julio", "hulio", "yulio", "hulio", "")
        val a = EntrenadorLogica.aprender(oidos)
        assertEquals(listOf("hulio", "yulio"), a) // la más repetida primero; «julio» no se repite porque ya despierta
    }

    @Test fun siElReconocedorTeOyeSiempreLoMismoLoAprende() {
        val a = EntrenadorLogica.aprender(listOf("huelo", "huelo", "huelo", "julio", "", "huelo"))
        assertTrue(a.contains("huelo"))
    }

    @Test fun nuncaAprendePalabrasCorrientes() {
        val a = EntrenadorLogica.aprender(listOf("el", "el", "el", "el", "que", "que"))
        assertTrue(a.isEmpty())
    }

    @Test fun reconoceJulioYLasFormasAprendidas() {
        assertTrue(EntrenadorLogica.reconoce("hola Julio", emptyList()))
        assertTrue(EntrenadorLogica.reconoce("hulio, ¿qué hora es?", listOf("hulio")))
        assertFalse(EntrenadorLogica.reconoce("hulio", emptyList()))
        assertFalse(EntrenadorLogica.reconoce("julios", listOf("hulio")))
    }

    @Test fun elVigiaAceptaLoAprendidoSoloSiHayAprendidas() {
        assertFalse(ReconocimientoUtil.esDespertar("hulio"))
        assertTrue(ReconocimientoUtil.esDespertar("hulio", listOf("hulio")))
        assertFalse(ReconocimientoUtil.esDespertar("julia", emptyList()))
    }

    @Test fun gramaticaDelVigia() {
        assertEquals("[\"julio\", \"hulio\", \"[unk]\"]", EntrenadorLogica.gramatica(listOf("Hulio", "julio")).replace("\",\"", "\", \""))
    }

    @Test fun umbralPersonalSeCalibraConTusMuestras() {
        assertEquals(HablanteMath.UMBRAL_NORMAL, EntrenadorLogica.umbralPersonal(listOf(0.10f, 0.12f)), 1e-6f)
        assertEquals(0.5f, EntrenadorLogica.umbralPersonal(listOf(0.20f, 0.3125f)), 1e-3f)
        assertEquals(HablanteMath.UMBRAL_PERMISIVO, EntrenadorLogica.umbralPersonal(listOf(0.55f)), 1e-6f)
        assertEquals(HablanteMath.UMBRAL_NORMAL, EntrenadorLogica.umbralPersonal(emptyList()), 1e-6f)
    }

    @Test fun consignasYResumen() {
        assertEquals("con tu voz normal", EntrenadorLogica.consigna(1))
        assertEquals("más bajo, como de noche", EntrenadorLogica.consigna(3))
        assertEquals("más rápido o como cansado", EntrenadorLogica.consigna(6))
        assertTrue(EntrenadorLogica.resumen(6, 6, emptyList()).contains("se entiende bien"))
        assertTrue(EntrenadorLogica.resumen(2, 6, listOf("hulio")).contains("«hulio»"))
        assertTrue(EntrenadorLogica.resumen(0, 6, emptyList()).contains("No encontré"))
    }
}
