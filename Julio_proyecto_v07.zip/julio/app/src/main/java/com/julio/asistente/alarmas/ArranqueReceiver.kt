package com.julio.asistente.alarmas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Reprograma las alarmas tras reiniciar, actualizar la app o cambiar la hora/zona horaria. */
class ArranqueReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pendiente = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AlarmaProgramador.reprogramarTodas(app)
            } finally {
                pendiente.finish()
            }
        }
    }
}
